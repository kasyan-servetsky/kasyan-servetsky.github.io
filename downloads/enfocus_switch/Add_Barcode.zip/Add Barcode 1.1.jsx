﻿// Copyright 2011, Fernando Martínez-Sayanes, Digipress
// September 29, 2011
// Written by Kasyan Servetsky
// http://www.kasyan.ho.com.ua
// e-mail: askoldich@yahoo.com
//========================== GLOBALS ============================
var gDoc, arg1, arg2, arg3;
var gRunInInDesign = RunInInDesign();
var gLog = true; // log into console
//===============================================================
if (!gRunInInDesign) {
	if ($error == null) { // Power Switch
		if ($arg2 == "") $error = "The parameter \"$arg2\" is empty";
		if ($arg3 == "") $error = "The parameter \"$arg3\" is empty";
		arg1 = $arg1; // code number
		arg2 = $arg2; // portada
		arg3 = $arg3; // paginas
		gDoc = $doc;

		try {
			Main();
		}
		catch(err) {
			$doc.close(SaveOptions.NO);
			$error = theError.description;
		}
	}
} else { // InDesign
	arg1 = "0023247"; // code number
	arg2 = "25, 175"; // portada
	arg3 = "203, 203"; // paginas
	gDoc = app.activeDocument;
	Main();	
}
//======================== FUNCTIONS ============================
function Main() {
	var barcodeContents, layer, page, story, par0, par1, xOffset, yOffset, tfWidth, tfHeight;
	gDoc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.MILLIMETERS;
	gDoc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.MILLIMETERS;

	barcodeContents = arg1;

	layer = gDoc.layers.itemByName("Barcode");
	if (layer == null) layer = gDoc.layers.add({name : "Barcode"});
	
	if (gDoc.name.match(/_portada/) != null) { // portada
		page = gDoc.pages.firstItem();
		xOffset = parseInt(arg2.split(",")[0]);
		yOffset = parseInt(arg2.split(",")[1]);
		tfWidth = 35;
		tfHeight = 12;
	}
	else if (gDoc.name.match(/_paginas/) != null) { // paginas
		page = gDoc.pages.lastItem();
		xOffset = parseInt(arg3.split(",")[0]);
		yOffset = parseInt(arg3.split(",")[1]);
		tfWidth = 4;
		tfHeight = 15;
	}
	else {
		if (gRunInInDesign) {
			if (gLog) $.writeln("The file name contains neither \"_portada\" nor \"_paginas\"");
			exit();
		}
		else {
			$error = "The file name contains neither \"_portada\" nor \"_paginas\"";
		}
	}

	var tf = page.textFrames.add(layer);
	
	if (gDoc.name.match(/_portada/) != null) { // portada
		tf.geometricBounds = [ yOffset, xOffset, yOffset + tfHeight, xOffset + tfWidth ];		
		tf.fillColor = gDoc.swatches.itemByName("Paper");
		tf.contents = "*" + barcodeContents + "*\r" + barcodeContents;
		story = tf.parentStory;
		par0 = story.paragraphs[0];
		par0.appliedFont = app.fonts.itemByName("Free 3 of 9\tRegular");
		par0.pointSize = 28;
		par0.leading = 28;
		par0.baselineShift = "-4 pt";
		par0.justification = Justification.CENTER_ALIGN;

		par1 = story.paragraphs[1];
		par1.appliedFont = app.fonts.itemByName("Consolas\tRegular"); 
		par1.pointSize = 10;
		par1.leading = 5;
		par1.baselineShift = "-7 pt";
		par1.justification = Justification.CENTER_ALIGN;
		par1.tracking = 800;
	}
	else if (gDoc.name.match(/_paginas/) != null) { // paginas
		tf.absoluteRotationAngle = 90;
		tf.geometricBounds = [ yOffset - tfHeight, xOffset, yOffset, xOffset + tfWidth ];
		tf.fillColor = gDoc.swatches.itemByName("None");
		tf.contents = barcodeContents;
		story = tf.parentStory;

		story.appliedFont = app.fonts.itemByName("Consolas\tRegular");
		story.pointSize = 10;
		story.leading = 10;
		story.justification = Justification.LEFT_ALIGN;
	}
}
//--------------------------------------------------------------------------------------------------------------
function RunInInDesign() {
	var scriptPath, result;
	try{
		scriptPath = app.activeScript.fsName;
	}
	catch(err){
		scriptPath = err.fileName;
	}
	result = (scriptPath.match(/(Adobe|Scripts)/) != null) ? true : false;	
	return result;
}
//--------------------------------------------------------------------------------------------------------------