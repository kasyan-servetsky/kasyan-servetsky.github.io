﻿/* DESCRIPTION:
Sets the “Based on" property of a Paragraph Style to “[No paragraph style]” 
and then back to what it was in order to restore potentially broken inheritance 
of some properties such as nested GREP styles. */

#target indesign

var doc = app.activeDocument;
var parStyles = doc.allParagraphStyles;

for (var i = parStyles.length - 1; i >= 2; i--) {
	thisBasedOn = parStyles[i].basedOn
	for (var j = parStyles.length - 1; j >= 0; j--) {
		thisStyleName = parStyles[j].name;
		if (thisStyleName.indexOf(thisBasedOn.name) != -1) {
			parStyles[i].basedOn = parStyles[0];
			parStyles[i].basedOn = parStyles[j];
		}
		break;
	}
}
