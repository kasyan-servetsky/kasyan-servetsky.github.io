﻿var scriptName = "Collect used fonts - all open documents";

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	var fonts, font, fontLocation, fontFile, copiedFontFile, copied, report,
	count = 0,
	docs = app.documents.everyItem().getElements(),
	fontsFolderPath = "~/Desktop/Used Fonts/",
	fontsFolder = new Folder(fontsFolderPath);

	if (!fontsFolder.exists) fontsFolder.create();

	for (var d = 0; d < docs.length; d++) {
		fonts = app.documents[d].fonts.everyItem().getElements();
		
		for (var i = 0; i < fonts.length; i++) {
			font = fonts[i];
				
			try {
				fontLocation = font.location;
			}
			catch(err) {
				$.writeln(err.message + ", line: " + err.line);
				$.writeln(font.postscriptName + " is invalid");
				continue;
	//~ 			debugger;
			}		

			fontFile = new File(fonts[i].location);
			copiedFontFile = new File(fontsFolderPath + "/" + fontFile.name);

			if (!copiedFontFile.exists) {
				copied = fontFile.copy(copiedFontFile);
				if (copied) count++;
			}
		}
	}

	if (count == 0) {
		report = "No fonts were copied.";
	}
	else if (count == 1) {
		report = "One font was copied.";
	}
	else {
		report = count + " fonts were copied.";
	}

	alert(report, scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("No open documents.", true);
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------