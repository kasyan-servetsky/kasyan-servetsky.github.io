﻿var scriptName = "Collect used fonts - current document",
doc;

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	var font, fontLocation, fontFile, copiedFontFile, copied, report,
	count = 0,
	fonts = app.documents[0].fonts.everyItem().getElements(),
	fontsFolderPath = "~/Desktop/Used Fonts/",
	fontsFolder = new Folder(fontsFolderPath);

	if (!fontsFolder.exists) fontsFolder.create();

	for (var i = 0; i < fonts.length; i++) {
		font = fonts[i];
			
		try {
			fontLocation = font.location;
		}
		catch(err) {
			$.writeln(err.message + ", line: " + err.line);
			$.writeln(font.postscriptName + " is invalid");
			continue;
//~ 			debugger;
		}

		fontFile = new File(fontLocation);
		copiedFontFile = new File(fontsFolderPath + "/" + fontFile.name);
		
		if (!copiedFontFile.exists) {
			copied = fontFile.copy(copiedFontFile);
			if (copied) count++;
		}
	}

	if (count == 0) {
		report = "No fonts were copied.";
	}
	else if (count == 1) {
		report = "One font was copied.";
	}
	else {
		report = count + " fonts were copied.";
	}

	alert(report, scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------