﻿/* Copyright 2018, Kasyan Servetsky
Febuary 13, 2018
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Make font catalog 1.1",
set, selectedFontIndex,
appVersion = Number(String(app.version).split(".")[0]),
allFonts = app.fonts.everyItem().getElements(),
fontNamesList = ["All fonts"],
fontsFolder = null;

for (var i = 0; i < allFonts.length; i++) {
	fontNamesList.push(allFonts[i].name.replace(/\t/, " - "));
}

CreateDialog();
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var startTime = new Date(),
		doc, fonts, font, fontName, page, fontSizeText, bookmark, textFrame, textContents, gb,
		progressWin, progressBar,
		pointSize = [14, 6, 8, 10, 14, 18, 24, 42], // Font sizes to be displayed. The first value in the array is used for formatting the font info area above the horizontal line.
		insetSpacing = 30,
		pageCounter = 0,
		sampleText = set.sampleText.replace(/\\r/g, "\n").replace(/\\n/g, "\n");	

		if (selectedFontIndex == 0) {
			fonts = allFonts;
		}
		else {
			fonts = [allFonts[selectedFontIndex - 1]];
		}
	
		var fontsLength = fonts.length;
	
		doc = app.documents.add();
		doc.viewPreferences.horizontalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS;
		if (appVersion >= 13) doc.name = "Font catalog.indd"; // in earlier versions, 'name' is read only
		doc.documentPreferences.facingPages = false;
		doc.documentPreferences.pageOrientation = PageOrientation.LANDSCAPE;
		doc.viewPreferences.rulerOrigin = RulerOrigin.PAGE_ORIGIN;
		
		// Work around the 'set bookmark name bug': temporarily hide the panel if it's open
		if (appVersion >= 6) {
			var bookmarksPanelWasHidden = false,
			bookmarksPanel = app.panels.item("$ID/Bookmarks");

			if (bookmarksPanel.isValid && bookmarksPanel.visible) {
				bookmarksPanel.visible = false;
				bookmarksPanelWasHidden = true;
			}
		}

		if (fontsLength > 1) {
			progressWin = new Window("window", scriptName);
			progressBar = progressWin.add("progressbar" , undefined, 0, fontsLength);
			progressBar.preferredSize.width = 500;
			progressTxt = progressWin.add("statictext", undefined,  "");
			progressTxt.alignment = "fill";
			progressWin.show();
		}
  
		for (var f = 0; f < fontsLength; f++) {
			font = fonts[f];
			fontName = font.name.replace(/\t/, " - ");
			//WriteToFile(f + " - " + fontName);

			if (fontsLength > 1) {
				progressBar.value = f + 1;
				progressTxt.text = fontName + " (" + (f + 1) + " out of " + fontsLength + ")";
			}

			if (fontsLength > 1 && CheckExcludedFonts(fontName)) {
				continue;
			}
		
			if (fontsLength > 1 && set.forbiddenEditableEmbedding && !font.allowEditableEmbedding) {
				//WriteToFile("=== Skipping: forbiddenEditableEmbedding");
				continue;
			}
		
			if (fontsLength > 1 && set.forbiddenOutlines && !font.allowOutlines) {
				//WriteToFile("=== Skipping: forbiddenOutlines");
				continue;
			}
		
			if (fontsLength > 1 && set.forbiddenPDFEmbedding && !font.allowPDFEmbedding) {
				//WriteToFile("=== Skipping: forbiddenPDFEmbedding");
				continue;
			}
			
			if (fontsLength > 1 && set.forbiddenPrinting && !font.allowPrinting) {
				//WriteToFile("=== Skipping: forbiddenPrinting");
				continue;
			}

			if (fontsLength > 1 && set.restrictedPrinting && font.restrictedPrinting) {
				//WriteToFile("=== Skipping: restrictedPrinting");
				continue;
			}

			if (fontsLength > 1 && set.includeOnlyInFontsFolder && fontsFolder != null && !LocatedInSelectedFontsFolder(font)) {
				//WriteToFile("Skipping: Not in folder");
				continue;
			}
		
			if (fontsLength > 1 && set.includeOnlyIfNameBegins && set.searchNameString != "") {
				if (fontName.search(eval("/^" + set.searchNameString + "/i")) == -1) {
					//WriteToFile("Skipping: name doesn't begin with " + set.searchNameString);
					continue;
				}
			}

			if (doc.bookmarks.length == 0) { // 'bookmarks.length' equals a number of font samples created
				page = doc.pages[0];
			}
			else {
				page = doc.pages.add();
			}
		
			AddBookmark(fontName, page, f, doc);
			pageCounter++;
		
			with (page.marginPreferences) {
				top = bottom = left = right = 0;
			}
		
			textFrame = page.textFrames.add({geometricBounds: doc.pages[0].bounds});
			gb = textFrame.geometricBounds;
			textFrame.textFramePreferences.insetSpacing = insetSpacing;

			fontSizeText = " (" + pointSize[1] + ", " + pointSize[2] + ", " + pointSize[3] + ", " + pointSize[4] + ", " + pointSize[5] + ", " + pointSize[6] + ", " + pointSize[7] + ")";
			textContents = fontName + fontSizeText;
			
			try { // Some properties are unavailable in some fonts so let's be on a safe side
				textContents += " - " + font.version; // Version: 
				textContents += " - Type: " + GetType(font);
				if (!font.allowEditableEmbedding) textContents += " - Can't be embedded.";
				if (!font.allowOutlines) textContents += " - Can't be converted to outlines.";			
				if (!font.allowPDFEmbedding) textContents += " - Can't be embedded in a PDF document.";
				if (!font.allowPrinting) textContents += " - Can't be printed.";
				if (font.restrictedPrinting) textContents += " - Allows only restricted printing.";
				textContents += "\nLocation: " + font.location + "\n\t\r";
			}
			catch(err) {
				//$.writeln(err.message + ", line: " + err.line);
			}
			
			textContents += sampleText + "\r" + sampleText + "\r" + sampleText + "\r" + sampleText + "\r" + sampleText + "\r" + sampleText + "\r" + sampleText;
			
			textFrame.contents = textContents;

			for (k = 0; k < pointSize.length; k++) {
				textFrame.parentStory.paragraphs.item(k).appliedFont = font;
				textFrame.parentStory.paragraphs.item(k).pointSize = pointSize[k];
			}
		
			var firstPar = textFrame.paragraphs[0];
			firstPar.spaceAfter = 20;
			var tabStop = firstPar.tabStops.add();
			with (tabStop) {
				alignment = TabStopAlignment.RIGHT_ALIGN;
				leader = "_";
				position = (gb[3] - gb[1]) - (insetSpacing * 2);
			}
				
			if (appVersion >= 7 && textFrame.overflows) {
					while (textFrame.overflows) {
					gb = textFrame.geometricBounds;
					gb[2] += 1;
					textFrame.geometricBounds = gb;
				}
			
				page.resize(CoordinateSpaces.INNER_COORDINATES, AnchorPoint.TOP_LEFT_ANCHOR, ResizeMethods.REPLACING_CURRENT_DIMENSIONS_WITH, [gb[3] - gb[1], gb[2] - gb[0]]);
			}
		} // END -- for -- fonts

		if (fontsLength > 1) progressWin.close();
		
		if (appVersion >= 6) {
			if (bookmarksPanelWasHidden) {
				bookmarksPanel.visible = true;
			}
		}
		
		var endTime = new Date();
		var duration = GetDuration(startTime, endTime);
		var report = pageCounter + ((pageCounter == 1) ? " font sample was" : " font samples were") + " created.\n(time elapsed: " + duration + ")";	
		alert("Finished. " + report, scriptName);
	}
	catch(err) {
		alert("Oops! Something went wrong: " + err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	GetDialogSettings();
	var w = new Window("dialog", scriptName);

	w.p = w.add("panel", undefined, "");
	w.p.orientation = "column";
	w.p.alignment = "fill";
	w.p.alignChildren = "fill";
	
	w.p.ddl = w.p.add("dropdownlist", undefined, fontNamesList);
	w.p.ddl.selection = 0;
	w.p.ddl.onChange = function() {
		if (this.selection.index == 0) {
			w.p1.enabled = w.p2.enabled = w.p3.enabled = true;
		}
		else {
			 w.p1.enabled = w.p2.enabled = w.p3.enabled = false;
		}
	}

	// Sample text
	w.p.st = w.p.add("statictext", undefined, "Sample text:");
	w.p.et = w.p.add("edittext", undefined, set.sampleText, {multiline: true});
	
	 // Exclude font
	w.p1 = w.add("panel", undefined, "Exclude the following fonts:");
	w.p1.alignment = "fill";
	w.p1.alignChildren = "fill";
	w.p1.et1 = w.p1.add("edittext", undefined, set.excludeFonts, {multiline: true});
	w.p1.et1.helpTip = "Type in here the font names to be excluded separated by commas.";
	
	w.p1.st = w.p1.add("statictext", undefined, "If the font");	
	w.p1.cb = w.p1.add("checkbox", undefined, "can't be embedded");
	w.p1.cb.value = set.forbiddenEditableEmbedding;
	w.p1.cb1 = w.p1.add("checkbox", undefined, "can't be converted to outlines");
	w.p1.cb1.value = set.forbiddenOutlines;
	w.p1.cb2 = w.p1.add("checkbox", undefined, "can't be embedded in a PDF document");
	w.p1.cb2.value = set.forbiddenPDFEmbedding;
	w.p1.cb3 = w.p1.add("checkbox", undefined, "can't be printed");
	w.p1.cb3.value = set.forbiddenPrinting;
	w.p1.cb4 = w.p1.add("checkbox", undefined, "allows only restricted printing");
	w.p1.cb4.value = set.restrictedPrinting;
	
	// Include in folder 
	w.p2 = w.add("panel", undefined, "");
	w.p2.alignment = "fill";

	w.p2.cb = w.p2.add("checkbox", undefined, "Include only the fonts installed in this folder and it's subfolders:");
	w.p2.cb.value = set.includeOnlyInFontsFolder;
	w.p2.cb.onClick = function() {
		if (this.value) {
			w.p2.st.enabled = w.p2.b.enabled = true;
		}
		else {
			w.p2.st.enabled = w.p2.b.enabled = false;
		}
	}
	
	w.p2.st = w.p2.add("statictext");
	w.p2.st.alignment = "left";
	
	if (fontsFolder == null || !fontsFolder.exists) { 
		w.p2.st.text = "No folder has been selected";
	}
	else {
		w.p2.st.text = TrimPath(fontsFolder.absoluteURI);
		w.p2.st.helpTip = decodeURI(fontsFolder.fsName);
	}

	w.p2.b = w.p2.add("button", undefined, "Select ...");
	w.p2.b.onClick = function() {
		fontsFolder = SelectFolder(this, "Pick a folder with fonts installed.");
	}

	if (set.includeOnlyInFontsFolder) {
		w.p2.st.enabled = w.p2.b.enabled = true;
	}
	else {
		w.p2.st.enabled = w.p2.b.enabled = false;
	}

	w.p3 = w.add("panel", undefined, "");
	w.p3.orientation = "column";	
	w.p3.alignment = "fill";
	w.p3.alignChildren = "fill";
	
	// Filter by name
	w.p3.cb = w.p3.add("checkbox", undefined, "Include only the fonts whose names begin with:");
	w.p3.cb.alignment = "left";
	w.p3.cb.value = set.includeOnlyIfNameBegins;
	w.p3.cb.onClick = function() {
		if (this.value) {
			w.p3.et.enabled = true;
		}
		else {
			w.p3.et.enabled = false;
		}
	}
	
	w.p3.et = w.p3.add("edittext", undefined, set.searchNameString);
	
	if (set.includeOnlyIfNameBegins) {
		w.p3.et.enabled = true;
	}
	else {
		w.p3.et.enabled = false;
	}

	w.g = w.add("group");
	w.g.orientation = "row";
	w.g.alignment = "center";
		
	w.g.ok = w.g.add("button", undefined, "OK", {name:"ok"});
	w.g.ok.onClick = function() {
		if (w.p2.children[0].value && w.p2.children[1].text == "No folder has been selected") {
			alert("No 'Fonts' folder has been selected.", scriptName, true);
			return;
		}

		w.close(1);
	}

	w.g.cancel = w.g.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		set.sampleText = w.p.et.text.replace(/\r/g, "\\n").replace(/\n/g, "\\n");
		selectedFontIndex = w.p.ddl.selection.index;
		
		set.excludeFonts = w.p1.et1.text.replace(/\\r/g, "").replace(/\\n/g, "");		
		set.forbiddenEditableEmbedding = w.p1.cb.value;
		set.forbiddenOutlines = w.p1.cb1.value;
		set.forbiddenPDFEmbedding = w.p1.cb2.value;
		set.forbiddenPrinting = w.p1.cb3.value;
		set.restrictedPrinting = w.p1.cb4.value;
		
		set.includeOnlyInFontsFolder = w.p2.cb.value;
		
		if (fontsFolder instanceof Folder) {
			set.fontsFolderPath = fontsFolder.fsName;
		}
		else {
			set.fontsFolderPath = "";
		}	
		
		set.includeOnlyIfNameBegins = w.p3.cb.value;
		set.searchNameString = w.p3.et.text;
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}	
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function SelectFolder(button, prompt) {
	var folder = Folder.selectDialog(prompt);
	
	if (folder != null) {
		var panel = button.parent;
		var window = panel.parent;
		var children = panel.children;
		var checkBox = children[0];
		var staticText = children[1];
		var button = button;
		panel.remove(staticText);
		panel.remove(button);
		staticText = panel.add("statictext", undefined, TrimPath(folder.absoluteURI));
		staticText.helpTip = folder.absoluteURI;
		button = panel.add("button", undefined, "Select ...");
		button.onClick = function() {
			SelectFolder(this);
		}
		window.layout.layout(true);
		return folder;		
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {   sampleText: "The quick brown fox jumps over the lazy dog.\\n1234567890",
					excludeFonts: "Webdings, Wingdings, Symbol, ZapfDingbats, TypographicSymbols, WP MultinationalA, Marlett, HoloLens, MS Outlook, MS Reference Specialty, MT Extra, FontAwesome, Segoe MDL2 Assets, Bookshelf Symbol 7, Apple Symbols",
					forbiddenEditableEmbedding: false,
					forbiddenOutlines: false,
					forbiddenPDFEmbedding: false,
					forbiddenPrinting: false,
					restrictedPrinting: false,
					includeOnlyInFontsFolder: false,
					fontsFolderPath: "",
					includeOnlyIfNameBegins: false,
					searchNameString: ""
				};
	}

	fontsFolder = new Folder(set.fontsFolderPath);
	if (!fontsFolder.exists) {
		fontsFolder = null;
	}

	var tmp = set;
	
	return set;
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetType(font) {
	var str,
	fontType = font.fontType;
	
	switch (fontType) {
		case FontTypes.ATC:
			str = "ATC";
			break;
		case FontTypes.BITMAP:
			str = "Bitmap";
			break;
		case FontTypes.CID:
			str = "CID";
			break;
		case FontTypes.OCF:
			str = "OCF";
			break;
		case FontTypes.OPENTYPE_CFF:
			str = "OpenType CFF";
			break;			
		case FontTypes.OPENTYPE_CID:
			str = "OpenType CID";
			break;
		case FontTypes.OPENTYPE_TT:
			str = "OpenType TT";
			break;
		case FontTypes.TRUETYPE:
			str = "TrueType";
			break;
		case FontTypes.TYPE_1:
			str = "Type 1";
			break;
		default:
			str = "Unknown";
	}
	
	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckExcludedFonts(fontName) {
	var str, regEx,
	excludeFonts = set.excludeFonts.split(","),
	exclude = false;
	
	for (var i = 0; i < excludeFonts.length; i++) {
		str = Trim(excludeFonts[i]);
		regEx = eval("/^" + str + "/i");

		if (fontName.match(regEx) != null) {
			exclude = true;
			break;
		}
	}

	return exclude;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
function LocatedInSelectedFontsFolder(currentFont) {
	var result = false,
	currentFontFile = new File(currentFont.location),
	currentFontFolder = currentFontFile.parent;
	
	try {	
		if (currentFontFolder.fsName.toLowerCase() == fontsFolder.fsName.toLowerCase()) {
			result = true;
		}
		else {
			while (currentFontFolder != null) {
				currentFontFolder = currentFontFolder.parent;
				if (currentFontFolder == null) break;
				if (currentFontFolder.fsName.toLowerCase() == fontsFolder.fsName.toLowerCase()) {
					result = true;
					break;
				}
			}
		}
	}
	catch(err) {
		//$.writeln(err.message + ", line: " + err.line);
	}

	return result;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
function AddBookmark(currentFontName, page, idx, doc) {
	var parentBookmark, bookmark,
	currentArr = currentFontName.split(" - "),
	currentFontFamily = currentArr[0],
	currentFontStyleName = currentArr[1],
	prev = allFonts[idx - 1],
	next = allFonts[idx + 1];

	if ((typeof prev != "undefined" && prev.fontFamily == currentFontFamily) || (typeof next != "undefined" && next.fontFamily == currentFontFamily)) {
		parentBookmark = doc.bookmarks.itemByName(currentFontFamily);
		
		if (parentBookmark == null) {
			parentBookmark = doc.bookmarks.add(page, {name: currentFontFamily});
		}
	
		bookmark = parentBookmark.bookmarks.add(page, {name: currentFontStyleName});
	}
	else {
		bookmark = doc.bookmarks.add(page, {name: currentFontName});
	}
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
function TrimPath(path) {
	var theFile = new File(path);
	if (File.fs == "Macintosh") {
		var trimPath = "..." + theFile.fsName.split("/").splice(-3).join("/");
	}
	else if (File.fs == "Windows" ) {
		var trimPath = ((theFile.fsName.split("\\").length > 3) ? "...\\" : "") + theFile.fsName.split("\\").splice(-3).join("\\");
	}
	return trimPath;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
function Trim(str) { // removes whitespace from both sides of a string
	return str.replace(/^\s+|\s+$/gm, "");
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
/* function WriteToFile(text) { // For debugging only
	file = new File("~/Desktop/Log.txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text + "\r"); 
	file.close();
} */
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}