﻿var doc = app.activeDocument;
ResizeOverset();

function ResizeOverset() { 
	var lastFrame,
	stories = doc.stories; 
	for (var j = stories.length - 1; j >= 0; j--) { 
		if (stories[j].overflows == true) { 
			lastFrame = stories[j].texts[0].parentTextFrames[stories[j].texts[0].parentTextFrames.length - 1]; 
			lastFrame.fit(FitOptions.FRAME_TO_CONTENT); 
		} 
	} 
}