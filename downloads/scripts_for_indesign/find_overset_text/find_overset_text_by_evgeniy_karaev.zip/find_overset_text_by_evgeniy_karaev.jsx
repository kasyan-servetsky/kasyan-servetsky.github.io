/* Cкрипт Евгения Карева позволяет искать вытесненный текст не только в простых одиночных фреймах, но и во фреймах, которые входят в состав группы. Даже если группа помещена в другую группу, скрипт безошибочно укажет вам проблемы
overset-a, показав в окне номер страницы и первую строку текста переполненного фрейма. */
with(app){
myDoc = activeDocument
myText = ''
copyright = "© jvk • 2007 | karev_e@mail.ru"
myCount = 0
myPageCount = myDoc.pages.length
for (pg = 0;pg<myPageCount;pg++){
myPage = myDoc.pages.item(pg)
//фреймы не в группе
myFrCount = myPage.textFrames.length
if (myFrCount !=0){
for (fr = 0; fr<myFrCount;fr++){
myFr = myPage.textFrames.item(fr)
myString = myFr.paragraphs.item(0).lines.item(0)
if (myFr.overflows == true){
myCount=myCount+1
myText = myText + "\nPage "+myFr.parent.name+ "; "+myString.contents+"\n=============="}}}
//=========================================
//фреймы в группе
myGrCount = myPage.groups.length
if (myGrCount != 0){
for (gr = 0;gr<myGrCount;gr++){
myGr = myPage.groups.item(gr)
myFrGrCount = myGr.textFrames.length
if (myFrGrCount != 0){
for (grf = 0;grf<myFrGrCount;grf++){
myFrGr = myGr.textFrames.item(grf)
myString = myFrGr.paragraphs.item(0).lines.item(0)
if (myFrGr.overflows == true){
myCount=myCount+1
myText = myText + "\nPage "+myGr.parent.name+" (group); "+myString.contents+"\n=============="}}}
//=========================================
//фреймы в группе которая в группе
myGrGrCount = myGr.groups.length
if (myGrGrCount != 0){
for (grgrf = 0;grgrf<myGrGrCount;grgrf++){
myGrGr = myGr.groups.item(grgrf)
myFrGrGrCount = myGrGr.textFrames.length
if (myFrGrGrCount != 0){
for (grgrf = 0;grgrf< myFrGrGrCount;grgrf++){
myFrGrGr = myGrGr.textFrames.item(grgrf)
myString = myFrGrGr.paragraphs.item(0).lines.item(0)
if (myFrGrGr.overflows == true){
myCount=myCount+1
myText = myText + "\nPage "+myGr.parent.name+" (group); "+myString.contents+"\n=============="
}}}}}}}}
if (myCount!=0){alert ("Overset Text!"+myText+"\n\n"+copyright)}else{alert("No overset text!" + "\n" + copyright)}}