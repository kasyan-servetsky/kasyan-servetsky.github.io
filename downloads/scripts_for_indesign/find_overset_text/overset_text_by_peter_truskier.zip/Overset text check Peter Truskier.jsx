if (app.documents.length != 0){ 
	var myFrames = app.activeDocument.textFrames; 
	var thePageNames = new Array(); 

	for (var j = 0 ; j <= (myFrames.length - 1); j++) { 
		if(myFrames[j].overflows == true){ 
		thePageName = myFrames[j].parent.name; 
		thePageNames[thePageName] = 1 
		} 
	} 
	if (thePageNames.length == 0) { 
		alert("No oversets found."); 
	} 
	else{ 
		var s = ""; 
		for (i in thePageNames) { s = s + (i) + ", " }; 
		s = s.substring(0,s.length - 2); 
	alert("Check for oversets on page(s): " + "\n" + s); 
	} 
} 
else{ 
	alert("No documents are open."); 
} 

// http://adobeforums.com/cgi-bin/webx?128@@.3bc2bbb5