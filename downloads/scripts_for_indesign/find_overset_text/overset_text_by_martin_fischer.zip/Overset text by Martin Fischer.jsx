﻿// // DESCRIPTION: Finds overset text in active document
// A JavaScript for InDesign CS2
// by Martin Fischer http://www.hilfdirselbst.ch/foren/alle_Zellen%E2%88%8Fberl0%20ufe_finden_P187246.html#187246
endMessage = "No overset text found in document."

// Deselect whatever might be selected

if (app.documents.length > 0) {
	app.select(null);
	var myDoc = app.documents[0];
	var myStories = myDoc.stories;
	scount = myStories.length;
	for (myCounter=0; scount>myCounter; myCounter++) {
		if (myStories[myCounter].textFrames[-1].overflows) {
			myFrame = myStories[myCounter].textFrames[-1];
			myPage = myFrame.parent;            
			// what if parent is not a page (e.g., inline frame)
			endMessage = "No other overset text found in document."
			try {
				while (myPage.constructor.name != "Page") {
					if (myPage.parentTextFrame == undefined) {
						myPage = myPage.parent;
					} else {
						myPage = myPage.parentTextFrame;
					}
				}
				app.activeWindow.activeSpread = myPage.parent;
				app.select(myStories[myCounter].textFrames[-1]);
				theMessage = "Overset text frame found. Ignore and look for others?";              
			} catch (e) {
				theMessage = "Deeply overset frame found; can't be selected. Ignore and look for others?";
			}
			if (confirm(theMessage)) {
				continue;
			} else {
				exit();
			}
		}
	}
	for (myCounter=0; scount>myCounter; myCounter++) {
		myTables = myStories[myCounter].tables;
		tcount = myTables.length
		if (tcount != 0) {
			for (j=0; tcount>j; j++) {
				myCells = myTables[j].cells;
				ccount = myCells.length;
				for (k=0; ccount>k; k++) {
					if (myCells[k].overflows) {                        
						// Found one; find page it's on                          
						endMessage = "No other overset text found in document."                          
						try {                              
							myCellNos = [k,k-1,k+1];                              
							for (x = 0; myCellNos.length > x; x++) {                                  
								try {                                      
									myPage = myCells[myCellNos[x]].texts[0].parentTextFrames[0].parent;
									break;
								} catch (e) {
									if (x = myCellNos.length) {throw "Blast!"}
								}
							}                            
							// what if parent is not a page (e.g., inline frame)                              
							while (myPage.constructor.name != "Page") {                                  
								if (myPage.parentTextFrames[0] == undefined) {                                      
									myPage = myPage.parent;                                  
								} else {                                      
									myPage = myPage.parentTextFrames[0].parent;                                  
								}
							}                              
							app.activeWindow.activeSpread = myPage.parent;                              
							app.select(myCells[k]);                              
							theMessage = "Overset cell found. Ignore and look for others?"                          
						} catch (e) {                              
							theMessage = "Completely overset cell found; can’t find page. Ignore and look for others?"
						}
						if (confirm(theMessage)) {
							continue;
						} else {
							exit();
						}
					}
				}
			}
		}
	}
	alert(endMessage);
} else {
	alert("This script operates on the active document; please open one and try again.")
}