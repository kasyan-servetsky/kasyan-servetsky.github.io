﻿/* Copyright 2012, Kasyan Servetsky
November 6, 2012
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Expand main text frames to the bottom of page - 2.3";

Main();

//===================================== FUNCTIONS  ======================================
function Main() {
	var page, textFrame, lastChar, gb, objStyle,
	counter = 0,
	progressBarCounter = 0,
	wasRun = false;
	
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.");
	var doc = app.activeDocument;
	var pagesLength = doc.pages.length;
	
	if (doc.objectStyles.itemByName("main").isValid) {
		objStyle = doc.objectStyles.itemByName("main");
	}
	else {
		objStyle = doc.objectStyles.add({name: "main", fillColor: "C=0 M=0 Y=100 K=0", fillTint: 20});
	}

	if (doc.extractLabel(scriptName + "_wasRun") != "") {
		wasRun = eval(doc.extractLabel(scriptName + "_wasRun"));
	}
	
	if (wasRun) ErrorExit("The script was already run on this document.", false);
	
	var progressWin = new Window("window", scriptName);
	var progressBar = progressWin.add("progressbar", undefined, 0, 0, undefined);
	progressBar.preferredSize.width = 450;
	var progressTxt = progressWin.add("statictext", undefined,  "Starting");
	progressTxt.preferredSize.width = 400;
	progressTxt.preferredSize.height = 30;
	progressTxt.alignment = "left";
	progressBar.maxvalue = pagesLength;
	progressWin.show();	

	for (var i = pagesLength-1; i >= 0; i--) {
		page = doc.pages[i];
		progressBar.value = ++progressBarCounter;
		progressTxt.text = "Page: " + progressBarCounter + " out of " + pagesLength;
		
		for (var f = 0; f < page.textFrames.length; f++) {
			textFrame = page.textFrames[f];
			if (textFrame.label == "main") { //&& textFrame.characters.length != 0
		
				lastChar = textFrame.characters[-1];
				
				if (lastChar.isValid && lastChar.contents != SpecialCharacters.PAGE_BREAK && lastChar.contents != SpecialCharacters.FRAME_BREAK && lastChar.contents != SpecialCharacters.COLUMN_BREAK) {
					if (lastChar.contents == "\r" || lastChar.contents == SpecialCharacters.FORCED_LINE_BREAK) {
						lastChar.contents = SpecialCharacters.PAGE_BREAK;
					}
					else {
						textFrame.insertionPoints[-1].contents = SpecialCharacters.PAGE_BREAK;
					}
				} 
			
				gb = textFrame.geometricBounds;
				
				if ((gb[2] - gb[0]) > 50) { // if height > 50 mm -- ignore small header frames like "Глава вторая"
					textFrame.appliedObjectStyle = doc.objectStyles.itemByName("main");
					textFrame.geometricBounds = [gb[0], gb[1], page.bounds[2], gb[3]];
					counter++;
				}
			}	
		}
	}
	
	progressWin.close();
	
	if (counter > 0) {
		doc.insertLabel(scriptName + "_wasRun", "true");
	}

	alert(counter + " text frames were expanded to the bottom of page.", scriptName, false);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------