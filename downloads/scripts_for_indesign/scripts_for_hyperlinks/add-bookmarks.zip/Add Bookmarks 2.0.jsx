﻿// Copyright 2012, Kasyan Servetsky
// October 29, 2012
// Written by Kasyan Servetsky
// http://www.kasyan.ho.com.ua
// e-mail: askoldich@yahoo.com
//======================================================================================
var doc, progressWin, progressBar, progressTxt, prefix, firstPage, lastPage,
scriptName = "Add Bookmarks - 2.0",
bookmarkCounter = 0;

CheckPreConditions();

//===================================== FUNCTIONS  ======================================
function CreateDialog() {
	var win = new Window("dialog", scriptName);

	win.p1 = win.add("panel", undefined, "Prefix:");
	win.p1.orientation = "column";
	win.p1.alignment = "fill";
	win.p1.alignChildren = "fill";
	
	prefix = app.extractLabel("Kas_" + scriptName);
	if (prefix == "") prefix = "Page-";
	
	win.p1.et = win.p1.add("edittext", undefined, prefix);
	
	win.p2 = win.add("panel", undefined, "Pages:");
	win.p2.orientation = "row";
	win.p2.alignment = "fill";
	win.p2.alignChildren = "left";
	
	win.p2.st1 = win.p2.add("statictext", undefined, "From");
	win.p2.et1 = win.p2.add("edittext", undefined, doc.pages[0].name);
	win.p2.et1.characters = 6;	
	win.p2.et1.onChange = function() {
		if (!doc.pages.itemByName(this.text).isValid) {
			alert("Page " + this.text + " is not valid.", "Error");
			this.text = doc.pages[0].name;
		}
	}

	win.p2.st2 = win.p2.add("statictext", undefined, "to");
	win.p2.et2 = win.p2.add("edittext", undefined, doc.pages[-1].name);
	win.p2.et2.characters = 6;
	win.p2.et2.onChange = function() {
		if (!doc.pages.itemByName(this.text).isValid) {
			alert ("Page " + this.text + " is not valid.", "Error");
			this.text = doc.pages[-1].name;
		}
	}
	
	// Buttons
	win.grBtns = win.add("group");
	win.grBtns.orientation = "row";   
	win.grBtns.alignment = "center";
	win.grBtns.okBtn = win.grBtns.add("button", undefined, "OK", {name:"ok" });
	win.grBtns.cancelBtn = win.grBtns.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = win.show();
	
	if (showDialog == 1) {
		prefix = win.p1.et.text;
		firstPage = doc.pages.itemByName(win.p2.et1.text);
		if (!firstPage.isValid) ErrorExit("The first page is invalid", true);
		lastPage = doc.pages.itemByName(win.p2.et2.text);
		if (!lastPage.isValid) ErrorExit("The last page is invalid", true);
		app.insertLabel("Kas_" + scriptName, prefix);
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	var page, pageName, mainFrame,
	arr = [],
	startTime = new Date();

	progressWin = new Window ("window", scriptName);
	progressBar = progressWin.add ("progressbar", [12, 12, 350, 24], 0, 0, undefined);
	progressTxt = progressWin.add("statictext", undefined, "Starting adding bookmarks");
	progressTxt.bounds = [0, 0, 340, 20];
	progressTxt.alignment = "left";	
	progressBar.maxvalue = doc.pages.length;
	progressWin.show();
	
	for (var i = 0; i < doc.pages.length; i++) {
		page = doc.pages[i];
		
		if (page.documentOffset < firstPage.documentOffset || page.documentOffset > lastPage.documentOffset) {
			//$.writeln("Skipping: " + i + " / " + page.name + " / " + page.documentOffset);
			continue;
		}
		
		pageName = page.name;
		mainFrame = GetItemFromCollection("main", page.textFrames);
	
		if (mainFrame == null) {
			arr.push(pageName);
		}
		else {
			AddBookmark(mainFrame, pageName);
			
			if (arr.length > 0) {
				for (var a = arr.length-1; a >= 0; a--) {
					AddBookmark(mainFrame, arr[a]);
				}
				arr = [];
			}
		}

		progressBar.value++;
	}

	var endTime = new Date();
	var duration = GetDuration(startTime, endTime);
	progressWin.close();
	
	alert("Finished. " + bookmarkCounter + " bookmarks were created.\n(time elapsed: " + duration + ")", scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddBookmark(mainFrame, pageName) {
	var hyperlinkTextDestination;
	
	try {
		var ip = mainFrame.insertionPoints[0];
		var name = prefix + pageName;
		
		if (!doc.bookmarks.itemByName(name).isValid) {
			
			hyperlinkTextDestination = doc.hyperlinkTextDestinations.itemByName(name);
			
			if (!hyperlinkTextDestination.isValid) {
				hyperlinkTextDestination = doc.hyperlinkTextDestinations.add(ip, {name: name});
			}
		
			var bookmark = doc.bookmarks.add(hyperlinkTextDestination, {name: name});
			if (bookmark.isValid) {
				bookmarkCounter++;
			}
		}
	
		progressTxt.text = "Adding bookmark: " + name;
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckPreConditions() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------