﻿// Copyright 2012, Kasyan Servetsky
// October 19, 2012
// Written by Kasyan Servetsky
// http://www.kasyan.ho.com.ua
// e-mail: askoldich@yahoo.com
//======================================================================================
var doc, progressWin, progressBar, progressTxt, prefix,
scriptName = "Add Bookmarks - 1.4",
bookmarkCounter = 0;

CreateDialog();

//===================================== FUNCTIONS  ======================================
function CreateDialog() {
	var win = new Window("dialog", scriptName);
	// Panel
	win.p = win.add("panel", undefined, "");
	win.p.orientation = "column";
	win.p.alignment = "fill";
	win.p.alignChildren = "fill";
	
	prefix = app.extractLabel("Kas_" + scriptName);
	if (prefix == "") prefix = "Page-";
	
	win.p.et = win.p.add("edittext", undefined, prefix);
	
	// Buttons
	win.grBtns = win.add("group");
	win.grBtns.orientation = "row";   
	win.grBtns.alignment = "center";
	win.grBtns.okBtn = win.grBtns.add("button", undefined, "OK", {name:"ok" });
	win.grBtns.cancelBtn = win.grBtns.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = win.show();
	
	if (showDialog == 1) {
		prefix = win.p.et.text;
		app.insertLabel("Kas_" + scriptName, prefix);
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	var page, pageName, mainFrame,
	arr = [],
	startTime = new Date();
	
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.");

	doc = app.activeDocument;
	
	progressWin = new Window ("window", scriptName);
	progressBar = progressWin.add ("progressbar", [12, 12, 350, 24], 0, 0, undefined);
	progressTxt = progressWin.add("statictext", undefined, "Starting adding bookmarks");
	progressTxt.bounds = [0, 0, 340, 20];
	progressTxt.alignment = "left";	
	progressBar.maxvalue = doc.pages.length;
	progressWin.show();
	
	for (var i = 0; i < doc.pages.length; i++) { //for (var i = doc.pages.length-1; i >= 0; i--) {
		page = doc.pages[i];
		pageName = page.name;
		mainFrame = GetItemFromCollection("main", page.textFrames);
	
		if (mainFrame == null) {
			arr.push(pageName);
		}
		else {
			AddBookmark(mainFrame, pageName);
			
			if (arr.length > 0) {
				//debugger
				//arr.sort( function(a,b) {return b-a} );

				for (var a = arr.length-1; a >= 0; a--) {
//~ 				for (var a = 0; a < arr.length; a++) {
					//$.writeln(arr[a]);
					//debugger
					AddBookmark(mainFrame, arr[a]);
				}
				arr = [];
			

			}
		}

		progressBar.value++;
	}

	var endTime = new Date();
	var duration = GetDuration(startTime, endTime);
	progressWin.close();
	
	alert("Finished. " + bookmarkCounter+ " bookmarks were created.\n(time elapsed: " + duration + ")", scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddBookmark(mainFrame, pageName) {
	try {
		var ip = mainFrame.insertionPoints[0];
		var name = prefix + pageName;
		
		if (!doc.bookmarks.itemByName(name).isValid) {		
			var hyperlinkTextDestination = doc.hyperlinkTextDestinations.add(ip, {name: name});
			var bookmark = doc.bookmarks.add(hyperlinkTextDestination, {name: name});
			if (bookmark.isValid) {
				bookmarkCounter++;
			}
		}
	
		progressTxt.text = "Adding bookmark: " + name;
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------