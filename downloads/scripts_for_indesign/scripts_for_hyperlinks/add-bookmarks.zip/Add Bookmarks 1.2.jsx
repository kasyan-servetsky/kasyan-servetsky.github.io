﻿// Copyright 2012, Kasyan Servetsky
// October 8, 2012
// Written by Kasyan Servetsky
// http://www.kasyan.ho.com.ua
// e-mail: askoldich@yahoo.com
//======================================================================================
const scriptName = "Add Bookmarks";
const scriptVersion = "1.2";
var doc, progressWin, progressBar, progressTxt, bookmarkCounter, prefix;

CreateDialog();

//===================================== FUNCTIONS  ======================================
function CreateDialog() {
	var win = new Window("dialog", scriptName + " - " + scriptVersion);
	// Panel
	win.p = win.add("panel", undefined, "");
	win.p.orientation = "column";
	win.p.alignment = "fill";
	win.p.alignChildren = "fill";
	
	prefix = app.extractLabel("Kas_" + scriptName + scriptVersion);
	if (prefix == "") prefix = "Page-";
	
	win.p.et = win.p.add("edittext", undefined, prefix);
	
	// Buttons
	win.grBtns = win.add("group");
	win.grBtns.orientation = "row";   
	win.grBtns.alignment = "center";
	win.grBtns.okBtn = win.grBtns.add("button", undefined, "OK", {name:"ok" });
	win.grBtns.cancelBtn = win.grBtns.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = win.show();
	
	if (showDialog == 1) {
		prefix = win.p.et.text;
		app.insertLabel("Kas_" + scriptName + scriptVersion, prefix);
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	var page, pageName, mainFrame;
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.");
	var startTime = new Date();
	doc = app.activeDocument;
	bookmarkCounter = 0;
	
	progressWin = new Window ("window", scriptName + " - " + scriptVersion);
	progressBar = progressWin.add ("progressbar", [12, 12, 350, 24], 0, 0, undefined);
	progressTxt = progressWin.add("statictext", undefined, "Starting adding bookmarks");
	progressTxt.bounds = [0, 0, 340, 20];
	progressTxt.alignment = "left";	
	progressBar.maxvalue = doc.pages.length;
	progressWin.show();
	
	for (var i = doc.pages.length-1; i >= 0; i--) {
		page = doc.pages[i];
		pageName = page.name;
		mainFrame = GetItemFromCollection("main", page.textFrames); // get by label
	
		if (mainFrame == null) { // if not labeled, try to get it by size
			mainFrame = GetMainFrame(page);
		}
		
		if (mainFrame != null && mainFrame.contents != "") {
			AddBookmark(mainFrame, pageName);
		}
		else {
			$.writeln("Page - " + pageName + ", main frame not found or empty");
		}
	
		progressBar.value++;
	}

	var endTime = new Date();
	var duration = GetDuration(startTime, endTime);
	progressWin.close();
	
	alert("Finished. " + bookmarkCounter+ " bookmarks were created.\n(time elapsed: " + duration + ")", scriptName + " - " + scriptVersion);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddBookmark(mainFrame, pageName) {
	try {
		var ip = mainFrame.insertionPoints[0];
		var name = prefix + pageName;
		var hyperlinkTextDestination = doc.hyperlinkTextDestinations.add(ip, {name: name});
		var bookmark = doc.bookmarks.add(hyperlinkTextDestination, {name: name});
		if (bookmark.isValid) bookmarkCounter++;
		progressTxt.text = "Adding bookmark: " + name;
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetMainFrame(page) {
	var tf, gb, width, height;
	var mainFrame = null;
	var textFrames = page.textFrames;
	
	for (var i = 0; i < textFrames.length; i++) {
		tf = textFrames[i];
		gb = tf.geometricBounds;
		width = Math.floor((gb[3]-gb[1])*100)/100;
		height = Math.floor((gb[2]-gb[0])*100)/100;
		if (width >= 80 && height >= 40) {
			mainFrame = tf;
		}
	}
	
	return mainFrame;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName + " - " + scriptVersion, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------