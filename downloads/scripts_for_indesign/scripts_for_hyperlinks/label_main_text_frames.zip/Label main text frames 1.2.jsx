﻿/* Copyright 2012, Kasyan Servetsky
October 7, 2012
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Label main text frames - 1.0";
Main();
//===================================== FUNCTIONS  ======================================
function Main() {
	var story, objectStyleMain, swatchMain,
	doc = app.activeDocument,
	counter = 0;
	
	// check if text is selected
	if (app.selection.length == 0 || app.selection.length > 1) ErrorExit("One text frame or some text should be selected, or the cursor should be inserted into the text.", true);
	var sel = app.selection[0];
		
	if (sel.constructor.name == "TextFrame") { // a text frame is selected
		story = sel.texts[0].parentStory;
	}
	else if (sel.hasOwnProperty("baseline")) { // some text is selected or the cursor is placed in the text
		story = sel.parentStory;
	}
	else {
		ErrorExit("One text frame or some text should be selected, or the cursor should be inserted into the text.");
	}

	if (story == undefined || !story.isValid) ErrorExit("Can't find the story.", true);
	if (story.contents == "") ErrorExit("The selection contains no text.", true); // story is empty
	
	if (doc.swatches.itemByName("=== Main ===") == null) {
		swatchMain = doc.colors.add({name : "=== Main ===", model : ColorModel.PROCESS, space : ColorSpace.CMYK, colorValue : [0, 5, 25, 0]});
	}
	else {
		swatchMain = doc.swatches.itemByName("=== Main ===");
	}
	
	if (doc.objectStyles.itemByName("main") == null) {
		objectStyleMain = doc.objectStyles.add({name : "main", fillColor: swatchMain});
	}
	else {
		objectStyleMain = doc.objectStyles.itemByName("main");
	}

	var textFrames = story.textContainers;
	
	for (var i = 0; i < textFrames.length; i++) {
		textFrames[i].label = "main";
		textFrames[i].appliedObjectStyle = objectStyleMain;
		counter++;
	}

	alert(counter + " text frames were labeled as 'main'", scriptName, false);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------

/*

	
	
*/