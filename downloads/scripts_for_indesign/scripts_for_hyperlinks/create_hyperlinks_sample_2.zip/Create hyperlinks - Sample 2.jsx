﻿/* Copyright 2013, Kasyan Servetsky
January 17, 2013
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var doc, set, hyperlinksCounter, progressBar, progressTxt, swatchGreen, swatchBlue, swatchRed, estimatedHyperlinksNumber, storyMain,
scriptName = "Create hyperlinks - Sample 2",
hypCount = 0,
arr = [];

CreateDialog();

//===================================== FUNCTIONS  ======================================
function Main() {
	var obj, textToProcess;
	doc = app.activeDocument; // global
	
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	
	var startTime = new Date();
	if (set.log) arr.push(GetDate() + "\r");
	
	CheckSwatches();

	var storyIndex = (set.rbSel == 0) ? doc.stories.itemByID(13246) : doc.stories.itemByID(13421);
	storyMain = doc.stories.itemByID(359); // global
	if (!storyIndex.isValid || !storyMain.isValid) ErrorExit("Index and/or main story is invalid.", true);

	if (set.rbSel == 0 || set.rbSel == 1) {
		if (app.selection.length > 0 && app.selection[0].hasOwnProperty("baseline") && app.selection[0].constructor.name != "InsertionPoint") {
			pars = app.selection[0].paragraphs;
			textToProcess = app.selection[0];
			if (pars.length == 0)  ErrorExit("No paragraphs in the selection.", true);
		}
		else {
			pars = storyIndex.paragraphs;
			textToProcess = storyIndex;
		}

		estimatedHyperlinksNumber = EstimateHyperlinksNumber(textToProcess);
	}
	else if (set.rbSel == 2) {
		app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
		app.findGrepPreferences.findWhat = "See also: №№.+";
		app.findGrepPreferences.appliedParagraphStyle = doc.paragraphStyles.itemByName("MainNumbered");
		pars = storyMain.findGrep();

		estimatedHyperlinksNumber = EstimateHyperlinksNumber(pars);
	}

	var progressWin = new Window ("window", scriptName);
	progressBar = progressWin.add ("progressbar", undefined, 0, undefined);
	progressBar.preferredSize.width = 480;
	progressTxt = progressWin.add("statictext", undefined,  "Starting adding hyperlinks");
	progressTxt.preferredSize.width = 430;
	progressTxt.preferredSize.height = 30;
	progressTxt.alignment = "left";
	progressBar.maxvalue = estimatedHyperlinksNumber;
	progressWin.show();
	
	hyperlinksCounter = GetLastHyperlinkNumber();

	for (var i = 0; i < pars.length; i++) {
		var par = pars[i];
		if (par.contents != "" && par.contents != "\r" && par.contents != " " && par.contents != " \r") {
			obj = GetInfo(par);

			if (obj != null) {
				//$.writeln("-----------------------------\r" + obj.name);
				if (set.log) arr.push("-----------------------------\r" + obj.name);
				//================================================================================================
				if (obj.pageNumbersArr.length > 0) {
					for (var j = obj.pageNumbersArr.length-1; j >= 0; j--) { 
						if (obj.sourceTextRefs[j] != undefined && obj.pageNumbersArr[j] != undefined) {
							if (set.log) arr.push("Page: " + obj.pageNumbersArr[j]);
							MakeHyperlink(obj.name, obj.sourceTextRefs[j], obj.pageNumbersArr[j]);
						}
					}
				}
				//================================================================================================
			} // obj != null
		}
	} // for

	var endTime = new Date();
	var duration = GetDuration(startTime, endTime);
	progressWin.close();
	
	var reportHyperlinks = hypCount + " hyperlinks " + ((hypCount == 1) ? "was" : "were") + " created.\n(time elapsed: " + duration + ")";

	if (set.log) {
		arr.push("\r=========================================================\r" + reportHyperlinks + "\r\r");
		var text = arr.join("\r");
		WriteToFile(text);
	}

	alert("Finished. " + reportHyperlinks, scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeHyperlink(str, sourceTextRef, pageNum) {
	var mainFrame, finds, found, name, hypTextDest, hypSource, hyperlink;

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;	
	
	if (pageNum.match(/[а-я]$/) != null) {
		pageNum = pageNum.replace("-", ""); // sub-item like so:1171-а
		app.findGrepPreferences.findWhat = "^" + pageNum;
	}		
	else {
		app.findGrepPreferences.findWhat = "^" + pageNum + "(?=\\.\\s)";
	}

	finds = storyMain.findGrep();
	
	if (finds.length == 0) { // nothing was found
		//$.writeln("Found nothing: " + str + " / " + pageNum);
		sourceTextRef.fillColor = swatchRed;
		if (set.log) arr.push("Found nothing: " + str + " / " + pageNum);
		return;
	}	
	else if (finds.length == 1) { // OK - found one
		found = finds[0];
		found.fillColor = swatchGreen;
	}
	else if (finds.length > 1) { // it's hardly possible
		//$.writeln("Found " + finds.length);
		found = finds[0];
	}

	name = set.internalPrefix + ZeroPad(hyperlinksCounter, 5);
	
	try {	
		hypTextDest = doc.hyperlinkTextDestinations.add(found, {name: name});
		hypSource = doc.hyperlinkTextSources.add(sourceTextRef, {name: name});
		hyperlink = doc.hyperlinks.add(hypSource, hypTextDest, {name: name, borderStyle: HyperlinkAppearanceStyle.SOLID, visible: false});
		
		if (hyperlink.isValid) {
			hyperlinksCounter++;
			hypCount++;
			sourceTextRef.fillColor = swatchGreen;
			if (set.log) arr.push(hyperlink.name + " / "+ hypSource.sourceText.contents +  " -- OK");
		}
	
		progressTxt.text = "Adding hyperlink №" + hyperlinksCounter + " (" + hypCount + " out of " + estimatedHyperlinksNumber + "), Name: " + ((str.length < 21) ? str : (str.substr(0, 20) + "...\"")) + " (Page - " + pageNum + ")";
		progressBar.value = (hypCount);
		
		if (set.log) arr.push(hyperlinksCounter +  " (" + name + "), Name - " + str + " (Page - " + pageNum + ")");

		app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
	}
	catch(err) {
		$.writeln(err.message + ", sourceTextRef: " + sourceTextRef.contents + ", name: " + name + ", line: " + err.line + ", str: " + str + ", pageNum: " + pageNum);
		hyperlinksCounter++;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function InsertLabelToTextFrame(mainFrame, str, destName) {
	//$.writeln("InsertLabelToTextFrame - " + mainFrame.parentPage.name);
	var stringsList = mainFrame.extractLabel("strings");
	var destNamesList = mainFrame.extractLabel("destination_names");
	mainFrame.insertLabel("strings", stringsList + ((stringsList == "") ? "" : "|") + str);
	mainFrame.insertLabel("destination_names", destNamesList + ((destNamesList == "") ? "" : "|") + destName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetInfo(par) {
	var item, range, found, str, arr, txtRange;
	
	var obj = {};
	obj.par = par;
	// Get list of pages
	obj.pageNumbersArr = [];
	obj.sourceTextRefs = [];
	
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	
	if (set.rbSel == 2) {
		obj.name = "See also: №";
		app.findGrepPreferences.findWhat = "See also: №№.+";
		found = par.findGrep();
		if (found.length == 0) {
			return null;
		}
		else {
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
			app.findGrepPreferences.findWhat = "(?<=№ )\\d{1,4},.+";
			found = par.findGrep();
			if (found.length == 0) { // find a number at the end of line
				app.findGrepPreferences.findWhat = "(?<=№ )\\d{1,4}";
				found = par.findGrep();
			}
		}
	}
	else {
		// Get name
		if (set.rbSel == 0) {
			app.findGrepPreferences.findWhat = "^\\<.+?\\>"; // first word
		}
		else if (set.rbSel == 1) {
			app.findGrepPreferences.findWhat =  "«.+?»";
		}
		
		foundName = par.findGrep();
		 if (foundName.length == 0) {
			 return null;
		}
		obj.name = foundName[0].contents;
		//$.writeln("obj.name = " + obj.name);

		app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
		app.findGrepPreferences.findWhat = "(?<=\\t)\\**\\s*\\d{1,4}(-|,).+"; // everything after (including) the 1st page number/range; can be like so: * 428, 763,
		found = par.findGrep();
		0
		if (found.length == 0) { // find a number at the end of line
			app.findGrepPreferences.findWhat = "(?<=\\t)\\**\\s*\\d{1,4}(?= *\\r)";
			found = par.findGrep();
		}
	}

	if (found.length == 0) return null;
	
	txtRange = found[0];
	str = txtRange.contents;

	if (str != undefined) {
		str = str.replace(/\s/g, ""); // remove spaces
		str = str.replace(/\*/, ""); // remove *
		GetPageNumbers(str, txtRange, obj.pageNumbersArr, obj.sourceTextRefs);
	}

	if (str== undefined) return null;

	return obj;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetPageNumbers(str, txtRange, pageNumbersArr, sourceTextRefs) {
	var item, range, num, sourceTextRef, subItem,
	array = str.split(",");

	for (var i = 0; i < array.length; i++) {
		item = array[i];
		if (item == "") continue;
		//$.writeln("item = " + item);
		if (item.match(/\r$/) != null) {
			item = item.replace(/\r$/, "");
			$.writeln("item.match(/\r$/) != null -- " + item);
		}
	
		range = item.match(/\d{1,4}(-[а-я])*-\d{1,4}(-[а-я])*$/);

		if (range != null) { // Range of pages
			//$.writeln("Range = " + range);
			range = range[0];
			var expandedArray = Unrange(range).split(",");
			// first
			sourceTextRef = GetSourceTextRef(txtRange, expandedArray[0]);
			if (sourceTextRef != null && sourceTextRef.fillColor != swatchGreen && sourceTextRef.fillColor != swatchBlue) {
				sourceTextRefs.push(sourceTextRef);
				pageNumbersArr.push(expandedArray[0]);
			}
			// last
			sourceTextRef = GetSourceTextRef(txtRange, expandedArray[expandedArray.length-1]);
			if (sourceTextRef != null && sourceTextRef.fillColor != swatchGreen && sourceTextRef.fillColor != swatchBlue) {
				sourceTextRefs.push(sourceTextRef);
				pageNumbersArr.push(expandedArray[expandedArray.length-1]);
			}
			continue;
		}
		
		num = parseInt(item); // Single page
	
		if (!isNaN(num)) {
			if (item.match(/[а-я]$/) != null) {
				subItem = item.match(/[а-я]$/)[0]; // sub-item like so:1171-а
				sourceTextRef = GetSourceTextRef(txtRange, item);
				if (sourceTextRef != null && sourceTextRef.fillColor != swatchGreen && sourceTextRef.fillColor != swatchBlue) {
					sourceTextRefs.push(sourceTextRef);
					pageNumbersArr.push(item);
				}
			}
			else {
				sourceTextRef = GetSourceTextRef(txtRange, num);
				if (sourceTextRef != null && sourceTextRef.fillColor != swatchGreen && sourceTextRef.fillColor != swatchBlue) {
					sourceTextRefs.push(sourceTextRef);
					pageNumbersArr.push(String(num));
				}
			}
		}
		else { // in case text anchor precedes page number
			$.writeln("Not number - trying to get number at the end of the line - " + item);
			//debugger;
			num = item.match(/\d+$/m);
			if (num != null) {
				sourceTextRef = GetSourceTextRef(txtRange, item); //num[0]
				if (sourceTextRef != null && sourceTextRef.fillColor != swatchGreen && sourceTextRef.fillColor != swatchBlue) {
					sourceTextRefs.push(sourceTextRef);
					pageNumbersArr.push(num[0]);
				}
			}
		}
	
	} // for
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSourceTextRef(txtRange, num) {
	var findsGr, foundGr;

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
	app.findGrepPreferences.findWhat = "\\<" + num + "\\>"; // start and end of the word (find 30, but not in 830) 
	var finds = txtRange.findGrep();

	if (finds.length > 0) {
		var text = finds[0].texts[0];

		if (text.contents.match(/\d{1,4}-\d{1,4}$/) != null) { // range
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
			app.findGrepPreferences.findWhat = String(num) + "(?=-\\d{1,4})"; // before dash
			findsGr = text.findGrep();
			if (findsGr.length > 0) {
				foundGr = findsGr[0];
				app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
				app.findTextPreferences = app.changeTextPreferences = NothingEnum.nothing;
				return foundGr;
			}
			else {
				app.findGrepPreferences.findWhat = String(num) + "$"; // after dash
				findsGr = text.findGrep();
				if (findsGr.length > 0) {
					foundGr = findsGr[0];
					app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
					app.findTextPreferences = app.changeTextPreferences = NothingEnum.nothing;
					return foundGr;
				}
			}
		}
		else { // single number
			app.findGrepPreferences.findWhat = String(num) + "$";
			findsGr = text.findGrep();
			if (findsGr.length > 0) {
				foundGr = findsGr[0];
				app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
				return foundGr;
			}
		}
	}
	else {
		//debugger
		$.writeln("Text not found: " + num);
		app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
		app.findTextPreferences = app.changeTextPreferences = NothingEnum.nothing;
		return null;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Unrange(s) {
	return s.replace(/(\d+)-(\d+)/g, Expand);
} 
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Expand() {
	var args = arguments;
	var expanded = []; 
	var start = Number(arguments[1]); 
	var stop = Number(arguments[2]);

	for (var i = start; i <= stop; i++) {
		expanded.push(i);
	}

	return expanded;
}

//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckSwatches() {
	if (doc.swatches.itemByName("C=75 M=5 Y=100 K=0") == null) {
		swatchGreen = doc.colors.add({name : "C=75 M=5 Y=100 K=0", model : ColorModel.PROCESS, space : ColorSpace.CMYK, colorValue : [75, 5, 100, 0]});
	}
	else {
		swatchGreen = doc.swatches.itemByName("C=75 M=5 Y=100 K=0");
	}

	if (doc.swatches.itemByName("C=100 M=0 Y=0 K=0") == null) {
		swatchBlue = doc.colors.add({name : "C=100 M=0 Y=0 K=0", model : ColorModel.PROCESS, space : ColorSpace.CMYK, colorValue : [0, 100, 0, 0]});
	}
	else {
		swatchBlue = doc.swatches.itemByName("C=100 M=0 Y=0 K=0");
	}

	if (doc.swatches.itemByName("C=0 M=100 Y=100 K=0") == null) {
		swatchRed = doc.colors.add({name : "C=0 M=100 Y=100 K=0", model : ColorModel.PROCESS, space : ColorSpace.CMYK, colorValue : [0, 100, 100, 0]});
	}
	else {
		swatchRed = doc.swatches.itemByName("C=0 M=100 Y=100 K=0");
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	GetDialogSettings();
	var w = new Window("dialog", scriptName);
	
	w.p = w.add("panel", undefined, "Settings");
	w.p.alignChildren = "left";
	w.p.alignment = "fill";
	
	w.p.g = w.p.add("group");
	w.p.g.st = w.p.g.add("statictext", undefined, "Internal Prefix:");
	w.p.g.et = w.p.g.add("edittext", undefined, set.internalPrefix);
	w.p.g.et.characters = 20;
	w.p.g.et.helpTip = "Used in names of hyperlinks, sources and destinations";
	
	// Checkbox
	w.p.cb = w.p.add("checkbox", undefined, "Create log file on the desktop");
	w.p.cb.alignment = "left";
	w.p.cb.value = set.log;
	
	w.p1 = w.add("panel");
	w.p1.orientation = "column";
	w.p1.alignment = "fill";
	w.p1.alignChildren = "left";
	w.p1.rb0 = w.p1.add("radiobutton", undefined, "Index to names");
	w.p1.rb1 = w.p1.add("radiobutton", undefined, "Index to dramatic works");
	w.p1.rb2 = w.p1.add("radiobutton", undefined, "See also: №№...");
	
	if (set.rbSel == 0) {
		w.p1.rb0.value = true;
	}
	else if (set.rbSel == 1) {
		w.p1.rb1.value = true;
	}
	else if (set.rbSel == 2) {
		w.p1.rb2.value = true;
	}
	
	// Buttons
	w.buttons = w.add("group");
	w.buttons.orientation = "row";   
	w.buttons.alignment = "center";
	w.buttons.ok = w.buttons.add("button", undefined, "OK", {name:"ok" });
	w.buttons.cancel = w.buttons.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		set.internalPrefix = w.p.g.et.text;
		set.log = w.p.cb.value;
		
		if (w.p1.rb0.value == true) {
			set.rbSel = 0;
		}
		else if (w.p1.rb1.value == true) {
			set.rbSel = 1;
		}
		else if (w.p1.rb2.value == true) {
			set.rbSel = 2;
		}
	
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = { internalPrefix: "Sample2_", log: true , rbSel: 0 };
	}
	return set;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetLastHyperlinkNumber() {
	var number,
	tmpArr = [];
	
	progressTxt.text = "Getting the last hyperlink number";
	
	if (doc.hyperlinks.length == 0 && doc.hyperlinkTextDestinations.length == 0 && doc.hyperlinkTextSources.length == 0) {
		number = 1;
	}
	else {
		var hyperlinkNames = doc.hyperlinks.everyItem().name;
		
		for (var i = 0; i < hyperlinkNames.length; i++) {
			if (hyperlinkNames[i].match(/\d{4,5}/) != null) {
				tmpArr.push(Number(hyperlinkNames[i].match(/\d{4,5}/)[0]));
			}
		}
		
		if (tmpArr.length > 0) {
			tmpArr.sort(function(a,b){return a-b});
			number = tmpArr[tmpArr.length-1] + 1; // return next number for creating next hyperlink
		}
		else {
			number = 1;
		}
	
	}
	return number;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function EstimateHyperlinksNumber(text) {
	var found,
	counter = 0;
	
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = "\\b\\d{1,4}\\b";
	
	if (set.rbSel == 0 || set.rbSel == 1) {
		found = text.findGrep();
		app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
		return found.length;
	}
	else if (set.rbSel == 2) {
		for (var i = 0; i < text.length; i++) {
			found = text[i].findGrep();
			counter = counter + found.length;
		}
		app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
		return counter;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ZeroPad(num, digit) {
	var tmp = num.toString();
	while (tmp.length < digit) {
		tmp = "0" + tmp;
	}
	return tmp;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDate() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function WriteToFile(text) {
	var file = new File("~/Desktop/" + scriptName + ".txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text); 
	file.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------