// Copyright 2010 CatBase Software Limited
// www.catbase.com
// Create Cross-References 2.3.jsx
// Version 2.3
// September 19, 2010
// Written by Kasyan Servetsky
// http://www.kasyan.ho.com.ua
// e-mail: askoldich@yahoo.com
//==================================================================
if (Number(String(app.version).split(".")[0]) < 6) ErrorExit("This script requires InDesign CS4 or CS5.", true);
if (app.documents.length == 0) ErrorExit("No documents are open. Please open a document and try again.", true);

var myDoc = app.activeDocument;

var myHighligh, myBorderColor, myWidth, myBorderStyle;
var myCrossRefFormats = myDoc.crossReferenceFormats.everyItem().name;
var myTypeList = ["Visible Rectangle", "Invisible Rectangle"];
var myHighlightList = ["None", "Invert", "Outline", "Inset"];
var myHighlightEnumList = ["NONE", "INVERT", "OUTLINE", "INVERT"];

var myBorderColDesList = ["Black", "Blue", "Brick red", "Brown", "Burgundy", "Charcoal", "Cute teal", "Cyan", "Dark blue", "Dark green", "Fiesta", "Gold", "Grass green", "Gray", "Green", "Grid blue", "Grid green", "Grid orange", "Lavender", "Light blue", "Light gray", "Light olive", "Lipstick", "Magenta", "Ochre", "Olive green", "Orange", "Peach", "Pink", "Purple", "Red", "Sulphur", "Tan", "Teal", "Violet", "White", "Yellow"];

var myWidthList = ["Thin", "Medium", "Thick"];
var myWidthEnumList = ["THIN", "MEDIUM", "THICK"];
var myStyleList = ["Solid", "Dashed"];
var myStyleEnumList = ["SOLID", "DASHED"];
var myCounter = 0;

var myPrBarWin = new Window ( "window", "Creating Cross-References" );
var myPrBar = myPrBarWin.add ("progressbar", [12, 12, 375, 24]);
var myPrBarText = myPrBarWin.add("statictext", undefined, "Starting");
myPrBarText.bounds = [0, 0, 365, 20];
myPrBarText.alignment = "center";
var myPrBarCounter = 1;

var mySet = GetSettings();
CreateDialog();

//-------------------------------------- FUNCTIONS ---------------------------------------------
function Main() {
	myHighligh = eval("HyperlinkAppearanceHighlight." + myHighlightEnumList[mySet.myDdl3Sel]);
	myBorderColor = eval("UIColors." + myBorderColDesList[mySet.myDdl4Sel].toUpperCase().replace(" ", "_"));
	myWidth = eval("HyperlinkAppearanceWidth." + myWidthEnumList[mySet.myDdl5Sel]);
	myBorderStyle = eval("HyperlinkAppearanceStyle." + myStyleEnumList[mySet.myDdl6Sel]);
	
	myPrBarWin.show();

	 if (mySet.myCheckBoxValue) WriteToFile("\r--------------------- Script started -- " + GetDate() + " ---------------------\n");
	 if (mySet.myCheckBoxValue) WriteToFile("File: " + myDoc.fullName.fsName + "\n");
	
	MoveDestinationTags();
	CreateDestinations();
	CreateHyperlinks();
	
	 if (mySet.myCheckBoxValue) WriteToFile("\r--------------------- Script finished -- " + GetDate() + " ---------------------\r\r");

	myPrBarWin.close();

	if (myCounter == 0) {
		alert("No cross-references have been created", "Create Cross-References");
	}
	else if (myCounter == 1) {
		alert("One cross-reference has been created", "Create Cross-References");
	}
	else if (myCounter > 1) {
		alert(myCounter  + " cross-references have been created", "Create Cross-References");
	}
}		
//--------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	var myDialog = new Window("dialog", "Create Cross-Reference Settings");
	myDialog.orientation = "column";
	myDialog.alignChildren = "fill";
	
	var myXrefPanel = myDialog.add("panel", undefined, "Cross-Reference Format");
	myXrefPanel.orientation = "column";
	myXrefPanel.alignChildren = "right";
	
	var myGroup1 = myXrefPanel.add("group");
	myGroup1.orientation = "row";
	var myStTxt1 = myGroup1.add("statictext", undefined, "Format:");
	var myDropDownList1 = myGroup1.add("dropdownlist", undefined, myCrossRefFormats);
	myDropDownList1.selection = mySet.myDdl1Sel;
	
	var myPanel = myDialog.add("panel", undefined, "Appearance");
	myPanel.orientation = "row";
	
	var myLeftGroup = myPanel.add("group");
	myLeftGroup.orientation = "column";
	myLeftGroup.alignChildren = "right";
	
	var myRightGroup = myPanel.add("group");
	myRightGroup.orientation = "column";
	myRightGroup.alignChildren = "right";
		
	var myGroup2 = myLeftGroup.add("group");
	myGroup2.orientation = "row";
	var myStTxt2 = myGroup2.add("statictext", undefined, "Type:");
	myStTxt2.justify = "right";
	var myDropDownList2 = myGroup2.add("dropdownlist", undefined, myTypeList);
	myDropDownList2.selection = mySet.myDdl2Sel;
	myDropDownList2.onChange = TypeOnChange;

	var myGroup3 = myLeftGroup.add("group");
	myGroup3.orientation = "row";
	var myStTxt3 = myGroup3.add("statictext", undefined, "Highlight:");
	myStTxt3.justify = "right";
	var myDropDownList3 = myGroup3.add("dropdownlist", undefined, myHighlightList);
	myDropDownList3.selection = mySet.myDdl3Sel;
	
	var myGroup4 = myLeftGroup.add("group");
	myGroup4.orientation = "row";
	var myStTxt4 = myGroup4.add("statictext", undefined, "Colour:");
	myStTxt4.justify = "right";
	var myDropDownList4 = myGroup4.add("dropdownlist", undefined, myBorderColDesList);
	myDropDownList4.selection = mySet.myDdl4Sel;

	var myGroup5 = myRightGroup.add("group");
	myGroup5.orientation = "row";
	var myStTxt5 = myGroup5.add("statictext", undefined, "Width:");
	myStTxt5.justify = "right";
	var myDropDownList5 = myGroup5.add("dropdownlist", undefined, myWidthList);
	myDropDownList5.selection = mySet.myDdl5Sel;
	
	var myGroup6 = myRightGroup.add("group");
	myGroup6.orientation = "row";
	var myStTxt6 = myGroup6.add("statictext", undefined, "Style:");
	myStTxt6.justify = "right";
	var myDropDownList6 = myGroup6.add("dropdownlist", undefined, myStyleList);
	myDropDownList6.selection = mySet.myDdl6Sel;
	
	var myCheckBox = myDialog.add("checkbox", undefined, "Create a log file");
	myCheckBox.value = mySet.myCheckBoxValue;
	
	var myOkCancelGroup = myDialog.add("group");
	myOkCancelGroup.orientation = "row";
	myOkCancelGroup.alignment = "center";
	var myOkBtn = myOkCancelGroup.add("button", undefined, "Ok", {name:"ok"});
	var myCancelBtn = myOkCancelGroup.add("button", undefined, "Cancel", {name:"cancel"});
	
	if (mySet.myDdl2Sel == 1) {
		myDropDownList4.enabled = false;
		myDropDownList5.enabled = false;
		myDropDownList6.enabled = false;
		myStTxt4.enabled = false;
		myStTxt5.enabled = false;
		myStTxt6.enabled = false;
	}
	
	function TypeOnChange() {
		if (this.selection.index == 0) {
			myDropDownList4.enabled = true;
			myDropDownList5.enabled = true;
			myDropDownList6.enabled = true;
			myStTxt4.enabled = true;
			myStTxt5.enabled = true;
			myStTxt6.enabled = true;
		}
		else if (this.selection.index == 1) {
			myDropDownList4.enabled = false;
			myDropDownList5.enabled = false;
			myDropDownList6.enabled = false;
			myStTxt4.enabled = false;
			myStTxt5.enabled = false;
			myStTxt6.enabled = false;
		}
	}
	
	var myShowDialog = myDialog.show();
	
	if (myShowDialog== 1) {
		mySet.myDdl1Sel = myDropDownList1.selection.index;
		mySet.myDdl2Sel = myDropDownList2.selection.index;
		mySet.myDdl3Sel = myDropDownList3.selection.index;
		mySet.myDdl4Sel = myDropDownList4.selection.index;		
		mySet.myDdl5Sel = myDropDownList5.selection.index;
		mySet.myDdl6Sel = myDropDownList6.selection.index;
		mySet.myCheckBoxValue = myCheckBox.value;
		app.insertLabel("Kas_CreateCrossReferences_2.2", mySet.toSource());
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------
function GetSettings() {
	var mySettings = eval(app.extractLabel("Kas_CreateCrossReferences_2.2"));
	if (mySettings == undefined) {
		mySettings = { myDdl1Sel:8,  myDdl2Sel:0, myDdl3Sel:0, myDdl4Sel:0, myDdl5Sel:0, myDdl6Sel:0, myCheckBoxValue:true }
	}
	return mySettings;
}
//--------------------------------------------------------------------------------------------------------------
function CreateDestinations() {
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
	app.findGrepPreferences.findWhat = "<d=Anchor\\s\\d+>";
	var myFinds = myDoc.findGrep();
	if (myFinds.length == 0) ErrorExit("No destination tags have been found.");
	
	var myDestCounter = 1;
	 if (mySet.myCheckBoxValue) WriteToFile("\rCreating destinations:\n"); 
	
	myPrBar.minvalue = 0;
	myPrBar.maxvalue = myFinds.length;

	for ( var j = myFinds.length-1; j >= 0; j-- ) {

		try {
			var myFound = myFinds[j];
			var myHypTextDest = myDoc.hyperlinkTextDestinations.add(myFound);
			myHypTextDest.name = myFound.contents.match(/Anchor\s\d+/)[0];
			 if (mySet.myCheckBoxValue) WriteToFile( ((myDestCounter < 10) ? ("  " + myDestCounter) : myDestCounter) + " - " + myFound.contents + " -- Ok\n" );
			myPrBar.value = myDestCounter;
			myPrBarText.text = String("Creating destinations \"" + myFound.contents + "\" (" + myDestCounter + " out of " + myFinds.length + ")");		
			myFound.contents = "";

		}
		catch(e) {
			$.writeln(e);
			 if (mySet.myCheckBoxValue) WriteToFile( ((myDestCounter < 10) ? ("  " + myDestCounter) : myDestCounter) + " - ERROR  -- Can't create destination \"" + myFound.contents + "\"\n");
		}
		myDestCounter++;
	}
}
//--------------------------------------------------------------------------------------------------------------
function CreateHyperlinks() {
	var xRefFormat = myDoc.crossReferenceFormats.item(mySet.myDdl1Sel); 
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
	app.findGrepPreferences.findWhat = "<s=Anchor\\s\\d+>";
	var myFinds = myDoc.findGrep();
	if (myFinds.length == 0) ErrorExit("No source tags have been found.");
	
	var mySourceCounter = 1;
	 if (mySet.myCheckBoxValue) WriteToFile("\rCreating sources and cross-references:\n");
	myPrBar.minvalue = 0;
	myPrBar.maxvalue = myFinds.length;
	
	for ( var j = myFinds.length-1; j >= 0; j-- ) {
		var myFound = myFinds[j];
		var mySourceText = myFound;
		var mySourceName = myFound.contents.match(/Anchor\s\d+/)[0];
		try {
			var mySource = myDoc.crossReferenceSources.add(mySourceText, xRefFormat);
			mySource.name = mySourceName;
			 if (mySet.myCheckBoxValue) WriteToFile(((mySourceCounter < 10) ? ("  " + mySourceCounter) : mySourceCounter) + " - Source - " + myFound.contents + " -- Ok\n");
			myPrBar.value = mySourceCounter;
			myPrBarText.text = String("Creating sources \"" + myFound.contents + "\" (" + mySourceCounter + " out of " + myFinds.length + ")");
		}
		catch(e) {
			$.writeln(e);
			 if (mySet.myCheckBoxValue) WriteToFile( ((mySourceCounter < 10) ? ("  " + mySourceCounter) : mySourceCounter) + " - ERROR  -- Can't create source \"" + myFound.contents + "\"\n");
		}
		
		var myHypDest = myDoc.hyperlinkTextDestinations.itemByName(mySourceName);
		if (myHypDest.isValid) {
			var myHyperLink = myDoc.hyperlinks.add(mySource, myHypDest);
			myHyperLink.visible = (mySet.myDdl2Sel == 1) ? false : true;
			myHyperLink.highlight = myHighligh;
			myHyperLink.borderColor = myBorderColor;
			myHyperLink.width = myWidth;
			myHyperLink.borderStyle = myBorderStyle;
			if (myHyperLink.isValid) {
				myCounter++;
				 if (mySet.myCheckBoxValue) WriteToFile(((myCounter < 10) ? ("  " + myCounter) : myCounter) + " - Cross-reference - " + mySourceName + " -- Ok\n");
			}
			
			try{
				myHyperLink.name = mySourceName;
			}
			catch(e) {
				$.writeln(j + " - " + e);
			}
		}
		else {
			$.writeln(j + " - myHypDest - " + mySourceName + " - is Not Valid");
		}
		mySourceCounter++;
	}
}
//--------------------------------------------------------------------------------------------------------------
function MoveDestinationTags() {
	var myPrevChar, myRectangle, myTmpArr;
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.nothing;
	app.findGrepPreferences.findWhat = "<d=Anchor\\s\\d+>";
	var myFinds = myDoc.findGrep();
	if (myFinds.length == 0) ErrorExit("No destination tags have been found.");
	 if (mySet.myCheckBoxValue) WriteToFile("\rMoving destination tags into images:\n");
	
	var myArray = [];
	
	for ( var x = myFinds.length-1; x >= 0; x-- ) {
		var myStory = myFinds[x].parent;
		var myRectangle = myStory.characters.item(myFinds[x].index-1).rectangles.item(0).getElements()[0];
		
		myTmpArr = [];
		myTmpArr[0] = myRectangle;
		myTmpArr[1] = myFinds[x].contents + "";
		myArray.push(myTmpArr);
		myFinds[x].remove();
	}

	myPrBar.minvalue = 0;
	myPrBar.maxvalue = myArray.length;
	
	for ( var j = myArray.length-1; j >= 0; j-- ) {
		try {
			
			myPrBar.value = myPrBarCounter;
			myPrBarText.text = String("Moving destination tags \"" + myArray[j][1]) + "\" (" + myPrBarCounter + " out of " + myArray.length + ")";
			
			if (myArray[j][0].isValid) {
				var myTextFrame = myArray[j][0].textFrames.add({geometricBounds:myArray[j][0].geometricBounds, contents:myArray[j][1]});
				 if (mySet.myCheckBoxValue) WriteToFile( ((myPrBarCounter < 10) ? ("  " + myPrBarCounter) : myPrBarCounter) + " - " + myArray[j][1] + " -- Ok\n" );
			}
		}
		catch(e) {
			$.writeln(e);
			 if (mySet.myCheckBoxValue) WriteToFile( ((myPrBarCounter < 10) ? ("  " + myPrBarCounter) : myPrBarCounter) + " - ERROR  -- Can't move destination tag \"" + myFound.contents + "\"\n");
		}
	
		myPrBarCounter++;
	}
}
//--------------------------------------------------------------------------------------------------------------
function ErrorExit(myMessage, myIcon) {
	alert(myMessage, "Create Cross-References Script", myIcon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------
function WriteToFile(myText) {
	myFile = new File("~/Desktop/Create X-refs Report.txt");
	if ( myFile.exists ) {
		myFile.open("e");
		myFile.seek(0, 2);
	}
	else {
		myFile.open("w");
	}
	myFile.write(myText); 
	myFile.close();
}
//--------------------------------------------------------------------------------------------------------------
function GetDate() {
	var myDate = new Date();
	if ((myDate.getYear() - 100) < 10) {
		var myYear = "0" + new String((myDate.getYear() - 100));
	} else {
		var myYear = new String ((myDate.getYear() - 100));
	}
	var myDateString = (myDate.getMonth() + 1) + "/" + myDate.getDate() + "/" + myYear + " " + myDate.getHours() + ":" + myDate.getMinutes() + ":" + myDate.getSeconds();
	return myDateString;
 }
//--------------------------------------------------------------------------------------------------------------