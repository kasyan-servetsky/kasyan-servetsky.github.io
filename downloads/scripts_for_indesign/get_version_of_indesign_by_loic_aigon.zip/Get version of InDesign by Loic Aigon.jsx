﻿var main = function() {  
	if (!ExternalObject.AdobeXMPScript) {  
		try {  
			ExternalObject.AdobeXMPScript = new ExternalObject('lib:AdobeXMPScript');  
		}  
		catch(e) {  
			alert('Unable to load the AdobeXMPScript library!');   
			return false;
		}  
	}  
	var f = File.openDialog(); 

	if (!f) return;  

	var xmpFile = new XMPFile(f.fsName, XMPConst.UNKNOWN, XMPConst.OPEN_FOR_READ);  
	var xmp = xmpFile.getXMP();  
	xmpFile.closeFile(XMPConst.CLOSE_UPDATE_SAFELY);  

	alert( xmp.getProperty ( XMPConst.NS_XMP, "CreatorTool") );  
}

main(); 