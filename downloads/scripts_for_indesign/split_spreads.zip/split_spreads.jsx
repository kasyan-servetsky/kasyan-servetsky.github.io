﻿#targetengine "PaginaNaarEnkel"


// THE MAIN PROCESS
// -----------------------------------------------
var fcaTitle = "Split Spreads";

var fcaHandlers = {
	'beforeDisplay' : function(ev)
		{
		if(app.documents.length==0){return} 
var doc=app.documents[0]
		},
		
	'onInvoke' : function() 
{ 
aDoc = app.activeDocument;
for (i=0;i<aDoc.pages.length;i++){
	aSide = aDoc.pages[i].side;
	aSide = aSide + "";
	aDoc.pages[i].insertLabel("direction",aSide);
	}
aDoc.documentPreferences.allowPageShuffle = true;
aDoc.documentPreferences.facingPages = false;
aDoc.documentPreferences.allowPageShuffle = false;
aDoc.documentPreferences.facingPages = true;
for (i=0;i<aDoc.pages.length;i++){
	myPage = aDoc.pages[i];
	mySide = myPage.extractLabel("direction");
	if (mySide == "1818653800"){
		myPage.move(LocationOptions.atEnd,myPage,BindingOptions.leftAlign);
		}else{
		myPage.move(LocationOptions.atEnd,myPage,BindingOptions.rightAlign);
		}
	}
}
};
	

// THE MENU INSTALLER
// -----------------------------------------------
var fcaMenuInstaller = fcaMenuInstaller||
(function(mnuTitle,mnuHandlers)
{
// 1. Create the script menu action
var mnuAction = app.scriptMenuActions.add(mnuTitle);

// 2. Attach the event listener
var ev;
for( ev in mnuHandlers )
	{
	mnuAction.eventListeners.add(ev,mnuHandlers[ev]);
	}

// 3. Create the menu item
var fileMenu = app.menus.item("$ID/PagesPanelPopup");

fileMenu.menuItems.add(mnuAction);
		
return true;
})(fcaTitle, fcaHandlers);