﻿(function(){  
  var doc=app.activeDocument,  
  sw=doc.swatches.everyItem().getElements(),  
  c;  
  for(var i=3; i<sw.length; i++){  
  try{  
  c=doc.colors.itemByID(sw[i].id);  
  switch (c.space){  
  case ColorSpace.RGB:  
  c.name='R='+Math.round(c.colorValue[0])+  
	' G='+Math.round(c.colorValue[1])+  
	' B='+Math.round(c.colorValue[2]);  
  break;  
  case ColorSpace.LAB:  
  c.name='L='+Math.round(c.colorValue[0])+  
	' A='+Math.round(c.colorValue[1])+  
	' B='+Math.round(c.colorValue[2]);  
  break;  
  case ColorSpace.CMYK:  
  c.name='C='+Math.round(c.colorValue[0])+  
	' M='+Math.round(c.colorValue[1])+  
	' Y='+Math.round(c.colorValue[2])+  
	' K='+Math.round(c.colorValue[3]);  
  break;  
  }  
  }catch(e){};  
  }  
}())  