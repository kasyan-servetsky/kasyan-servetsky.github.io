﻿var s = app.activeDocument.swatches

for (var i = 0; i < s.length; i++){
    try {
        setNameAsValue(s[i])
    }catch(e) {}  
};   


/**
* Sets the swatch name to color values 
* @ param the swatch 
* @ return void 
* 
*/
function setNameAsValue(s){
    var va = s.colorValue;
    var ns;
    if (s.space == ColorSpace.CMYK) {
        ns = "C=" + Math.round(va[0]) + " M=" + Math.round(va[1]) + " Y=" +Math.round(va[2]) + " K=" + Math.round(va[3])
    } 
    if (s.space == ColorSpace.RGB) {
        ns = "R=" + Math.round(va[0]) + " G=" + Math.round(va[1]) + " B=" +Math.round(va[2])
    }
    if (s.space == ColorSpace.LAB) {
        ns = "L=" + Math.round(va[0]) + " A=" + Math.round(va[1]) + " B=" +Math.round(va[2])
    }
    if (s.space == ColorSpace.HSB) {
        ns = "H=" + Math.round(va[0]) + " S=" + Math.round(va[1]) + " B=" +Math.round(va[2])
    }
    s.name = ns
}