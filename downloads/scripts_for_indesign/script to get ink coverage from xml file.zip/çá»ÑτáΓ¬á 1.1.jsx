﻿main();

function main() {
	var scriptFile = new File(app.activeScript),
	folder = scriptFile.parent,
	xmlFiles = folder.getFiles("*.xml");
	
	if (xmlFiles.length == 0) {
		alert("В текущей папке нет xml-файлов", "Запечатка", true);
	}
	else {
		for (var i = 0; i < xmlFiles.length; i++) {
			processXml(xmlFiles[i]);	
		}
	}
}

function processXml(xmlFile) {
	var text,
	str = "",
	totakInkCov = 0,
	txtArr = [],
	inkCovArr = [];

	xmlFile.open("r");
	var xml = new XML(xmlFile.read());
	xmlFile.close();

	var inks = xml..INKS;
	var inksCount = inks.elements().length();
	
	if (inksCount > 0) {
		for (var i = 0; i < inksCount; i++) {
			str = xml..INK[i].INKNAME + "\t" + xml..INK[i].INKCOVPCT + "\r";
			txtArr.push(str);
			inkCovArr.push(Number(xml..INK[i].INKCOVPCT.toString()));
		}
		
		for (var j = 0; j < inkCovArr.length; j++) {
			totakInkCov += inkCovArr[j];
		}

		txtArr.push("------------------------------------\rΣ\t" + totakInkCov + "%");
		
		text = txtArr.join("");
	}
	else {
		text = "Файл не содержит данные о запечатке.";
	}
	
	var txtFilePath = xmlFile.absoluteURI.replace(/xml$/i, "txt");
	writeToFile(text, txtFilePath);
}

function writeToFile(text, filePath) {
	file = new File(filePath);
	file.encoding = "UTF-8";
	file.open("w");
	file.write(text); 
	file.close();
	file.execute();
}