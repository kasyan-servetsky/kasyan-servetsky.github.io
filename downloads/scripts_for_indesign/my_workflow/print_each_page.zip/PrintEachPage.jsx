/* Copyright 2017, Kasyan Servetsky
November 21, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Print each page",
doc, gInFolderPath, printPreset;

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	var adSuffix, baseName, pageName, pageNumber, pageNumberInAd, filePath, pdfPath, file;	
	var printPrefs = doc.printPreferences;
	var docName = doc.name.replace(/\.[^\.]+$/, "");
	var currentIssueInddFolderName = doc.filePath.name;
	var match = doc.name.match(/(\d{1,3})(-\d{1,3})*(_)(\d{4})(.+)*(_.+)*(\.indd$)/i);
	var match_1 = currentIssueInddFolderName.match(/^\d{4}(_rus|_ukr|_eng)*$/i);
	var issueNumber = null;
	var lang = null;
	
	if (match_1 != null && typeof match_1[1] != "undefined") {
		lang = match_1[1].toLowerCase();
	}

	if (match != null) {
		issueNumber = match[4];
		pageNumberInAd = match[1];
		
		if (typeof match[6] != "undefined") {
			adSuffix = match[6].replace(/ +/g, "_");
		}
		else {
			adSuffix = null;
		}
	}

	if (adSuffix != null && doc.pages.length > 1) ErrorExit("Неправильное имя файла: у рекламы должна быть только одна страница.", true);

	printPrefs.activePrinterPreset = printPreset;
	
	doc.sections.everyItem().sectionPrefix = "";
	doc.sections.everyItem().includeSectionPrefix = false;

	var stop = doc.pages.length + 1;
	var w = new Window("window", "Профиль — " + app.colorSettings.workingSpaceCMYK); 
	var pb = w.add ("progressbar", [12, 12, 300, 24], 0, stop); 
	var st = w.add("statictext");
	st.bounds = [0, 0, 200, 20]; 
	st.alignment = "left";
	w.show();
	
	pb.value = 0.5;
	st.text = "Проверка на картинки в RGB";
	CheckRGB();
	pb.value = 1;
	st.text = "Проверка линков";
	CheckLinkNormal();
	//$.writeln("========================");
	
	for (var i = 0; i < doc.pages.length; i++) {
		curPage = i + 1;
		pb.value = curPage + 1;
		st.text = "Страница " + curPage + " из " + doc.pages.length;         
		pageName = doc.pages[i].name;
		pageNumber = ZeroPad(pageName, 3);

		if (issueNumber != null && adSuffix == null) { // Обычная страница
			baseName = pageNumber + "_business_" + issueNumber + ((lang != null) ? lang : "") + ".ps";
		}
		else if (issueNumber != null && adSuffix != null) { // Реклама
			baseName = ZeroPad(pageNumberInAd, 3) + "_business_" + issueNumber + adSuffix  + ((lang != null) ? lang : "") + ".ps";
		}
		else {
			baseName = pageNumber + "_" + docName + ".ps"
		}

		filePath = gInFolderPath + baseName;
		file = new File(filePath);
		printPrefs.pageRange = pageName;
		printPrefs.printFile = file;
		//$.writeln(filePath);

		doc.print(false);
	}

	w.hide();
	
	doc.close(SaveOptions.YES);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckRGB() {
	var image, answer;
	
	for (var i = 0; i < doc.links.length; i++) {
		var link = doc.links[i];
		if (link.linkType != "InCopyInterchange" && link.linkType != "InCopyStory" && link.linkType != "EPS") {
			image = link.parent;
			try{
				if (image.space == "RGB" || image.space == "Lab"){
					link.show();
					answer = confirm("Внимание! Эта картинка не в CMYK, хотите исправить?");
					if (answer){
						link.editOriginal(); 
						exit();
					}
					else {
						alert("Скрипт будет остановлен.");
						exit();
					}
				}
			}
			catch(err) {}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ZeroPad(num, digit) {
	var tmp = num.toString();
	while (tmp.length < digit) {
		tmp = "0" + tmp;
	}
	return tmp;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckLinkNormal() {
	for(var i = 0; i < doc.links.length; i++) {
	var link = doc.links[i];
		if (link.status != LinkStatus.normal) {
			link.show();
			alert ("Внимание! Этот линк модифицирован и его необходимо обновить.");
			exit();
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	var inFolder = GetRootFolderPath("10.44.54.70|10.44.54.70-1|10.44.54.70-2|New-Nomer|NEW-NOMER|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|W|X|Y|Z");
	
	if (inFolder == null) {
		ErrorExit("Папка \"/PS/in/\" не существует.", true);
	}

	printPreset = app.printerPresets.item("Business PS to PDF");
	if (printPreset == null) ErrorExit("Присет для печати \"Business PS to PDF\" не установлен.", true);

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetRootFolderPath(str) {
	var folder, inFolderPath,
	inFolder = null;
	
	var list = str.split("|");

	for (var i = 0; i < list.length; i++) {
		inFolderPath = "/" + list[i] + "/PS/in/";
		folder = new Folder(inFolderPath);
		
		if (folder.exists) {
			gInFolderPath = inFolderPath;
			inFolder = folder;
		}
	}

	return inFolder;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------