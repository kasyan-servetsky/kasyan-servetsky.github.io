﻿/* Copyright 2017, Kasyan Servetsky
November 21, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Export Each Page as JPEG",
doc;

PreCheck();

//===================================== FUNCTIONS ======================================
function Main(raskladkaFolder) {
	try {
		var currentIssueInddFolderName = doc.filePath.name.toLowerCase();
		var match = doc.name.match(/(\d{1,3})(-\d{1,3})*(_)(\d{4})(.+)*(_.+)*(\.indd$)/i);
		var match_1 = currentIssueInddFolderName.match(/^\d{4}(_rus|_ukr|_eng)*$/i);

		if (match != null && match_1 != null && doc.name.substring(0, 4) != "000_") {
			var issueNumber = match[4];
			var pageNumber = (typeof match[6] != "undefined") ? match[1] : null; // ad

			var raskladkaFolderPath = raskladkaFolder.fsName + "/";
			var currentIssueRaskladkaFolder = GetCurrentIssueRaskladkaFolder(raskladkaFolder, currentIssueInddFolderName);

			if (currentIssueRaskladkaFolder == null) {
				var currentIssueRaskladkaFolderPath = raskladkaFolder  + "/" + currentIssueInddFolderName;
				currentIssueRaskladkaFolder = new Folder(currentIssueRaskladkaFolderPath);
				if (!currentIssueRaskladkaFolder.exists) {
					currentIssueRaskladkaFolder.create();
					//$.writeln("Gonna create currentIssueRaskladkaFolder!");
				}				
			}
			else {
				var currentIssueRaskladkaFolderPath = currentIssueRaskladkaFolder.absoluteURI; // fsName
			}

			doc.metadataPreferences.author = app.userName;
			//$.writeln("currentIssueRaskladkaFolderPath = " + currentIssueRaskladkaFolderPath);
			MakeJPEGfile(currentIssueRaskladkaFolderPath, pageNumber);
		}
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetCurrentIssueRaskladkaFolder(raskladkaFolder, currentIssueInddFolderName) {
	var currentIssueRaskladkaFolder = null,
	fileList = raskladkaFolder.getFiles(),
	i, file;
	
	for (i = 0; i < fileList.length; i++) {
		file = fileList[i];
		if (file instanceof Folder && file.name.search(currentIssueInddFolderName) != -1) {
			currentIssueRaskladkaFolder = file;
		}
	}

	return currentIssueRaskladkaFolder;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length > 0) {
		doc = app.activeDocument;
		
		if (!doc.converted && doc.saved) {
			var raskladkaFolder = GetRaskladkaFolder("10.44.54.70|INDISIGN|InDisign|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|X|Y|Z");

			if (raskladkaFolder != null) {
				Main(raskladkaFolder);
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetRaskladkaFolder(str) {
	var folder,
	raskladkaFolder = null;

	var list = str.split("|");

	for (var i = 0; i < list.length; i++) {
		folder = new Folder("/" + list[i] + "/Raskladka/");
		
		if (folder.exists) {
			raskladkaFolder = folder;
		}
	}

	return raskladkaFolder;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ZeroPad(num, digit) {
	var tmp = num.toString();
	while (tmp.length < digit) {
		tmp = "0" + tmp;
	}
	return tmp;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeJPEGfile(currentIssueRaskladkaFolderPath, pageNumber) { 
	var pageName, zeroPaddedPageNumber, filePath, file,
	appVersion = Number(String(app.version).split(".")[0]);
	
	app.jpegExportPreferences.exportingSpread = false;
	app.jpegExportPreferences.jpegQuality = JPEGOptionsQuality.medium; // low medium high maximum
	
	if (appVersion < 7) { // CS4 and below
		app.jpegExportPreferences.resolution = 72;
	}
	else {
		app.jpegExportPreferences.exportResolution = 72;
	}

	app.jpegExportPreferences.jpegExportRange = ExportRangeOrAllPages.exportRange; // Specifies whether a range or all pages of a document are exported.
	
	for (var i = 0; i < doc.pages.length; i++) {
		if (doc.pages.item(i).appliedSection.name != "") doc.pages.item(i).appliedSection.name = ""; // Убираем разделы из нумерации страниц, если они есть.
		
		if (pageNumber == null) {
			pageName = doc.pages[i].name;
			app.jpegExportPreferences.pageString = pageName;
		}
		else { // ad
			pageName = pageNumber;
			app.jpegExportPreferences.pageString = "1";		
		}
		
		zeroPaddedPageNumber = ZeroPad(pageName, 3);
		filePath = currentIssueRaskladkaFolderPath + "/" + ((zeroPaddedPageNumber == "001" || zeroPaddedPageNumber == "002") ? "Cover_" : "") + zeroPaddedPageNumber + ".jpg";
		//$.writeln("filePath = " + filePath);
		file = new File(filePath);
		doc.exportFile(ExportFormat.jpg, file, false);
	}
}