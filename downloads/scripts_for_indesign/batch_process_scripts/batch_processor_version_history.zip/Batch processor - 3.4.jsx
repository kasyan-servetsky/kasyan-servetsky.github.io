﻿/* Copyright 2020, Kasyan Servetsky
May 3, 2020
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var g = {   scriptName: "Batch processor - 3.4",
				appVersionNum: Number(String(app.version).split(".")[0]),
				debugMode: true,
				count: 0, // counter of processed documents
				docsFolder: null,
				scriptFile: null,
				scriptFolder: null,
				argumentsFile: null,
				openDocsList: [],
				arguments: []
			};
//===================================== FUNCTIONS  ======================================
g.Main = function() {
	var doc, inddFiles,
	startTime = new Date();
	
	g.GetArguments();

	for (var d = 0; d < app.documents.length; d++) { // get the list of open documents
		if (g.appVersionNum >= 7) { // the most reliable way to identify documents
			g.openDocsList.push(app.documents[d].id); // id is better in case a document hasn't been saved yet
		}
		else { // a workaround for CS4 and below: don't have 'id'
			try {
				if (app.documents[d].saved) {
					g.openDocsList.push(app.documents[d].decodeURI(doc.filePath));
				}
			}
			catch(err) {
				if (g.debugMode) $.writeln(err.message + ", line: " + err.line);
			}
		}
	}

	if (g.set.log && g.set.rbScript == 0) { // log -- one script
		g.WriteToFile("=========================================================\rDate & time: " + g.GetDate() + "\rRunning script: " + g.scriptFile.displayName);
	}
	else if (g.set.log && g.set.rbScript == 1) { // log -- a few scripts
		g.WriteToFile("=========================================================\rDate & time: " + g.GetDate() + "\rRunning scripts:");
		var jsxFiles = g.scriptFolder.getFiles("*.jsx");
		for (var i = 0; i < jsxFiles.length; i++) {
			g.WriteToFile(jsxFiles[i].displayName);
		}
	}

	if (g.set.rbScope == 0 || g.set.rbScope == 1) {
		if (g.set.rbScope == 0) { // active document
			doc = app.activeDocument;
			g.ProcessDocument(doc);
		}
		else if (g.set.rbScope == 1) { // all open documents
			for (var d = 0; d < app.documents.length; d++) {
				doc = app.documents[d];
				g.ProcessDocument(doc);
			}
		}
	}
	else if (g.set.rbScope == 2) { // active book
		inddFiles = g.GetFilesFromBook();
		if (inddFiles.length == 0) g.ErrorExit("Found no InDesign documents in the active book.", true);
		g.ProcessAllInddDocs(inddFiles);
	}
	else if (g.set.rbScope == 3 || g.set.rbScope == 4) {// folder, or folder with all subfolders
		inddFiles = g.GetAllInddFiles(g.docsFolder);
	
		if (inddFiles.length == 0) g.ErrorExit("Found no InDesign documents in the selected folder.", true);
		g.ProcessAllInddDocs(inddFiles);
	}
	
	var endTime = new Date();
	var duration = g.GetDuration(startTime, endTime);
	
	var report = g.count + ((g.count == 1) ? " document was" : " documents were") + " processed.\rTime elapsed: " + duration + ". ";

	if (g.set.log) {
		g.WriteToFile("\r=========================================================\r\r");
	}
	
	alert("Finished. " + report, g.scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.GetArguments = function() {
	var str, splitChar;

	if (g.set.argsSeparatorSelectedIdx == 0) { // custom
		splitChar = g.set.argsSeparator; // use \n -- not \r in the dialog box
		if (splitChar.match(/\\/) != null) {
			splitChar = eval("\"" + g.set.argsSeparator +"\"");
		}
	}
	else if (g.set.argsSeparatorSelectedIdx == 1) { // line feed
		splitChar = "\n";
	}
	else if (g.set.argsSeparatorSelectedIdx == 2) { // comma
		splitChar = ",";
	}
	else if (g.set.argsSeparatorSelectedIdx == 3) { // semicolon
		splitChar = ";";
	}
	else if (g.set.argsSeparatorSelectedIdx == 4) { // pile
		splitChar = "|";
	}
	
	if (g.argumentsFile != null) {
		var txt = g.ReadTxtFile(g.argumentsFile);
		var arr = txt.split(splitChar);

		if (arr.length > 0) {
			for (var i = 0; i < arr.length; i++) {
				str = arr[i];

				if (g.set.ignoreComments) {
					str = str.replace(/\/{2}.+$/, ""); // remove comments -- //					
					str = str.replace(/\/\*.+\*\//, ""); // remove comments -- /* */
				}

				str = str.replace(/^"/, "").replace(/"$/, ""); // remove quotes -- " "
				str = g.Trim(str); // remove whitespace from both sides of a string
				g.arguments.push(str);
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.ProcessAllInddDocs = function(inddFiles) {
	var doc, inddFile;
	
	if (g.set.log) {
		if (g.set.rbScope == 2) g.WriteToFile("Book name: " + app.activeBook.name); // log 'Active Book' name
	}

	var progressWin = g.CreateProgressBar();
	progressWin.show();
	progressWin.pb.minvalue = 0;
	progressWin.pb.maxvalue = inddFiles.length;
	
	app.scriptPreferences.userInteractionLevel = UserInteractionLevels.NEVER_INTERACT;	
	
	for (var i = 0; i < inddFiles.length; i++) {
		try {
			inddFile = inddFiles[i];
			progressWin.pb.value = (i + 1);
			progressWin.st.text = "Processing file - " + inddFile.displayName;

			if ((g.set.docType == 1 || g.set.docType == 2) && inddFile.name.match(/\.indt$/i) != null) {
				doc = app.open(inddFile, !g.set.invisibleMode, OpenOptions.OPEN_ORIGINAL);
			}
			else {
				doc = app.open(inddFile, !g.set.invisibleMode);
			}
			
			g.ProcessDocument(doc);
			
			if (g.set.saveOnClosing) {
				if (g.set.rbScope == 2 || g.set.rbScope == 3 || g.set.rbScope == 4) {
					if (g.appVersionNum >= 7 && g.GetArrayIndex(g.openDocsList, doc.id) == -1) { // if it wasn't open before running the script, save & close
						doc.close(SaveOptions.YES);
					}
					else if (g.GetArrayIndex(g.openDocsList, doc.decodeURI(doc.filePath)) == -1) { // a workaround for CS4 and below: don't have 'id'
						doc.close(SaveOptions.YES);
					}
					else { // otherwise save and don't close
						doc.save();
					}
				}
			}		
			else { // don't save on closing
				if (g.set.rbScope == 2 || g.set.rbScope == 3 || g.set.rbScope == 4) {
					if (g.appVersionNum >= 7 && g.GetArrayIndex(g.openDocsList, doc.id) == -1) { // if it wasn't open before running the script, save & close
						doc.close(SaveOptions.NO);
					} // just to be on a safe side: make sure not to close a newly created and unsaved document
					else if (doc.saved && g.GetArrayIndex(g.openDocsList, doc.decodeURI(doc.filePath)) == -1) { // a workaround for CS4 and below: don't have 'id'
						doc.close(SaveOptions.NO);
					}
				}
			}
		}  
		catch(err) {
			if (g.debugMode) $.writeln(err.message + ", line: " + err.line);
			if (err.message == "open") {
				g.WriteToFile("ERROR: Can't open the document; maybe damaged or was saved in a newer version. -- " + inddFile.displayName);
			}
			else {
				g.WriteToFile("ERROR: something went wrong. -- " + err.message + ", line: " + err.line + " -- " + inddFile.displayName);
			}
			// Don't turn on user interaction here, otherwise multiple warnings pop up
		}
	} // end For

	app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;
			
	progressWin.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.ProcessDocument = function(doc) { // Make backup and trigger script(s)
	if (doc.name.match(/^Backup/) != null) return; // Skip backups	
	if (g.set.log) g.WriteToFile("---------------------------------------------------------------------------------------------------\rDocument name: " + doc.name + "\rDocument path: " + File(doc.filePath).fsName);
	var oldDocPath = doc.filePath.absoluteURI;
	
	if (g.set.saveOnClosing && g.set.backUp) { // Create a backup copy
		var newDocFile = new File(oldDocPath + "/Backup_" + doc.name);
		
		if (newDocFile.exists) { // Don't overwrite existing files
			var increment = 1;
			while (newDocFile.exists) {
				newDocFile = new File(oldDocPath + "/Backup" + "(" + increment++ + ")_" + doc.name);
			}
		}
		doc.fullName.copy(newDocFile.absoluteURI);
	}

	g.count++;
	g.RunScripts(g.arguments);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.RunScripts = function(arguments) {
	var jsxFile;
	if (!g.set.useArguments) arguments = undefined; // if checkbox is off, don't send srguments
	
	if (g.set.rbScript == 0) { // single script
		if (g.appVersionNum >= 6) { // Version CS4 and above
			app.doScript(g.scriptFile, ScriptLanguage.JAVASCRIPT, arguments, UndoModes.ENTIRE_SCRIPT, "\"" + g.scriptName + "\" Script");
		}
		else if (g.appVersionNum == 5) { // Version CS3
			app.doScript(g.scriptFile, ScriptLanguage.JAVASCRIPT, arguments);
		}	
		else if (g.appVersionNum >= 3 && appVersion <= 4) { // Versions CS -- CS2
			app.doScript(g.scriptFile, ScriptLanguage.JAVASCRIPT);
		}
	}
	else { // set of scripts
		var jsxFiles = g.scriptFolder.getFiles("*.jsx");
	
		for (var i = 0; i < jsxFiles.length; i++) {
			jsxFile = jsxFiles[i];
			
			if (g.appVersionNum >= 6) { // Version CS4 and above
				app.doScript(jsxFile, ScriptLanguage.JAVASCRIPT, g.arguments, UndoModes.ENTIRE_SCRIPT, "\"" + g.scriptName + "\" Script");
			}
			else if (g.appVersionNum == 5) { // Version CS3
				app.doScript(jsxFile, ScriptLanguage.JAVASCRIPT, g.arguments);
			}	
			else if (g.appVersionNum >= 3 && appVersion <= 4) { // Versions CS -- CS2
				app.doScript(jsxFile, ScriptLanguage.JAVASCRIPT);
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.GetAllInddFiles = function(folder) {
	var files = [],
	fileList = folder.getFiles(),
	i, file;

	for (i = 0; i < fileList.length; i++) {
		file = fileList[i];
		if (file instanceof Folder && g.set.rbScope == 4) {
			files = files.concat(g.GetAllInddFiles(file));
		}
		else if (file instanceof File && file.name.match(/^Backup/) == null) {
			if (g.set.docType == 0 && file.name.match(/\.indd$/i)) {
//~ 				if (g.debugMode) $.writeln("Adding documents only: " + file.name);
				files.push(file);
			}
			else if (g.set.docType == 1 && file.name.match(/\.indt$/i)) {
//~ 				if (g.debugMode) $.writeln("Adding templates only: " + file.name);
				files.push(file);
			}
			else if (g.set.docType == 2 && file.name.match(/\.ind(d|t)$/i)) {
//~ 				if (g.debugMode) $.writeln("Adding both documents and templates: " + file.name);
				files.push(file);
			}
		}
	}

	return files;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.GetArrayIndex = function(arr, val) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] == val) {
			return i;
		}
	}
	return -1;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.GetFilesFromBook = function() {
	var bookContent, file, decodedPath,
	activeBook = app.activeBook,
	files = [];
	
	for (var i = 0; i < activeBook.bookContents.length; i++) {
		bookContent = activeBook.bookContents[i];
		decodedPath = decodeURI(bookContent.fullName.absoluteURI);
		
		if (bookContent.status != BookContentStatus.MISSING_DOCUMENT && bookContent.status != BookContentStatus.DOCUMENT_IN_USE) {
			file = new File(bookContent.fullName);
			files.push(file);
		}
		else if (bookContent.status == BookContentStatus.MISSING_DOCUMENT && g.set.log) {
			g.WriteToFile("ERROR: " + decodedPath + "' is missing because it has been moved, renamed, or deleted.");
		}
		else if (bookContent.status == BookContentStatus.DOCUMENT_IN_USE && g.set.log) {
			g.WriteToFile("ERROR: " + decodedPath + "' is being used by someone else and is therefore locked.");
		}
	}
	
	return files;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.CreateDialog = function() {
	var jsxFiles;
	g.GetDialogSettings();
	var isFile = (g.set.rbScript == 0) ? true : false; // file, or g.set of scripts in the folder
	if (g.scriptFolder != null) {
		jsxFiles = g.scriptFolder.getFiles("*.jsx");
	}

	var w = new Window("dialog", g.scriptName);
	w.orientation = "column";
	w.alignChildren = "fill";

	// Container
	var gc = w.add("group");
	gc.orientation = "row";
	gc.alignChildren = "top";

	// Left column group
	var gl = gc.add("group");
	gl.orientation = "column";
	gl.alignChildren = "left";
	
	// Right column group
	var gr = gc.add("group");
	gr.orientation = "column";
	gr.alignChildren = "right";
	// Left column 
	gl.p = gl.add("panel", undefined, "Process:");
	gl.p.orientation = "column";
	gl.p.alignment = "fill";
	gl.p.alignChildren = "left";

	// Scope
	gl.p.rb = gl.p.add("radiobutton", undefined, "active document");
	if (app.documents.length == 0) gl.p.rb.enabled = false;
	gl.p.rb1 = gl.p.add("radiobutton", undefined, "all open documents");
	if (app.documents.length < 2) gl.p.rb1.enabled = false;
	gl.p.rb2 = gl.p.add("radiobutton", undefined, "active book");
	if (app.books.length == 0) gl.p.rb2.enabled = false;
	gl.p.rb3 = gl.p.add("radiobutton", undefined, "documents in the selected folder");
	gl.p.rb4 = gl.p.add("radiobutton", undefined, "documents in the selected folder and its subfolders");
	gl.p.rb.onClick = gl.p.rb1.onClick = gl.p.rb2.onClick = gl.p.rb3.onClick = gl.p.rb4.onClick = function() {
		if (this.text.match(/^documents in the selected folder/) != null) {
			gr.p4.cb1.enabled = gr.p1.enabled = gl.p.ddl.enabled = true;
		}
		else if (this.text == "active book") {
			gr.p4.cb1.enabled = true;
			gr.p1.enabled = gl.p.ddl.enabled = false;
		}
		else {
			gr.p4.cb1.enabled = gr.p1.enabled = gl.p.ddl.enabled = false;
		}
	}

	gl.p.ddl = gl.p.add("dropdownlist", undefined, ["Documents only (indd-files)", "Templates only (indt-files)", "Documents & Templates (indd & indt files)"]);
	gl.p.ddl.selection = g.set.docType;
	gl.p.ddl.alignment = "fill";

	if (g.set.rbScope == 0 && app.documents.length != 0) { // active document
		gl.p.rb.value = true;
		gl.p.ddl.enabled = false;
	}
	else if (g.set.rbScope == 1 && app.documents.length > 1) { // all open documents
		gl.p.rb1.value = true;
		gl.p.ddl.enabled = false;
	}
	else if (g.set.rbScope == 2 && app.books.length != 0) { // active book
		gl.p.rb2.value = true;
		gl.p.ddl.enabled = false;
	}
	else if (g.set.rbScope == 3) { // documents in the selected folder
		gl.p.rb3.value = gl.p.ddl.enabled = true;
	}
	else  { // documents in the selected folder and its subfolders
		gl.p.rb4.value = gl.p.ddl.enabled = true;
	}

	// What to run: a script or g.set of scripts
	gl.p2 = gl.add("panel", undefined, "What to run:");
	gl.p2.alignChildren = "left";
	gl.p2.alignment = "fill";
	gl.p2.rb = gl.p2.add("radiobutton", undefined, "single script");
	gl.p2.rb.onClick = UpdateScriptPanel;
	gl.p2.rb1 = gl.p2.add("radiobutton", undefined, "set of scripts");
	gl.p2.rb1.onClick = UpdateScriptPanel;

	function UpdateScriptPanel() { // clicking a radio button switches between "scipt" and "g.set of scripts"
		var fileObj;

		if (this.text == "single script") {
			isFile = true;
			fileObj = g.scriptFile;
			gl.p3.text = "Script:";
			
			if (fileObj == undefined || !fileObj.exists) {
				gl.p3.st.text = "No file has been selected";
			}
		}
		else {
			isFile = false;
			fileObj = g.scriptFolder;
			gl.p3.text = "Folder with scripts:";
			
			if (fileObj == undefined || !fileObj.exists) {
				gl.p3.st.text = "No folder has been selected";
			}
		}
		
		UpdateWindow(fileObj, gl.p3);
	}
	
	if (isFile) {
		gl.p2.rb.value = true;
	}
	else  {
		gl.p2.rb1.value = true;
	}
	
	var fileObj = (isFile) ? g.scriptFile : g.scriptFolder;
	
	// Scripts folder or a script panel
	gl.p3 = gl.add("panel", undefined, ((isFile) ? "Script:": "Folder with scripts:"));
	gl.p3.alignment = "fill";
	gl.p3.st = gl.p3.add("statictext");
	gl.p3.st.alignment = "left"; // center

	if (fileObj == undefined || !fileObj.exists) {
		gl.p3.st.text = "No " + ((isFile) ? "file": "folder") + " has been selected";
	}
	else {
		gl.p3.st.text = g.TrimPath(fileObj.fsName);
		gl.p3.st.helpTip = fileObj.fsName;
	}

	gl.p3.bt = gl.p3.add("button", undefined, "Select ...");
	gl.p3.bt.onClick = SelectScript;
	
	function SelectScript() {
		if (isFile) {
			g.scriptFile = File.openDialog("Pick a script", "*.jsx");
			if (g.scriptFile != null) {
				UpdateWindow(g.scriptFile, gl.p3);
			}
		}
		else {
			g.scriptFolder = Folder.selectDialog("Pick a folder with scripts");
			
			if (g.scriptFolder != null) {
				jsxFiles = g.scriptFolder.getFiles("*.jsx");
				if (jsxFiles.length == 0) {
					alert("There are no scripts in the selected folder.", g.scriptName, true);
					g.scriptFolder = null;
					gl.p3.st.text = "No " + ((isFile) ? "file": "folder") + " has been selected";
				}
				else {
					UpdateWindow(g.scriptFolder, gl.p3);
				}
			}
		}
	}
//====================================   Right column   =====================================================
	// Documents folder
	gr.p1 = gr.add("panel", undefined, "Documents folder:");
	gr.p1.alignment = "fill";
	gr.p1.st = gr.p1.add("statictext");
	gr.p1.st.alignment = "left";
	if (g.docsFolder == null || !g.docsFolder.exists) { 
		gr.p1.st.text = "No folder has been selected";
	}
	else {
		gr.p1.st.text = g.TrimPath(g.docsFolder.absoluteURI);
		gr.p1.st.helpTip = g.docsFolder.fsName;
	}
	gr.p1.bt = gr.p1.add("button", undefined, "Select ...");
	gr.p1.bt.onClick = function() {
		g.docsFolder = g.SelectFolder(this, "Pick a folder with documents.");
	}

	if (gl.p.rb3.value || gl.p.rb4.value) {
		gr.p1.enabled = true;
	}
	else {
		gr.p1.enabled = false;
	}

	// Settings panel
	gr.p4 = gr.add("panel", undefined, "Settings:");
	gr.p4.alignChildren = "left";
	gr.p4.alignment = "fill";
	
	// Check boxes
	gr.p4.cb = gr.p4.add("checkbox", undefined, "Create log file on the desktop");
	gr.p4.cb.alignment = "left";
	gr.p4.cb.value = g.set.log;
	
	gr.p4.cb1 = gr.p4.add("checkbox", undefined, "Save documents on closing");
	gr.p4.cb1.alignment = "left";
	gr.p4.cb1.value = g.set.saveOnClosing;
	gr.p4.cb1.helpTip = "Saves documents before closing. Works only for documents in the selected folder. The documents that have already been opened before running the script will be saved and remain open.";
	gr.p4.cb1.onClick = function() {
		if (this.value) {
			gr.p4.cb2.enabled = true;
		}
		else {
			gr.p4.cb2.enabled = false;
		}
	}

	if (gl.p.rb2.value || gl.p.rb3.value || gl.p.rb4.value) {
		gr.p4.cb1.enabled = true;
	}
	else {
		gr.p4.cb1.enabled = false;
	}
	
	gr.p4.cb2 = gr.p4.add("checkbox", undefined, "Backup original InDesign documents");
	gr.p4.cb2.alignment = "left";
	gr.p4.cb2.value = g.set.backUp;
	if (!g.set.saveOnClosing) {
		gr.p4.cb2.enabled = false;
	}

	gr.p4.cb3 = gr.p4.add("checkbox", undefined, "Open in invisible mode");
	gr.p4.cb3.alignment = "left";
	gr.p4.cb3.value = g.set.invisibleMode;
	gr.p4.cb3.helpTip = "If on, the document is opened but is not displayed in a window. This may result in a better performance.";

	// Arguments panel
	gr.p5 = gr.add("panel", undefined, "Arguments file (optonal):");
	gr.p5.alignment = "fill";
	
	if (g.appVersionNum >= 5) {
		gr.p5.cb = gr.p5.add("checkbox", undefined, "Use arguments");
		gr.p5.cb.alignment = "left";
		gr.p5.cb.value = g.set.useArguments;
		gr.p5.cb.onClick = function() {
			if (this.value) {
				gr.p5.cb1.enabled = gr.p5.g.enabled = gr.p5.st.enabled = gr.p5.bt.enabled = true;
			}
			else {
				gr.p5.cb1.enabled = gr.p5.g.enabled = gr.p5.st.enabled = gr.p5.bt.enabled = false;
			}
		}

		gr.p5.cb1 = gr.p5.add("checkbox", undefined, "Ignore comments");
		gr.p5.cb1.alignment = "left";
		gr.p5.cb1.value = g.set.ignoreComments;
		
		gr.p5.g = gr.p5.add("group");
		gr.p5.g.orientation = "row";
		gr.p5.g.alignment = "left";
		
		gr.p5.g.st = gr.p5.g.add("statictext", undefined, "Separator:");
		gr.p5.g.st.alignment = "left";

		var separatorList = ["Custom", "\\n (Line feed)", ", (Comma)", "; (Semicolon)", "| (Pile)"];
		gr.p5.g.ddl = gr.p5.g.add("dropdownlist", undefined, separatorList);
		gr.p5.g.ddl.selection = g.set.argsSeparatorSelectedIdx;
		gr.p5.g.ddl.onChange = UpdateEditText;
	
		function UpdateEditText() {
			if (gr.p5.g.ddl.selection == 0) {
				gr.p5.g.et.text = g.set.argsSeparator;
			}
			else if (gr.p5.g.ddl.selection == 1) {
				gr.p5.g.et.text = "\\n";
			}
			else if (gr.p5.g.ddl.selection == 2) {
				gr.p5.g.et.text = ",";
			}
			else if (gr.p5.g.ddl.selection == 3) {
				gr.p5.g.et.text = ";";
			}		
			else if (gr.p5.g.ddl.selection == 4) {
				gr.p5.g.et.text = "|";
			}

			if (gr.p5.g.ddl.selection != 0) {
				gr.p5.g.et.enabled = false;
			}
			else {
				gr.p5.g.et.enabled = true;
			}
		}

		gr.p5.g.et = gr.p5.g.add("edittext", undefined, g.set.argsSeparator);
		gr.p5.g.et.minimumSize = [20, undefined];
		gr.p5.g.et.minimumSize.width = 40; // characters = 3
		gr.p5.g.et.onChange = function() {
			if (this.text.replace(/\s+/g, "") == "") {
				alert("You left the 'Separator' text edit field empty; restoring it to the previous value.", g.scriptName, true);
				this.text = g.set.argsSeparator;
				return;
			}
		}
		
		UpdateEditText();

		gr.p5.p = gr.p5.add("panel", undefined, ""); // separator line
		gr.p5.p.alignment = "fill";

		gr.p5.st = gr.p5.add("statictext");
		gr.p5.st.alignment = "left";

		if (g.argumentsFile == undefined || !g.argumentsFile.exists) {
			gr.p5.st.text = "No arguments file has been selected";
		}
		else {
			gr.p5.st.text = g.TrimPath(g.argumentsFile.fsName);
			gr.p5.st.helpTip = g.argumentsFile.fsName;
		}

		gr.p5.bt = gr.p5.add("button", undefined, "Select ...");
		gr.p5.bt.onClick = SelectArgumentsFile;

		function SelectArgumentsFile() {
			g.argumentsFile = File.openDialog("Pick an arguments file", "*.txt");
			if (g.argumentsFile != null) {
				UpdateWindow(g.argumentsFile, gr.p5);
			}
		}

		if (g.set.useArguments) {
			gr.p5.cb1.enabled = gr.p5.g.enabled = gr.p5.st.enabled = gr.p5.bt.enabled = true;
		}
		else {
			gr.p5.cb1.enabled = gr.p5.g.enabled = gr.p5.st.enabled = gr.p5.bt.enabled = false;
		}
	}
	else {
		gr.p5.preferredSize.height = 140;
		gr.p5.orientation = "column";
		gr.p5.alignChildren = ["center", "center"];
		gr.p5.st = gr.p5.add("statictext", undefined, "In InDesign CS3 and below the arguments feature is unavailable", {multiline: true});
	}

	function UpdateWindow(fileObj, panel) {
		if (fileObj != null && fileObj.exists) {
			panel.remove(panel.st);
			panel.remove(panel.bt);
			panel.st = panel.add("statictext");
			panel.st.text = g.TrimPath(fileObj.fsName);
			panel.st.helpTip = fileObj.fsName;
			panel.bt = panel.add("button", undefined, "Select ...");
			panel.bt.onClick = SelectScript;
			w.layout.layout(true);
		}
	}

	// Buttons
	w.gb = w.add("group");
	w.gb.orientation = "row";
	w.gb.alignment = "center";
	w.gb.ok = w.gb.add("button", undefined, "OK", {name: "ok" });
	w.gb.ok.onClick = function() { // Use 'children[0]' because the panel is dynamically rebuilt on selecting a new folder so the original references become invalid
		if ((gl.p.rb3.value || gl.p.rb4.value) && gr.p1.children[0].text == "No folder has been selected") {
			alert("No 'Documents' folder has been selected.", g.scriptName, true);
			return;
		}
		else if (gr.p5.cb.value && gr.p5.children[3].text == "No arguments file has been selected") {
			alert("No arguments file has been selected.", g.scriptName, true);
			return;
		}
		else if (isFile) { // File
			if (g.scriptFile == null) {
				alert("No script has been selected", g.scriptName, true);
				return;
			}
			else if (!g.scriptFile.exists) {
				alert("Script '" + g.scriptFile.displayName + "' doesn't exist.", g.scriptName, true);
				return;
			}
		}
		else if (!isFile) { // Folder
			if (g.scriptFolder == null) {
				alert("No scripts folder has been selected", g.scriptName, true);
				return;
			}
			else if (!g.scriptFolder.exists) {
				alert("Folder '" + g.scriptFolder.displayName + "' doesn't exist.", g.scriptName, true);
				return;
			}
			else if (jsxFiles == undefined || jsxFiles.length == 0) {
				alert("There are no scripts in the scripts folder.", g.scriptName, true);
				return;
			}
		}

		w.close(1); // If we've reached here, everythin's OK
	}

	w.gb.cancel = w.gb.add("button", undefined, "Cancel", {name: "cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		if (gl.p.rb.value == true) { // active document
			g.set.rbScope = 0;
		}
		else if (gl.p.rb1.value == true) { // all open documents
			g.set.rbScope = 1;
		}
		else if (gl.p.rb2.value == true) { // active book
			g.set.rbScope = 2;
		}
		else if (gl.p.rb3.value == true) { // documents in the selected folder
			g.set.rbScope = 3;
		}
		else if (gl.p.rb4.value == true) { // documents in the selected folder and its subfolders
			g.set.rbScope = 4;
		}

		g.set.docType = gl.p.ddl.selection.index;

		if (gl.p2.rb.value == true) { // A script file
			g.set.rbScript = 0;
		}
		else if (gl.p2.rb1.value == true) { // A folder of script files
			g.set.rbScript = 1;
		}
	
		if (g.scriptFile instanceof File) {
			g.set.scriptFilePath = g.scriptFile.fsName;
		}
		else {
			g.set.scriptFilePath = "";
		}
	
		if (g.scriptFolder instanceof Folder) {
			g.set.scriptFolderPath = g.scriptFolder.fsName;
		}
		else {
			g.set.scriptFolderPath = "";
		}

		g.set.docsFolderPath = (g.docsFolder != null) ? g.docsFolder.absoluteURI : ""; // if selected, remember the path; if not, empty string. e.g. for active doc we don't need this

		// Settings panel
		g.set.log = gr.p4.cb.value;
		g.set.saveOnClosing = gr.p4.cb1.value;
		g.set.backUp = gr.p4.cb2.value;
		g.set.invisibleMode = gr.p4.cb3.value;

		// Arguments panel
		g.set.useArguments = gr.p5.cb.value;
		g.set.ignoreComments = gr.p5.cb1.value;
		
		if (g.argumentsFile instanceof File) {
			g.set.argsFilePath = g.argumentsFile.fsName;
		}
		else {
			g.set.argsFilePath = "";
		}

		g.set.argsSeparatorSelectedIdx = gr.p5.g.ddl.selection.index;
		
		if (gr.p5.g.ddl.selection.index == 0) {
			g.set.argsSeparator = g.Trim(gr.p5.g.et.text);
		}
		
		var tmp = g.set;
		app.insertLabel("Kas_" + g.scriptName, g.set.toSource());
		
		g.Main();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.GetDialogSettings = function() {
	g.set = eval(app.extractLabel("Kas_" + g.scriptName));
	
	if (g.set == undefined) {
		g.set = {    rbScope: 0, docType: 0, rbScript: 0, docsFolderPath: "", scriptFilePath: "", scriptFolderPath: "", 
						useArguments: false, ignoreComments: true, argsFilePath: "", argsSeparatorSelectedIdx: 1, argsSeparator: ",",
						log: true, backUp: true, saveOnClosing: false, invisibleMode: false
					};
	}

	g.docsFolder = new Folder(g.set.docsFolderPath);
	if (!g.docsFolder.exists) {
		g.docsFolder = null;
	}

	g.scriptFile = new File(g.set.scriptFilePath);
	if (!g.scriptFile.exists) {
		g.scriptFile = null;
	}

	g.scriptFolder = new Folder(g.set.scriptFolderPath);
	if (!g.scriptFolder.exists) {
		g.scriptFolder = null;
	}

	g.argumentsFile = new File(g.set.argsFilePath);
	if (!g.argumentsFile.exists) {
		g.argumentsFile = null;
	}

	var tmp = g.set;
	
	return g.set;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.CreateProgressBar = function() {
	var w = new Window("window", g.scriptName);
	w.pb = w.add("progressbar", [12, 12, 350, 24], 0, undefined);
	w.st = w.add("statictext");
	w.st.bounds = [0, 0, 340, 20];
	w.st.alignment = "left";
	return w;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.GetDuration = function(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.GetDate = function() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.SelectFolder = function(button, prompt) {
	var folder = Folder.selectDialog(prompt);
	
	if (folder != null) {
		var panel = button.parent;
		var window = panel.parent;
		var children = panel.children;
		var staticText = children[0];
		var button = button;
		panel.remove(staticText);
		panel.remove(button);
		staticText = panel.add("statictext", undefined, g.TrimPath(folder.absoluteURI));
		staticText.helpTip = folder.absoluteURI;
		button = panel.add("button", undefined, "Select ...");
		button.onClick = function() {
			g.SelectFolder(this);
		}
		window.layout.layout(true);
		return folder;		
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.TrimPath = function(path) {
	var theFile = new File(path);
	if (File.fs == "Macintosh") {
		var trimPath = "..." + theFile.fsName.split("/").splice(-3).join("/");
	}
	else if (File.fs == "Windows" ) {
		var trimPath = ((theFile.fsName.split("\\").length > 3) ? "...\\" : "") + theFile.fsName.split("\\").splice(-3).join("\\");
	}
	return trimPath;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.Trim = function(str) { // removes whitespace from both sides of a string
	return str.replace(/^\s+|\s+$/gm, "");
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.ReadTxtFile = function(file) {
	file.open("r"); 
	var txt = file.read();
	file.close();
	return txt;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.WriteToFile = function(text) {
	var file = new File("~/Desktop/" + g.scriptName + ".txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text + "\r"); 
	file.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
g.ErrorExit = function(error, icon) {
	alert(error, g.scriptName, icon);
	exit();
}
//======================================================================================
g.CreateDialog();
//======================================================================================
/* 
PROBLEMS:
1) empty separator text field on close

TO DO LIST:
1) Make correct order numbers in groups in the dialog box
*/