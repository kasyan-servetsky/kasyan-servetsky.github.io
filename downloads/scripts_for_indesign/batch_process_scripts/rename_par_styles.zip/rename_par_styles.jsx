﻿main();

function main() {
	try { // if something goes wrong in the try-catch block, the batch processor won't stop here. It will log the error message and continue further	
		var parStylesList = [
			["H1", "BKRM_H1"], // [ "find this", "change to this" ]
			["H2", "BKRM_H2"],
			["H3", "BKRM_H3"],
			["H4", "BKRM_H4"],
			["TXT", "BKRM_TXT"],
			["TXT_IN", "BKRM_TXT_IN"] // no comma after the last element!
		];	
		
		var paragraphStyle, characterStyle,
		doc = app.activeDocument, // The frontmost document
		paragraphStyles = doc.allParagraphStyles;
		
		// Change in paragraph styles
		for (var p = 2; p < paragraphStyles.length; p++) {
			paragraphStyle = paragraphStyles[p];
			for (var i = 0; i < parStylesList.length; i++) {
				if (paragraphStyle.name == parStylesList[i][0]) {
					paragraphStyle.name = parStylesList[i][1];
				}
			}
		}
	}
	catch(err) { // if an error occurs, catch it and write the  document's name, error message and line# where it happened into the log
		gErrorLog.push(doc.name + " - " + err.message + ", line: " + err.line);
	}
}