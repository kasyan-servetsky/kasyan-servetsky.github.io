﻿/* Copyright 2022, Kasyan Servetsky
July 27, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com
Version 2.0 */
//======================================================================================
var scriptName = "Change fonts CSV",
doc,
debugMode = true, // for debugging only
args = [],
calledFromBatchProcessor = CalledFromBatchProcessor();

if (calledFromBatchProcessor) { // called as a 'secondary' script from the batch processor
	if (g.doc != null) { // If the script is called from the batch processor and the g.doc variable is sent from it, the doc variable is set to g.doc.
		doc = g.doc; // With the all open documents option selected, make sure to use g.doc variable to send the current document from the batch processor to this script otherwise, it will not work correctly.
		Main();
	}
}
else { // called as a 'regular' script
//~ 	PreCheck();
	app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	try { // if something goes wrong in the try-catch block, the batch processor won't stop here. It will log the error message and continue further
		var oldFont, newFont, paragraphStyle, characterStyle, changed, report,
		doc = app.activeDocument, // The frontmost document
		paragraphStyles = doc.allParagraphStyles,
		characterStyles = doc.allCharacterStyles,
		scriptFile = GetActiveScript(),
		scriptFilePath = scriptFile.absoluteURI,
		csvFilePath = scriptFilePath.replace(scriptFile.name, "Change fonts list.csv"),
		csvFile = new File(csvFilePath),
		countParStyles = countCharStyles = countLocals = 0;

		if (!csvFile.exists) {
			(calledFromBatchProcessor) ? g.WriteToFile("No CSV-file. Exiting.") : $.writeln("No CSV-file. Exiting.");
			exit();
		}

		var fontList = ReadCsvData(csvFile);

		// Change in paragraph styles
		for (var p = 1; p < paragraphStyles.length; p++) {
			paragraphStyle = paragraphStyles[p];
			newFont = GetNewFont(paragraphStyle.appliedFont.name, fontList);
			if (newFont != null) {
				paragraphStyle.appliedFont = newFont;
				countParStyles++;
			}
		}

		// Change in character styles
		for (var c = 1; c < characterStyles.length; c++) {
			characterStyle = characterStyles[c];
			newFont = GetNewFont(characterStyles[c].appliedFont + "\t" + characterStyles[c].fontStyle, fontList);
			if (newFont != null) {
				characterStyles[c].appliedFont = newFont;
				countCharStyles++;
			}
		}
	
		with (app.findChangeTextOptions) {
			includeMasterPages = true;
			includeHiddenLayers = true;
			includeLockedLayersForFind = true;
			includeLockedStoriesForFind = true;
			includeFootnotes = true;
			wholeWord = false;
			caseSensitive = false;
		}

		for (var i = 0; i < fontList.length; i++) {
			app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
			oldFont = app.fonts.itemByName(fontList[i][0]);
			(calledFromBatchProcessor) ? g.WriteToFile(i + " - oldFont: " + fontList[i][0]  + " - is valid = " + oldFont.isValid) : $.writeln("-----------\n" + i + " - oldFont: " + fontList[i][0]  + " - is valid = " + oldFont.isValid);

			newFont = GetNewFont(fontList[i][0], fontList);
			if (oldFont != null && newFont != null) {
				(calledFromBatchProcessor) ? g.WriteToFile("newFont is OK: " + newFont.name) : $.writeln("newFont is OK: " + newFont.name);
				app.findTextPreferences.appliedFont = oldFont;
				app.changeTextPreferences.appliedFont = newFont;
				changed = doc.changeText();
				(calledFromBatchProcessor) ? g.WriteToFile("changed.length = " + changed.length) : $.writeln("changed.length = " + changed.length);
				countLocals += changed.length;
				app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
			}
		}

		if (countParStyles == 0 && countCharStyles == 0 && countLocals == 0) {
			report = "No changes have been made to the document.";
		}
		else {
			report = "Changed fonts in " + countParStyles + " paragraph style" + ((countParStyles == 1)  ? ", " : "s, ") + countCharStyles + " character style" + ((countCharStyles == 1)  ? "," : "s,") + " and " + countLocals + " instance"  + ((countLocals == 1)  ? "" : "s") + " of locally formatted text.";
		}
	
		(calledFromBatchProcessor) ? g.WriteToFile(report) : $.writeln(report);
	}
	catch(err) { // if an error occurs, catch it and write the  document's name, error message and line# where it happened into the log
		if (calledFromBatchProcessor) {
			g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", Line: " + err.line + ", Time: " + GetTime());
		}
		else if (debugMode) {
			$.writeln(err.message + ", line: " + err.line); // in debugMode -- write the error message and line# to ESTK console
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetNewFont(oldFontName, fontList) {
	var newFontName,
	newFont = null;

	for (var p = 0; p < fontList.length; p++) {
		newFontName = fontList[p][1];

		if (oldFontName == fontList[p][0]) {
			newFont = app.fonts.itemByName(newFontName);

			if (!newFont.isValid) {
				newFont = null;
				(calledFromBatchProcessor) ? g.WriteToFile(fontList[p][1] + " - Font isn't installed.") : $.writeln(fontList[p][1] + " - Font isn't installed.");
			}

			break;
		}
	}

	return newFont;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ReadCsvData(csvFile) {
	var line, temp, csvRecord, tempArr;
	var csvData = [];
	csvFile.open("r");
	
	while (!csvFile.eof) { 
		line = csvFile.readln();
		if (line == "") continue; // skip empty lines
		tempArr = line.split(";");
		if (tempArr[0] == "" || tempArr[1] == "") continue; // skip if one element is empty
		
		csvData.push([
							eval("\"" + tempArr[0] + "\""), // A -- Find
							eval("\"" + tempArr[1]+ "\"") // B -- Change to
							]);
	}

	csvFile.close();
	
	return csvData;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetActiveScript() {
    try {
        return app.activeScript;
    }
    catch(err) {
        return new File(err.fileName);
    }
}
//=======================================================================================
function GetTime() { // get exact time for the log -- hr : min : sec -- so we could know when exactly an error occured
	var date = new Date();
	var dateString = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CalledFromBatchProcessor() { // Let's see if it's called as a 'secondary' (returns true) or as a 'regular' (returns false) script
	var result = false;
	
	try {
		var arr = $.stack.split(/[\n]/);
		if (arr.length > 0 && arr[0].match(/\[Batch processor/i) != null) {
			result = true;
		}
	}
	catch(err) {}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) { // Something went totally wrong.
	alert(error, scriptName, icon); // Give a warning
	exit(); // and stop the script
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------