﻿main();

function main() {
	var doc = app.activeDocument;
	var masterSpread = doc.masterSpreads.itemByName("P-Portrait");
	
	if (masterSpread.isValid) {
		processMasterSpread(masterSpread);
	}

	masterSpread = doc.masterSpreads.itemByName("L-Landscape");
	
	if (masterSpread.isValid) {
		processMasterSpread(masterSpread);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function processMasterSpread(masterSpread) {
	try {
		var allPageItems, frameFittingOptions,
		allPageItems = masterSpread.allPageItems;
		
		for (var i = 0; i < allPageItems.length; i++) {
			pageItem = allPageItems[i];
		
			if (pageItem instanceof Polygon && pageItem.rectangles.length == 1 && pageItem.rectangles[0].label != "") {
				pageItem = pageItem.rectangles[0];
			}
			
			if (pageItem instanceof Rectangle && pageItem.label != "") {
				pageItem.clearFrameFittingOptions();
				frameFittingOptions = pageItem.frameFittingOptions;

				with (frameFittingOptions) {
					autoFit = true;
					fittingAlignment = AnchorPoint.CENTER_ANCHOR;
					fittingOnEmptyFrame = EmptyFrameFittingOptions.FILL_PROPORTIONALLY;
					leftCrop = rightCrop = topCrop = bottomCrop = "2 mm";
				}
			}
		}
	}
	catch(err) {
		g.WriteToFile("ERROR: " + err.message + ", line: " + err.line);
	}
}