﻿main();

function main() {
	try {
		var link,
		doc = app.activeDocument,
		links = doc.links;
		
		for (var i = links.length - 1; i >= 0; i--) {
			link = links[i];
			if (link.status == LinkStatus.LINK_OUT_OF_DATE) {
				link.update();
			}
		}
	}
	catch(err) {
		g.WriteToFile(doc.name + " - " + err.message + ", line: " + err.line);
	}
}