﻿main();

function main() {
	try {
		// The frontmost document
		var doc = app.activeDocument;
		// idml file will be created in the same folder as the indd-file: the file path remains the same -- only extension is changed
		var file = new File(doc.fullName.absoluteURI.replace(/indd$/, "idml"));
		// Export to idml
		doc.exportFile(ExportFormat.INDESIGN_MARKUP, file, false);
	}
	catch(err) {
		// If an error occurs, an error message and the line number where it happens is logged
		g.WriteToFile(doc.name + " - " + err.message + ", line: " + err.line);
	}
}