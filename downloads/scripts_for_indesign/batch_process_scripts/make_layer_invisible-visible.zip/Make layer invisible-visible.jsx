﻿main();

function main() {
	// The frontmost document
	var doc = app.activeDocument;
	// Get the layer by name
	var layer = doc.layers.itemByName("Layer 1");
	if (layer.isValid) { // If the layer exists, go on
		layer.visible = false; // true -- make visible; false -- make invisible
	}
}