Set theApp = CreateObject("InDesign.Application")
Set theDoc = theApp.ActiveDocument
Set thePage = theDoc.Pages.Add