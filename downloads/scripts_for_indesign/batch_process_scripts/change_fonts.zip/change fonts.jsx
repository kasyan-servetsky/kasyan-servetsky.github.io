﻿var fontList = [
	["Minion Pro\tRegular", "Myriad Pro\tRegular"],
	["Minion Pro\tBold", "Myriad Pro\tBold"],
	["Minion Pro\tItalic", "Myriad Pro\tItalic"],
	["Minion Pro\tBold Italic", "Myriad Pro\tBold Italic"]
];
	
main();

function main() {
	try { // if something goes wrong in the try-catch block, the batch processor won't stop here. It will log the error message and continue further
		
		var newFont, paragraphStyle, characterStyle,
		doc = app.activeDocument, // The frontmost document
		paragraphStyles = doc.allParagraphStyles,
		characterStyles = doc.allCharacterStyles;
		
		// Change in paragraph styles
		for (var p = 1; p < paragraphStyles.length; p++) {
			paragraphStyle = paragraphStyles[p];
			newFont = getNewFont(paragraphStyle.appliedFont.name);
			if (newFont != null) {
				paragraphStyle.appliedFont = newFont;
			}
		}

		// Change in character styles
		for (var c = 1; c < characterStyles.length; c++) {
			characterStyle = characterStyles[c];
			newFont = getNewFont(characterStyles[c].appliedFont + "\t" + characterStyles[c].fontStyle);
			if (newFont != null) {
				characterStyles[c].appliedFont = newFont;
			}
		}
		
		with (app.findChangeTextOptions) {
			includeMasterPages = true;
			includeHiddenLayers = true;
			includeLockedLayersForFind = true;
			includeLockedStoriesForFind = true;
			includeFootnotes = true;
			wholeWord = false;
			caseSensitive = false;
		}
		
		for (var i = 0; i < fontList.length; i++) {
			var changed;
			app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
			app.findTextPreferences.appliedFont = fontList[i][0];
			app.changeTextPreferences.appliedFont = fontList[i][1];
			changed = doc.changeText();
			app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
		}

	}
	catch(err) { // if an error occurs, catch it and write the  document's name, error message and line# where it happened into the log
		g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", line: " + err.line);
	}
}

function getNewFont(oldFontName) {
	var newFont = null;
	
	for (var p = 0; p < fontList.length; p++) {
		if (oldFontName == fontList[p][0]) {
			newFont = app.fonts.itemByName(fontList[p][1]);
			if (!newFont.isValid) {
				newFont = null;
			}
			break;
		}
	}

	return newFont;
}