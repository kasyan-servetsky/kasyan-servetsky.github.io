﻿main();

function main() {
	try {
		// The frontmost document
		var doc = app.activeDocument;
		// PDF-preset name -- replace it with the preset name exacty as you see it in InDesign
		var pdfPreset = app.pdfExportPresets.itemByName("[High Quality Print]");
		// PDF file will be created in the same folder as the indd-file: the file path remains the same -- only extension is changed
		var pdfFile = new File(doc.fullName.absoluteURI.replace(/indd$/, "pdf"));
		// Export to PDF in foreground
		doc.exportFile(ExportFormat.PDF_TYPE, pdfFile, false, pdfPreset);
		// If everything goes as expected, the document name and + " – Successfully exported" is added to the log
		g.WriteToFile(doc.name + " -- Successfully exported");
	}
	catch(err) {
		// If an error occurs, an error message and the line number where it happens is logged
		g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", line: " + err.line);
	}
}