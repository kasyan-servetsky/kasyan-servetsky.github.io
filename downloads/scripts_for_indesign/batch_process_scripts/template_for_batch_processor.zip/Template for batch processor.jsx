﻿// Global variables are defined here
var scriptName = "Script name",
doc,
debug = false, // for debugging only
args = [],
calledFromBatchProcessor = CalledFromBatchProcessor();

if (calledFromBatchProcessor) { // called as a 'secondary' script from the batch processor
	if (typeof g.arguments != "undefined") {
		args = NormalizeArgs(g.arguments);
	}
	
	if (g.doc != null) { // If the script is called from the batch processor and the g.doc variable is sent from it, the doc variable is set to g.doc.
		doc = g.doc; // With the all open documents option selected, make sure to use g.doc variable to send the current document from the batch processor to this script otherwise, it will not work correctly.
		Main();
	}
	else { // If something goes wrong, though it’s hardly possible, the error message is written to the log
		g.WriteToFile("ERROR: 'g.doc == null' - Failed to get the document to process.");
	}
}
else { // called as a 'regular' script
	PreCheck();
	// To undo/redo the whole script, call the 'PreCheck' function via 'doScript' method	
	// app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
}

//===================================== FUNCTIONS =======================================
function Main() {
	try {
		var myParameter = "My default value";
		
		if (calledFromBatchProcessor) {
			if (args.length == 0 || // check if we have at least one valid argument
				typeof args[0] === "undefined" ||
				args[0] === null ||
				args[0] === "") // empty string
			{
				myParameter += " - no argument(s) arrived"; // set a default value
			}
			else {
				myParameter = args[0];
			}
		}

		// Do something here
		// For example, display/log the first argument being sent, or the default value if arguments aren’t used.
		if (calledFromBatchProcessor) {
			g.WriteToFile(myParameter);
		}
		else {
			alert(myParameter, scriptName, false);
		}
	}
	catch(err) { // if an error occurs
		if (calledFromBatchProcessor) { // catch it and write the document's name, error message and line# where it happened into the log
			g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", Line: " + err.line + ", Time: " + GetTime());
		}
		else { // executed as a 'regular' script
			if (debug) { // in debug mode -- write the error message and line# to ESTK console
				$.writeln(err.message + ", line: " + err.line);
			}
			else { // give a warning
				alert(err.message + ", line: " + err.line, scriptName, true);
			}
		}
	}
}
//=======================================================================================
function GetTime() { // get exact time for the log -- hr : min : sec -- so we could know when exactly an error occured
	var date = new Date();
	var dateString = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CalledFromBatchProcessor() { // Let's see if it's called as a 'secondary' (returns true) or as a 'regular' (returns false) script
	var result = false;
	
	try {
		var arr = $.stack.split(/[\n]/);
		if (arr.length > 0 && arr[0].match(/\[Batch processor/i) != null) {
			result = true;
		}
	}
	catch(err) {}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function NormalizeArgs(args) { // convert a string value read from the arguments file to actual boolen data type (or undefined)
	for (var i = 0; i < args.length; i++) {
		if (args[i] == "true" || args[i] == "false" || args[i] == "undefined" || args[i] == "null") {
			args[i] = eval(args[i]);
		}
	}

	return args;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) { // Something went totally wrong.
	alert(error, scriptName, icon); // Give a warning
	exit(); // and stop the script
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------