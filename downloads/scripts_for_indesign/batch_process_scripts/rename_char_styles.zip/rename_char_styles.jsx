﻿main();

function main() {
	try { // if something goes wrong in the try-catch block, the batch processor won't stop here. It will log the error message and continue further	
		var charStylesList = [
			["A", "C"],
			["B", "D"] // no comma after the last element!
		];
		
		var characterStyle,
		doc = app.activeDocument, // The frontmost document
		characterStyles = doc.allCharacterStyles;

		// Change in character styles
		for (var c = 1; c < characterStyles.length; c++) {
			characterStyle = characterStyles[c];
			for (var j = 0; j < charStylesList.length; j++) {
				if (characterStyle.name == charStylesList[j][0]) {
					characterStyle.name = charStylesList[j][1];
				}
			}
		}
	}
	catch(err) { // if an error occurs, catch it and write the  document's name, error message and line# where it happened into the log
		g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", line: " + err.line);
	}
}