﻿var doc = app.activeDocument;
updateAllOutdatedLinks();

function updateAllOutdatedLinks() {
	var link;
	for (var i = doc.links.length - 1; i >= 0; i--) {
		link = doc.links[i];
		if (link.status == LinkStatus.LINK_OUT_OF_DATE) link.update();
	}
}