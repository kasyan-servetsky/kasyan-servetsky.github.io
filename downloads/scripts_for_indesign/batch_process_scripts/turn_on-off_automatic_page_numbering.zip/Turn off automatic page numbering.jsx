﻿var section,
doc = app.activeDocument,
sections = doc.sections.everyItem().getElements();

if (doc.pages[0].name != "3") {
	for (var i = 0; i < sections.length; i++) {
		section = sections[i];
		
		if (section.continueNumbering) {
			section.continueNumbering = false;
		}
	}
}