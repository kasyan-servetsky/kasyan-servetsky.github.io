﻿/* Copyright 2017, Kasyan Servetsky
October 22, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Jump script",
sourceDoc, bookContents, story,
listPageNames = [],
listDocNames = [],
set = {};

PreCheck();
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var destDoc,
		listPages = GetListOFPages(),	
		activePage = app.layoutWindows[0].activePage;
		
		set.activePageName = activePage.name;

		CreateDialog();
		
		var destBookContent = bookContents.itemByName(listDocNames[set.destinationPageNum]);


		if (destBookContent.status != BookContentStatus.DOCUMENT_IS_OPEN) { // not open yet
			if (destBookContent.status == BookContentStatus.DOCUMENT_IN_USE) { // check if it's locked
				ErrorExit("File '" + destBookContent.name + "' is locked because it is open by someone else on the network.", true);
			}
			else {
				destDoc = app.open(destBookContent.fullName);
			}
		}
		else {
			destDoc = app.documents.itemByName(listDocNames[set.destinationPageNum]);
		}

		app.activeDocument = destDoc;
		
		var oversetText = GetOversetText(story);

		if (oversetText != null) {
			// Save & change units: have to work in inches
			var savedHorizontalMeasurementUnits = destDoc.viewPreferences.horizontalMeasurementUnits;
			var savedVerticalMeasurementUnits = destDoc.viewPreferences.verticalMeasurementUnits;
			destDoc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.INCHES;
			destDoc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.INCHES;
			
			// Body
			var frameBody = destDoc.pages[0].textFrames.add();
			var y1 = 1.8889;
			var x1 = -4.2289;
			var y2 = 5;
			var x2 = 0;
			frameBody.geometricBounds = [y1, x1, y2, x2];
			var movedTxtBody = oversetText.move(LocationOptions.BEFORE, frameBody.texts[0]);
			movedTxtBody = movedTxtBody[0];
			
			var chapeauParStyle = destDoc.paragraphStyles.itemByName("Chapeau");
			if (chapeauParStyle.isValid) {
				frameBody.texts[0].paragraphs[0].applyParagraphStyle(chapeauParStyle, false);
			}

			frameBody.texts[0].recompose();		
			frameBody.fit(FitOptions.FRAME_TO_CONTENT);
			
			// Header
			var header = GetHeader();
			
			if (header != null) {
				var headerFrame = destDoc.pages[0].textFrames.add();
				headerFrame.geometricBounds = [1.2, x1, 2, 0];
				headerFrame.texts[0].contents = header;
				
				var headerParStyle = destDoc.paragraphStyles.itemByName("H2");
				if (headerParStyle.isValid) {
					headerFrame.texts[0].applyParagraphStyle(headerParStyle, true);
				}
				
				var lastChar = headerFrame.texts[0].characters[-1];
				if (lastChar.contents == "\r") {
					lastChar.remove();
				}
			
				headerFrame.texts[0].recompose();
				headerFrame.fit(FitOptions.FRAME_TO_CONTENT); 
				headerFrame.move([x1, y1 - (headerFrame.geometricBounds[2] - headerFrame.geometricBounds[0]) - 0.1389]);
				
				// > Suite de la une
				var continuedFromFrame = destDoc.pages[0].textFrames.add();
				continuedFromFrame.geometricBounds = [headerFrame.geometricBounds[0] - 0.1389, x1, headerFrame.geometricBounds[0] - 0.2778, x2];
				continuedFromFrame.texts[0].contents = "> Suite de la une";
				
				var categorieParStyle = destDoc.paragraphStyles.itemByName("Catégorie");
				if (categorieParStyle.isValid) {
					continuedFromFrame.texts[0].applyParagraphStyle(categorieParStyle, true);
				}
			}
		
			story.insertionPoints[-1].contents = "Suite en page " + set.activePageName + " >";
			var lastPar = story.paragraphs[-1];
			
			var jumpParStyle = sourceDoc.paragraphStyles.itemByName("Jump");
			if (jumpParStyle.isValid) {
				lastPar.applyParagraphStyle(jumpParStyle, true);
			}
			
			// Restore units
			destDoc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
			destDoc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
		}
	}
	catch(err) {
		try { // Restore units if something goes wrong
			destDoc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
			destDoc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;			
		}
		catch(err) {}
		
		alert("ERROR: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetHeader() {
	var header = null;
	app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
	app.findTextPreferences.appliedParagraphStyle = "H1";
	var foundItems = sourceDoc.findText();
	
	if (foundItems.length > 0 && foundItems[0].contents != "") {
		header = foundItems[0].contents;
	}

	return header;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	var w = new Window("dialog", scriptName);
	
	w.p = w.add("panel", undefined, "");
	w.p.orientation = "column";
	w.p.alignment = "fill";
	w.p.alignChildren = "left";
	
	w.p.g = w.p.add("group");
	w.p.g.orientation = "row";
	w.p.g.st = w.p.g.add("statictext", undefined, "Move overset text in the selected story from page " + set.activePageName + " to page");
	w.p.g.ddl = w.p.g.add("dropdownlist", undefined, listPageNames);
	w.p.g.ddl.selection = 0;

	w.g1 = w.add("group");
	w.g1.orientation = "row";   
	w.g1.alignment = "center";
	w.g1.ok = w.g1.add("button", undefined, "OK", {name:"ok"});
	w.g1.cancel = w.g1.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		set.destinationPageNum = w.p.g.ddl.selection.index;
	}
	else {
		exit(); // Cancel
	}
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelectedStory() {
	var selectedStory = null,
	sel = app.selection[0];
	
	if (sel.parent instanceof Character) { // anchored box is selected -- get the main text flow
		selectedStory = sel.parent.parentStory;
	}
	else if (sel.hasOwnProperty("baseline") || sel.constructor.name == "TextFrame") {
		selectedStory = sel.parentStory;
	}

	return selectedStory;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetOversetText(textFlow) {
	if (!textFlow.overflows) return null;
	
	var start = textFlow.characters[0];
	var myTFs = textFlow.textContainers;   

	for (var j = myTFs.length - 1; j >= 0; j--) {    
		if (myTFs[j].characters.length > 0) {       
			start = textFlow.characters[myTFs[j].paragraphs[-1].characters[0].index];
			break;     
		}
	}

	return textFlow.texts.itemByRange(start, textFlow.texts[0].characters[-1]);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetListOFPages() {
	var bookContent, docName, pageName;
	
	for (var i = 0; i < bookContents.length; i++) {
		bookContent = bookContents[i];
		
		docName = bookContent.name;
		pageName = bookContent.name.replace(/C?\.indd$/i, "");
		
		if (docName != sourceDoc.name) {
			listDocNames.push(docName);
			listPageNames.push(pageName);
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	sourceDoc = app.activeDocument; // global
	if (sourceDoc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!sourceDoc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	if (app.books.length > 0) {
		bookContents = app.activeBook.bookContents; // global
	}
	else {
		ErrorExit("There's no open book. Please open a book and try again.", true);
	}
	
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	story = GetSelectedStory(); // global
	if (story == null) ErrorExit("No story is selected.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------