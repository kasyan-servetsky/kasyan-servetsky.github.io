﻿// Apply paragraph styles
// Copyright 2011 L'Express de Toronto Inc.
// Version 1.10
// October 25, 2011
// Written by Kasyan Servetsky
// http://www.kasyan.ho.com.ua
// e-mail: askoldich@yahoo.com
//==================================================================
app.doScript(SuperFunction, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.FAST_ENTIRE_SCRIPT, "Apply Paragraph Styles");

function SuperFunction() {
	var text, scenario;
	var scriptName = "Apply paragraph styles";
	var scriptVersion = "1.10";
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.");
	var doc = app.activeDocument;
	var selection = doc.selection;

	if (selection.length != 1) ErrorExit("One text frame or some text should be selected, or the cursor should be inserted into the text.");

	if (selection[0].constructor.name == "TextFrame") { // a text frame is selected
		text = selection[0].texts[0];
	}
	else if (selection[0].constructor.name == "InsertionPoint" || // some text is selected or the cursor is placed in the text
		selection[0].constructor.name == "Character" ||
		selection[0].constructor.name == "Word" ||
		selection[0].constructor.name == "TextStyleRange" ||
		selection[0].constructor.name == "Line" ||
		selection[0].constructor.name == "Paragraph" ||
		selection[0].constructor.name == "TextColumn" ||
		selection[0].constructor.name == "Text" ||
		selection[0].constructor.name == "TextFrame")
		{
			text = selection[0].parentStory.texts[0];
		}
	else if (selection[0].constructor.name == "Cell") { // a cell is selected
		text = selection[0].parent.parent.parentStory.texts[0];
	}
	else if (selection[0].constructor.name == "Table") { // a table is selected
		text = selection[0].parent.parentStory.texts[0];
	}
	else {
		ErrorExit("One text frame or some text should be selected, or the cursor should be inserted into the text.");
	}
	 
	if (text.contents == "") ErrorExit("The selection contains no text."); // text frame is empty

	if (text.constructor.name == "Text") {
		var story = text.parentStory; // get the story
	}
	else {
		ErrorExit("Can't find the story.", true);
	}

	Main();

	if (scenario == undefined) {
		alert("Fini. Rien a changé", scriptName + " - " + scriptVersion);
	}
	else {
		alert("Fini.\rAppliqué scénario #" + scenario, scriptName + " - " + scriptVersion);
	}

	//===================================== FUNCTIONS  ======================================
	function Main() {
		if (story.paragraphs.length == 0) {
			ErrorExit("The story is empty.", true);
		}
		else if (story.paragraphs.length == 1) {
			ErrorExit("The story contains only one paragraph.", true);
		}
		
		var firstParagraph = story.paragraphs[0];
		var firstParContents = firstParagraph.contents;
		var nextParagraph = story.paragraphs.nextItem(firstParagraph);
		var nextParContents = nextParagraph.contents;
		var lastParagraph = story.paragraphs[-1];
		var lastParContents = lastParagraph.contents;
		var regExpURLs = /^(http|www)(.+)/; // find URLs
		var regExpEmails = /^[A-Za-z0-9._%-]+@(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,4}/gi; // find email addresses
		
	/* 2nd scenario:
		If the first paragraph contains more than one sentence
		Apply "Chapeau" then Next Style.
		
		If the last sentence begins with an Em dash
		Apply "Byline_fin" to that last sentence.
		
		If the article's last paragraph is "Suite en Page", then apply "Jumpline_suite" to that paragraph */
		if (CountSentences(firstParagraph) > 1) {
			ApplyStyles(firstParagraph, doc.paragraphStyleGroups.item("Corps de Text").paragraphStyles.item("corps.chapeau"));
			}
			scenario = 2;
		}
		// apply "Intertitre" to any paragraph that is a single sentence that appears between either 
		// between "Corps" and "Corps.indentation" or between "Corps.indentation" and "Corps"
		ApplyIntertitre();
		FindListe();
		FindInterview();
		FindDialogs();
	//--------------------------------------------------------------------------------------------------------------------------------------------------------
	function FindDialogs() {
		var foundItem, previousPar, nextPar;
		if (story.paragraphs.length > 1) {
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
			app.findGrepPreferences.findWhat = "^«~=\\s.+?\\r";
			var foundItems = story.findGrep();
			
			if (foundItems.length > 0) {
				for (var i = 0; i < foundItems.length; i++) {
					foundItem = foundItems[i];
					//$.writeln( i + " - foundItem - " + foundItem.contents + "/" + foundItem.index+ "/" + foundItem.constructor.name );
					foundItem.appliedParagraphStyle = doc.paragraphStyleGroups.item("Corps de Text").paragraphStyles.item("corps");
						try {
							previousPar = story.paragraphs.previousItem(foundItem);
							if (previousPar != null) {
								//$.writeln( i + " - previousPar is valid - " + previousPar.contents );
								if (previousPar.contents.match(/.+:\r$/) != null) {
									//$.writeln( i + " - previousPar ends with :" );
									previousPar.appliedParagraphStyle = doc.paragraphStyleGroups.item("Corps de Text").paragraphStyles.item("corps.indentation");
									nextPar = story.paragraphs.nextItem(foundItem);
									//$.writeln( i + " - nextPar - "  + nextPar.contents);
									while (nextPar != null) {
										if (nextPar.contents.match(/^–\s.+/) == null) {
											//$.writeln( i + " - nextPar doesn't start with N-dash" );
											return;
										}
										nextPar.appliedParagraphStyle = doc.paragraphStyleGroups.item("Corps de Text").paragraphStyles.item("corps");
										nextPar = story.paragraphs.nextItem(nextPar);
										//$.writeln( i + " - nextPar - "  + nextPar.contents);
										if (nextPar.contents.match(/.+»\r?$/) != null) {
											//$.writeln( i + " - nextPar ends with »" );
											nextPar.appliedParagraphStyle = doc.paragraphStyleGroups.item("Corps de Text").paragraphStyles.item("corps");
											return;
										}
									}
								}
							}
						}
						catch(err) {
							//$.writeln(err);
							return;
						}
				} // for
			} // if
		}
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------
	function FindInterview() {
		var foundItem, previousPar;
		if (story.paragraphs.length > 1) {
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
			app.findGrepPreferences.findWhat = "^.+?: .+\\r?"; // "(^.+?)(: .+\\r?)"
			var foundItems = story.findGrep();
			
			if (foundItems.length > 1) {
				for (var i = 0; i < foundItems.length; i++) {
					foundItem = foundItems[i];
					//$.writeln( i + " - foundItem - " + foundItem.contents + "/" + foundItem.index+ "/" + foundItem.constructor.name );
					foundItem.appliedParagraphStyle = doc.paragraphStyleGroups.item("Corps de Text").paragraphStyles.item("corps.reponse");
						try {
							previousPar = story.paragraphs.previousItem(foundItem);
							if (previousPar != null) {
								//$.writeln( i + " - previousPar is valid - " + previousPar.contents );
								if (previousPar.contents.match(/.+\?\r$/) != null) {
									//$.writeln( i + " - previousPar ends with ?" );
									previousPar.appliedParagraphStyle = doc.paragraphStyleGroups.item("Corps de Text").paragraphStyles.item("corps.question");
								}
							}
						}
						catch(err) {
							//$.writeln(err);
						}
				} // for
			} // if
		//$.writeln( "-----------------" );
		} // story
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------
	// When there is a sequence of paragraphs (more than one) that begin with an N dash 
	// within the body of the article (After the Chapeau),  apply them with the Liste style.
	function FindListe() {
		if (story.paragraphs.length > 1) {
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
			app.findGrepPreferences.findWhat = "(^~=\\t)(.+?\\r?)";
			app.changeGrepPreferences.changeTo = "$2";
			app.changeGrepPreferences.appliedParagraphStyle = doc.paragraphStyleGroups.item("Liste").paragraphStyles.item("liste");
			foundItems = story.changeGrep();
		}
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------
	function CountSentences(paragraph) {
		var contents = paragraph.contents;
		if (contents == "") return 0;
		var countArr = contents.match(/(\.|\?|!)/g);
		var count = (countArr != null) ? countArr.length + 1 : 1;
		
		if (count == 0 && paragraph.contents != "") count = 1;
		return count;
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------
	function ApplyStyles(firstParagraph, parStyle) {
		firstParagraph.appliedParagraphStyle = parStyle;
		var allParagraphs = story.paragraphs;
		
		for (var i = 1; i < allParagraphs.length; i++) {
			allParagraphs[i].appliedParagraphStyle = allParagraphs[i-1].appliedParagraphStyle.nextStyle;
		}
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------
	function ApplyIntertitre() {
		var currentPar, previousPar, nextPar, currentParCont;
		var allParagraphs = story.paragraphs;
		
		for (var i = 1; i < allParagraphs.length; i++) {
			currentPar = allParagraphs[i];
			currentParCont = currentPar.contents;
			previousPar = allParagraphs.previousItem(currentPar);
			if (previousPar == null) continue;
			nextPar = allParagraphs.nextItem(currentPar);
			if (nextPar == null) continue;
			
			if  (currentParCont.match(/([a-z]|\?|«.+»)\r$/) != null && // the paragraph ends with a lowercase letter or "?"
				currentParCont.match(/\./) == null && // there is no period
				(previousPar.appliedParagraphStyle.name == "corps" || previousPar.appliedParagraphStyle.name == "corps.indentation") && // after "Corps" or "Corps.indentation"
				nextPar.appliedParagraphStyle.name == "corps.indentation" && // before "Corps.indentation"
				currentPar.words.length <= 8) // no more than 8 words
			{
					currentPar.appliedParagraphStyle = doc.paragraphStyleGroups.item("Corps de Text").paragraphStyles.item("corps.intertitre");
					nextPar.appliedParagraphStyle = doc.paragraphStyleGroups.item("Corps de Text").paragraphStyles.item("corps");
			} // if
		} // for
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------
	function ErrorExit(error, icon) {
		alert(error, scriptName + " - " + scriptVersion, icon);
		exit();
	}
}