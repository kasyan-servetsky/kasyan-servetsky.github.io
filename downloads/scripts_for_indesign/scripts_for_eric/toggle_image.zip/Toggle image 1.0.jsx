﻿// Copyright 2012, L'Express de Toronto Inc.
// February 28, 2012
// Written by Kasyan Servetsky
// http://www.kasyan.ho.com.ua
// e-mail: askoldich@yahoo.com
//======================================================================================
const gScriptName = "Toggle image";
const gScriptVersion = "1.0";

if (app.documents.length == 0) ErrorExit("Please open a document and try again.");

Main();

//===================================== FUNCTIONS  ======================================
function Main() {
	var newLinkName, newLinkFile;
	var doc = app.activeDocument;
	
	if (app.selection[0].constructor.name == "Image") {
		image = app.selection[0];
	}
	else if (app.selection[0].allGraphics.length > 0) {
		image = app.selection[0].allGraphics[0];
	}
	else {
		ErrorExit("Can't get the image.");
	}

	var link = image.itemLink;
	if (!link.isValid) ErrorExit("Can't get the link.");
	var linkFolderPath = new File(link.filePath).parent.fullName + "/";
	var name = GetFileName(link.name);
	var ext = GetExtension(link.name);
	
	if (name.match(/(_CMYK$|_GREY$)/) != null) {
		newLinkName = name.replace(/(_CMYK$|_GREY$)/, "") + "." + ext;
		newLinkFile = new File(linkFolderPath + newLinkName);
		if (newLinkFile.exists) {
			link.relink(newLinkFile);
		}
		else {
			ErrorExit("Image \"" + newLinkName + "\" doesn't exist.");
		}
	}
	else {
		newLinkName = name + "_CMYK." + ext;
		newLinkFile = new File(linkFolderPath + newLinkName);
		if (newLinkFile.exists) {
			link.relink(newLinkFile);
		}
		else {
			newLinkName = name + "_GREY." + ext;
			newLinkFile = new File(linkFolderPath + newLinkName);
			if (newLinkFile.exists) {
				link.relink(newLinkFile);
			}
			else {
				ErrorExit("Neither \""+ name + "_CMYK." + ext + "\" nor \"" + newLinkName + "\" has been found.");
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetFileName(fileName) {
	var str = "";
	var res = fileName.lastIndexOf(".");
	if (res == -1) {
		str = fileName;
	}
	else {
		str = fileName.substr(0, res);
	}
	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetExtension(name) {
	var idx = name.lastIndexOf( "." );
	var ext = "";
	if (idx > -1) {
		ext = name.substr((idx + 1));
	}
	return ext;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, gScriptName + " - " + gScriptVersion, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------