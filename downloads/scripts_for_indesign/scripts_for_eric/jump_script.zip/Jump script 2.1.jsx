﻿/* Copyright 2022, Kasyan Servetsky
Juдн 26, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com

When I try to apply Jump Script 1.1, InDesign says: There's no open book. Please open a book and try again.
It should work in a single indd document, without a book.

For jump script, please see before and after screenshots.
Instead of copying and pasting the overset text in a new text frame, the overset text should be linked. */
//======================================================================================
var scriptName = "Jump script",
debugMode = false,
listPageNames = [],
listPages = [],
doc, sel, story, parSt_h1, parSt_jump, parSt_jumpLine,
set = {};

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var destinationPage = doc.pages.itemByName(set.destinationPageNum),
		leftTextBound,
		oversetText = GetOversetText(story);

		if (oversetText != null) {
			// Save & change units: have to work in inches
			var savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits;
			var savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
			doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.INCHES;
			doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.INCHES;

			var isVerso = (destinationPage.side == PageSideOptions.LEFT_HAND) ? true : false;
			var pageBounds = destinationPage.bounds;
			
			var topBound = 1.8889, // top edge of the moved text
			textFramesWidth = 4.2289, // width of title and text frames = 4 columns
			textFrameDefaultHeight = 3, // starting height of text frames
			shift = 0.1389;  // shift from the page or frame ( in / 0.1398)
			
			// Body
			if (isVerso) {
				leftTextBound = pageBounds[1] - shift - textFramesWidth;
			}
			else { // recto
				leftTextBound = pageBounds[3] + shift; 
			}

			var frameBody = destinationPage.textFrames.add();
			frameBody.geometricBounds = [topBound, leftTextBound, textFrameDefaultHeight, leftTextBound + textFramesWidth];
			
			var movedTxtBody = oversetText.move(LocationOptions.BEFORE, frameBody.texts[0]);
			movedTxtBody = movedTxtBody[0];
			frameBody.texts[0].recompose();		
			frameBody.fit(FitOptions.FRAME_TO_CONTENT);

			ShowIt(frameBody);
			
			// Header
			var header = GetHeader();
			
			if (header != null) {
				var headerFrame = destinationPage.textFrames.add();
				headerFrame.geometricBounds = [topBound, leftTextBound, textFrameDefaultHeight, leftTextBound + textFramesWidth];
				
				headerFrame.texts[0].contents = header;
				headerFrame.texts[0].applyParagraphStyle(parSt_h1, true);
				
				var lastChar = headerFrame.texts[0].characters[-1];
				if (lastChar.contents == "\r") { 
					lastChar.remove();
				}
			
				headerFrame.texts[0].recompose();
				headerFrame.fit(FitOptions.FRAME_TO_CONTENT);
				headerFrame.move([leftTextBound, (topBound - (headerFrame.geometricBounds[2] - headerFrame.geometricBounds[0]) - shift)]);
				
				// > Suite de la une
				var continuedFromFrame = destinationPage.textFrames.add();
				continuedFromFrame.geometricBounds = [topBound, leftTextBound, topBound + shift, leftTextBound + textFramesWidth];
				continuedFromFrame.texts[0].contents = "Suite de la une";
				continuedFromFrame.texts[0].applyParagraphStyle(parSt_jump, true);
				continuedFromFrame.move([leftTextBound, (headerFrame.geometricBounds[0] - (continuedFromFrame.geometricBounds[2] - continuedFromFrame.geometricBounds[0]) - shift)]);
			} // // End Header

			story.insertionPoints[-1].contents = "Suite en page " + set.destinationPageNum + "B";
			story.insertionPoints[-2].contents = SpecialCharacters.EN_SPACE;
			story.insertionPoints[-1].contents = SpecialCharacters.COLUMN_BREAK;
			
			var lastPar = story.paragraphs[-1];
			lastPar.applyParagraphStyle(parSt_jumpLine, true);
			
			var frameSelected = story.textContainers[0];
			frameSelected.nextTextFrame = frameBody;
			
			// Restore units
			doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
			doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
		}
	} 
	catch(err) {
		try { // Restore units if something goes wrong
			doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
			doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;			
		}
		catch(err) {} 
		
		alert("ERROR: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ShowIt(theObj) {
	if (arguments.length > 0) {
		// Select object, turn to page and center it in the window
		app.select(theObj, SelectionOptions.replaceWith);
	}

	// Note: if no object is passed and there is no selection the current page
	// will be centered in the window at whatever zoom is being used
	var zoom = app.activeWindow.zoomPercentage;
	app.activeWindow.zoom(ZoomOptions.showPasteboard);
	app.activeWindow.zoomPercentage = zoom;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetHeader() {
	var header = null;
	app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
	app.findTextPreferences.appliedParagraphStyle = "h1";
	var foundItems = doc.findText();
	
	if (foundItems.length > 0 && foundItems[0].contents != "") {
		header = foundItems[0].contents;
	}

	return header;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	var w = new Window("dialog", scriptName);
	
	w.p = w.add("panel", undefined, "");
	w.p.orientation = "column";
	w.p.alignment = "fill";
	w.p.alignChildren = "left";
	
	w.p.g = w.p.add("group");
	w.p.g.orientation = "row";
	w.p.g.st = w.p.g.add("statictext", undefined, "Move overset text in the selected story from page " + set.currentPageName + " to page");
	w.p.g.ddl = w.p.g.add("dropdownlist", undefined, listPageNames);
	w.p.g.ddl.selection = 0;

	w.g1 = w.add("group");
	w.g1.orientation = "row";   
	w.g1.alignment = "center";
	w.g1.ok = w.g1.add("button", undefined, "OK", {name:"ok"});
	w.g1.cancel = w.g1.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		set.destinationPageNum = w.p.g.ddl.selection.text;
		var tmp_set = set;
		
		Main(); 
	}
	else {
		exit(); // Cancel
	}
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelectedStory() {
	var selectedStory = null;
	sel = app.selection[0];
	
	if (sel.parent instanceof Character) { // anchored box is selected -- get the main text flow
		selectedStory = sel.parent.parentStory;
	}
	else if (sel.hasOwnProperty("baseline") || sel.constructor.name == "TextFrame") {
		selectedStory = sel.parentStory;
	}

	return selectedStory;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetOversetText(textFlow) {
	if (!textFlow.overflows) return null;
	
	var start = textFlow.characters[0];
	var textFrames = textFlow.textContainers;   

	for (var j = textFrames.length - 1; j >= 0; j--) {    
		if (textFrames[j].characters.length > 0) {       
			start = textFlow.characters[textFrames[j].paragraphs[-1].characters[0].index];
			break;     
		}
	}

	return textFlow.texts.itemByRange(start, textFlow.texts[0].characters[-1]);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	if (!debugMode && app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	story = GetSelectedStory(); // global
	if (story == null) ErrorExit("No story is selected.", true);
	
	// check paragraph styles
	parSt_h1 = doc.paragraphStyles.itemByName("h1");
	if (!parSt_h1.isValid) ErrorExit("Paragraph style 'h1' is missing in the current document.", true);
	
	parSt_jump = doc.paragraphStyles.itemByName("jump");
	if (!parSt_jump.isValid) ErrorExit("Paragraph style 'jump' is missing in the current document.", true);
	
	parSt_jumpLine = doc.paragraphStyles.itemByName("jumpLine");
	if (!parSt_jumpLine.isValid) ErrorExit("Paragraph style 'jumpLine' is missing in the current document.", true);

	// get pages
	var currentPage = story.textContainers[0].parentPage; // user can select some text so get frame from story
	set.currentPageName = currentPage.name;
	
	var page;
	
	for (var i = 0; i < doc.pages.length; i++) {
		page = doc.pages[i];
		
		if (page != currentPage) { // exclude current page
			listPageNames.push(page.name);
			listPages.push(page);
		}
	}
	
	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------