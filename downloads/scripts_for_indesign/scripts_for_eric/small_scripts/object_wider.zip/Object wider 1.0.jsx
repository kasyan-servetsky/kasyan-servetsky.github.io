﻿/* Copyright 2017, L'Express de Toronto Inc.
October 30, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com

Description: With one or more objects selected, script increases the width of the right side of each object by 1.0964 inches. */
//======================================================================================
var scriptName = "Object wider",
doc,
selectedItems = GetSelection();

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" script");

//===================================== FUNCTIONS ======================================
function Main() {
	var item, gb,	
	savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits,
	savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
	
	doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.INCHES;
	doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.INCHES;
	
	for (var i = 0; i < selectedItems.length; i++) {
		try {
			item = selectedItems[i];
			vb = item.visibleBounds;
			item.visibleBounds = [vb[0], vb[1], vb[2], vb[3] + 1.0964];
		}
		catch(err) {}
	}

	doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
	doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelection() {
	var selection = app.selection,
	selectedItems = [];
	
	for (var i = 0; i < selection.length; i++) {
		if (selection[i].hasOwnProperty("geometricBounds")) {
			selectedItems.push(selection[i]);
		}
	}

	return selectedItems;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	if (selectedItems.length == 0) ErrorExit("Invalid selection.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------