﻿/* Copyright 2013, Kasyan Servetsky
April 2, 2013
Written by Kasyan Servetsky 
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com 

When on right page, move selected object to x : 0.5 in
When on left page, move selected object to x : -0.9165 in
*/
//======================================================================================
var scriptName = "Horizontal Position - 1.0";

Main();

//===================================== FUNCTIONS  ======================================
function Main() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	var doc = app.activeDocument;
	
	if (app.selection.length != 1) ErrorExit("One object should be selected.", true);
	var sel = app.selection[0];
	
	if (!sel.hasOwnProperty("geometricBounds")) ErrorExit("The selection can't be moved.", true);
	var gb = sel.geometricBounds;
	
	var page = sel.parentPage;
	if (page == null) ErrorExit("The selected object is not on page.", true);
	
	try {
		if (page.side == PageSideOptions.RIGHT_HAND) {
			sel.move([ 0.5, gb[0] ]);
		}
		else if (page.side == PageSideOptions.LEFT_HAND) {
			sel.move([ -0.9165, gb[0] ]);
		}
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------