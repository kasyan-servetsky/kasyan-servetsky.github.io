﻿/* Copyright 2017, L'Express de Toronto Inc.
November 5, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com

Description: With one story frame selected, script adds 1 column. */
//======================================================================================
var scriptName = "Column add";

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "'" + scriptName + "' script");

//===================================== FUNCTIONS ======================================
function Main(textFrame) {
	if (textFrame.textFramePreferences.textColumnCount < 40) {
		textFrame.textFramePreferences.textColumnCount += 1;
	}
	else {
		alert("Can't add more columns. The maximum number is 40.", scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	var textFrame;
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	if (app.selection.length == 0) {
		ErrorExit("Nothing is selected.", true);
	}
	else if (app.selection.length == 1) {
		if (app.selection[0].constructor.name == "TextFrame") {
			textFrame = app.selection[0];
		}
		else if (app.selection[0].hasOwnProperty("baseline")) {
			textFrame = app.selection[0].parentTextFrames[0];
			if (!textFrame.isValid || !textFrame  instanceof TextFrame) ErrorExit("Can't get the text frame from the selection.", true);
		}
		else {
			ErrorExit("Please select one text frame, or some text, or place the cursor and try again.", true);
		}
	}
	else if (app.selection.length > 1) {
		ErrorExit("Only one text frame or some text should be selected, or the cursor placed into the text.", true);
	}
	
	Main(textFrame);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------