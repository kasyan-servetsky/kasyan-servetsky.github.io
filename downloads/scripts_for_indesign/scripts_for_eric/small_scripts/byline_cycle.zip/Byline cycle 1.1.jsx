﻿/* Copyright 2017, L'Express de Toronto Inc.
November 5, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com

Description:
With story frame selected,

If story has a paragraph with ‘byline begin’ paragraph style,
script cuts that paragraph and pasts it at the end of the story and applies ‘byline end’

If story has a paragraph with ‘byline end’ paragraph style,
script cuts that paragraph:
	If there is a paragraph styled with ‘byline address’, then paste it before the paragraph styled with ‘byline address’ and apply style ‘byline begin’
	If there is not paragraph styled with ‘byline address’, the paste it before ‘lede’ paragraph style of the story and apply style ‘byline begin’
*/
//======================================================================================
var scriptName = "Byline cycle",
doc, story, parStyleBylineBegin, parStyleBylineEnd, parStyleBylineAddress, parStyleLede;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" script");

//===================================== FUNCTIONS ======================================
function Main() {
	var applyParStyle,
	moved = false,
	bylineBeginTxt = FindGrep(story, parStyleBylineBegin),
	bylineEndTxt = FindGrep(story, parStyleBylineEnd),
	bylineAddressTxt = FindGrep(story, parStyleBylineAddress),
	ledeFirstTxt = FindGrep(story, parStyleLede);
	
	if (bylineBeginTxt != null || bylineEndTxt != null) {
		if (story.characters[-1].contents != "\r") {
			story.insertionPoints[-1].contents = "\r";
		}
	}

	if (bylineBeginTxt != null && bylineEndTxt == null) {
		applyParStyle = parStyleBylineEnd;
		moved = bylineBeginTxt.move(LocationOptions.AT_END, story);
	}
	else if (bylineEndTxt != null) {
		applyParStyle = parStyleBylineBegin;
		
		if (bylineAddressTxt != null) {
			moved = bylineEndTxt.move(LocationOptions.AT_BEGINNING, bylineAddressTxt);
		}
		else if (bylineAddressTxt == null && ledeFirstTxt != null) {
			moved = bylineEndTxt.move(LocationOptions.BEFORE, ledeFirstTxt);
		}
	}

	if (moved) {
		CleanUp(story);
		moved.applyParagraphStyle(applyParStyle, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FindGrep(story, parStyle) {
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = ".+\\r*";
	app.findGrepPreferences.appliedParagraphStyle = parStyle;
	var foundItems = story.findGrep();
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	return (foundItems.length != 0) ? foundItems[0] : null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CleanUp(story) {
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = "\\r+$";
	app.changeGrepPreferences.changeTo = "";
	var foundItems = story.changeGrep();
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	if (app.selection.length == 0) {
		ErrorExit("Nothing is selected.", true);
	}
	else if (app.selection.length == 1) {
		if (app.selection[0].constructor.name == "TextFrame" || app.selection[0].hasOwnProperty("baseline")) {
			story = app.selection[0].parentStory;
		}
		else {
			ErrorExit("Please select one text frame, or some text, or place the cursor and try again.", true);
		}
	}
	else if (app.selection.length > 1) {
		ErrorExit("Only one text frame or some text should be selected, or the cursor placed into the text.", true);
	}

	parStyleBylineBegin = doc.paragraphStyles.itemByName("byline begin");
	if (!parStyleBylineBegin.isValid) ErrorExit("Paragraph style 'byline begin' doesn't exist in the document.", true);
	parStyleBylineEnd = doc.paragraphStyles.itemByName("byline end");
	if (!parStyleBylineEnd.isValid) ErrorExit("Paragraph style 'byline end' doesn't exist in the document.", true);
	parStyleBylineAddress = doc.paragraphStyles.itemByName("byline address");
	if (!parStyleBylineAddress.isValid) ErrorExit("Paragraph style 'byline address' doesn't exist in the document.", true);
	parStyleLede = doc.paragraphStyles.itemByName("lede");
	if (!parStyleLede.isValid) ErrorExit("Paragraph style 'lede' doesn't exist in the document.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------