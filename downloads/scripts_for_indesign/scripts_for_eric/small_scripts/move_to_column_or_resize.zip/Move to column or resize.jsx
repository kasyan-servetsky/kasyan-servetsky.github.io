﻿/* Copyright 2024, L'Express de Toronto Inc.
May 20, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com 

Description:
With one object selected, move the object to the nearest column guideline. If it is already on a guideline, do not move it. 
Then, (depending on user choice) increase or decrease the width of the object to the nearest column guideline. 
The script should reference the column guidelines on the current page. 

23 III 2023
These attached scripts do not function properly on right-hand pages.
Please fix them. */
//======================================================================================

var scriptName = "Move to column or resize",
storedRulerOrigin;

if (typeof arguments == "undefined") {
	ErrorExit("This is a secondary script which should be run from the 'Move/Increase to left/Increase to right/Decrease to left/Decrease to right.jsx' script.", true);
}

var mode = arguments[0];
mode = mode.toUpperCase();
mode = mode.replace(/\s/g, "_");

var doc, item,
page = app.layoutWindows[0].activePage,
columnsPositions = GetColumnsPositions();

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var storedZeroPoint = null;
		
		if (doc.zeroPoint[0] != 0 || doc.zeroPoint[1] != 0) {
			storedZeroPoint = doc.zeroPoint;
			doc.zeroPoint = [0, 0];
		}

		storedRulerOrigin = doc.viewPreferences.rulerOrigin;
		doc.viewPreferences.rulerOrigin = RulerOrigin.PAGE_ORIGIN;		

		var vb = item.visibleBounds,
		itemLeft = RoundWithDecimal(vb[1], 4),
		itemRight = RoundWithDecimal(vb[3], 4),
		itemWidth = itemRight - itemLeft,
		itemCenter = itemLeft + itemWidth / 2,
		leftTextColumn = GetArrayIndex(columnsPositions.left, itemLeft),
		rightTextColumn = GetArrayIndex(columnsPositions.right, itemRight);
	
		var nearestColPos = GetNearestColumns(itemLeft, itemRight);
		if (nearestColPos == null) ErrorExit("The selected isn't located on the page.", true);
		
		var leftDist = itemLeft - nearestColPos.left;
		var rightDist = nearestColPos.right - itemRight;		
	
		if (mode == "MOVE") {
			if (leftTextColumn != -1 && rightTextColumn != -1) {
				ErrorExit("The selected object is already aligned to both the left and right column guidelines.", true);
			}
			else if (leftTextColumn != -1) {
				ErrorExit("The selected object is already aligned to the left column guideline.", true);
			}
			else if (rightTextColumn != -1) {
				ErrorExit("The selected object is already aligned to the right column guideline.", true);
			}
			
			if (leftDist <= rightDist) { // move to the left -- if closer to left, or the distance is equal both to the left and right
				item.move([nearestColPos.left, vb[0]]);
			}
			else if (leftDist > rightDist) { // move to the right
				item.move([nearestColPos.right - itemWidth, vb[0]]);
			}
		}

		if (mode == "INCREASE_TO_LEFT") {
			item.visibleBounds = [vb[0], nearestColPos.left, vb[2], vb[3]];
		}
	
		if (mode == "INCREASE_TO_RIGHT") {
			item.visibleBounds = [vb[0], vb[1], vb[2], nearestColPos.right];
		}

		if (mode == "DECREASE_TO_LEFT") {
			if (leftTextColumn != -1) { // alighned to left
				var newLeftPosIndex = GetArrayIndex(columnsPositions.left, itemLeft) + 1;
			}
			else { // NOT alighned to left
				if (itemLeft > columnsPositions.left[0]) { // withing text block
					var newLeftPosIndex = GetArrayIndex(columnsPositions.left,  nearestColPos.left) + 1;
				}
				else {
					var newLeftPosIndex = 0; // on the left margine or pasteboard
				}
			}

			var newLeftPos = null;
			
			if (newLeftPosIndex < columnsPositions.left.length) {
				newLeftPos = columnsPositions.left[newLeftPosIndex];
			}
			 
			if (newLeftPos != null && newLeftPos < itemRight) {
				item.visibleBounds = [vb[0], newLeftPos, vb[2], vb[3]];
			}
			else {
				ErrorExit("No more space left to decrease the selected object.", true);
			}		
		}

		if (mode == "DECREASE_TO_RIGHT") {
			if (rightTextColumn != -1) { // alighned to right
				var newRightPosIndex = GetArrayIndex(columnsPositions.right, itemRight) - 1;
			}
			else { // NOT alighned to right
				if (itemRight < columnsPositions.right[columnsPositions.right.length - 1]) { // withing text block
					var newRightPosIndex = GetArrayIndex(columnsPositions.right,  nearestColPos.right) - 1;
				}
				else {
					var newRightPosIndex = columnsPositions.right.length - 1;
				}
			}

			var newRightPos = null;
			
			if (newRightPosIndex < columnsPositions.right.length) {
				newRightPos = columnsPositions.right[newRightPosIndex];
			}

			if (newRightPos != null && newRightPos > itemLeft) {
				item.visibleBounds = [vb[0], vb[1], vb[2], newRightPos];
			}
			else {
				ErrorExit("No more space left to decrease the selected object.", true);
			}
		}
	
		if (storedZeroPoint != null) doc.zeroPoint = storedZeroPoint;
		doc.viewPreferences.rulerOrigin = storedRulerOrigin;
	}
	catch(err) {
		if (storedZeroPoint != null) doc.zeroPoint = storedZeroPoint;
		if (typeof storedRulerOrigin != "undefined") doc.viewPreferences.rulerOrigin = storedRulerOrigin;
		alert("Something went wrong. Error: " + err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetNearestColumns(itemLeft, itemRight) {
	var nearestLeftColPos, nearestRightColPos;

	if (!LocatedOnPage()) {
		return null;
	}

	// Left
	for (var l = 0; l < columnsPositions.left.length; l++) {
		nearestLeftColPos = columnsPositions.left[l];
		
		if (columnsPositions.left[l] >= itemLeft) {
			if (l != 0) nearestLeftColPos = columnsPositions.left[l - 1];
			break;
		}
	}

	// Right
	for (var r = columnsPositions.right.length - 1; r >= 0; r--) {
		nearestRightColPos = columnsPositions.right[r];
		
		if (columnsPositions.right[r] <= itemRight) {
			if (r != columnsPositions.right.length - 1) nearestRightColPos = columnsPositions.right[r + 1];
			break;
		}
	}

 	return {left: nearestLeftColPos, right: nearestRightColPos};
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function LocatedOnPage() {
	try {
		item.parentPage.name;
		return true;
	}
	catch(err) {
		// $.writeln(err.message + ", line: " + err.line);
		return false;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetArrayIndex(arr, val) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] == val) {
			return i;
		}
	}
	return -1;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetColumnsPositions() {
	var position,
	marginPreferences = page.marginPreferences,
	leftMargin = marginPreferences.left,
	positions = marginPreferences.columnsPositions,
	columnsPositions = {left: [], right: []};
	
	for (var i = 0; i < positions.length; i++) {
		position = RoundWithDecimal(positions[i], 4);
		
		if (i % 2 == 0) { // left
			columnsPositions.left.push(RoundWithDecimal(leftMargin + position, 4));
		}
		else if (i % 2 != 0) { // right
			columnsPositions.right.push(RoundWithDecimal(leftMargin + position, 4));
		}
	}
	
	return columnsPositions;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function RoundWithDecimal(number, decimals) {
	var multiplier = Math.pow(10, decimals);
	return Math.round(number * multiplier) / multiplier;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	if (app.selection.length == 0) {
		ErrorExit("Nothing is selected.", true);
	}
	else if (app.selection.length > 1) {
		ErrorExit("Only one object should be selected.", true);
	}
	else if (!app.selection[0].hasOwnProperty("geometricBounds")) {
		ErrorExit("Invalid selection.", true);
	}
	else {
		item = app.selection[0];
	}

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	if (typeof storedRulerOrigin != "undefined") doc.viewPreferences.rulerOrigin = storedRulerOrigin;
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
