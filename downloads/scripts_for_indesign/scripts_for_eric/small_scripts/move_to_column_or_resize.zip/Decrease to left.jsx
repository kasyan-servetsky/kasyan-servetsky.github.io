﻿var activeScript = GetActiveScript(),
scriptName = activeScript.displayName.replace(/\.jsx$/, ""),
scriptFile = new File(decodeURI(activeScript.parent.absoluteURI ) + "/Move to column or resize.jsx");
Check();
app.doScript(scriptFile, ScriptLanguage.JAVASCRIPT, [scriptName], UndoModes.ENTIRE_SCRIPT, "'\'" + scriptName + "\" script");

function Check() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	if (!scriptFile.exists) ErrorExit("The '" + scriptName + "' script should be located in the same folder as this script.", true);
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}

function GetActiveScript() {
    try {
        return app.activeScript;
    }
    catch(err) {
        return new File(err.fileName);
    }
}