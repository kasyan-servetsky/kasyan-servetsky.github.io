﻿// Copyright 2012, Kasyan Servetsky
// May 5, 2012
// Written by Kasyan Servetsky
// http://www.kasyan.ho.com.ua
// e-mail: askoldich@yahoo.com
//======================================================================================
const gScriptName = "Reveal in Finder";
const gScriptVersion = "1.0";

Main();

//===================================== FUNCTIONS  ======================================
function Main() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.");
	var doc = app.activeDocument;
	
	if (app.selection.length == 0 || app.selection.length > 1) ErrorExit("Please select a single image and try again.");
	var sel = app.selection[0];
	
	if (sel.constructor.name == "Image" && sel.itemLink.isValid) {
		sel.itemLink.revealInSystem();
	}
	else if (sel.allGraphics.length == 0) {
		ErrorExit("Your selection contains no image to reveal.");
	}
	else if (sel.allGraphics[0].itemLink.isValid) {
		sel.allGraphics[0].itemLink.revealInSystem();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, gScriptName + " - " + gScriptVersion, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------