﻿/* Copyright 2017, L'Express de Toronto Inc.
November 27, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com

Description: It increases the size of an object to fit the column width.
If the object is already an exact column width (say 2 columns), then it is resized one column wider (3 columns). */
//======================================================================================
var scriptName = "Size to column",
doc,
page = app.layoutWindows[0].activePage,
columnsPositions = GetColumnsPositions(),
selectedItems = GetSelection();

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" script");

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var pageCenter, item, vb, itemLeft, itemRight, itemWidth, itemCenter, oldPosition, columnPosition,
		leftTextColumn, rightTextColumn, itemLeftNew, itemRightNew,
		pb = page.bounds,
		pageIsLeft = (page.side == PageSideOptions.LEFT_HAND) ? true : false;
		
		if (pageIsLeft) {
			pageCenter = (pb[3] - pb[1]) / 2;
		}
		else {
			pageCenter = pb[1] + (pb[3] - pb[1]) / 2;
		}

		for (var i = 0; i < selectedItems.length; i++) {
			item = selectedItems[i];
			vb = item.visibleBounds;
			itemLeft = RoundWithDecimal(vb[1], 4);
			itemRight = RoundWithDecimal(vb[3], 4);
			itemWidth = itemRight - itemLeft;
			itemCenter = itemLeft + itemWidth / 2;
			
			leftTextColumn = GetArrayIndex(columnsPositions.left, itemLeft);
			rightTextColumn = GetArrayIndex(columnsPositions.right, itemRight);

			if (leftTextColumn != -1 && rightTextColumn != -1) {
				if (itemCenter > pageCenter) { // expand to the left
					itemLeftNew = GetNewPosition(itemLeft, false);
					
					if (itemLeftNew != null) {
						item.visibleBounds = [vb[0], itemLeftNew, vb[2],  vb[3]];
					}
				}
				else { // expand to the right
						itemRightNew = GetNewPosition(itemRight, true);

					if (itemRightNew != null) {
						item.visibleBounds = [vb[0], vb[1], vb[2], itemRightNew];
					}
				}
			}
			else if (leftTextColumn == -1 && rightTextColumn != -1) { // expand to the left
				itemLeftNew = GetNewPosition(itemLeft, false);
				
				if (itemLeftNew != null) {
					item.visibleBounds = [vb[0], itemLeftNew, vb[2],  vb[3]];
				}
			}
			else if (leftTextColumn != -1 && rightTextColumn == -1) { // expand to the right
				itemRightNew = GetNewPosition(itemRight, true);

				if (itemRightNew != null) {
					item.visibleBounds = [vb[0], vb[1], vb[2], itemRightNew];
				}
			}
			else if (leftTextColumn == -1 && rightTextColumn == -1) { // expand to both sides
				itemLeftNew = GetNewPosition(itemLeft, false);
				itemRightNew = GetNewPosition(itemRight, true);
				
				if (itemLeftNew != null && itemRightNew != null) {
					item.visibleBounds = [vb[0], itemLeftNew, vb[2],  itemRightNew];
				}
			}
		} // end for-loop
 
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetNewPosition(oldPosition, toTheRight) {
	var columnPosition,
	newPosition = null;

	if (toTheRight) { // to the right
		for (var i = 0; i < columnsPositions.right.length; i++) {
			columnPosition = columnsPositions.right[i];

			if (columnPosition > oldPosition) {
				newPosition = columnPosition;
				break;
			}
		}
	}
	else { // to the left
		for (var i = columnsPositions.left.length - 1; i >= 0; i--) {
			columnPosition = columnsPositions.left[i];

			if (columnPosition < oldPosition) {
				newPosition = columnPosition;
				break;
			}
		}		
	}

	return newPosition;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetArrayIndex(arr, val) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] == val) {
			return i;
		}
	}
	return -1;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetColumnsPositions() {
	var position,
	marginPreferences = page.marginPreferences,
	leftMargin = marginPreferences.left,
	positions = marginPreferences.columnsPositions,
	columnsPositions = {left: [], right: []};
	
	for (var i = 0; i < positions.length; i++) {
		position = RoundWithDecimal(positions[i], 4);
		
		if (i % 2 == 0) { // left
			columnsPositions.left.push(RoundWithDecimal(leftMargin + position, 4));
		}
		else if (i % 2 != 0) { // right
			columnsPositions.right.push(RoundWithDecimal(leftMargin + position, 4));
		}
	}
	
	return columnsPositions;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelection() {
	var selection = app.selection,
	selectedItems = [];
	
	for (var i = 0; i < selection.length; i++) {
		if (selection[i].hasOwnProperty("geometricBounds")) {
			selectedItems.push(selection[i]);
		}
	}

	return selectedItems;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function RoundWithDecimal(number, decimals) {
	var multiplier = Math.pow(10, decimals);
	return Math.round(number * multiplier) / multiplier;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	if (selectedItems.length == 0) ErrorExit("Invalid selection.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------