﻿/* Copyright 2017, L'Express de Toronto Inc.
November 5, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com

Description:
With one or more objects selected, script sets width to 2.0362 inches for each object.
The left side of the object(s) should stay on the same X coordinate… so change in width only affects the right side of object(s). */
//======================================================================================
var scriptName = "Object set width",
doc,
selectedItems = GetSelection();

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "'" + scriptName + "' script");

//===================================== FUNCTIONS ======================================
function Main() {
	var item, gb,	
	savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits,
	savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
	
	doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.INCHES;
	doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.INCHES;
	
	for (var i = 0; i < selectedItems.length; i++) {
		try {
			item = selectedItems[i];
			vb = item.visibleBounds;
			item.visibleBounds = [vb[0], vb[1], vb[2], vb[1] + 2.0362];
		}
		catch(err) {}
	}

	doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
	doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelection() {
	var selection = app.selection,
	selectedItems = [];
	
	if (app.selection.length == 1 && app.selection[0].hasOwnProperty("baseline")) {
		var textFrame = app.selection[0].parentTextFrames[0];
		if (textFrame.isValid && textFrame  instanceof TextFrame) {
			selectedItems.push(textFrame);
		}
	}
	else {
		for (var i = 0; i < selection.length; i++) {
			if (selection[i].hasOwnProperty("geometricBounds")) {
				selectedItems.push(selection[i]);
			}
		}
	}

	return selectedItems;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	if (selectedItems.length == 0) ErrorExit("Invalid selection.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
/*
	
		
if (app.selection.length == 0) {
	ErrorExit("Nothing is selected.", true);
}
else if (app.selection.length == 1) {
	if (app.selection[0].constructor.name == "TextFrame") {
		textFrame = app.selection[0];
	}
	else if (app.selection[0].hasOwnProperty("baseline")) {
		textFrame = app.selection[0].parentTextFrames[0];
		if (!textFrame.isValid || !textFrame  instanceof TextFrame) ErrorExit("Can't get the text frame from the selection.", true);
	}
	else {
		ErrorExit("Please select one text frame, or some text, or place the cursor and try again.", true);
	}
}
else if (app.selection.length > 1) {
	ErrorExit("Only one text frame or some text should be selected, or the cursor placed into the text.", true);
}

	
item.geometricBounds = [gb[0], gb[1], gb[2], eval(gb[1] + 2.0362 + " in")];
*/