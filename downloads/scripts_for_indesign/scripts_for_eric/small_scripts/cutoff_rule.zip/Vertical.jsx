﻿var scriptName = "Cutoff rule",
activeScript = GetActiveScript(),
scriptFile = new File(activeScript.parent.absoluteURI + "/" + "Cutoff rule.jsx");

if (scriptFile.exists) {
	app.doScript(scriptFile, ScriptLanguage.JAVASCRIPT, [true], UndoModes.ENTIRE_SCRIPT, "'\'" + scriptName + "\" script");
}
else {
	alert("The '" + scriptName + "' script should be located in the same folder as this script.", scriptName, true);
}

function GetActiveScript() {
    try {
        return app.activeScript;
    }
    catch(err) {
        return new File(err.fileName);
    }
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}