﻿/* Copyright 2017, L'Express de Toronto Inc.
October 30, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com

Description:
With one or more objects selected, script aligns them (from the top of the objects) to Y = 0.9167 in
Can script look for the top most guide on the page? if so, align to the top most guide on the page instead of Y = 0.9167 */
//======================================================================================
var scriptName = "Align top", doc,
selectedItems = GetSelection();

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" script");

//===================================== FUNCTIONS ======================================
function Main() {
	var item,
	activePage = doc.layoutWindows[0].activePage,
	appliedMaster = activePage.appliedMaster;
	
	if (appliedMaster == null) ErrorExit("Master page [None] is applied to the current page.", true);
	
	var guides = appliedMaster.guides;
	var guideLocation = GetTopGuideLocation(guides);
	
	if (guideLocation == null) ErrorExit("No horizontal guides exist on the applied master page.", true);
	
	for (var i = 0; i < selectedItems.length; i++) {
		item = selectedItems[i];
		
		try {
			item.move([item.visibleBounds[1], guideLocation]);
		}
		catch(err) {}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetTopGuideLocation(guides) {
	var guide,
	location = null;
	
	for (var i = 0; i < guides.length; i++) {
		guide = guides[i];
		if (guide.orientation == HorizontalOrVertical.HORIZONTAL) {
			if (location == null || guide.location < location) {
				location = guide.location;
			}
		}
	}
	return location;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelection() {
	var selection = app.selection,
	selectedItems = [];
	
	for (var i = 0; i < selection.length; i++) {
		if (selection[i].hasOwnProperty("geometricBounds")) {
			selectedItems.push(selection[i]);
		}
	}

	return selectedItems;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	if (selectedItems.length == 0) ErrorExit("Invalid selection.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------