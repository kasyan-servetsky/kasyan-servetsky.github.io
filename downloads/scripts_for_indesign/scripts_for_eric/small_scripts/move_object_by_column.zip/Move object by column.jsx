﻿/* Copyright 2023, L'Express de Toronto Inc.
Script: Move object by column
Version: 1.2
March 25, 2023
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com

Warning: this script should be run from the 'Move-left/right.jsx'  */
//======================================================================================
var scriptName = "Move object by column";

if (typeof arguments == "undefined") {
	ErrorExit("This script should be run from the 'Move-left/right.jsx' script.", true);
}

var toTheRight = (arguments[0] == "Move-right") ? true : false,
doc,
page = app.layoutWindows[0].activePage,
selectedItems = GetSelection();

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var item, vb, width, oldPosition, newPosition,
		storedRulerOrigin = doc.viewPreferences.rulerOrigin;

		doc.viewPreferences.rulerOrigin = RulerOrigin.PAGE_ORIGIN;
		
		var columnsPositions = GetColumnsPositions(toTheRight);
		
		for (var i = 0; i < selectedItems.length; i++) {
			item = selectedItems[i];
			vb = item.visibleBounds;
			width = RoundWithDecimal(vb[3] - vb[1], 4);
			oldPosition = (toTheRight) ? vb[3] : vb[1];

			newPosition = GetNewPosition(columnsPositions, oldPosition, width);	
			
			try {
				if (newPosition != null) {
					item.move([newPosition, vb[0]], undefined);
				}
			}
			catch(err) {
				//$.writeln(err.message + ", line: " + err.line);
			}

			doc.viewPreferences.rulerOrigin = storedRulerOrigin;
		}
	}
	catch(err) {
		if (typeof storedRulerOrigin != "undefined") doc.viewPreferences.rulerOrigin = storedRulerOrigin;
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetNewPosition(columnsPositions, oldPosition, width) {
	var columnPosition,
	oldPosition = RoundWithDecimal(oldPosition, 4),
	newPosition = null;
	
	if (toTheRight) { // to the right
		for (var i = 0; i < columnsPositions.length; i++) {
			columnPosition = RoundWithDecimal(columnsPositions[i], 4);

			if (columnPosition > oldPosition) {
				newPosition = columnPosition - width;
				break;
			}
		}
	}
	else { // to the left
		for (var i = columnsPositions.length - 1; i >= 0; i--) {
			columnPosition = RoundWithDecimal(columnsPositions[i], 4);
			
			if (columnPosition < oldPosition) {
				newPosition = columnPosition;
				break;
			}
		}		
	}

	return newPosition;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetColumnsPositions() {
	var marginPreferences = page.marginPreferences,
	leftMargin = marginPreferences.left,
	columnsPositions = marginPreferences.columnsPositions,
	theColumnsPositions = [];
	
	for (var i = 0; i < columnsPositions.length; i++) {

		if (!toTheRight && i % 2 == 0) { // to the left
			theColumnsPositions.push(leftMargin + columnsPositions[i]);
		}
		else if (toTheRight && i % 2 != 0) { // to the right
			theColumnsPositions.push(leftMargin + columnsPositions[i]);
		}			
	}
	
	return theColumnsPositions;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelection() {
	var selection = app.selection,
	selectedItems = [];
	
	for (var i = 0; i < selection.length; i++) {
		if (selection[i].hasOwnProperty("geometricBounds")) {
			selectedItems.push(selection[i]);
		}
	}

	return selectedItems;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function RoundWithDecimal(number, decimals) {
	var multiplier = Math.pow(10, decimals);
	return Math.round(number * multiplier) / multiplier;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	if (selectedItems.length == 0) ErrorExit("Invalid selection.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
/* Description:
Here are two scripts that have the same concept.
Perhaps the script can reference column guides?
 
Move object(s) to the column to the right
With one or more object selected,
Script references nearest column (X coordinate) and moves object(s) from right side of the object(s) to that column.
Here are the X coordinates to snap the object(s) when moving to the the right:
1.4398 in
2.5362 in
3.6326 in
4.7289 in
5.8253 in
6.9217 in
8.0181 in
9.1145 in
10.2109 in
11.3072 in
12.4036 in
 
Move object(s) to the column to the left
With one or more object selected,
Script references nearest column (X coordinate) and moves object(s) from left side of the object(s) to that column.
 
Here are the X coordinates to snap the object(s) when moving to the the left:
 
0.5 in
1.5964 in
2.6928 in
3.7892 in
4.8855 in
5.9819 in
7.0783 in
8.1747 in
9.2711 in
10.3675 in
11.4638 in
12.5602 in
//--------------------------------------------------------------------------------------------------------------------------------------------------------

5 XII 2017
For Move object by column, the object should still be moved even when it sits exactly on the column guides. 
Right now an object can no longer move left or right if sits exactly on the column.

-- Fixed in version 1.1
//--------------------------------------------------------------------------------------------------------------------------------------------------------

23 III 2023
These attached scripts do not function properly on right-hand pages.
Please fix them.

-- Fixed in version 1.2
*/