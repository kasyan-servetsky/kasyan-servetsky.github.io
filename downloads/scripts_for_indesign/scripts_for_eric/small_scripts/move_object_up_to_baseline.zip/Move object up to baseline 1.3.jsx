﻿/* Copyright 2017, L'Express de Toronto Inc.
November 8, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Move object up to baseline",
doc, selectedItems, increment, topMargin, lastBaselinePosition, relativeToTopMargin;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" script");

//===================================== FUNCTIONS ======================================
function Main() {
	// Save & change units
	var savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits;
	var savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
	doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.POINTS;
	doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS;
	
	var item;

	for (var i = 0; i < selectedItems.length; i++) {
		item = selectedItems[i];
		
		try {
			MoveObjectUpToBaseline(item);
		}
		catch(err) {
			//$.writeln(err.message + ", line: " + err.line);
		}
	}

	// Restore units
	doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
	doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MoveObjectUpToBaseline(obj) {
	var objOldTopPos = obj.visibleBounds[0];

	if (objOldTopPos > topMargin) { // move object only if it's below the top margin
		var distanceFromTopMarginOld = objOldTopPos - topMargin;
		var numOfBaselinesFromFromTopMargine = Math.floor(distanceFromTopMarginOld / increment);
		var distanceFromTopMargineNew = numOfBaselinesFromFromTopMargine * increment;
		
		if (objOldTopPos > lastBaselinePosition) { // if it's below the bottom margin, move it up to the last baseline
			var distanceToMove = objOldTopPos - lastBaselinePosition;	
		}
		else {
			var distanceToMove = distanceFromTopMarginOld - distanceFromTopMargineNew;
		}

		obj.move(undefined, [0, -distanceToMove]);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelection() {
	var selection = app.selection,
	selectedItems = [];
	
	for (var i = 0; i < selection.length; i++) {
		if (selection[i].hasOwnProperty("geometricBounds")) {
			selectedItems.push(selection[i]);
		}
	}

	return selectedItems;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	selectedItems = GetSelection();
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	if (selectedItems.length == 0) ErrorExit("Invalid selection.", true);
	
	var pageHeight = doc.documentPreferences.pageHeight;
	var marginPreferences = doc.marginPreferences;
	var gridPreferences = doc.gridPreferences;
	increment = gridPreferences.baselineDivision;
	var relativeToTopMargin = (gridPreferences.baselineGridRelativeOption == BaselineGridRelativeOption.TOP_OF_MARGIN_OF_BASELINE_GRID_RELATIVE_OPTION) ? true : false;
	topMargin = (relativeToTopMargin) ? marginPreferences.top : 0;	
	var bottomMargin = marginPreferences.bottom;
	var totalNumberOfBaselines = (relativeToTopMargin) ? Math.floor((pageHeight - topMargin - bottomMargin) / increment) : Math.floor(pageHeight / increment);
	lastBaselinePosition = (relativeToTopMargin) ? totalNumberOfBaselines * increment + topMargin : totalNumberOfBaselines * increment;

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------