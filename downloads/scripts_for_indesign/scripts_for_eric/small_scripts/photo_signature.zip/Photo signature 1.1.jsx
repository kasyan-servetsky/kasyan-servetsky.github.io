﻿/* Copyright 2017, L'Express de Toronto Inc.
November 12, 2017
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com

Description:
With one frame selected,
script finds paragraph styled with ‘byline begin’ or ‘byline end’
script searches for the text string in that paragraph and looks for a file name ‘[string].idms’ in:
/Home/Dropbox-LExpress/Dropbox/PhotoSignatures  for Mac or if user is on PC, then the PC equivalent.
Script loads snippet and places snippet on the top left corner of the frame (see InDesign file for end state example)
Let me know if there are problems with spaces or special characters in file names between Mac and PC */
//======================================================================================
var scriptName = "Photo signature",
doc, textFrame, story, parStyleBylineBegin, parStyleBylineEnd;

//~ PreCheck();
app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" script");

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var txt = FindGrep(story, parStyleBylineBegin);
		
		if (txt == null) {
			txt = FindGrep(story, parStyleBylineEnd);
		}

		if (txt == null) {
			ErrorExit("Can't find the author's name: neither 'byline begin', nor 'byline end' was found in the selected text frame.", true);
		}

		var authorName = txt.contents.replace(/\r/g, "");
		var snippetsFolderPath = (File.fs == "Macintosh") ? "/Home/Dropbox-LExpress/Dropbox/PhotoSignatures/" : "/E/Dropbox/Work in progress/_Eric/PhotoSignatures/";
		var snippetFilePath = snippetsFolderPath + authorName + ".idms";
		var snippetFile = new File(snippetFilePath);
		
		if (snippetFile.exists) {
			var gb = textFrame.geometricBounds;
			var page = textFrame.parentPage;
			var placedSnippet = page.place(snippetFile, [gb[1], gb[0]], textFrame.itemLayer, false)[0];
			txt.remove();
			CleanUp(story);
		}
		else {
			alert("Snippet wasn't found: " + snippetFilePath, scriptName, true);
		}
	}
	catch(err) {
		//$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FindGrep(story, parStyle) {
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = ".+\\r*";
	app.findGrepPreferences.appliedParagraphStyle = parStyle;
	var foundItems = story.findGrep();
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	return (foundItems.length != 0) ? foundItems[0] : null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CleanUp(story) {
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = "\\r+$";
	app.changeGrepPreferences.changeTo = "";
	var foundItems = story.changeGrep();
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	if (app.selection.length == 0) {
		ErrorExit("Nothing is selected.", true);
	}
	else if (app.selection.length == 1) {
		if (app.selection[0].constructor.name == "TextFrame") {
			textFrame = app.selection[0];
			story = app.selection[0].parentStory;
		}
		else if (app.selection[0].hasOwnProperty("baseline")) {
			story = app.selection[0].parentStory;
			textFrame = story.textContainers[0];
		}
		else {
			ErrorExit("Please select one text frame, or some text, or place the cursor and try again.", true);
		}
	}
	else if (app.selection.length > 1) {
		ErrorExit("Only one text frame or some text should be selected, or the cursor placed into the text.", true);
	}

	parStyleBylineBegin = doc.paragraphStyles.itemByName("byline begin");
	if (!parStyleBylineBegin.isValid) ErrorExit("Paragraph style 'byline begin' doesn't exist in the document.", true);
	parStyleBylineEnd = doc.paragraphStyles.itemByName("byline end");
	if (!parStyleBylineEnd.isValid) ErrorExit("Paragraph style 'byline end' doesn't exist in the document.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------