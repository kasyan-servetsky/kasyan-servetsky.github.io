﻿
var a = app.activeDocument.allPageItems,  t; 

while( t=a.pop() )  {

    if( !(t instanceof TextFrame) ) continue; 

    try{ var outlineList = t.createOutlines(true) ;//removes original

        var thisItem = outlineList[0];//assumes only 1 item in frame

        //in case you want to style polygon created

        thisItem.fillColor = "Dark Red";

        thisItem.strokeWeight = "2 pt";

        thisItem.strokeColor = "Black";

    } catch(_){

    } 

}