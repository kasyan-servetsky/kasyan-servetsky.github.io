﻿#targetengine "session"

var afterImportEventListener = app.addEventListener("afterImport", AfterImport, false);

function AfterImport(event) {
	function CreateBridgeTalkMessage(filePath) {
		var bt = new BridgeTalk();
		bt.target = "photoshop";
		var script = OpenInPhotoshop.toString() + "\r";
		script += "OpenInPhotoshop(\""  + filePath + "\");";
		bt.body = script;
		bt.send(100);
	}

	function OpenInPhotoshop(filePath) {
		try {
			app.displayDialogs = DialogModes.NO;
			var psDoc = app.open(new File(filePath));
			app.displayDialogs = DialogModes.ALL;
			app.bringToFront(); // Make Photoshop the active application		
		}
		catch(err) {
			psDoc.close(SaveOptions.DONOTSAVECHANGES);
			app.displayDialogs = DialogModes.ALL;
		}
	}

	var filePath = event.fullName.absoluteURI;
	
	// Filter out image types. Placing text also triggers the event.
	if (filePath.match(/(jpg|tif|tiff|psd|png)/i) != null) {
		CreateBridgeTalkMessage(filePath);
	}
}