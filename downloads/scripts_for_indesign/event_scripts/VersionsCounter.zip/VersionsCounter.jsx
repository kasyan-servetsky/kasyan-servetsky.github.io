﻿// VersionsCounter.jsx  
//DESCRIPTION: Sets the maximum version number for the 'saveVersion.jsx' event script  
  
setMax(app.activeDocument);  
  
function setMax( aDoc )  
{  
        if (myMax = aDoc.extractLabel( 'theMax' )) {}  
        else   
            var myMax = 1;  
        do   
        {  
            var myMax = prompt ('Maximum number of versions:', myMax);  
            if (myMax == null)  
                exit();  
        } while (myMax < 1)  
        aDoc.insertLabel( 'theMax', myMax);  
        return myMax;  
}  