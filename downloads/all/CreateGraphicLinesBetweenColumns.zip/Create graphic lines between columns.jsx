// JavaScript to draw a line between column
// http://www.nobrainer.dk/create-graphiclines-between-columns/
//Changes, then resets the active document's measurement units.
//Assumes you have a document open.
var myObjectList = new Array;
//Script does nothing if no documents are open or if no objects are selected.
if(app.documents.length != 0){
    var myDocument = app.activeDocument
    if(app.selection.length != 0){
        //Process the objects in the selection to create a list of
        //qualifying objects (text frames).
        for(myCounter = 0; myCounter < app.selection.length; myCounter ++){
            switch(app.selection[myCounter].constructor.name){
                case "TextFrame":
                    myObjectList.push(app.selection[myCounter]);
                    break;
            }
        }
        if(myObjectList.length != 0){
            with (myDocument.viewPreferences){
                var myOldXUnits = horizontalMeasurementUnits;
                var myOldYUnits = verticalMeasurementUnits;
                horizontalMeasurementUnits = MeasurementUnits.points;
                verticalMeasurementUnits = MeasurementUnits.points;
            }
            drawGraphicLines(myObjectList);
            with (myDocument.viewPreferences){
                try{
                    horizontalMeasurementUnits = myOldXUnits;
                    verticalMeasurementUnits = myOldYUnits;
                }
                catch(myError){
                    alert("Could not reset custom measurement units.");
                }
            }
        }
    }
}

function drawGraphicLines(myTextFrames) {
    //alert(myTextFrames.length);
    for (tf = 0; tf < myTextFrames.length; tf++) {
        var myTextFrame = myTextFrames[tf];
        //alert(myTextFrame);
        var myFrameBounds = myTextFrame.geometricBounds;
        var myFrameColumns = myTextFrame.textFramePreferences.textColumnCount;

        var myFrameWidth = myFrameBounds[3] - myFrameBounds[1];
        var myColWidth = myTextFrame.textFramePreferences.textColumnFixedWidth;
        var myColGutter = myTextFrame.textFramePreferences.textColumnGutter;
        var myTextFrameInset = myTextFrame.textFramePreferences.insetSpacing[0];
            for(i = 1; i < myFrameColumns; i++) {
            // draw a line between collumns
            with (myTextFrame.parent) {
                myX = myFrameBounds[1] + myColWidth * i + myColGutter * i - (myColGutter/2) + myTextFrameInset;
                myBounds = new Array(myFrameBounds[0],
                                    myX,
                                    myFrameBounds[2], 
                                    myX
                                    );
                                //alert(myBounds);
                myLine = graphicLines.add({geometricBounds: myBounds});
            }
        }
    }
}