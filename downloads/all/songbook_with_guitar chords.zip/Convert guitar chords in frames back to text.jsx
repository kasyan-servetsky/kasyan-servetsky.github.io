﻿/* Copyright 2016, Kasyan Servetsky
January 11, 2015
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Convert guitar chords in frames back to text",
doc;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");

//===================================== FUNCTIONS ======================================
function Main() {
	var frame, ip;
	var sel = app.selection[0];
	var textFrames = sel.textFrames;
	
	for (var i = textFrames.length - 1; i >= 0; i--) {
		frame = textFrames[i];
		ip = frame.parent.insertionPoints[0];
		ip.contents = "[" + frame.contents + "]";
		frame.remove();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (app.selection.length == 0 || app.selection.length > 1 || (!app.selection[0].hasOwnProperty("baseline") && app.selection[0].constructor.name != "TextFrame") || app.selection[0].constructor.name == "InsertionPoint") ErrorExit("One text frame or some text should be selected, or the cursor should be inserted into the text.", true);

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}