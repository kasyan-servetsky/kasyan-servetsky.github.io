﻿/* Copyright 2016, Kasyan Servetsky
January 9, 2015
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Songbook with guitar chords",
doc, objStyle;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");

//===================================== FUNCTIONS ======================================
function Main() {
	var sel = app.selection[0];
	
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = "\\[.+?\\]";
	var foundItems = sel.findGrep(true);
	
	for (var i = 0; i < foundItems.length; i++) {
		AddFrame(foundItems[i]);
	}

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddFrame(txt) {
	var textFrame = txt.insertionPoints[0].textFrames.add();
	txt.move(LocationOptions.AT_BEGINNING, textFrame.texts[0]);
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = "\\[|\\]";
	app.changeGrepPreferences.changeTo = "";
	textFrame.parentStory.changeGrep();
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	
	var gb = textFrame.geometricBounds;
	textFrame.geometricBounds = [gb[0], gb[1], gb[2]+10, gb[3]+10];

	textFrame.fit(FitOptions.FRAME_TO_CONTENT);	
	textFrame.fit(FitOptions.FRAME_TO_CONTENT);	
	textFrame.applyObjectStyle(objStyle, true, true);	
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	objStyle = doc.objectStyles.itemByName("Chords");
	if (!objStyle.isValid) ErrorExit("Object style \"Chords\" doesn't exist.", true);
	if (app.selection.length == 0 || app.selection.length > 1 || (!app.selection[0].hasOwnProperty("baseline") && app.selection[0].constructor.name != "TextFrame") || app.selection[0].constructor.name == "InsertionPoint") ErrorExit("One text frame or some text should be selected, or the cursor should be inserted into the text.", true);

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}