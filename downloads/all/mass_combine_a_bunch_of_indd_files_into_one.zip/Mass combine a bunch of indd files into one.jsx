﻿// DESCRIPTION: Mass combine a bunch of indd files into one.
// 6 July 2013

// INSTRUCTIONS
// Put all the files you want to combine into one document in a folder, named in the order
// you want them to appear in the book (e.g. "001.indd", "002.indd", etc. or something) so
// they appear correctly when sorted by name in finder/explorer.

#target indesign

// set the destination document as the active document.
var destination_doc = app.activeDocument;

// select the source folder
var sourceFolder = Folder.selectDialog("Select a folder with source InDesign files.");

// if we're not in the source folder, stop running the script.
if ( !sourceFolder ) {
	exit(0);
}

// set file list and run through each file. Sorting them alphanumerically.
var fileList = sourceFolder.getFiles();
fileList.sort();

// run through each file
for ( var i = 0; i < fileList.length; i++ ) {
	var source_file = fileList[i];
	// making sure it's an indesign file...
	if ( source_file instanceof File && source_file.name.match(/\.indd$/i)) {
		app.open(source_file);
		var source_doc = app.documents.item(source_file.name);
		var sourcePages = source_doc.pages.item(0);
		// break the master page items so they can be moved onto the new document.
		var masterItems = sourcePages.masterPageItems;
		if ( masterItems.length > 0 ) {
			for ( var j=0; j<masterItems.length; j++ ) {
				masterItems[j].override(sourcePages);
			}
		}
		// removing the applied master (this can mess up some files if not done)
		sourcePages.appliedMaster=null;
		// duplicating it in the original file (due to errors) and them moving it to
		// the destination document.
		sourcePages.duplicate(LocationOptions.AFTER, source_doc.pages.item(0));
		sourcePages.move(LocationOptions.AFTER, destination_doc.pages.item(-1));
		// closes the file that was opened without saving (to avoid memory problems)
		app.activeDocument.close(SaveOptions.NO);
	}
}