CreateBridgeTalkMessage();

function CreatePalette () {
	var myDialog = new Window('palette', 'Save PSD-PNG');
	var myGroup = myDialog.add('group', undefined, '');
	myGroup.orientation = 'row'; // change to 'column' if you want to place buttons vertically
	var mySavePSD = myGroup.add('button', undefined, 'Save PSD', {name:'SavePSD'});
	var mySavePNG = myGroup.add('button', undefined, 'Save PNG', {name:'SavePNG'});
	var myDelPSD = myGroup.add('button', undefined, 'Delete', {name:'myDelPSD'});
	myDialog.show();

	myDialog.onClose = function (){
		try {
			var myPrefsFolder = new Folder(Folder.userData.absoluteURI + '/TempScriptData');
			var myTempFile = new File(myPrefsFolder.fsName + '/TempData.txt');
			if (myTempFile.exists) myTempFile.remove();
			if (myPrefsFolder.exists) myPrefsFolder.remove();
		}
		catch (err) {}
	}

	mySavePSD.onClick =function (){
		if (app.documents.length > 0) {
			var myDoc = app.activeDocument;
			var myDocName = myDoc.name;
			var myFolder = new Folder('~/Desktop/psd'); // change location to your own folder
			if (!myFolder.exists) myFolder.create();
			var myDialog = new Window('dialog', 'Save file as PSD');
			myDialog.size = {width:300, height:90};
			var myEditText = myDialog.add('edittext');
			myEditText.preferredSize = {width:200, height:20};
			var myNewName = myEditText.text;
			var myGroup = myDialog.add('group');
			myGroup.orientation = 'row';
			var myOkBtn = myGroup.add('button', undefined, 'Save', {name:'ok'});
			var myCancelBtn = myGroup.add('button', undefined, 'Cancel', {name:'cancel'});
			if (myDialog.show() == 1) {
				var myNewName = myEditText.text;
				if (myNewName != "") {
					myNewName += '.psd';
					var myNewFile = new File(myFolder.fsName + '/' + myNewName);
					var id51 = charIDToTypeID( "save" );
					var desc8 = new ActionDescriptor();
					var id52 = charIDToTypeID( "As  " );
					var desc9 = new ActionDescriptor();
					var id53 = stringIDToTypeID( "maximizeCompatibility" );
					desc9.putBoolean( id53, true );
					var id54 = charIDToTypeID( "Pht3" );
					desc8.putObject( id52, id54, desc9 );
					var id55 = charIDToTypeID( "In  " );
					desc8.putPath( id55, new File( myNewFile ) );
					var id56 = charIDToTypeID( "LwCs" );
					desc8.putBoolean( id56, true );
					executeAction( id51, desc8, DialogModes.NO );
					var myLastPsd = app.activeDocument.fullName.toSource();
					try {
						var myPrefsFolder = new Folder( Folder.userData.absoluteURI + '/TempScriptData' );	
						if (!myPrefsFolder.exists) myPrefsFolder.create();
						var myTempFile = new File(myPrefsFolder.fsName + '/TempData.txt');
						myTempFile.open("w");
						myTempFile.write(myLastPsd);
						myTempFile.close();
					}
					catch (err) {
						alert("Failed to create a temp file. -- Error: " + err.message);
						exit();
					}
				}
			}
		}
		else {
			alert("Please open a document and try again.");
		}
	}

	mySavePNG.onClick =function (){
			if (app.documents.length > 0) {
			var myDoc = app.activeDocument;
			var myDocName = myDoc.name;
			if (myDocName.lastIndexOf("psd") > 0) {
				var myNewFolder = new Folder('~/Desktop/png'); // change location to your own folder
				if (!myNewFolder.exists) myNewFolder.create();
				var myNewName = myDocName.replace(/.psd$/, '1.png');
				var myNewFile = new File(myNewFolder.fsName + '/' + myNewName);
				myDoc.saveAs(myNewFile, SaveDocumentType.PNG, true, Extension.LOWERCASE);
			}
			else {
				alert("The current document is not PSD-file.");
			}
		}
		else {
			alert("Please open a document and try again.");
		}
	}

	myDelPSD.onClick =function () {
		try {
			var myPrefsFolder = new Folder( Folder.userData.absoluteURI + '/TempScriptData' );	
			var myTempFile = new File(myPrefsFolder.fsName + '/TempData.txt');
			if (myTempFile.exists) {
			myTempFile.open("r");
			var myDoc = eval(myTempFile.read());
			myTempFile.close();
				if (!IsDocOpen(myDoc)) {
					myDoc.remove();
				}
				else {
					alert("Can't delete " + myDoc.fullName + " because it's open.");
				}
			}
			else {
				alert("The last saved PSD-file: " + myDoc.fullName + " does not exist.");
			}
		}
		catch (err) {
			alert("Failed to delete PSD-file. -- Error: " + err.message);
		}

		function IsDocOpen(myDoc) {
			for (i = 0; i < app.documents.length; i++) {
				if (app.documents[i].fullName == myDoc.fullName) {
					return true;
				}
			}
			return false;
		}
	}
}

function CreateBridgeTalkMessage() {
	var bt = new BridgeTalk();
	bt.target = "photoshop";
	var myScript = CreatePalette.toString() + '\r';
	myScript += 'CreatePalette();';
	bt.body = myScript; 
	bt.send();
}