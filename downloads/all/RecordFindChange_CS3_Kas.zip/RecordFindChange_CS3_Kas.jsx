//RecordFindChange_CS3.jsx   
// version 0.3  
//  
//An InDesign CS3 JavaScript   
//Writes the current find/change preferences to a text file so that you can copy/paste   
//them into a find/change list file.   
  
  
String.prototype.cleanProps = function ()   
{  
    var s = this;  
    // split parameters  
    s = s.replace( /, /g, '\r' );   
    // delete breaks at start and end  
    s = s.replace( /^\({/, '' );   
    s = s.replace( /\}\)$/, '' );   
    // delete undefined  
    s = s.replace( /[\w]+:1851876449\r/g, '' );  
    s = s.replace( /[\w]+:\"\"\r/g, '' );  
    s = s.replace( /[\w]+:null\r/g, '' );  
    // delete some dirty or useless  parameters  
    s = s.replace( /[^\r]+\/@find-[^\r]+\r+/g, '' );  
    s = s.replace( /[^\r]+\/@change-[^\r]+\r+/g, '' );  
    s = s.replace( /parent:resolve\(\"\/\"\)/g, '' );  
    // column or single line  
    if ( singleLine == true )  
    {  
        s = s.replace( /\r\r*/g, ', ' );  
        s = '{' + s + '}';  
        s = s.replace( /, }/g, '}' );     
    }  
    else  
        s.replace( /\r\r+/g, '\r' );  
    return s;  
}  
  
// =================== Preferences ================  
  
// singleLine = true -> Command line for findChangeByList.jsx  
// singleLine = false -> 	List View  
var singleLine = true;  
  
// fileSelect = true -> Select a file for output
// fileSelect = false -> Output file: 'desktop / findChangeStrings.txt'
var fileSelect = false;  
  
// open TXT file after executing the script
var fileOpen = true;  
  
// Final report output  
var finalMessage = true;  
  
// Record findChangeTextOptions and findChangeGrepOptions 
var catchOptions = true;  
// ===============================================================  
  
  
// ===============================================================  
//                                  main
// ===============================================================  
var myResult;   
var myFindTextProperties = app.findTextPreferences.properties.toSource().cleanProps();  
var myChangeTextProperties = app.changeTextPreferences.properties.toSource().cleanProps();  
var myFindChangeTextOptions = ( catchOptions == true )   
    ? app.findChangeTextOptions.properties.toSource().cleanProps()  
    : '{}';  
  
var myFindGrepProperties = app.findGrepPreferences.properties.toSource().cleanProps();  
var myChangeGrepProperties = app.changeGrepPreferences.properties.toSource().cleanProps();  
var myFindChangeGrepOptions =  ( catchOptions == true )   
    ? app.findChangeGrepOptions.properties.toSource().cleanProps()  
    : '{}';  
  
var myFile = myGetFileName();   
var myData = collectData();  
writeData ( myData );  
if ( finalMessage == true )  
    alert('Done.');  
  
// ===============================================================  
//                                  functions
// ===============================================================  
function myGetFileName()  
{   
  
	if ( fileSelect == false )  
    {  
        //var myFile =  new File( '~/Desktop/findChangeStrings.txt' ) 
		var myFile =  new File( 'findChangeStrings.txt' );
    }  
    else  
    {  
        if( File.fs != 'Macintosh' )  
        {   
           
			//Filter files by extension.   
            var myFile = File.saveDialog( 'Save Text File As:', 'Text Files:*.txt;All Files:*' )   
        }   
        else  
        {   
               
			var myFile = File.saveDialog( 'Save Text File As:' )   
        }   
        if ( myFile == null )  
            exit();  
    }  
    return myFile;   
}  
  
function collectData()  
{  
    if ( singleLine == true )  
    {  
        if ( myFindTextProperties == '{}' && myChangeTextProperties == '{}' )  
        {  
            var myText = '';  
        }  
        else  
        {     
            var myText = 'text' + '\t' +  
                myFindTextProperties + '\t' +  
                myChangeTextProperties + '\t' +  
                myFindChangeTextOptions +   
                '\t//Comment\r\r';  
        }  
        if ( myFindGrepProperties != '{}' || myChangeGrepProperties != '{}' )  
        {  
            myText += 'grep' + '\t' +  
            myFindGrepProperties + '\t' +  
            myChangeGrepProperties + '\t' +   
            myFindChangeGrepOptions +  
            '\t//Comment';  
        }  
    }  
    else  
    {  
        if ( myFindTextProperties == '' && myChangeTextProperties == '' )  
        {  
            var myText = '';  
        }  
        else  
        {     
            var myText = '//FindTextProperties\r' +   
                myFindTextProperties + '\r\r' +  
                '//ChangeTextProperties\r' +   
                myChangeTextProperties + '\r\r' +  
                '//FindChangeTextOptions\r' +   
                myFindChangeTextOptions + '\r\r';  
        }  
        if ( myFindGrepProperties != '' || myChangeGrepProperties != '' )  
        {  
            myText += '//FindGrepProperties\r' +           
                myFindGrepProperties + '\r\r' +  
                '//ChangeGrepProperties\r' +           
                myChangeGrepProperties + '\r\r' +   
                '//FindChangeGrepOptions\r' +   
                myFindChangeGrepOptions;  
        }  
    }  
    return myText;  
}  
  
function writeData ( aData )  
{  
    if( myFile!='' )  
    {   
        //Open the file for writing.   
        myResult = myFile.open( 'w', undefined, undefined );   
    }  
    if( myResult != false )  
    {      
        myFile.writeln( aData );           
        myFile.close();   
        if ( fileOpen == true )   
            myFile.execute();  
    }   
}  