#target "bridge"

var SnpCreateTextInspectorPanel = {};

SnpCreateTextInspectorPanel.getDetails = function() {
	var myObj = app.document.selections[0];
	myObj.refresh();
	var myMd = myObj.metadata;
	myMd.namespace = "http://ns.adobe.com/xap/1.0/";
	var myDesc = myMd.read("http://ns.adobe.com/xap/1.0/", "xap:Description");
	var retval = (myDesc != "") ? myDesc : "No information about links";
	return retval;
}

if ((MenuElement.find("ShowInDesignLinks" ))) {
	$.writeln("Error:Menu element already exists!\nRestart Bridge to run this snippet again.");
}
else {	
	main();
}

function main() {
	var myTest = new MenuElement( "command", "Show InDesign links", "at the end of Tools", "ShowInDesignLinks" ); 
	myTest.onSelect = function () {
		// Create the object-inspector panel
		var myPanel = new InspectorPanel("Kasyan's Panel");
		// Register the panel with the application.
		app.registerInspectorPanel(myPanel);
		var kvp = [ ["","[[javascript:SnpCreateTextInspectorPanel.getDetails()]]"] ];
		var myTextPanelette = new TextPanelette("Kasyan Text Panelette", "List of links", "[[this]]", kvp);
		// Register the subpanel with the panel.
		myPanel.registerPanelette(myTextPanelette);
		// Show the inspector panel
		app.document.displayInspectorView = true;
	}
}