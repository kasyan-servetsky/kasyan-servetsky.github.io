﻿#target Indesign

if (app.documents.length == 0) {
	alert("Please open a document and try again.");
	exit();
}
 
Array.prototype.unique = function() {
	var o = {}, i, l = this.length, r = [];
	for(i=0; i<l;i+=1) o[this[i]] = this[i];
	for(i in o) r.push(o[i]);
	return r;
};
 
 
var storyFiles = new Array();
var currDoc = app.activeDocument;
var docName = currDoc.name;
var currStories = currDoc.stories.everyItem().getElements();
l = currStories.length;
 
while(l--) {
	currStory = currStories[l];
	currStory.exportFile(ExportFormat.TEXT_TYPE, File('~/Desktop/' + docName + l + '.txt'));
	storyFiles.push(File('~/Desktop/' + docName + l + '.txt'))
}

var masterStory = '';
l= storyFiles.length;
while(l--) {
	currExport = storyFiles[l];
	currExport.open('r');
	masterStory = masterStory + currExport.read();
	currExport.close();
	currExport.remove();
}

var finalCut =masterStory.replace(/[?,.!\n\r]/g,' ').split(' ').unique().sort().join('\n');
destFile = File('~/Desktop/' + docName.replace(/indd/, 'txt'));
write_file(destFile, finalCut);
destFile.execute();

function write_file(_file, _data) { 
	_file.open('w'); 
	_file.encoding = 'UTF-8'; 
	_file.write(_data); 
	_file.close(); 
} 