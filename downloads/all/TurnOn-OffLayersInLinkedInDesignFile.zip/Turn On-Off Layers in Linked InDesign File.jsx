var myDoc = app.activeDocument;
var myPages = myDoc.pages;

for (i = 0; i < myPages.length; i++) {
	var myPlacedFile;
	var myPage = myPages[i];
	if (myPage.appliedMaster.name == "B-Master") {
		var myGraphics = myPage.allGraphics;
		for (j = myGraphics.length-1; j >= 0; j--) {
			myPlacedFile = myPage.allGraphics[j];
			if (myPlacedFile.constructor.name == "ImportedPage" && myPlacedFile.itemLink.linkType == "InDesign") {
				if (parseInt(myPage.name) % 2 == 0) {
					myPlacedFile.graphicLayerOptions.graphicLayers.item("Layer 1").currentVisibility = true;
					myPlacedFile = myPage.allGraphics[j];
					myPlacedFile.graphicLayerOptions.graphicLayers.item("Layer 2").currentVisibility = false;
				}
				else {
					myPlacedFile.graphicLayerOptions.graphicLayers.item("Layer 2").currentVisibility = true;
					myPlacedFile = myPage.allGraphics[j];
					myPlacedFile.graphicLayerOptions.graphicLayers.item("Layer 1").currentVisibility = false;
				}
			}
		}
	}
}

alert("Done");