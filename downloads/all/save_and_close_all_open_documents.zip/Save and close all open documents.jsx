﻿Main();

//===================================== FUNCTIONS  ======================================
function Main() {
	var docs = app.documents;
	
	for (var i = docs.length-1; i >= 0; i--) {
		docs[i].close(SaveOptions.YES);
	}

}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function LogToFile(text) {
	var file = new File("~/Desktop/Log.txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text + "\r"); 
	file.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
/*
var doc = app.activeDocument;
app.selection[0];
$.writeln("");
alert("Pause");

for (var i = 0; i < myArray.length; i++) {
	
}
for (var i = myArray.length-1; i >= 0; i--) {
	
}

LogToFile(i + " - " + pars[i].index + "/" + pars[i].contents);
*/