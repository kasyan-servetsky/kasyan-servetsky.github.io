﻿var note,
doc = app.activeDocument;

app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;

app.findChangeGrepOptions.includeFootnotes = false;
app.findChangeGrepOptions.includeHiddenLayers = false;
app.findChangeGrepOptions.includeLockedLayersForFind = false;
app.findChangeGrepOptions.includeLockedStoriesForFind = false;
app.findChangeGrepOptions.includeMasterPages = false;

app.findGrepPreferences.findWhat = "\\[.+?\\]";
var foundItems = doc.findGrep();

for (var i = foundItems.length-1; i >= 0; i--) {
	try {
		var note = foundItems[i].convertToNote();
		note.texts[0].contents = note.texts[0].contents.replace(/(\[|\])/g, "");
	} catch (e) {
		alert("The string: " + foundItems[i].contents + " could not be converted to note");
	}
}

app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;