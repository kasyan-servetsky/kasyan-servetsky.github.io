var doc = app.activeDocument;
var links = doc.links;

for (var i = links.length-1; i >= 0; i--) {
	links[i].unlink();
}