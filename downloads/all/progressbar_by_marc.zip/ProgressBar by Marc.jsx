﻿var ProgressBar = function(/*str*/title)
{
     var w = new Window('palette', ' '+title, {x:0, y:0, width:340, height:60}),
          pb = w.add('progressbar', {x:20, y:12, width:300, height:12}, 0, 100),
          st = w.add('statictext', {x:10, y:36, width:320, height:20}, '');
     st.justify = 'center';
     w.center();
     this.reset = function(msg,maxValue)
          {
          st.text = msg;
          pb.value = 0;
          pb.maxvalue = maxValue||0;
          pb.visible = !!maxValue;
          w.show();
          };
     this.hit = function() {++pb.value;};
     this.hide = function() {w.hide();};
     this.close = function() {w.close();};
};


//------------------------------------------------
//      SAMPLE CODE
//------------------------------------------------

function main()
{
     var pBar = new ProgressBar("Script Title");
     var i;
     
     // Routine #1
     pBar.reset("Processing Routine #1...", 100);
     for( i=0 ; i < 100; ++i, pBar.hit() )
          {
          $.sleep(10);
          }
     
     // Routine #2
     var i;
     pBar.reset("Processing Routine #2...", 10);
     for( i=0 ; i < 10; ++i, pBar.hit() )
          {
          $.sleep(300);
          }
     
     pBar.close();
}
main();