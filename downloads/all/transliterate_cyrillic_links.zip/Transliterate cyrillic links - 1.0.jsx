﻿/* Copyright 2012, Kasyan Servetsky
October 20, 2012
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var doc,
scriptName = "Transliterate cyrillic links - 1.0";

Main();

//===================================== FUNCTIONS  ======================================
function Main() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument; // global
	
	var link, linkUsage, linkName, filePath, file, newName, renameResult, 
	newPath, folderPath, basicName,extension, newBasicName, increment,
	thisLink, thisLinkFile, multiUsedLinks, allLinks, originalLinkFile,
	renamedLinksCounter = 0,
	links = doc.links;

	for (var i = links.length-1; i >= 0; i--) {
		link = links[i];
		linkUsage = LinkUsage(link);			
		linkName = link.name;
		
		if (linkName.match(/[А-я]/gi) != null && link.status == LinkStatus.NORMAL) {
			filePath = link.filePath;
			file = new File(filePath);
			folderPath = file.parent.fullName;
			basicName = GetFileName(linkName);
			extension = GetExtension(linkName);
			newBasicName = ToTranslit(basicName);
			newName = newBasicName + "." + extension;
			newPath = folderPath + "/" + newName;
			newFile = new File(newPath);
			
			if (file.exists) {
				if (newFile.exists) {
					increment = 1;
					while (newFile.exists) {
						newBasicName = ToTranslit(basicName) + "(" + increment++ + ")";
						newName = newBasicName + "." + extension;
						newPath = folderPath + "/" + newName;
						newFile = new File(newPath);
					}
				}

				renameResult = file.rename(newName);
				
				if (renameResult) {
					if (newFile.exists) {
						originalLinkFile = new File(link.filePath);
						link.relink(newFile);
						
						if (linkUsage > 1) {
							thisLinkFile;
							multiUsedLinks = [];
							allLinks = doc.links;

							for (var d = 0; d < allLinks.length; d++)  {
								thisLinkFile = new File(allLinks[d].filePath);
								
								if (thisLinkFile.fsName == originalLinkFile.fsName) {
									multiUsedLinks.push(allLinks[d].id);
								}
							}

							for (var f = multiUsedLinks.length-1; f >= 0 ; f--) {
								var thisLink = doc.links.itemByID(multiUsedLinks[f]);
								if (thisLink != null) {
									thisLink.relink(newFile);
								}
							}
						}
					
						renamedLinksCounter++;
					}
				}
			}
		}
	}
	
	var report = renamedLinksCounter + " links " + ((renamedLinksCounter == 1) ? "was" : "were") + " renamed.";
	alert("Finished. " + report, scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetFileName(fileName) {
	var str = "";
	var res = fileName.lastIndexOf(".");
	if (res == -1) {
		str = fileName;
	}
	else {
		str = fileName.substr(0, res);
	}
	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetExtension(name) {
	var idx = name.lastIndexOf(".");
	var ext = "";
	if (idx > -1) {
		ext = name.substr((idx + 1));
	}
	return ext;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ToTranslit(text) {
	return text.replace(/([а-яё])|([\s_-])|([^a-z\d])/gi,
	function (all, ch, space, words, i) {
		if (space || words) {
			return space ? "-" : "";
		}
		var code = ch.charCodeAt(0),
			index = code == 1025 || code == 1105 ? 0 : code > 1071 ? code - 1071 : code - 1039,
			t = [ "yo", "a", "b", "v", "g", "d", "e", "zh",
					"z", "i", "y", "k", "l", "m", "n", "o", "p",
					"r", "s", "t", "u", "f", "h", "c", "ch", "sh",
					"shch", "", "y", "", "e", "yu", "ya" ];

		return t[index];
	});
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function LinkUsage(link) {
	var links = doc.links,
	counter = 0;
	for (var i =  0; i < links.length; i++) {
		if (link.filePath == links[i].filePath) {
			counter++;
		}
	}
	return counter;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------