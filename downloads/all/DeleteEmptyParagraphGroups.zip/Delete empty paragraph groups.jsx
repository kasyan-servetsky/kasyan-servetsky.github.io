var styleGroup;
var doc = app.activeDocument;
var styleGroups = doc.paragraphStyleGroups;

for (var p = styleGroups.length-1; p >= 0; p--) {
	ProcessGroups(styleGroups[p]);
}

function ProcessGroups(styleGroup) {
	if (styleGroup.allParagraphStyles.length == 0) {
		styleGroup.remove();
		return;
	}
	else if (styleGroup.paragraphStyleGroups.length > 0) {
		for (var g = styleGroup.paragraphStyleGroups.length-1; g >= 0; g--) {
			ProcessGroups(styleGroup.paragraphStyleGroups[g]);
		}
	}
}