﻿/* Copyright 2013, Kasyan Servetsky
January 30, 2013
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var doc,
scriptName = "Clean Up Index Topics - 1.0";

Main();
//===================================== FUNCTIONS  ======================================
function Main() {
	var topic, name, sortOrder;
	var startTime = new Date();
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);	
	var doc = app.activeDocument;

	var index = doc.indexes[0];
	var allTopics = index.allTopics;
	var log = false;
	var tmpArr = [];
	var counter = 0;
	var progressBarCounter = 0;
	
	// Progress bar
	var progressWin = new Window ("window", scriptName);
	var progressBar = progressWin.add ("progressbar", [12, 12, 550, 24], 0, undefined);
	progressBar.maxvalue = allTopics.length;
	var progressTxt = progressWin.add("statictext", undefined, "Starting cleaning up topics");
	progressTxt.bounds = [0, 0, 540, 20];
	progressTxt.alignment = "left";
	progressWin.show();
	
	for (var i = allTopics.length-1; i >= 0; i--) {
		topic = allTopics[i];
		
		progressBarCounter++;
		progressTxt.text = topic.name + " (" + (i+1) + " out of " + allTopics.length + ")";
		progressBar.value = progressBarCounter;
		
		// Change all en dashes (metacharacter: “^=”) to em dashes (metacharacter: “^_”)
		if (topic.name.match(/–/) != null) {
			topic.name = topic.name.replace(/–/g, "—");
			topic.sortOrder = topic.sortOrder.replace(/–/g, "—");
			counter++;
		}

		// Change all hyphens to em dashes UNLESS the word after the hyphen begins with a lower case letter. 
		if (topic.name.match(/-(?![0-9a-z])/) != null) {
			topic.name = topic.name.replace(/-(?![0-9a-z])/g, "—");
			topic.sortOrder = topic.sortOrder.replace(/-(?![0-9a-z])/g, "—");
			counter++;
		}

		// Change all ampersands (&) to “and” (no quotation marks)
		if (topic.name.match(/&/) != null) {
			topic.name = topic.name.replace(/&/g, "and");
			topic.sortOrder = topic.sortOrder.replace(/&/g, "and");
			counter++;
		}
	
		tmpArr.push(topic.name);
	} // end for

	var tmpStr = tmpArr.join("\r");
	if (log) WriteToFile(tmpStr);
	progressWin.close();
	var endTime = new Date();
	var duration = GetDuration(startTime, endTime);
	
	alert("Finished. " + counter+ " topics were changed.\n(time elapsed: " + duration + ")", scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------