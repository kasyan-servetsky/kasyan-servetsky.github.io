﻿// DoQueryList.jsx
// Программа для подготовки списка запросов, исполнения их и сохранения для использования в будущем.
// © Михаил Иванюшин, 2012 ivanyushin#yandex.ru
// Инструкция по работе с программой размещена на сайте adobeindesign.ru
// Всплывающие подсказки на кнопках также помогут разобраться в работе скрипта.
//
// Благодарю Питера Карела (Peter Kahrel) /Великобритания/, Лорана Турньера (Laurent Tournier) /Франция/, 
// Жаннету Кат (Janneta Kat) /Германия/, Татьяну Прокофьеву (Россия) и Алексея Чмеля (Россия) 
// за помощь в переводе сообщений с русского на другие языки и участие в тестировании программы.
//
// I owe much to Peter Kahrel (Great Britain), Laurent Tournier (France), Janneta Kat (Germany), Tatiana Prokofieva (Russia), Alexey Chmel (Russia) 
// for help in translating and testing this script.
//
#target indesign
#targetengine "DoQueryList"
////  
myFastHelp = true; // true - выводится подсказка при наведении курсора на кнопку;  false -- если эти подсказки раздражают, их можно отключить.
mySavePosition = true; 
myOwnQueriesInAppFolder = true; 
// myOwnQueriesInAppFolder = false в этом случае для хранения очередного исполняемого запроса будет использоваться UserTextFolder или UserGrepFolder
// myOwnQueriesInAppFolder =true в этом случае для хранения очередного исполняемого запроса будет использоваться AppTextFolder или AppGrepFolder
myFirstLockX = 177;
myFirstLockY= 177; 
var myLockX = myFirstLockX;
var myLockY = myFirstLockY;
var myLngInd = 0;
var myNamberOfLanguages = 4;
var mySetQFile = "";
var myScrQFolder = "";
var mySpecFolderName = ""; // каталог, в котором хранится созданный или загруженный список запросов и папки с запросами
var myCurrentFileQName = "";
var myLastFileName = "";
var myFilePathQSave = "";
var myOwnTextQueryFolder = "";
var myOwnGrepQueryFolder = "";
var myNumberOfPendingQueries = 0;
var myAsteriskInQueryName;
var myRightWindowSaved = false;
var myQueryList;
var myQueInfo;
var firstCharIsPlus = false;
/*
индексы языка
0 - русский
1 - английский
2 - немецкий
3 - французский

language indices
0 - russian language
1 - english language
2 - german language
3 - french language
*/   
DataRF = "22.10.2012";
myCurrentEditionData_xx_xx_xxR = DataRF;
myCurrentEditionData_xx_xx_xxE = "October 22, 2012";
myCurrentEditionData_xx_xx_xxD = "22. Oktober 2012";
myCurrentEditionData_xx_xx_xxF = DataRF;

myCurrentEditionData = new Array ( myCurrentEditionData_xx_xx_xxR,myCurrentEditionData_xx_xx_xxE,myCurrentEditionData_xx_xx_xxD,myCurrentEditionData_xx_xx_xxD);
myStartSpace = "\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0";
myMes01R = myStartSpace + "Подготовка списка запросов и обработка им текста " +"(" +myCurrentEditionData_xx_xx_xxR +" )"
myMes01E = myStartSpace + "Create Query List " + "(" + myCurrentEditionData_xx_xx_xxE +" )"
myMes01D = myStartSpace + "Abfrage List vorbereiten" + " (" + myCurrentEditionData_xx_xx_xxD + ")";
myMes01F = myStartSpace + "Créer une liste de requêtes" + " (" + myCurrentEditionData_xx_xx_xxF + ")";

myMes02 = "Перед запуском программы поставьте курсор в текст для подготовки всей статьи к верстке.\nВыделите часть текста для обработки только её.\n\nTo process a story, place the cursor in the text. To process part of a story, select that text.\n\nBevor das Programm startet, soll der Kursor im Text stehen, um den ganzen Artikel zu bearbeiten.\nUm nur einen Textteil zu bearbeiten, soll er markiert werden.\n\nPlacez le point d'insertion dans le texte pour rechercher dans un article ou sélectionnez la portion de texte voulue."

myMes03 = "Нет открытых документов\n\nNo open documents\n\nKeine Dokumente offen\n\nAucun document ouvert"

myMes04R = "Операции поиска-замены текста"
myMes04E = "Find-Change Text Actions"
myMes04D = "Text suchen-verändern"
myMes04F = "Requêtes Rechercher/Remplacer au format Texte "

myMes05R = "Обработка текста grep-запросами"
myMes05E = "Find-Change GREP Actions"
myMes05D = "GREP Abfrage-Textbearbeitung"
myMes05F = "Requêtes Rechercher/Remplacer au format GREP"

myMes06R = "Обработать текст"
myMes06E = "Process text"
myMes06D = "Text bearbeiten"
myMes06F = "Exécutez la requête"

myMes07R = "Выполняются запросы, выбранные в правом окне. Очерёдность обработки списка — сверху вниз.\nЕсли запрос выполнен, слева него появится плюс.\nПовторный запуск или любые действия с запросами удалят символы '+', добавленные в строки при предыдущем успешном исполнении запросов."
myMes07E = "Execute selected queries.\nQueries that ran successfully are marked by a plus sign."
myMes07D = "Markierte Abfragen im rechten Fenster in der Reihenfolge von oben nach unten bearbeiten.\nWenn Operation erfolgreich ist, erscheint links +. ";
myMes07F = "Requêtes exécutées.\nLes requêtes excécutées avec succès sont précédées du signe +.";

myMes08R = "Поместить запрос в список.\nЗапросы добавляются только по одному.\nДругой вариант переноса строки запроса из левого окна в правое — двойной щелчок на ней."
myMes08E = "Add a query to the list.\nQueries can be added by double-clicking as well."
myMes08D = "Abfrage in die Liste aufnehmen.\nAbfragen werden nur einzeln hinzugefügt.\nMan kann die Abfrage aus dem linken ins rechte Fenster dadurch bewegen, dass man ein Doppelklick macht.";
myMes08F = "Ajouter une requête à la liste.\nLes requêtes peuvent également être ajoutées par double-clic.";

myMes09R = "Переместить в правом окне выделенную строку вверх";
myMes09E = "Move selected line up";
myMes09D = "Die markierte Zeile im rechten Fenster soll nach oben versetzt werden";
myMes09F = "Déplacer vers le haut la ligne sélectionnée";

myMes10R = "Переместить в правом окне выделенную строку вниз"
myMes10E = "Move selected line down"
myMes10D = "Die markierte Zeile im rechten Fenster soll nach unten versetzt werden";
myMes10F = "Déplacer vers le bas la ligne sélectionnée"

myMes11R = "Удалить выделенные строки.\nДвойной щелчок мышкой удаляет только одну выделенную строку, на которой сейчас курсор.\nЭта кнопка также удаляет символы '+' перед названиями выполненных запросов."
myMes11E = "Remove selected lines.\nDouble-click to remove single lines."
myMes11D = "Markierte Zeilen sollen entfernt werden.\nDoppelklick mit der Maus entfernt nur die Zeile, auf der sich der Kursor gerade befindet.\nDieser Knopf entfernt auch Symbole '+' vor den Namen der erfolgreichen Abfragen."
myMes11F = "Supprimer les lignes sélectionnées.\nDouble-clic pour supprimer une seule ligne."

myMes12R = "Сохранить этот список, присвоив ему имя.\nЕсли в этом имени первый символ '+' — будет создан каталог с таким же названием,\nи в нём сохранятся этот список и xml-файлы запросов."
myMes12E = "Save the list of queries.\nIf the name of the saved list is marked by +, the script creates a directory with this name and stores the list and the text and grep queries in it."
myMes12D = "Diese Liste unter einem Namen speichern.\nWenn das 1. Symbol in diesem Namen '+'  ist, wird ein Ordner mit demselben Namen erschaffen, darin werden diese Liste und xml-Abfragen-Dateien gespeichert."
myMes12F = "Enregistrer la liste des requêtes.\nSi le nom de la liste enregistrée est marquée du signe +, le script enregistre la liste et crée un répertoire portant ce nom et contenant la liste ainsi que les requêtes Texte et Grep."

myMes13R = "Загрузить подготовленный ранее список"
myMes13E = "Load queries"
myMes13D = "Vorbereitete Liste soll geladen werden"
myMes13F = "Charger les requêtes"

myMes14R = "Закончить"
myMes14E = "Close"
myMes14D = " Beenden"
myMes14F = "Fermer "

myMes15R = "Содержимое правого окна будет сохранено в файле #DoQueryList.startque, и загрузится при следующем запуске программы."
myMes15E = "The list of queries is saved in #DoQueryList.startque and will be loaded in next session."
myMes15D = "Inhalt im rechten Fenster wird in der Datei unter #DoQueryList.startque gespeichert und wird beim nächsten Start des Programms geladen."
myMes15F = "La liste des requête est enregistrée dans #DoQueryList.startque et peut être chargée au prochain lancement du script."

myMes16R = "Михаил Иванюшин"
myMes16E = "Mikhail Ivanyushin"
myMes16D = "Mikhail Ivanyuschin"
myMes16F = "Mikhail Ivaniuchin"

myMes17R = "Дайте списку запросов поиска/замены осмысленное имя.\nПредлагаемое имя содержит дату и время создания файла.\nДля отказа от сохранения списка нажмите кнопку 'Cancel'."
myMes17E = "Use a correct name.\nThe default name contains the file's creation date and time."
myMes17D = "Geben Sie dieser Suche-Ersetze-Abfragenliste einen vernünftigen Namen.\nDer vorgeschlagene Name enthält das Datum und die Uhrzeit ihrer Erschaffung. Wenn Sie die Liste nicht speichern möchten, drücken Sie auf 'Cancel'."
myMes17F = "Utilisez un nom correct.\nLe nom par défaut contient la date et l'heure de création du fichier."

myMes18R = "Список запросов поиска/замены сохранён в файле\n"
myMes18E = "List of queries is saved in file\n"
myMes18D = " Suche-Ersetze-Abfragenliste wurde in der Datei gespeichert\n"
myMes18F = "La liste des requêtes est sauvegardée dans le dossier\n"

myMes19R = "Ошибка в структуре данных списка запросов.\nПервая буква может быть только T или G."
myMes19E = "There is an error in the query line.\nFirst letter must be T or G."
myMes19D = "Fehler in der Struktur der Abfragenliste. Der erste Buchstabe kann nur T oder G sein."
myMes19F = "Erreur dans la ligne de la requête.\nLa première lettre doit être T ou G."

myMes20R = "Нет файлов с запросами поиска/замены"
myMes20E = "File with list of queries not found"
myMes20D = "Es gibt keine Dateien mit Suche-Ersetze-Abfragen"
myMes20F = "Le dossier contenant la liste des requêtes n'a pas été trouvé"

myMes21R = "Файлы запросов поиска/замены"
myMes21E = "Lists with queries"
myMes21D = "Dateien der Suche-Ersetze-Abfragen "
myMes21F = "Listes des requêtes"

myMes22R = "Не удалось прочитать выбранный файл с запросами поиска/замены"
myMes22E = "Can't read selected file"
myMes22D = "Markierte Datei mit Suche-Ersetze-Abfragen konnte nicht gelesen werden"
myMes22F = "Le fichier sélectionné ne peut pas être lu"

myMes23R = "В правом окне не выбрано ни одного запроса"
myMes23E = "Please select some lines"
myMes23D = "Keine Abfrage wurde im rechten Fenster ausgewählt"
myMes23F = "Veuillez sélectionner une ligne"

myMes24R = "Перед запуском программы поставьте курсор в текст для подготовки всей статьи к верстке.\nВыделите часть текста для обработки только её."
myMes24E = "Before running the script, place the cursor in the text to process the whole story.\nTo process a part of text, select some text."
myMes24D = "Bevor das Programm startet, soll der Cursor im Text stehen, um den ganzen Artikel zu bearbeiten. Um nur einen Textteil zu bearbeiten, soll er markiert werden." 
myMes24F = "Avant de lancer le script, placez le point d'inserion dans le texte pour rechercher dans un article.\nOu sélectionnez la portion de texte voulue."

myMes25R = "Встречен неучтённый в программе вариант выделения текста.\n"
myMes25E = "Selection not recognised.\n"
myMes25D = "Unzulässige Textmarkierung"
myMes25F = "Sélection non reconnue.\n"

myMes26R ="Не найден запрос: "
myMes26E ="Query not found: "
myMes26D ="Abfrage nicht gefunden"
myMes26F ="Requête introuvable: "

myMes27R = "У вас нет полномочий помещать файлы и создавать каталоги в папке, где размещён этот скрипт.\nПопросите администратора дать полный доступ."
myMes27E = "You have no rights to write in directory where placed this script.\nAsk admin to give you full access to this directory."
myMes27D = "Sie haben keine Berechtigung stellen Dateien, und erstellen Sie die Verzeichnisse, in dem Ordner, wo Sie platziert werden das Skript. Bitten Sie Ihren Administrator, geben vollen Zugriff."
myMes27F = "Vous n'êtes pas autorisé à écrire dans le répertoire contenant le script.\nVeuillez en demander l'autorisation à l'administrateur."

myMes28R = "В правом окне ничего нет."
myMes28E = "Right window is empty"
myMes28D = "Im rechten Fenster gibt es nichts"
myMes28F = "La fenêtre droite est vide"

myMes29R = "Перечень операций, включающий пользовательские запросы, должeн быть сохранён в отдельном каталоге.\nДля этого имя файла списка запросов должно начинаться со знака '+'."
myMes29E = "List with users queries must be saved in separate folder.\nFor do this, the name of list must be started by '+'."
myMes29D = "Benutzer-Abfragenliste soll in einem separaten Ordner gespeichert werden.\nDie Ordnerbezeichnung soll mit einem  '+' anfangen."
myMes29F = "La liste des requêtes personnalisées doit être sauvegardée dans un dossier séparé. Pour ce faire, le nom de la liste doit commencer par le signe +."

myMes30R = "Не найден указанный в списке запросов файл\n"
myMes30E = "File specified in query list not found\n"
myMes30D = "Datei der Abfragen List ist nicht gefunden "
myMes30F = "Le fichier indiqué dans la requête n'a pas été trouvé\n"

myMes31aR = "Не удалось перенести пользовательский файл запроса\n"
myMes31aE = "Attempt to move query file\n"
myMes31aD = "Der Versuch, die Datei\n"
myMes31aF = "Le fichier des requêtes personnalisées\n"

myMes31bR = "\nв каталог\n"
myMes31bE = "\nin folder\n"
myMes31bD = "\nzum Katalog\n"
myMes31bF = "\nn'a pas pu être déplacé dans le dossier\n"

myMes31cR = "\nВозможно, пользователю не предоставлено право полного доступа ка этому каталогу."
myMes31cE = "\nwas unsuccessful.\nDo you have administrative right to write in this folder?"
myMes31cD = "\nzu verlegen ist nicht gelungen.\nHaben Sie Verwaltungsrechte der Aufzeichnung in diesen Katalog?"
myMes31cF = "\nAvez-vous les droits d'administrateur pour écrire dans ce dossier?"

myMes32R = "Число невыполненных запросов: "
myMes32E = "Number of unprocessed queries: "
myMes32D = "Die Zahl der unerfüllten Anfragen: "
myMes32F = "Nombre des requêtes ayant échoué:"

var myMes01 = new Array ( myMes01R,myMes01E,myMes01D,myMes01F);
var myMes04 = new Array ( myMes04R,myMes04E,myMes04D,myMes04F);
var myMes05 = new Array ( myMes05R,myMes05E,myMes05D,myMes05F);
var myMes06 = new Array ( myMes06R,myMes06E,myMes06D,myMes06F);
var myMes07 = new Array ( myMes07R,myMes07E,myMes07D,myMes07F);
var myMes08 = new Array ( myMes08R,myMes08E,myMes08D,myMes08F);
var myMes09 = new Array ( myMes09R,myMes09E,myMes09D,myMes09F);
var myMes10 = new Array ( myMes10R,myMes10E,myMes10D,myMes10F);
var myMes11 = new Array ( myMes11R,myMes11E,myMes11D,myMes11F);
var myMes12 = new Array ( myMes12R,myMes12E,myMes12D,myMes12F);
var myMes13 = new Array ( myMes13R,myMes13E,myMes13D,myMes13F);
var myMes14 = new Array ( myMes14R,myMes14E,myMes14D,myMes14F);
var myMes15 = new Array ( myMes15R,myMes15E,myMes15D,myMes15F);
var myMes16 = new Array ( myMes16R,myMes16E,myMes16D,myMes16F);
var myMes17 = new Array ( myMes17R,myMes17E,myMes17D,myMes17F);
var myMes18 = new Array ( myMes18R,myMes18E,myMes18D,myMes18F);
var myMes19 = new Array ( myMes19R,myMes19E,myMes19D,myMes19F);
var myMes20 = new Array ( myMes20R,myMes20E,myMes20D,myMes20F);
var myMes21 = new Array ( myMes21R,myMes21E,myMes21D,myMes21F);
var myMes22 = new Array ( myMes22R,myMes22E,myMes22D,myMes22F);
var myMes23 = new Array ( myMes23R,myMes23E,myMes23D,myMes23F);
var myMes24 = new Array ( myMes24R,myMes24E,myMes24D,myMes24F);
var myMes25 = new Array ( myMes25R,myMes25E,myMes25D,myMes25F);
var myMes26 = new Array ( myMes26R,myMes26E,myMes26D,myMes26F);
var myMes27 = new Array ( myMes27R,myMes27E,myMes27D,myMes27F);
var myMes28 = new Array ( myMes28R,myMes28E,myMes28D,myMes28F);
var myMes29 = new Array ( myMes29R,myMes29E,myMes29D,myMes29F);
var myMes30 = new Array ( myMes30R,myMes30E,myMes30D,myMes30F);
var myMes31a = new Array ( myMes31aR,myMes31aE,myMes31aD,myMes31aF);
var myMes31b = new Array ( myMes31bR,myMes31bE,myMes31bD,myMes31bF);
var myMes31c = new Array ( myMes31cR,myMes31cE,myMes31cD,myMes31cF);
var myMes32 = new Array ( myMes32R,myMes32E,myMes32D,myMes32F);
  

function main() { // main
var myProgramTitul = myMes01[myLngInd]; // " Подготовка списка запросов и обработка им текста " +"(версия " +myCurrentVersionData_xx_xx_xx +" )";
var myDefSetName = "#DoQueryList.startque" // это стандартный файл с установками предыдущего запуска скрипта
var mySpecialName;
var myStartOfFragment;
var myEndOfFragment;
var myText;
var mySearchMask;
var myQueIsProcessed = false;
///
var mySavedQueryList = new Array;
var myQueCntr;
/// шрифт диалогов
var dialogFont = File.fs == "Macintosh" ? "Lucida Grande" : "Verdana";
///
if(app.documents.length == 0) {
    alert(myMes03, myProgramTitul); // "Нет открытых документов."
    exit();    
    }
var mySelection = app.selection[0];
var myDocument = app.documents.item(0);

if (mySelection == undefined ) {
    alert(myMes02, myProgramTitul); // "Перед запуском программы поставьте курсор в текст для подготовки всей статьи к верстке.\nВыделите часть текста для обработки только её."	
    exit();
    }
var myScriptFile = myGetScriptPath();
var myScriptFolder = decodeURI(myScriptFile.path);
var myFilePath = decodeURI(myScriptFolder + "/" + myDefSetName);
var mySetFile = File (myFilePath);
if (mySetFile.exists) { //File.exists
mySetFile.open("r");
myLastFileName = mySetFile.readln(); // полный маршрут к myFilePathQSave
var myLngIndTry = mySetFile.readln(); //  язык диалога
myLockX = mySetFile.readln(); // координата Х
myLockY = mySetFile.readln(); //  // координата Y
mySetFile.close();
var mySetQFile = File (myLastFileName);
if (mySetQFile.exists) { // mySetQFile.exists
myGetQueryListFromFile(mySetQFile);    
} // mySetQFile.exists
if (myLngIndTry >= 0 && myLngIndTry < myNamberOfLanguages) myLngInd = myLngIndTry;
} // File exists
if (mySavePosition == true) {
    if (myLockX > 32767)  myLockX = -(65535 - myLockX); 
    else if (myLockX == 0)  myLockX = myFirstLockX;
    if (myLockY > 32767)  myLockY =  -(65535 - myLockY); 
    else if (myLockY == 0)  myLockY =  myFirstLockY;
}
///
var myWin = myScriptWindow();
//=================
function myScriptWindow() { // myScriptWindow
//var w = new Window ("palette", myProgramTitul, undefined, {closeButton: true}); // myMes01
var w = new Window ("palette", myMes01[myLngInd], undefined, {closeButton: true}); // 
w.helpTip = decodeURI(myLastFileName); 
w.alignChildren = "right";
var myBtnAdd = File (decodeURI(myScriptFolder + "/" + "AddBtn.png"));
var myBtnUp = File (decodeURI(myScriptFolder + "/" + "ArrowUp.png"));
var myBtnDn = File (decodeURI(myScriptFolder + "/" + "ArrowDwn.png"));
var myBtnDel = File (decodeURI(myScriptFolder + "/" + "DelBtn.png"));
var mySaveBtn =  File (decodeURI(myScriptFolder + "/" + "DataOut.png"));
var myLoadBtn =  File (decodeURI(myScriptFolder + "/" + "DataIn.png"));
var myInfo16 = File (decodeURI(myScriptFolder + "/" + "InfoPict.png"));
var myRussiaFlag =  File (decodeURI(myScriptFolder + "/" + "Russian Federation.png"));
var myGreatBritainFlag =  File (decodeURI(myScriptFolder + "/" + "Great Britain.png"));
var myUSAFlag =  File (decodeURI(myScriptFolder + "/" + "USA.png"));
var myGermanyFlag =  File (decodeURI(myScriptFolder + "/" + "Germany.png"));
var myFranceFlag =  File (decodeURI(myScriptFolder + "/" + "France.png"));

myEngFlag = myGreatBritainFlag; // To show USA flag in script window this line must be active: myEngFlag = myUSAFlag;

myFlagArray = new Array (myRussiaFlag, myEngFlag, myGermanyFlag, myFranceFlag);
myFlagInfo = new Array ("Русский язык", "English", "Deutsch", "Français");
myWelcomeInfo = new Array ("adobeindesign.ru\nЗаходите! Тут море информации по работе в InDesign", "Welcome to adobeindesign.ru!", "Willkommen in adobeindesign.ru!", "Bienvenue à adobeindesign.ru !");

w.alignChildren = "left";
mySizeOfThreeButtons = [0,0,67,25];
var myTreeAndList =  w.add ("group");
myTreeAndList.orientation = "row";
var q_options = myTreeAndList.add ("group", undefined, "");
q_options.alignChildren = ["fill", "fill"];
var myTree = q_options.add ( "treeview", [0,0,390,350]);
var myUserTextFolder = Folder(app.scriptPreferences.scriptsFolder.parent.parent + "/Find-Change Queries/Text/");
var myUserGrepFolder = Folder(app.scriptPreferences.scriptsFolder.parent.parent + "/Find-Change Queries/Grep/");
if (parseInt (app.version) == 5) {
    var myAppTextFolder = Folder (app.filePath + "/Presets/Find-Change Queries/Text/");
    var myAppGrepFolder = Folder (app.filePath + "/Presets/Find-Change Queries/Grep/");
}
else {
    var myAppTextFolder = Folder (app.filePath + "/Presets/Find-Change Queries/Text/" + $.locale);
    var myAppGrepFolder = Folder (app.filePath + "/Presets/Find-Change Queries/Grep/" + $.locale);
}
var myTQ = myTree.add("node", myMes04[myLngInd]); // "Операции поиска-замены текста"
myTextQueSources = [decodeURI(myAppTextFolder) + "/", decodeURI(myUserTextFolder) + "/"];
myGrepQueSources = [decodeURI(myAppGrepFolder) + "/", decodeURI(myUserGrepFolder) + "/"];
if (myTextQueSources.length > 0) { // myTextQueSources.length > 0
for (i = 0;  i < myTextQueSources.length;  i++) { // i < myTextQueSources.length
var myNodeT = myTQ.add("node", myTextQueSources[i]);
var myTxtDir = new Folder(myTextQueSources[i]);
var myListQ1 = myTxtDir.getFiles("*.xml");
var myArrT = [];
for (t = 0; t < myListQ1.length; t++) { // t < myListQ1.length
     myArrT = decodeURI(myListQ1[t]).split("/");
     myNodeT.add("item",myArrT[myArrT.length-1]);    
    } // t < myListQ1.length
} // i < myTextQueSources.length
} // myTextQueSources.length > 0
myQueryList = myTreeAndList.add ("listbox", [0,0,255,350],undefined,{multiselect: true});
for (i = 0; i < myQueCntr; i++)  {
    myQueryList.add("item",mySavedQueryList[i]);
    }
if (myGrepQueSources.length > 0) { // myGrepQueSources.length
var myGQ = myTree.add("node", myMes05[myLngInd]); // "Обработка текста grep-запросами"
for (i = 0;  i < myGrepQueSources.length;  i++) { // i < myGrepQueSources.length
var myNodeG = myGQ.add("node", myGrepQueSources[i]);
var myGrpDir = new Folder(myGrepQueSources[i]);
var myListQ2 = myGrpDir.getFiles("*.xml");
var myArrG = [];
for (t = 0; t < myListQ2.length; t++) { // t < myListQ2.length
     myArrG = decodeURI(myListQ2[t]).split("/");
     myNodeG.add("item",myArrG[myArrG.length-1]);    
    } // t < myListQ2.length
} //  i < myGrepQueSources.length
} // myGrepQueSources.length
///
myTree.onDoubleClick = function() { // myTree.onDoubleClick
myQueryList.selection = null;
try { if (myTree.selection.type == "node") return; } catch (e) {return;}
myRemovePlusMarkersInRightList(myQueryList);
var mySelectedLine = String(myTree.selection.parent);
if (mySelectedLine.indexOf("/Find-Change Queries/GREP/") != -1 || mySelectedLine.indexOf("/Find-Change Queries/Grep/") != -1) { 
    myQueryList.add("item","G: " + String(myTree.selection));
    return; 
    }
if (mySelectedLine.indexOf("/Find-Change Queries/Text/") != -1) {
    myQueryList.add("item", "T: " + String(myTree.selection)); 
    return; 
    }
return;
} // myTree.onDoubleClick
///
//===========================
var myAllButtonsAndCopyrightInfo = w.add ("panel");
var myOkAndCancelButtons = myAllButtonsAndCopyrightInfo.add ("group");
myOkAndCancelButtons.orientation = "row";
myOkAndCancelButtons.alignChildren = ["fill", "fill"];
myEmptySpace = [0,0,0,25];
myButtonOKSize = [0,0,145,25];
myButtonCancelSize = [0,0,126,25];
var myFlag = myOkAndCancelButtons.add ("iconbutton", [0,0,36,24], myFlagArray[myLngInd]);
myFlag.helpTip = myFlagInfo[myLngInd];
var myWelcomeToSiteInfo = myOkAndCancelButtons.add ("iconbutton", [0,0,32,24], myInfo16);
myOkAndCancelButtons.add ("statictext",undefined,"\u00A0\u00A0\u00A0");
myWelcomeToSiteInfo.helpTip = myWelcomeInfo[myLngInd];
myOKButton = myOkAndCancelButtons.add ("button",myButtonOKSize , myMes06[myLngInd], {name: "ok"}); // "Обработать текст"
myOKButton.helpTip = (myFastHelp == true) ? myMes07[myLngInd] : ""; // "Выполняются запросы, выбранные в правом окне. Очерёдность обработки списка — сверху вниз.\nЕсли запрос выполнен, слева него появится плюс.\nПовторный запуск или любые действия с запросами удалят символы '+', добавленные в строки при предыдущем успешном исполнении запросов."
myOkAndCancelButtons.add ("statictext",myEmptySpace,"");
try { var myGetQueriesButton = myOkAndCancelButtons.add ("iconbutton", [0,0,25,25], myBtnAdd);  } catch (e) { var myGetQueriesButton = myOkAndCancelButtons.add ("button", [0,0,25,25], "+"); } 
myGetQueriesButton.helpTip = (myFastHelp == true) ? myMes08[myLngInd] : ""; // "Поместить запрос в список.\nЗапросы добавляются только по одному.\nДругой вариант переноса строки запроса из левого окна в правое — двойной щелчок на ней."
try { var myUpButton = myOkAndCancelButtons.add("iconbutton", [0,0,25,25], myBtnUp); } catch (e) { var myUpButton = myOkAndCancelButtons.add ("button", [0,0,25,25], "U"); } 
myUpButton.helpTip = (myFastHelp == true) ? myMes09[myLngInd] : ""; //"Переместить в правом окне выделенную строку вверх."
try { var myDnButton = myOkAndCancelButtons.add("iconbutton", [0,0,25,25], myBtnDn); } catch (e) { var myDnButton = myOkAndCancelButtons.add ("button", [0,0,25,25], "D"); }
myDnButton.helpTip = (myFastHelp == true) ? myMes10[myLngInd] : ""; //"Переместить в правом окне выделенную строку вниз."
try { var myDelButton = myOkAndCancelButtons.add("iconbutton", [0,0,25,25], myBtnDel); } catch (e) { var myDelButton = myOkAndCancelButtons.add ("button", [0,0,25,25], "X"); }
myDelButton.helpTip = (myFastHelp == true) ? myMes11[myLngInd] : ""; // "Удалить выделенные строки.\nДвойной щелчок мышкой удаляет только одну выделенную строку, на которой сейчас курсор.\nЭта кнопка также удаляет символы '+' перед названиями выполненных запросов."

try { var mySaveSetButton = myOkAndCancelButtons.add("iconbutton", [0,0,25,25], mySaveBtn); } catch (e) { var mySaveSetButton = myOkAndCancelButtons.add ("button", [0,0,25,25], "S"); }
mySaveSetButton.helpTip = (myFastHelp == true) ? myMes12[myLngInd] : ""; // "Сохранить этот список, присвоив ему имя.\nЕсли в этом имени первый символ '+'  — кроме сохранения списка будет создан каталог с таким же названием,\nи в нём сохранятся этот список и xml-файлы запросов."

try { var myLoadSetButton = myOkAndCancelButtons.add("iconbutton", [0,0,25,25], myLoadBtn); } catch (e) { var myLoadSetButton = myOkAndCancelButtons.add ("button", [0,0,25,25], "L"); }
myLoadSetButton.helpTip = (myFastHelp == true) ? myMes13[myLngInd] : ""; //"Загрузить подготовленный ранее список."

myOkAndCancelButtons.add ("statictext",myEmptySpace,"");
myCancelButton = myOkAndCancelButtons.add ("button", myButtonCancelSize, myMes14[myLngInd], {name: "cancel"}); // "Закончить работу"
myCancelButton.helpTip = (myFastHelp == true) ? myMes15[myLngInd] : ""; //"Содержимое правого окна будет сохранено в файле #DoQueryList.startque, и загрузится при следующем запуске программы."
var myButtonAndInfo = w.add("group");
myButtonAndInfo.orientation = "row";
var myMessage = myButtonAndInfo.add ("statictext",[0,0,500,15]);
//myMessage.alignChildren = "right";
myMessage.text = "DoQueryList (" + myCurrentEditionData[myLngInd] + ") | © " + myMes16[myLngInd] + " | adobeindesign.ru"; // Михаил Иванюшин
myMessage.graphics.font = dialogFont + ":9";
myMessage.graphics.foregroundColor = myMessage.graphics.newPen (myMessage.graphics.PenType.SOLID_COLOR, [0, 0,1, 1], 1);
////
myWelcomeToSiteInfo.onClick = function () { // mySiteButton.onClick
openInBrowser("adobeindesign.ru")
} // mySiteButton.onClick    
////

myFlag.onClick = function () { // myFlag.onClick
myLngInd++;
myLngInd = myLngInd%myNamberOfLanguages;
myFlag.icon = myFlagArray[myLngInd];
myFlag.helpTip = myFlagInfo[myLngInd];
myWelcomeToSiteInfo.helpTip = myWelcomeInfo[myLngInd]; 
myProgramTitul = myMes01[myLngInd];
w.text = myMes01[myLngInd];
myTQ.text = myMes04[myLngInd];
myGQ.text = myMes05[myLngInd];
myOKButton.text = myMes06[myLngInd];
myOKButton.helpTip = (myFastHelp == true) ? myMes07[myLngInd] : "";
myGetQueriesButton.helpTip = (myFastHelp == true) ? myMes08[myLngInd] : "";
myUpButton.helpTip = (myFastHelp == true) ? myMes09[myLngInd] : "";
myDnButton.helpTip = (myFastHelp == true) ? myMes10[myLngInd] : "";
myDelButton.helpTip = (myFastHelp == true) ? myMes11[myLngInd] : "";
mySaveSetButton.helpTip = (myFastHelp == true) ? myMes12[myLngInd] : "";
myLoadSetButton.helpTip = (myFastHelp == true) ? myMes13[myLngInd] : "";
myCancelButton.text = myMes14[myLngInd];
myCancelButton.helpTip = (myFastHelp == true) ? myMes15[myLngInd] : "";
myMessage.text = "DoQueryList (" + myCurrentEditionData[myLngInd]  + ") | © " + myMes16[myLngInd] + " | adobeindesign.ru";
} // myFlag.onClick
/////
myCancelButton.onClick = function() { // myCancelButton.onClick
myRemovePlusMarkersInRightList(myQueryList);
var myFilePathQuSave= decodeURI(myScriptFolder + "/" + myDefSetName);
var myQueSetSave = new File (myFilePathQuSave);
tt = myQueSetSave.open("w");
if (tt == false) { alert(myMes27[myLngInd] +" [1]", myProgramTitul); exit(); }
myQueSetSave.writeln(myFilePathQSave);
var myCurWinLock = new Array;
myCurWinLock = w.location;
myQueSetSave.writeln(myLngInd);
myQueSetSave.writeln(myCurWinLock[0]);
myQueSetSave.writeln(myCurWinLock[1]);
//myQueSetSave.writeln(mySetQFile);
myQueSetSave.close();
w.close();
exit();
} // myCancelButton.onClick
///
myQueryList.onDoubleClick = function() { // myQueryList.onDoubleClick # Remove
if (myQueryList.selection == null) return; // ничего не выбрано, а кнопка нажата
myRemovePlusMarkersInRightList(myQueryList);
if (myQueryList.selection.length > 1) return; // удаляем только по одной строке
myQueryList.remove (myQueryList.selection[0]);
} // myQueryList.onDoubleClick # Remove
///
myDelButton.onClick =  function() { // myDelButton.onClick
if (myQueIsProcessed == true)  { myRemovePlusMarkersInRightList(myQueryList); return; }
if (myQueryList.selection == null) return; // ничего не выбрано, а кнопка нажата
myRemovePlusMarkersInRightList(myQueryList);
for (k = myQueryList.selection.length-1; k >= 0; k--) { // k = myQueryList.selection.length
    myQueryList.remove (myQueryList.selection[k]);
    } // k = myQueryList.selection.length
}  // myDelButton.onClick
///
myGetQueriesButton.onClick = function() { // myGetQueriesButton.onClick
myRemovePlusMarkersInRightList(myQueryList);
myQueryList.selection = null;
try { if (myTree.selection.type == "node") return; } catch (e) {return;}    
var mySelectedLine = String(myTree.selection.parent);
if (mySelectedLine.indexOf("/Find-Change Queries/GREP/") != -1 || mySelectedLine.indexOf("/Find-Change Queries/Grep/") != -1) { 
    myQueryList.add("item","G: " + String(myTree.selection));
    return; 
    }
if (mySelectedLine.indexOf("/Find-Change Queries/Text/") != -1) {
    myQueryList.add("item", "T: " + String(myTree.selection)); 
    return; 
    }
return;
} // myGetQueriesButton.onClick
////
myUpButton.onClick = function() { // myUpButton.onClick
if (myQueryList.selection == null) return; // ничего не выбрано, а кнопка нажата  
myRemovePlusMarkersInRightList(myQueryList);
if (myQueryList.selection.length > 1) return; // перемещается только одна строка
var mySelIndex = myQueryList.selection[0].index;
if (mySelIndex == 0) return;
var myPrevIndex = mySelIndex;
myPrevIndex--;
myQueryList.selection = null; // снимем выделение, иначе в списке из-за активной опции multiselect: true будут две выделенных строки
var myTmpL = myQueryList.items[myPrevIndex].text;
myQueryList.items[myPrevIndex].text = myQueryList.items[mySelIndex].text;
myQueryList.items[mySelIndex].text = myTmpL;
myQueryList.selection = [myPrevIndex];
} //  myUpButton.onClick
///
myDnButton.onClick = function() { // myDnButton.onClick
if (myQueryList.selection == null) return; // ничего не выбрано, а кнопка нажата    
myRemovePlusMarkersInRightList(myQueryList);
if (myQueryList.selection.length > 1) return; // перемещается только одна строка
var mySelIndex = myQueryList.selection[0].index;
if (mySelIndex == myQueryList.items.length - 1) return;
var myNextIndex = mySelIndex;
myNextIndex++;
myQueryList.selection = null;
var myTmpL = myQueryList.items[myNextIndex].text;
myQueryList.items[myNextIndex].text = myQueryList.items[mySelIndex].text;
myQueryList.items[mySelIndex].text = myTmpL;
myQueryList.selection = [myNextIndex];
} //  myDnButton.onClick
///
mySaveSetButton.onClick = function() { // mySaveSetButton.onClick 
if (myQueryList.items.length == 0) {
    alert (myMes28[myLngInd], myProgramTitul); // "В правом окне ничего нет"
    return;
} //  myQueList.length == 0
myRemovePlusMarkersInRightList(myQueryList);
var myDateF = new Date;
var myDayF = myDateF.getDate();
if (myDayF <10) myDayF = "0" + myDayF;
var myMonthF = myDateF.getMonth();
myMonthF++; // январь имеет индекс 0
if (myMonthF <10) myMonthF = "0" + myMonthF;
var myHourF = myDateF.getHours();
if (myHourF <10) myHourF = "0" + myHourF;
var myMinuteF = myDateF.getMinutes();
if (myMinuteF <10) myMinuteF = "0" + myMinuteF;
var mySecondeF = myDateF.getSeconds();
if (mySecondeF <10) mySecondeF = "0" + mySecondeF;
///	
// indique -- такое расширение будет у файлов со перечнями запросов
mySpecialQName = "QueryList" + "@"+ myDayF + "." + myMonthF + "-" + myHourF + "." + myMinuteF + "." + mySecondeF + ".indique";
var myNameTmpQ = prompt (myMes17[myLngInd], mySpecialQName, myProgramTitul);
if (myNameTmpQ == null || myNameTmpQ.length == 0) return;
myAsteriskInQueryName = false;
for (ii = 0; ii < myQueryList.items.length; ii++) if (myQueryList.items[ii].text[3] == "*")  myAsteriskInQueryName = true;
if (myAsteriskInQueryName == true && myNameTmpQ[0] != "+") {
    alert(myMes29[myLngInd], myProgramTitul); /// alert("Перечень операций, включающий пользовательские запросы, должeн быть сохранён в отдельном каталоге.\nДля этого имя файла списка запросов должно начинаться со знака '+'.", myProgramTitul);
    return; 
   }
if (myNameTmpQ.indexOf('.indique') == -1) myNameTmpQ += '.indique';
mySpecialQName = myNameTmpQ;
// плюс в начале названия означает, что сохраняется не только файл запроса, но и все запросы тоже.
// сохраним список запросов    
myFilePathQSave= decodeURI(myScriptFolder + "/" + mySpecialQName);  // полное имя к созданному indique-файлу
if (myFilePathQSave.length != 0) w.helpTip = decodeURI(myFilePathQSave);
var myQueSetSave = new File (myFilePathQSave);
tt = myQueSetSave.open("w");
if (tt == false) { alert(myMes27[myLngInd] +" [2]", myProgramTitul); return; }
myQueSetSave.writeln(myQueryList.items.length);
for (i = 0; i < myQueryList.items.length; i++)  myQueSetSave.writeln(myQueryList.items[i]);
myQueSetSave.close();
if (myNameTmpQ[0] != "+") { // тут, видимо, будет ещё операция удаления указателей на grep- и текстовые папки пользовательских каталогов
    mySpecFolderName = myScriptFolder; 
    //myAsteriskInQueryName = false;
    return; 
    } 
else { // myNameTmpQ[0] == "+"
// В отдельном каталоге сохраним список запросов и сами запросы
myFilePathQSave= decodeURI(myScriptFolder + "/" + mySpecialQName);
if (myFilePathQSave.length != 0) w.helpTip = decodeURI(myFilePathQSave);
var myStringPrevSpecFolderName = decodeURI(mySetQFile).replace(/\.indique$/,"");
myPrevSpecFolderName = Folder(myStringPrevSpecFolderName).parent;
mySpecFolderName = decodeURI(myFilePathQSave).replace(/\.indique$/,""); // каталог, в котором хранится созданный список запросов и папки с запросами
ff = Folder(mySpecFolderName).create();
myFilePathQSave = mySpecFolderName + "/" + mySpecialQName; // полное имя к созданному indique-файлу
if (myFilePathQSave.length != 0) w.helpTip = decodeURI(myFilePathQSave);
if (ff == false) { alert(myMes27[myLngInd] +" [5]", myProgramTitul); return; }
myQueSetSave.copy(mySpecFolderName + "/" + mySpecialQName);
myQueSetSave.remove();
mySpecTextFolder = mySpecFolderName + "/" + "Text" + "/";
ff = Folder(mySpecTextFolder).create();
if (ff == false) { alert(myMes27[myLngInd] +" [6]", myProgramTitul); return; }
mySpecGrepFolder = mySpecFolderName + "/" + "Grep" + "/";
ff = Folder(mySpecGrepFolder).create();
if (ff == false) { alert(myMes27[myLngInd] +" [7]", myProgramTitul); return; }
// разносим запросы по каталогам /Text и /Grep
// после этого зпросы в правом окне будут со звёздочками, что означает, что это пользовательские наборы
var myCurQueName;
var myCurQueRezName;
for (jj = 0; jj < myQueryList.items.length; jj++) { // jj < myQueryList.items.length
    if (myQueryList.items[jj].text[0] == "T" && myQueryList.items[jj].text[3] != "*") { // myQueryList.items[jj].text[0] == "T" 
        myCurQueName = myQueryList.items[jj].text.replace("T: ","");
        myCurQueRezName = "";
        myCurQueRezName = myTextQueSources[0] + "/" + myCurQueName;
        myTxtFile = File (myCurQueRezName);
        myTxtFile.copy(mySpecTextFolder + myCurQueName);
        myCurQueRezName = "";
        myCurQueRezName = myTextQueSources[1] + "/" + myCurQueName;
        myTxtFile = File (myCurQueRezName);
        myTxtFile.copy(mySpecTextFolder + myCurQueName);
        continue;
       } // myQueryList.items[jj].text[0] == "T"
    if (myQueryList.items[jj].text[0] == "T" && myQueryList.items[jj].text[3] == "*") { //  == "T"  & == "*" 
        myCurQueName = myQueryList.items[jj].text.replace("T: *","");
        myCurQueRezName = "";
        myCurQueRezName = myPrevSpecFolderName + "/Text/" + myCurQueName;
        myTxtFile = File (myCurQueRezName);
        myTxtFile.copy(mySpecTextFolder + myCurQueName);
        continue;
       } //  //  == "T"  & == "*" 
    if (myQueryList.items[jj].text[0] == "G" && myQueryList.items[jj].text[3] != "*") { // myQueryList.items[jj].text[0] == "G"
        myCurQueName = myQueryList.items[jj].text.replace("G: ","");
        myCurQueRezName = "";
        myCurQueRezName = myGrepQueSources[0] + myCurQueName;
        myTxtFile = File (myCurQueRezName);
        myTxtFile.copy(mySpecGrepFolder + myCurQueName);
        myCurQueRezName = "";
        myCurQueRezName = myGrepQueSources[1] + myCurQueName;
        myTxtFile = File (myCurQueRezName);
        myTxtFile.copy(mySpecGrepFolder + myCurQueName);     
        continue;
        } // myQueryList.items[jj].text[0] == "G"
    if (myQueryList.items[jj].text[0] == "G" && myQueryList.items[jj].text[3] == "*") { // == "G" & == "*" 
        myCurQueName = myQueryList.items[jj].text.replace("G: *","");
        myCurQueRezName = "";
        myCurQueRezName = myPrevSpecFolderName + "/Grep/" + myCurQueName;
        myTxtFile = File (myCurQueRezName);
        myTxtFile.copy(mySpecGrepFolder + myCurQueName);
        continue;
        } //  // == "G" & == "*" 
    alert(myMes19[myLngInd], myProgramTitul); // "Ошибка в структуре данных списка запросов.\nПервая буква может быть только T или G."
} // jj < myQueryList.items.length
} // myNameTmpQ[0] == "+"
} // mySaveSetButton.onClick
///
myLoadSetButton.onClick = function() { // myLoadSetButton.onClick 
myScrQFolder = new Folder (myScriptFile.path);
mySearchQMask = "*.indique";
var myQueList = myScrQFolder.getFiles(mySearchQMask);
/*
if (myQueList.length == 0) { // myQueList.length == 0
    alert (myMes20[myLngInd], myProgramTitul); // "Нет файлов с запросами поиска/замены"
    return;
} //  myQueList.length == 0
*/
mySetQFile = File(decodeURI(myScrQFolder + "/")).openDlg(myMes21[myLngInd], 'indique: *.indique'); // "Файлы запросов поиска/замены"
if (mySetQFile == null)  return;
var myArrForQSplit = [];
myArrForQSplit = decodeURI(mySetQFile).split("/");
myCurrentFileQName = myArrForQSplit[myArrForQSplit.length-1];
if (!mySetQFile.exists) { alert (myMes22[myLngInd], myProgramTitul); return; }   // "Не удалось прочитать выбранный файл с запросами поиска/замены"
else { //File.exists
firstCharIsPlus = false;
var myTmpArrPlus = new Array;
myFilePathQSave = String (mySetQFile);
if (myFilePathQSave.length != 0) w.helpTip = decodeURI(myFilePathQSave);
if (myArrForQSplit[myArrForQSplit.length - 1][0] == "+") { // == "+"
    firstCharIsPlus = true; 
  } // == "+"
//else ( myAsteriskInQueryName = false ) // при загрузке списка без плюсика надо забыть о том, что до этого в правом окне были запросы из пользовательских каталогов
myGetQueryListFromFile(mySetQFile);
} //File.exists
// удалим имеющийся сейчас список запросов...
var myQueListCounter = myQueryList.items.length;
for (k = 0; k < myQueListCounter; k++) { myQueryList.remove(myQueryList.items[0]); }
// ... и поместим сюда новый
for (i = 0; i < myQueCntr; i++)  { myQueryList.add("item",mySavedQueryList[i]); }
} // myLoadSetButton.onClick 
////
///-- http://forums.adobe.com/message/3462710#3462710
w.addEventListener('mouseout', leaveTestPalette);
function leaveTestPalette(/*MouseEvent*/mev)
    {
    if( mev.target instanceof Window ) app.activate();
    }
///--
//////
myOKButton.onClick = function() { // myOKButton.onClick 
try { if (myQueryList.selection.length == 0) } catch (e)  {
    alert(myMes23[myLngInd], myProgramTitul);  // "В правом окне не выбрано ни одного запроса."
    return;
    }
mySelection = app.selection[0];
if (mySelection == undefined ) {
    alert(myMes24[myLngInd], myProgramTitul); // "Перед запуском программы поставьте курсор в текст для подготовки всей статьи к верстке.\nВыделите часть текста для обработки только её."	
    return;
    }
myRemovePlusMarkersInRightList(myQueryList);
var mySel = -1;
mySelection.parentStory.recompose();
switch(mySelection.constructor.name) { // switch
    case "Text":
	case "Character":
	case "Word":
	case "Paragraph":
    case "Table":
	case "Cell":
        mySel = 0; break;
	case "TextFrame":
        mySel = 1;  break;
	case "InsertionPoint":
        if (mySelection.parent.constructor.name == "Cell") {mySelection.parent.select(); mySel = 0; } else mySel = 1;
} // switch
if (mySel == -1) { // mySel == -1
    alert(myMes25[myLngInd] + "mySelection.constructor.name = " + mySelection.constructor.name + "\nmySelection.parent.constructor.name = " + mySelection.parent.constructor.name, myProgramTitul);	
    return;
} // mySel == -1
for (j = 0; j < myQueryList.selection.length; j++) { // < myQueryList.selection.length
var myDate = new Date;
// имя исполняемаого запроса состоит из текущего времени в секундах и текущего значения индекса
var mySpecialNameForUserQuery = String(myDate.getTime()); // это время...
mySelection = app.selection[0];
mySelection.parentStory.recompose(); // после выполнения каждого запроса обновляем статью    
var myArrayXML = new Array;
myArrayXML = myQueryList.selection[j].text.split(".xml");
mySelection = app.selection[0];
var myQ =myArrayXML[0];
myArrayXML = myQ.split(": ");
myQ =myArrayXML[1];
if  (myQueryList.selection[j].text[0] == "T") { //  == "T"
        myQueIsProcessed = true;
        if (myQ[0] == "*") { //  == "*"
            myQueArrPlus = myQ.split("");
            myQueArrPlus.shift();
            myQ = myQueArrPlus.join("");
            myOwnTextQueryFolder = mySetQFile.path  + "/Text/";
            myFileObj = File (myOwnTextQueryFolder + myQ + ".xml");
            if (!myFileObj.exists) { alert(myMes30 + decodeURI(myFileObj), myProgramTitul); continue;} // "Не найден указанный в списке запросов файл\n" 
            myFolderForExecuteThisQuery = myOwnQueriesInAppFolder== true ? myAppTextFolder : myUserTextFolder;
            mySpecialNameForUserQuery = mySpecialNameForUserQuery + String(j); // ... добпавляем индекс
            myTarget = File (myFolderForExecuteThisQuery + "/" + mySpecialNameForUserQuery + ".xml");
             if (myFileObj.copy(myTarget) == false) { // (myTarget) == false
                alert (myMes31a[myLngInd] + decodeURI(myFileObj) + myMes31b[myLngInd] + decodeURI(myFolderForExecuteThisQuery) + myMes31c[myLngInd],myProgramTitul); //"Не удалось перенести пользовательский файл запроса\n" + decodeURI(myFileObj) + "\nв каталог\n" + decodeURI(myFolderForExecuteThisQuery) + "\nВозможно, пользователю не предоставлено право полного доступа ка этому каталогу."                
                continue; 
              } // (myTarget) == false
            myQ = String(mySpecialNameForUserQuery);
        } //  == "*"
       try { app.loadFindChangeQuery(myQ,SearchModes.textSearch); } catch (e) { myQueIsProcessed = false; alert(myMes26[myLngInd] + myQueryList.selection[j].text , myProgramTitul); continue;} // "Не найден запрос: "
       try { mySel == 0 ? mySelection.changeText() : mySelection.parentStory.changeText(); } catch (e) { myQueIsProcessed = false; myNumberOfPendingQueries++; }
       if (myArrayXML[1][0] == "*") myTarget.remove();
       if (myQueIsProcessed == true) myQueryList.selection[j].text = "+" + myQueryList.selection[j].text;
       continue;
      } //  == "T"
if  (myQueryList.selection[j].text[0] == "G") { //  == "G"
        myQueIsProcessed = true;
        if (myQ[0] == "*") { //  == "*"
            myQueArrPlus = myQ.split("");
            myQueArrPlus.shift();
            myQ = myQueArrPlus.join("");
            myOwnGrepQueryFolder = mySetQFile.path + "/GREP/";
            myFileObj = File (myOwnGrepQueryFolder + myQ + ".xml");
            if (!myFileObj.exists) { alert(myMes30  + decodeURI(myFileObj), myProgramTitul); continue;} // "Не найден указанный в списке запросов файл\n"
            myFolderForExecuteThisQuery = myOwnQueriesInAppFolder== true ? myAppGrepFolder : myUserGrepFolder;
            mySpecialNameForUserQuery = mySpecialNameForUserQuery + String(j); // ... добпавляем индекс
            myTarget = File (myFolderForExecuteThisQuery + "/" + mySpecialNameForUserQuery + ".xml");
             if (myFileObj.copy(myTarget) == false) { // (myTarget) == false
                alert (myMes31a[myLngInd] + decodeURI(myFileObj) + myMes31b[myLngInd] + decodeURI(myFolderForExecuteThisQuery) + myMes31c[myLngInd],myProgramTitul); //"Не удалось перенести пользовательский файл запроса\n" + decodeURI(myFileObj) + "\nв каталог\n" + decodeURI(myFolderForExecuteThisQuery) + "\nВозможно, пользователю не предоставлено право полного доступа ка этому каталогу."                                
                continue; 
              } // (myTarget) == false
            myQ = String(mySpecialNameForUserQuery);
        } //  == "*"
        try { app.loadFindChangeQuery(myQ,SearchModes.grepSearch); } catch (e) { myQueIsProcessed = false; alert(myMes26[myLngInd] + myQueryList.selection[j].text , myProgramTitul); continue;} // "Не найден запрос: "
        try { mySel == 0 ? mySelection.changeGrep() : mySelection.parentStory.changeGrep(); } catch (e) {  myQueIsProcessed = false;  myNumberOfPendingQueries++; }
        if (myQueIsProcessed == true) myQueryList.selection[j].text = "+" + myQueryList.selection[j].text;
        if (myArrayXML[1][0] == "*") myTarget.remove();
        continue;
      }  //  == "G"
  alert(myMes19[myLngInd], myProgramTitul); // "Ошибка формата: встречена строка, не начинающаяся с буквы T или G."
} // < myQueryList.selection.length
myQueIsProcessed = true;
if (myNumberOfPendingQueries != 0) alert(myMes32 + myNumberOfPendingQueries , myProgramTitul); // "Число невыполненных запросов: "
myNumberOfPendingQueries = 0;
} // myOKButton.onClick
if (mySavePosition == true) w.location = [myLockX, myLockY];
w.show();
} // myScriptWindow
//////
function myFile(myFileName) {
var myScriptFile = myGetScriptPath();
var myScriptFolder = decodeURI(myScriptFile.path);
var myFilePath = decodeURI(myScriptFolder + "/" +myFileName);
return myFilePath;
} //myFile
//
function myGetScriptPath() { // myGetScriptPath
	try{
		return app.activeScript;
	}
	catch(myError){
		return File(myError.fileName);
	}
} //myGetScriptPath()
////////
function myRemovePlusMarkersInRightList(myQueryList) { // myRemovePlusMarkersInRightList
if (myQueIsProcessed == false) return;
var myArrPlus = [];
for (i = 0; i < myQueryList.items.length; i++) { //  i < myQueryList.selection.length
    if (myQueryList.items[i].text[0] != "+") continue;
    myQ = myQueryList.items[i].text;
    myArrPlus = myQ.split("");
    myArrPlus.shift();
    myQueryList.items[i].text = myArrPlus.join("");
    } //  i < myQueryList.selection.length
myQueIsProcessed = false;
} // myRemovePlusMarkersInRightList
////
function openInBrowser(/*str*/url)
//--  http://forums.adobe.com/message/3181041#3181041
{
var isMac = (File.fs == "Macintosh"), fName = 'tmp' + (+new Date()) + (isMac ? '.webloc' : '.url'), fCode = isMac ?
        ('<?xml version="1.0" encoding="UTF-8"?>\r'+
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '+
        '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\r'+'<plist version="1.0">\r'+'<dict>\r'+
        '\t<key>URL</key>\r'+
        '\t<string>%url%</string>\r'+
        '</dict>\r'+
        '</plist>') :
        '[InternetShortcut]\rURL=%url%\r';
    var f = new File(Folder.temp.absoluteURI + '/' + fName);
    if(! f.open('w') ) return false;
    f.write(fCode.replace('%url%',url));
    f.close();
    f.execute();
    $.sleep(500);   // 500 ms timer
    f.remove();
    return true;
}
////
function myGetQueryListFromFile(mySetQFile) { // myGetQueryListFromFile
mySetQFile.open("r");
myQueCntr = mySetQFile.readln();
mySavedQueryList = new Array;
var myTempQueString;
for (i = 0; i < myQueCntr; i++)  { //  i < myQueCntr
    myTempQueString = mySetQFile.readln();
    if (firstCharIsPlus == true) { // firstCharIsPlus == true
    myTmpArrPlus = myTempQueString.split("");
    myTmpArrPlusLength = myTmpArrPlus.length;
    // Формат записи предполагает, что после буквы T/G и двоеточия стоит пробел. 
    // Если запрос берется из созданного, а не стандартного каталога, для сохранения пробела после двоеточия сдвигаем строку  на один знак, чтобы добавить '*" -- указатель, что это запрос из пользовательского каталога.
    // Но возможна ситуация, когда в сохраненном перечне запросов уже стоит звёздочка перед названием файла, например, сохраняется последовательность запросов, в которой ипользуются запросы из пользовательского каталога
    // Поэтому перед выполнением сдвига на один знак проверим, нет ли уже звёздочки перед названием запроса.
    if (myTmpArrPlus[3] != "*") { //  != "*"
        for (f = myTmpArrPlusLength; f > 2; f--) { //  f > 2
            myTmpArrPlus[f] = myTmpArrPlus[f-1];
            } //  f > 2
            myTmpArrPlus[3] = "*";
            //myAsteriskInQueryName = true;
        } //  != "*"
        myTempQueString = myTmpArrPlus.join("");    
    } // firstCharIsPlus == true
    mySavedQueryList[i] = myTempQueString;
} //  i < myQueCntr
mySetQFile.close();  
} // myGetQueryListFromFile
///////
} // main

main();
