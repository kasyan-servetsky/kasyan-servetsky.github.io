/* Script for InDesign CS2, CS3 and CS4
Version 14.1
This script relinks old links with new ones in a folder you choose, including subfolders.
At first, it looks for the new link that has the same name as the old one, in the selected folder, and if it's found, relinks it.
If the link with the exact name is not found and the link is not a text file (e.g. InCopy, Word, RTF, Exel file), the sript tries to find a file with the same base name but a different extension (".psd", ".tif", ".jpg", ".ai", ".eps", ".pdf", ".indd"). 
If the script doesn't find the new link in the chosen folder, it repeats the above-mentioned process for every subfolder.
Written by Kasyan Servetsky in June 2008.
askoldich@yahoo.com */

#target indesign

if (app.documents.length == 0) {
	alert("Please open a document and try again.", "Script will be terminated", true);
	exit();
}
var myDoc = app.activeDocument;
var myLinks = myDoc.links;
if (myLinks.length == 0) {
	alert("This document doesn't contain any links.", "Script will be terminated");
	exit();	
}
var myFolder = Folder.selectDialog ("Choose a folder with new links");
if (myFolder == null) {
	exit();
}
var myCounter = 0;
var myInDesignVersion = Number(String(app.version).split(".")[0]);
var mySubFolders = new Array (myFolder.absoluteURI);
getSubFolders(myFolder);
crearLabels();
// List all possible file extension in this array
var myExtentions = [".psd", ".tif", ".jpg", ".ai", ".eps", ".pdf", ".indd"];

	// Progress bar
	if (myInDesignVersion >= 5) {
		var stop = myLinks.length;
		var w = new Window ( 'window', 'Starting relinking files' );
		var pb = w.add ('progressbar', [12, 12, 350, 24], 0, stop);
		var txt = w.add('statictext');
		txt.bounds = [0, 0, 340, 20];
		txt.alignment = "left";
		w.show();
		var a = 1;
	} // Progress bar

// Loop through all links
for (i = myLinks.length-1; i >= 0 ; i--) {
	var myLink = myLinks[i];
	if (myLink.extractLabel("relinked") != "yes") {
		
		// Progress bar
		if (myInDesignVersion >= 5) {
			pb.value = a;
			a++;
			txt.text = String("Relinking file - " + myLink.name);
		} // Progress bar

		var myOldImageFile = new File (myLink.filePath);
		var myOldPath = myOldImageFile.toString();
		// Loop through all subfolders; the first subfolder is always the root folder
		for (var s = 0; s < mySubFolders.length; s++)  {
			mySubFolder = mySubFolders[s] + "/";
			
			// Progress bar
			if (myInDesignVersion >= 5) {
				var myCurrFolder = Folder (mySubFolders[s]);
				w.text = "Current folder - \"" + myCurrFolder.displayName + "\"";
			} // Progress bar
		
			if (LinkUsage(myLink) == 1) {
				main(myLink, mySubFolder);
			}
			else {
				processMultiUsedLinks();
			}
		}
	}
}
	// Progress bar
	if (myInDesignVersion >= 5) {
		w.close();
	} // Progress bar

//-------------------------------- Final report ----------------------------
if (myCounter == 1) {
	alert("One file has been relinked.", "Finished");
}
else if  (myCounter > 1) {
	alert(myCounter + " files have been relinked.", "Finished");
}
else {
	alert("Nothing has been relinked.", "Finished");
} 

//------------------------- Functions -------------------------------------
function main(myLink, myNewFolder) {
	var myNewPath = myNewFolder + myLink.name.replace(" ", "%20");
	if (myOldPath != myNewPath) {
		var myResult = myRelink(myNewPath, myLink);
		if (myResult == false) {
			// If the link is not a text file
			if (
				myLink.linkType != "InCopyInterchange" && 
				myLink.linkType != "InCopyStory" &&
				myLink.linkType != "InCopyMarkup" &&
				myLink.linkType != "Microsoft Excel Import Filter" &&
				myLink.linkType != "Microsoft Word Import Filter" &&
				myLink.linkType != "RTF Import Filter" &&
				myLink.linkType != "Text"
				) {
				// If file not found, try with another extention
				for (var k = 0; k < myExtentions.length; k++)  {
					try {
						var myBasename = myNewPath.match(/(.*)\.[^\.]+$/)[1];
						myNewPath = myBasename + myExtentions[k];
						myRelink(myNewPath, myLink);
					}
					catch (myError){}
				}
			}
		}
	}
}
// Relink and update
function myRelink(myNewPath, myLink) {
	var myNewLink =  new File (myNewPath);
		if (myNewLink.exists) {
			myLink.relink (myNewLink);
			try {
				var myCurrentLink = myLink.update();
			} catch(e){}
			if ( app.version.substr(0, 3) == "6.0" && (parseInt(app.version.substr(4, 1)) >= 4) ) {
				myLink.insertLabel("relinked", "yes");
			}
			else {
				myCurrentLink.insertLabel("relinked", "yes");
			}
		
			myCounter++;
			return true;
		}
	return false;
}
// Get all subfolders in the selected folder
function getSubFolders(theFolder) {
	var myFileList = theFolder.getFiles();
	for (var i = 0; i < myFileList.length; i++) {
		var myFile = myFileList[i];
		if (myFile instanceof Folder){
			mySubFolders.push(myFile.absoluteURI);
			getSubFolders(myFile);
		}
	}
	return mySubFolders;
}
// Check how many times the link was placed
function LinkUsage(myLink) {
	var myLinkCounter = 0;
		for (var c =  0; c < myDoc.links.length; c++) {
		if (myLink.filePath == myDoc.links[c].filePath) {
			myLinkCounter += 1;
		}
	}
	return myLinkCounter
}
// Relink the links placed more than once
function processMultiUsedLinks() {
	var myCounter = 1;
	var myMultiUsedLink = new Array();
	for (var d = 0; d < myLinks.length; d++)  {
		if (myLinks[d].filePath == myLink.filePath) {
			myMultiUsedLink.push(myLinks[d]);
		}
	}
	for (e = myMultiUsedLink.length-1; e >= 0 ; e--) {
		if (myMultiUsedLink[e].extractLabel("relinked") != "yes") {
			if (myInDesignVersion >= 5) {
				txt.text = String("Relinking file - " + myLink.name + " (" + myCounter + " of " + myMultiUsedLink.length + ")");
			}
			main(myMultiUsedLink[e], mySubFolder);
			myCounter++;
		}
	}
}
// Clear labels in case this script has been already run on the current document
function crearLabels() {
	for (var f =  0; f < myDoc.links.length; f++) {
		if (myDoc.links[f].extractLabel("relinked") != "") {
			myDoc.links[f].insertLabel("relinked", "");
		}
	}
}