// Nobrainer Scripting - http://www.nobrainer.dk

if (app.documents.length > 0) { 
	var myDocument = app.activeDocument;
	var myHyperlinkStyle = myDocument.characterStyles.item("hyperlink"); // replace hyperlink with name of your char style for links
	//alert(myHyperlinkStyle);
	main();
} else {
	alert("Please open a document");
}

function main() {
	try {
		var script = app.activeScript;
	} catch(err) {
		var script = File(err.fileName);
	}

	var myScriptFolderPath = script.path;
	var myFindChangeFile = new File(myScriptFolderPath + "/NamesAndURLs.txt"); //mac path for users desktop //File.openDialog("Choose the file containing the tab separated list"); 
	//alert(myFindChangeFile)
	myFindChangeFile = File(myFindChangeFile);
	var myResult = myFindChangeFile.open("r", undefined, undefined);
	if(myResult == true){
		app.findTextPreferences = NothingEnum.nothing;
		app.changeTextPreferences = NothingEnum.nothing;
		//Loop through the find/change operations.
		do {
			//read 1 line into myLine
			myLine = myFindChangeFile.readln();
			myFindChangeArray = myLine.split("\t");
			
			//The first field in the line is the value to find 
			myFindVal = myFindChangeArray[0];
			
			// second is the url
			myFindUrl = myFindChangeArray[1];
			
			doSearchAndReplace(myFindVal, myFindUrl, app.activeDocument);
				
		} while(myFindChangeFile.eof == false);
			myFindChangeFile.close();
			// reset search
			app.findTextPreferences = NothingEnum.nothing;
			app.changeTextPreferences = NothingEnum.nothing;
	}
}

function doSearchAndReplace(stringfind, urlstring, searchin) {
	app.findTextPreferences.findWhat = stringfind;
	
	//Set the find options.
	app.findChangeTextOptions.caseSensitive = false;
	app.findChangeTextOptions.includeFootnotes = false;
	app.findChangeTextOptions.includeHiddenLayers = false;
	app.findChangeTextOptions.includeLockedLayersForFind = false;
	app.findChangeTextOptions.includeLockedStoriesForFind = false;
	app.findChangeTextOptions.includeMasterPages = false;
	app.findChangeTextOptions.wholeWord = false;
	
	var myFoundItems = searchin.findText();

	for (i = 0; i < myFoundItems.length; i++) {
		var myHyperlinkDestination = myMakeURLHyperlinkDestination(urlstring);
		myMakeHyperlink(myFoundItems[i], myHyperlinkDestination);
		myFoundItems[i].applyCharacterStyle(myHyperlinkStyle, false);
	}
}

function myMakeHyperlink(myFoundItem, myHyperlinkDestination){
	try {
		var myHyperlinkTextSource = myDocument.hyperlinkTextSources.add(myFoundItem);
		var myHyperlink = myDocument.hyperlinks.add(myHyperlinkTextSource, myHyperlinkDestination);
		myHyperlink.visible = false;
	}
	catch(myError){
	}
}

function myMakeURLHyperlinkDestination(myURL){
	//If the hyperlink destination already exists, use it;
	//if it doesn't, then create it.
	try{
		var myHyperlinkDestination = myDocument.hyperlinkURLDestinations.item(myURL);
		myHyperlinkDestination.name;
	}
	catch(myError){
		myHyperlinkDestination = myDocument.hyperlinkURLDestinations.add(myURL);
	}
	myHyperlinkDestination.name = myURL;

	//Set other hyperlink properties here, if necessary.
	return myHyperlinkDestination;
}