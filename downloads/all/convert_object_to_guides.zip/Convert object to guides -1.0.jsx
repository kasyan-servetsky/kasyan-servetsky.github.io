﻿/* Copyright 2016, Kasyan Servetsky
October 23, 2016
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Convert object to guides",
doc, sel,
colorValue = [79, 153, 255];

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");

//===================================== FUNCTIONS ======================================
function Main() {
	var layerActive = doc.activeLayer;
	var layerGuides = MakeLayer("=== Guides ===", colorValue);
	layerGuides.move(LocationOptions.AT_BEGINNING);
	layerGuides.locked = true;
	layerGuides.visible = true;
	layerGuides.printable = false;
	
	for (var i = sel.length - 1; i >= 0; i--) {
		ConvertObjectToGuide(sel[i], layerGuides);
	}

	app.selection = NothingEnum.NOTHING;
	doc.activeLayer = layerActive;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ConvertObjectToGuide(obj, layer) {
	try {
		obj.move(layer);
		var color = MakeColor("=== Guides Color ===", ColorSpace.RGB, ColorModel.process, colorValue);		
		obj.strokeColor = color;
		obj.strokeWeight = 0.5;
		obj.fillColor = "None";
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeColor(colorName, colorSpace, colorModel, colorValue) {
	var doc = app.activeDocument;
	var color = doc.colors.item(colorName);
	if (!color.isValid) {
		color = doc.colors.add({name: colorName, space: colorSpace, model: colorModel, colorValue: colorValue});
	}
	return color;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeLayer(name, layerColor) {
	var layer = doc.layers.item(name);
	if (!layer.isValid) {
		layer = doc.layers.add({name: name});
		if (layerColor != undefined) layer.layerColor = layerColor;
	}
	return layer;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	sel = app.selection;
	if (sel.length == 0) ErrorExit("Nothing is selected. Please select something and try again.", true);

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------