﻿/* Script to make hyperlinks live by ckcosner

The aim is to take an InDesign document that was intended only for print, and go through to make all hyperlinks live. One of the problems is that typesetters can insert spaces or soft returns (shift-enter) in the middle of URLs to get them to break in the right spot. */

// --- Assumptions --- //
// One document open
// Hyperlinks not necessarily labeled by character style
// You want all hyperlinks to be live
// Typesetter sometimes inserts a space or return in middle of URL to force a line break
// Space or return comes before period or slash per style manual

var doc=app.activeDocument;

// Compress stray www .'s
fn_grepChange (doc, "www(\\s|\\n)\\.", "www.");
// Normalize to http://
fn_grepChange (doc, "(http\\:\\/\\/)?(www\\.([\\w\\-\\?\\=\\&]+[\\.\\/]?)+)", "http://$2");
// Remove ( space or return ) before ( period or slash )
fn_grepChange (doc, "(http\\:\\/\\/([\\w\\-\\?\\=\\&]+[\\.\\/]?)+)(\\s|\\n)(\\.|\\/)", "$1$4");

// ---- Main ---- //
app.changeGrepPreferences = NothingEnum.nothing;
app.findGrepPreferences = NothingEnum.nothing;
app.findChangeGrepOptions.includeFootnotes = true;

// Regardless of character styles, find hyperlinks
app.findGrepPreferences.findWhat = 'http\\:\\/\\/([\\w\\-\\?\\=\\&]+[\\.\\/]?)+';

var found = app.findGrep();
var report = "found and activated "+String(found.length)+" links\n";

// make hyperlinks

for(i=0; i<found.length; i++)
{
var report = report+found[i].contents+"\n";

var source = doc.hyperlinkTextSources.add(found[i]);    
var dest=doc.hyperlinkURLDestinations.add(found[i].contents);
    
doc.hyperlinks.add(source,dest, {visible:false, name:found[i].contents+"("+(i+1)+")"});

}
// If exporting to PDF set include hyperlinks to true
PDFExportPreset.includeHyperlinks = true;
// To export to html, choose File-->Export for Dreamweaver

app.changeGrepPreferences = NothingEnum.nothing;
app.findGrepPreferences = NothingEnum.nothing;

alert ( report );

function fn_grepChange (myDocument, regexFind, regexChange) {
    // purpose: execute a grep change, otherwise known as a regex s///;
    //Initialize.
    app.findGrepPreferences = NothingEnum.nothing;
    app.changeGrepPreferences = NothingEnum.nothing;

    //Set the find options.
    app.findChangeGrepOptions.includeFootnotes = true;
    app.findChangeGrepOptions.includeHiddenLayers = false;
    app.findChangeGrepOptions.includeLockedLayersForFind = false;
    app.findChangeGrepOptions.includeLockedStoriesForFind = false;
    app.findChangeGrepOptions.includeMasterPages = false;

    //Search and change
    app.findGrepPreferences.findWhat = regexFind;
    app.changeGrepPreferences.changeTo = regexChange;
    myDocument.changeGrep();

    //Clear the find/change preferences.
    app.findGrepPreferences = NothingEnum.nothing;
    app.changeGrepPreferences = NothingEnum.nothing;
    }

// --- end of script --- //