#targetengine "session"

var myEventListener = app.addEventListener("beforeSave", GetListOfLinks, false);

function GetListOfLinks(myEvent) {
	var myDoc = app.activeDocument;
	if (myDoc.links.length > 0) {
		var myList = myDoc.links.everyItem().filePath.join("\n");
	}
	else {
		var myList = "This document contains no links.";
	}
	var myMetaData = myDoc.metadataPreferences;
	myMetaData.description = myList;
}