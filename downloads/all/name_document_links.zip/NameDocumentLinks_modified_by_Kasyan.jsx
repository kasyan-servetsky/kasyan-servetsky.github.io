﻿/*
------------------------------------------------------------------------------------------------------------------
NameDocumentLinks
------------------------------------------------------------------------------------------------------------------
An InDesign CS/CS2/CS3 JavaScript by FourAces
© The Final Touch 2007
Version 1.0.0
Adds a name label with the link name, path, type, and status above the linked object (graphics & texts).
The link is placed in a new "Link Info" layer, and are set as nonprinting objects.
------------------------------------------------------------------------------------------------------------------
*/
var myScriptVer = "1.0";
var myInfoTitle = "Link Info";
var myInfoColor = [0,15,100,0];
var yPos = 0;
var xPos = 0;

if(app.documents.length != 0){
	var myDocument = app.activeDocument;
	var myOrgDocHUnits = myDocument.viewPreferences.horizontalMeasurementUnits;
	var myOrgDocVUnits = myDocument.viewPreferences.verticalMeasurementUnits;
	myDocument.viewPreferences.horizontalMeasurementUnits = 2053991795
	myDocument.viewPreferences.verticalMeasurementUnits = 2053991795
	var myLinks = myDocument.links;
	if(myLinks.length != 0){
		var myDialog = app.dialogs.add({name:"Name Document Links v"+ myScriptVer});
		with(myDialog){
			with(dialogColumns.add()){
				with (dialogRows.add()){
					with(borderPanels.add()){
						with(dialogColumns.add()){
							with (dialogRows.add()){
								staticTexts.add({staticLabel:"Link label displays:"});
							}
							with (dialogRows.add()){
								var myNameOpt = checkboxControls.add({staticLabel:"File Name", checkedState:true});
							}
							with (dialogRows.add()){
								var myPathOpt = checkboxControls.add({staticLabel:"File Path", checkedState:false});
							}
							with (dialogRows.add()){
								var myTypeOpt = checkboxControls.add({staticLabel:"File Type", checkedState:false});
							}
							with (dialogRows.add()){
								var myStatusOpt = checkboxControls.add({staticLabel:"Link Status", checkedState:false});
							}
						}
					}
				}
				with (dialogRows.add()){
					with(borderPanels.add()){
						with(dialogColumns.add()){
							with (dialogRows.add()){
								var myLabelOpt = checkboxControls.add({staticLabel:"Printable Labels", checkedState:false});
							}
						}
					}
				}
				with (dialogRows.add()){
					staticTexts.add({staticLabel:"© The Final Touch"});
				}
			}
		}
		var myResult = myDialog.show({name:"SplitOptions"});
		if(myResult == true){
			//Clear previous layer, color, and styles
			for(i = 0;i < myDocument.layers.length;i++){
				var myLayer = myDocument.layers[i];
				if(myLayer.name == myInfoTitle){
					myLayer.remove();
				}
			}
			for(i = 0;i < myDocument.colors.length;i++){
				var myColor = myDocument.colors[i];
				if(myColor.name == myInfoTitle){
					myColor.remove();
				}
			}			
			for(i = 0;i < myDocument.paragraphStyles.length;i++){
				var myPStyle = myDocument.paragraphStyles[i];
				if(myPStyle.name == myInfoTitle){
					myPStyle.remove();
				}
			}
			for(i = 0;i < myDocument.characterStyles.length;i++){
				var myCStyle = myDocument.characterStyles[i];
				if(myCStyle.name == myInfoTitle){
					myCStyle.remove();
				}
			}
			//Create the link info layer
			var myLinkInfoLayer = myDocument.layers.add();
			myLinkInfoLayer.name = myInfoTitle;
			//Create the link info color
			var myLinkInfoColor = myDocument.colors.add();
			myLinkInfoColor.name = myInfoTitle;
			myLinkInfoColor.colorValue = myInfoColor;
			//Create the link info Character Style
			var myLinkInfoCStyle = myDocument.characterStyles.add();
			myLinkInfoCStyle.name = myInfoTitle;
			try{
				myLinkInfoCStyle.fontStyle = "Semibold";
			}
			catch(e){}
			//Create the link info Paragraph Style
			var myLinkInfoPStyle = myDocument.paragraphStyles.add();
			myLinkInfoPStyle.name = myInfoTitle;
			try{
				myLinkInfoPStyle.paragraphDirection = ParagraphDirection.leftToRightDirection;
			}
			catch(e){}
			myLinkInfoPStyle.justification = Justification.leftAlign;
			try{
				myLinkInfoPStyle.appliedFont = "Myriad Pro";
				myLinkInfoPStyle.fontStyle = "Regular";
			}
			catch(e){}
			myLinkInfoPStyle.pointSize = 6;
			myLinkInfoPStyle.leading = 6;
			myLinkInfoPStyle.appliedLanguage = "English: USA";
			myLinkInfoPStyle.hyphenation = false;
			myLinkInfoPStyle.leftIndent = "7mm";
			myLinkInfoPStyle.firstLineIndent = "-7mm";

			var myLink, myLinkPos, myLinkName, myLinkPath, myLinkType, myLinkStat, myLinkInfoStr, myLinkParent, myLinkSpread, myLinkStatus, myLinkInfoFrame;
				
			for(l = 0;l < myLinks.length;l++){
				myLink = myLinks[l];
				if(myLink.status != LinkStatus.LINK_MISSING && myLink.parent.parent.hasOwnProperty("itemLayer") && myLink.parent.parent.itemLayer.visible == true){
					myLinkPos = myLink.parent.parent.geometricBounds;
					myLinkName = "";
					myLinkPath = "";
					myLinkType = "";
					myLinkStat = "";
					myLinkInfoStr = "";
				
					myLinkParent = myLink.parent;
					do{
						if(myLinkParent.constructor.name != "Character"){
							myLinkParent = myLinkParent.parent;
						}
						else{
							if(app.version.split(".")[0] >= 4){
								myLinkParent = myLinkParent.parentTextFrames[0];
							}
							else{
								myLinkParent = myLinkParent.parentTextFrame;
							}					
						}
					}while((myLinkParent.constructor.name != "Spread")&&(myLinkParent.constructor.name != "MasterSpread"))
					if(myLinkParent.constructor.name == "Spread"){
						myLinkSpread = myDocument.spreads[myLinkParent.index];
					}
					else{
						myLinkSpread = myDocument.masterSpreads[myLinkParent.index];
					}
				
					if(myNameOpt.checkedState){
						if((myPathOpt.checkedState == false) && (myTypeOpt.checkedState == false) && (myStatusOpt.checkedState == false)){
							myLinkInfoStr = myLinkInfoStr + myLink.name
						}
						else{
							myLinkInfoStr = myLinkInfoStr + "Name:\t" + myLink.name
						}
					}
					if(myPathOpt.checkedState){
						myLinkInfoStr = myLinkInfoStr + "\rPath:\t" + myLink.filePath;
					}
					if(myTypeOpt.checkedState){
						myLinkInfoStr = myLinkInfoStr + "\rType:\t" + myLink.linkType;
					}
					if(myStatusOpt.checkedState){
						myLinkStatus = "";
						switch(myLink.status){
							case LinkStatus.normal:
								myLinkStatus = "OK"
								break;
							case LinkStatus.linkOutOfDate:
								myLinkStatus = "Modified"
								break;
							case LinkStatus.linkMissing:
								myLinkStatus = "Missing"
								break;
							case LinkStatus.linkEmbedded:
								myLinkStatus = "Embedded"
								break;				
						}
						myLinkInfoStr = myLinkInfoStr + "\rStatus:\t" + myLinkStatus;
					}
				
					myLinkInfoFrame = myLinkSpread.textFrames.add();
					myLinkInfoFrame.geometricBounds = [myLinkPos[0],myLinkPos[1],myLinkPos[0]+10,myLinkPos[1]+50];
					myLinkInfoFrame.textFramePreferences.insetSpacing = ["0.5mm","0.5mm","0.5mm","0.5mm"];
					myLinkInfoFrame.textFramePreferences.ignoreWrap = true;
					myLinkInfoFrame.fillColor = myInfoTitle;
					myLinkInfoFrame.fillTint = 25;
					myLinkInfoFrame.strokeColor = myInfoTitle;
					myLinkInfoFrame.strokeWeight = 1;
					if(myLabelOpt.checkedState){
						myLinkInfoFrame.nonprinting = false;
					}
					else{
						myLinkInfoFrame.nonprinting = true;
					}
					myLinkInfoFrame.contents = myLinkInfoStr;
					for(p = 0;p < myLinkInfoFrame.parentStory.paragraphs.length;p++){
						myLinkInfoFrame.parentStory.paragraphs[p].appliedParagraphStyle = myInfoTitle;
						myLinkInfoFrame.parentStory.paragraphs[p].words[0].appliedCharacterStyle = myInfoTitle;
					}
					myLinkInfoFrame.fit(FitOptions.frameToContent); 
				}
			}
		}
	}
	myDocument.viewPreferences.horizontalMeasurementUnits = myOrgDocHUnits
	myDocument.viewPreferences.verticalMeasurementUnits = myOrgDocVUnits
}