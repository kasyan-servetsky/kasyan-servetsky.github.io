#target indesign
 
var myDoc = app.activeDocument;
var myFolder = Folder.selectDialog ("Select the Output Folder for the resized images");
 
SetDisplayDialogs("NO");
OpenFiles();
SetDisplayDialogs("ALL");
UpdateAllOutdatedLinks();
alert("Done");
 
function OpenFiles(){
     for (var i = myDoc.links.length-1; i >= 0; i--) { // process links collection backwards since it's changing! 
          var myLink = myDoc.links[i];
            
          if (myLink.linkType == "Photoshop"){
               var myImage = myLink.parent;
 
				var myHorScale = Math.abs(myImage.absoluteHorizontalScale);
				var myVerScale = Math.abs(myImage.absoluteVerticalScale);
                    
               if (myImage.space == "RGB") {
                    var myImagePath = myLink.filePath;
					var myImageFile = new File(myImagePath);
                         var myNewPath =  myFolder.absoluteURI + "/" + GetFileNameOnly(myImageFile.name) + ".png";
                         if (myLink.name.indexOf (".png")==-1) { // re-save any ph file, but the png
                              CreateBridgeTalkMessage(myImagePath, myNewPath, myHorScale, myVerScale, 300);
                              SetLink100percent(myLink, myNewPath);
                         }
               }
          }
     }
}
//--------------------------------------------------------------------------------------------------------------
function CreateBridgeTalkMessage(myImagePath, myNewPath, myHorScale, myVerScale, myResolution) {
     var bt = new BridgeTalk();
     bt.target = "photoshop";
     var myScript = ResizeInPS.toString() + "\r";
     myScript += "ResizeInPS(\"" + myImagePath + "\", \"" + myNewPath + "\", \"" +  myHorScale + "\", \"" + myVerScale + "\", \"" + myResolution + "\");";
     bt.body = myScript;
     // if something doesn't work, uncomment the following two lines -- the PS script will be written into console, copy it and dubbug it as a stand alone script in PS
//~      $.write(myScript);
//~      exit();
     // the following two lines are very important -- they force ID to wait until PS finishes resizing, saving and closing the image (this may take hours)
     bt.onResult = function(resObj) {} 
     bt.send(100);
}
//--------------------------------------------------------------------------------------------------------------
function ResizeInPS(myImagePath, myNewPath, myHorScale, myVerScale, myResolution) {
     var myPsDoc = app.open(new File(myImagePath));
     var docName = myPsDoc.name;
     
     try {
          if (myHorScale == "undefined") {
               var myHorScale = undefined;
          }
          else {
               var myHorScale = eval(new UnitValue(myHorScale, "%"));
          }
     
          if (myVerScale == "undefined") {
               var myVerScale = undefined;
          }
          else {
               var myVerScale = eval(new UnitValue(myVerScale, "%"));
          }
 
	myPsDoc.resizeImage(myHorScale, myVerScale, eval(myResolution), ResampleMethod.BICUBIC);

	var myPNGSaveOptions = new PNGSaveOptions();
	myPNGSaveOptions.interlaced = false; // or true
	myPsDoc.saveAs(new File(myNewPath), myPNGSaveOptions, true);
	myPsDoc.close(SaveOptions.DONOTSAVECHANGES);	 

     }
     catch (err) {
          try {
               app.activeDocument.close(SaveOptions.DONOTSAVECHANGES);
          }
          catch (err) {}
     }
}
//--------------------------------------------------------------------------------------------------------------
function SetLink100percent(myLink, myNewPath) { // relink to new file and set exactly to 100%
     var newFile = new File (myNewPath);
     if (myNewPath != undefined && newFile.exists) {
          var originalLinkFile = new File(myLink.filePath);
          myLink.relink(newFile);
          
          try { // for versions prior to 6.0.4
               var myLink = myLink.update();
          }
          catch(err) {}
          
          var myImage = myLink.parent;
          // set to exactly 100% if the image is not flipped
          if (myImage.absoluteHorizontalScale > 0 && myImage.absoluteVerticalScale > 0) {
               myImage.absoluteHorizontalScale = 100;
               myImage.absoluteVerticalScale = 100;
          }
     }
}
//--------------------------------------------------------------------------------------------------------------
function SetDisplayDialogs(Mode) { // turn on-off DialogModes in PS -- don't want to see the open file dialog while the script is running
     var bt = new BridgeTalk;
     bt.target = "photoshop";
     var myScript = "app.displayDialogs = DialogModes." + Mode + ";";
     bt.body = myScript;
     bt.send();
}
//--------------------------------------------------------------------------------------------------------------
function UpdateAllOutdatedLinks() {
     for (var myCounter = myDoc.links.length-1; myCounter >= 0; myCounter--) {
          var myLink = myDoc.links[myCounter];
          if (myLink.status == LinkStatus.linkOutOfDate) {
               myLink.update();
          }
     }
}
//--------------------------------------------------------------------------------------------------------------
function GetFileNameOnly(myFileName) {
	var myString = "";
	var myResult = myFileName.lastIndexOf(".");
	if (myResult == -1) {
		myString = myFileName;
	}
	else {
		myString = myFileName.substr(0, myResult);
	}
	return myString;
}
//--------------------------------------------------------------------------------------------------------------
function GetNewFileName(oldFile, newExtention, prefix, suffix, removeName) {
	var nameOnly = GetFileNameOnly(oldFile.name);
	var newPath = oldFile.path + "/" + ((prefix == undefined) ? "" : prefix) + ((removeName == true) ? "" : nameOnly) + ((suffix == undefined) ? "" : suffix) +  "." + newExtention;
	var newFile = new File(newPath);
	return newFile;
}
//--------------------------------------------------------------------------------------------------------------