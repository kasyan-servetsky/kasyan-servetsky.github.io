﻿// blindOpen_and_IDML-Export.jsx 

var file = File.openDialog("InDesign file"); // Select a file

if (file != null) { 
	try {
		var d = app.open(file, false); // Open the file without displaying it 
		d.exportFile(ExportFormat.INDESIGN_MARKUP,  File(file.fullName.replace(/.indd$/i, ".idml"))); // Export to IDML-Format 
		d.close(SaveOptions.NO); // Close without saving  
	}
	catch(err) {
		alert("Error: " + err.message + ", line: " + err.line, "Blind open and IDML-export", true);
	}
} 