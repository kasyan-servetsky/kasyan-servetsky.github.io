﻿/* Copyright 2015, Kasyan Servetsky
December 21, 2015
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Prepare xml-attributes",
glueFile = new File(app.filePath + "/Scripts/xml rules/glue code.jsx"),
txt,
count = 0;

PreCheck();
app.doScript(glueFile, ScriptLanguage.JAVASCRIPT);
CreateDialog();

//===================================== FUNCTIONS  ======================================
function Main() {
	var w = new Window("window", scriptName);
	txt = w.add("statictext", undefined,  "Processing xml-attribute #0000. Please be patient. It may take a while.");
	w.show();
	
	var ruleSet = [new ProcessTag];
	with (doc) {
		var elements = xmlElements;
		__processRuleSet(elements[0], ruleSet);
	}
	
	w.close();
	
	var report = count + " item" + ((count == 1) ? " was" : "s were") + " processed.";
	alert("Finished. " + report, scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessTag() {
	this.name = "ProcessTag";
	this.xpath = "//*";
	this.apply = function(xmlElement, ruleProcessor) {
		ProcessAttributes(xmlElement);
		return true;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessAttributes(xmlElement) {
	var xmlAttribute;
	
	if (xmlElement.xmlAttributes.length > 0) {
		for (var i = xmlElement.xmlAttributes.length - 1; i >= 0; i--) {
			xmlAttribute = xmlElement.xmlAttributes[i];
			if (set.rbSel == 0) {
				if (xmlAttribute.name.match(/:/) != null) {
					xmlAttribute.name = xmlAttribute.name.replace(/:/g, "_");
				}
			}
			else {
				if (xmlAttribute.name.match(/_/) != null) {
					xmlAttribute.name = xmlAttribute.name.replace(/_/g, ":");
				}
			}
		}
		count++;
		txt.text = "Processing xml-attribute #" + count + ". Please be patient. It may take a while.";
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	GetDialogSettings();
	var w = new Window("dialog", scriptName);

	w.p = w.add("panel", undefined, "");
	w.p.orientation = "column";
	w.p.alignChildren = "left";
	
	w.p.rb0 = w.p.add("radiobutton", undefined, "Prepare xml-attributes");
	w.p.rb1 = w.p.add("radiobutton", undefined, "Restore original xml-attributes");
	
	if (set.rbSel == 0) {
		w.p.rb0.value = true;
	}
	else if (set.rbSel == 1) {
		w.p.rb1.value = true;
	}

	w.buttons = w.add("group");
	w.buttons.orientation = "row";   
	w.buttons.alignment = "center";
	w.buttons.ok = w.buttons.add("button", undefined, "OK", {name:"ok" });
	w.buttons.cancel = w.buttons.add("button", undefined, "Cancel", {name:"cancel"});
	var showDialog = w.show();
	
	if (showDialog == 1) {
		if (w.p.rb0.value == true) {
			set.rbSel = 0;
		}
		else if (w.p.rb1.value == true) {
			set.rbSel = 1;
		}
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));

	if (set == undefined) {
		set = { rbSel: 0 };
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (!app.activeDocument.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (!glueFile.exists) ErrorExit("\"glue code.jsx\" should be located in the \"Scripts > xml rules\" folder for this script to work.", true);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}