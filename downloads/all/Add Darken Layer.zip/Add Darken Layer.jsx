var myDoc = app.activeDocument;
if (myDoc.mode == DocumentMode.CMYK) {
	main();
}
else {
	if (confirm("This file is not CMYK. Add layer?")) main();
}

function main() {
	app.displayDialogs = DialogModes.NO;
	var myLayer = myDoc.artLayers.add();
	myLayer.name = "Darken";
	myLayer.blendMode = BlendMode.DARKEN;
	app.displayDialogs = DialogModes.ALL;
}