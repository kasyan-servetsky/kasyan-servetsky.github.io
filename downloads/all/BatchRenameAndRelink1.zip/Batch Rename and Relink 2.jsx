﻿var myPrefix, myISBN;
var myDoc = app.activeDocument;
var myMultipleLinks = new Array();
var myLinksCounter = 0;
var myScriptName = "Batch rename and relink";
var myProcessedLinkNames = [];

CreateDialog();

//------------------------------------------- FUNCTIONS ------------------------------------------------
function CreateDialog() {
	var myDialog = new Window("dialog", myScriptName);
	myDialog.orientation = "column";
	myDialog.alignChildren = "fill";
	// Panel
	var myPanel = myDialog.add("panel", undefined, "Settings");
	myPanel.orientation = "column";
	myPanel.alignChildren = "right";
	// Prefix
	var myGroup1 = myPanel.add("group");
	myGroup1.orientation = "row";
	var myStTxt1 = myGroup1.add("statictext", undefined, "Prefix:");
	var myEdTxt1 = myGroup1.add("edittext");
	myEdTxt1.minimumSize.width = 130;
	if (app.extractLabel("Kas_BatchRenameAndRelink_ver1.0_Prefix") != "") myEdTxt1.text = app.extractLabel("Kas_BatchRenameAndRelink_ver1.0_Prefix");	
	// ISBN
	var myGroup2 = myPanel.add("group");
	myGroup2.orientation = "row";
	var myStTxt2 = myGroup2.add("statictext", undefined, "ISBN:");
	var myEdTxt2 = myGroup2.add("edittext");
	myEdTxt2.minimumSize.width = 130;
	if (app.extractLabel("Kas_BatchRenameAndRelink_ver1.0_ISBN") != "") myEdTxt2.text = app.extractLabel("Kas_BatchRenameAndRelink_ver1.0_ISBN");	
	// Buttons
	var myBtnGroup = myDialog.add("group");
	myBtnGroup.orientation = "row";
	myBtnGroup.alignment = "center";
	var myOkBtn = myBtnGroup.add("button", undefined, "Ok");
	var myCancelBtn = myBtnGroup.add("button", undefined, "Cancel");
	// Show dialog 
	var myShowDialog = myDialog.show();
	if (myShowDialog== 1) {
		myPrefix = myEdTxt1.text;
		myISBN = myEdTxt2.text.replace(/-/g, "");
		app.insertLabel("Kas_BatchRenameAndRelink_ver1.0_Prefix", myEdTxt1.text);
		app.insertLabel("Kas_BatchRenameAndRelink_ver1.0_ISBN", myEdTxt2.text);
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------
function Main() {
	WriteToFile("\r--------------------- Script started -- " + GetDate() + " ---------------------\n");
	
	ClearLabels();
	
	var myPrBarWin = new Window ("window", myScriptName);
	var myPrBar = myPrBarWin.add ("progressbar", [12, 12, 375, 24]);
	var myPrBarText = myPrBarWin.add("statictext", undefined, "Starting");
	myPrBarText.bounds = [0, 0, 365, 20];
	myPrBarText.alignment = "left";

	var myPages = myDoc.pages;
	myPrBar.minvalue = 0;
	myPrBar.maxvalue = myPages.length;
	
	for (var p = 0; p < myPages.length; p++) {
		var myPageNumber = Pad0000(myPages[p].name);
		var myLinks = myPages[p].allGraphics;
		myPrBarWin.show();
		
		for ( k = myLinks.length - 1; k >= 0; k-- ) {  //===================================================
			try {
				var myLink = myLinks[k].itemLink;
				
				if (myLink.extractLabel("relinked") != "yes") {
					var myOldLinkName = myLink.name;
					var myOldLinkNameStr = String(myOldLinkName);
					var myLinkUsage = LinkUsage(myLink);
					var myExtension = myOldLinkName.substr(myOldLinkName.lastIndexOf( "." ));
					if (LinkUsage(myLink) == 1) {
						var myNewLinkName = myPrefix + "_" + myPageNumber + "_" + myISBN + "_art_r" + (k+1) + myExtension;
						myPrBar.value = (p + 1);
						myPrBarText.text = "Renaming " + myOldLinkNameStr + " on page " + myPages[p].name;
						var myOldImageHDfile = new File( myLink.filePath );
						var myRenameResult = myOldImageHDfile.rename( myNewLinkName );
						if (myRenameResult)	{
							myLink.insertLabel("relinked", "yes");
							myLink.relink( myOldImageHDfile );
							try {
								myLink = myLink.update();
							}
							catch(err) {}
							WriteToFile(((myLinksCounter < 10) ? (" " + myLinksCounter) : myLinksCounter) + " - " + myOldLinkNameStr + " --> " + myNewLinkName + "\n");
							myLinksCounter++;
						}
						else {
							if (new File(myOldImageHDfile.parent + "/" + myNewLinkName + myExtension).exists) {
								WriteToFile("CAN'T RENAME LINK -- " + myLink.name + " to " + myNewLinkName + " because the file already exists\n");
							}
							else {
								WriteToFile("CAN'T RENAME LINK -- " + myOldImageHDfile.name + "\n");
							}
						}
					}
					else {
						ProcessMultiUsedLinks(myLink);
					}
				}
			}
			catch(err) {
				$.writeln(err.message + ", line: " + err.line);
			}
		
		} //===================================================
	}

	myPrBarWin.close();

	// Multiple images
	if (myMultipleLinks.length > 0) {
		for (var a = myMultipleLinks.length - 1; a >= 0; a--)
		{
			ProcessMultiUsedLinks(myMultipleLinks[a]);
		}
	}

	WriteToFile("\r--------------------- Script finished -- " + GetDate() + " ---------------------\r\r");
	
	if (myLinksCounter == 0) {
		alert("No links have been renamed", myScriptName);
	}
	if (myLinksCounter == 1) {
		alert("One link has been renamed", myScriptName);
	}
	else if (myLinksCounter > 1) {
		alert(myLinksCounter  + " links have been renamed", myScriptName);
	}
}
//--------------------------------------------------------------------------------------------------------------
// Check how many times the link was placed
function LinkUsage(myLink) {
	var myLinksNumber = 0;
		for (var c =  0; c < myDoc.links.length; c++) {
		if (myLink.filePath == myDoc.links[c].filePath) {
			myLinksNumber += 1;
		}
	}
	return myLinksNumber;
}
//--------------------------------------------------------------------------------------------------------------
// Relink the links placed more than once
function ProcessMultiUsedLinks(myLink) {
	if (IsObjInArray(myLink, myProcessedLinkNames)) return;
	var myExtension = myLink.name.substr(myLink.name.lastIndexOf( "." ));
	var myMultiUsedLink = new Array();
	var myAllLinks = myDoc.links;
	
	for (var d = 0; d < myAllLinks.length; d++)  {
		if (myAllLinks[d].filePath == myLink.filePath) {
			myMultiUsedLink.push(myAllLinks[d]);
		}
	}
	try {
		myLink.show();
	}
	catch(err) {}
	
	var myNewLinkName = prompt ("Enter a name for this image", GetFileNameOnly(myLink.name), "This image is placed " + myMultiUsedLink .length + " times");
	if (myNewLinkName) {
		if (myNewLinkName + myExtension != myLink.name) {
			var myOldImageHDfile = new File( myLink.filePath );
			var myOldLinkNameStr = String(myLink.name);
			var myRenameResult = myOldImageHDfile.rename( myNewLinkName + myExtension );
			if (myRenameResult) {
				myLink.insertLabel("relinked", "yes");
				myLink.relink(myOldImageHDfile);
				try {
					myLink = myLink.update();
				}
				catch(err) {}
				
				WriteToFile(((myLinksCounter < 10) ? (" " + myLinksCounter) : myLinksCounter) + " - " + myOldLinkNameStr + " --> " + (myNewLinkName + myExtension) + "\n");
				myLinksCounter++;

				for (var f = myMultiUsedLink.length-1; f >= 0 ; f--) {
					var myCurrLink = myMultiUsedLink[f];
					if (myNewLinkName + myExtension != myCurrLink.name) {
						myCurrLink.insertLabel("relinked", "yes");
						myCurrLink.relink(myOldImageHDfile);
						myLinksCounter++;

						try {
							myCurrLink = myLink.update();
						}
						catch(err) {}
					}
				}
			}
			else	{
				if (new File(myOldImageHDfile.parent + "/" + myNewLinkName + myExtension).exists) {
					WriteToFile("CAN'T RENAME LINK -- " + myOldImageHDfile.name + " to " + myNewLinkName + myExtension + " because the file already exists\n");
				}
				else {
					WriteToFile("CAN'T RENAME LINK -- " + myOldImageHDfile.name + "\n");
				}
			}
		}
	}
	else {
		myProcessedLinkNames.push(myLink);
	}

	UpdateAllOutdatedLinks();
}
//--------------------------------------------------------------------------------------------------------------
// Clear labels in case this script has been already run on the current document
function ClearLabels() {
	for (var f =  0; f < myDoc.links.length; f++) {
		if (myDoc.links[f].extractLabel("relinked") != "") {
			myDoc.links[f].insertLabel("relinked", "");
		}
	}
}
//--------------------------------------------------------------------------------------------------------------
function UpdateAllOutdatedLinks() {
	for(var myCounter = myDoc.links.length-1; myCounter >= 0; myCounter--){
		var myLink = myDoc.links[myCounter];
		if (myLink.status == LinkStatus.linkOutOfDate){
			myLink.update();
		}
	}
}
//--------------------------------------------------------------------------------------------------------------
function Pad0000(myNumber) {
	return ("0000" + myNumber).match (/....$/)[0];
}
//--------------------------------------------------------------------------------------------------------------
function GetFileNameOnly(myFileName) {
	var myString = "";
	var myResult = myFileName.lastIndexOf(".");
	if (myResult == -1) {
		myString = myFileName;
	}
	else {
		myString = myFileName.substr(0, myResult);
	}
	return myString;
}
//--------------------------------------------------------------------------------------------------------------
function IsObjInArray(myObj, myArray) {
	for (x in myArray) {
		if (myObj.filePath == myArray[x].filePath) {
			return true;
		}
	}
	return false;
}
//--------------------------------------------------------------------------------------------------------------
function WriteToFile(myText) {
	myFile = new File("~/Desktop/" + myScriptName + ".txt");
	if ( myFile.exists ) {
		myFile.open("e");
		myFile.seek(0, 2);
	}
	else {
		myFile.open("w");
	}
	myFile.write(myText); 
	myFile.close();
}
//--------------------------------------------------------------------------------------------------------------
function GetDate() {
	var myDate = new Date();
	if ((myDate.getYear() - 100) < 10) {
		var myYear = "0" + new String((myDate.getYear() - 100));
	} else {
		var myYear = new String ((myDate.getYear() - 100));
	}
	var myDateString = (myDate.getMonth() + 1) + "/" + myDate.getDate() + "/" + myYear + " " + myDate.getHours() + ":" + myDate.getMinutes() + ":" + myDate.getSeconds();
	return myDateString;
 }
//--------------------------------------------------------------------------------------------------------------