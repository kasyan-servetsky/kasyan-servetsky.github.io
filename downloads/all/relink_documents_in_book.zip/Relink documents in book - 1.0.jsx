﻿/* Copyright 2013, Kasyan Servetsky
April 24, 2013
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Relink documents in book - 1.0";

Main();

//===================================== FUNCTIONS  ======================================
function Main() {
	var bookContent, file, result,
	counter = 0;
	
	if (app.books.length == 0) ErrorExit("Please open a book and try again.", true);
	var activeBook = app.activeBook;
	
	var newFolder = Folder.selectDialog("Choose a folder with InDesign documents.");
	if (newFolder == null) exit();
	var newPath = newFolder.absoluteURI;
	
	for (var i = 0; i < activeBook.bookContents.length; i++) {
		result = null;
		bookContent = activeBook.bookContents[i];
		if (bookContent.status == BookContentStatus.MISSING_DOCUMENT) {
			file = new File(newPath + "/" + bookContent.name);
			if (file.exists) {
				result = bookContent.replace(file);
				if (result instanceof BookContent) {
					counter++;
				}
			}
		}
	}
	
	alert("Finished. Relinked " + counter + " files.", scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------