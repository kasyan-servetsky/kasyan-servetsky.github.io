﻿#target InDesign  
#targetengine "appliedFontsSession"; 
 
//DESCRIPTION: Which font is it?  
 
/*     
    + Indesign Version: CS5.5 und 6
    + Autor: Roland Dreger
    + Datum: 21. November 2012  
    
    + Das vorliegende Skript listet auswaehlte Eigenschaften der Textabschnitte/Absaetze/Formatbereiche/Einfuegemarke 
      im aktiven Dokument auf. Diese Eigenschaften werden in einem Textrahmen auf einer neuen Ebene eingefügt. 
      Die jeweilige Stelle wird mit einem Pfeil markiert.
      
      Hinweis zu Hintergrundfarbe und Kontur: 
      Die Farben der eingefuegten Textrahmen koennen geaendert werden. 
      Dazu in der InDesign-Farbpalette des aktiven Dokumentes die gewuenschten Farben 
      an die 3. Position (Hintergrund) bzw. 4. Position (Kontur) ziehen.
      
      Hinweis zum Absatzformat:
      Den Absaetzen im eingefuegten Textrahmen wird jeweils das Standardformat [Einf. Absatz] zugewiesen. 
*/ 
 
     
app.doScript(main, ScriptLanguage.JAVASCRIPT , [], UndoModes.ENTIRE_SCRIPT, "Which font is it?");   
 
function main () { 
 
  app.scriptPreferences.enableRedraw = true; 
     
  var _ui = appliedFontPalette (); 
  _ui.show(); 
 
 
  function appliedFontPalette () { 
 
    var _w = Window.find("palette", "Properties of fonts"); /* refresh UI */ 
     
    if (_w===null) { /* refresh UI */ 
 
      var _w = new Window ("palette", "Properties of fonts", undefined, {borderless: false, closeButton: true}); 
      with (_w) { 
        margins = [8,8,8,15];      
          
        var _rangesAndProps = add ("group"); 
        with (_rangesAndProps) { 
          orientation = "column"; 
          spacing = 5; 
          margins = [0,0,0,0]; 
          alignChildren = ["fill","fill"]; 
           
          var _look = add ("statictext", undefined, "Look for:"); 
          with (_look) { 
            graphics.font = "dialog:10"; 
          } 
           
          var _ranges = add ("panel"); 
          with (_ranges) { 
            alignChildren = "left"; 
            spacing = 3; 
            margins = [10,10,15,13]; 
            var _radioTSR = add ("radiobutton", undefined, "Style Ranges"); 
            with (_radioTSR) { 
              value = true; 
              graphics.font = "dialog:13"; 
              helpTip = "Formatbereiche"; 
            } 
            var _radioParagraph = add ("radiobutton", undefined, "Paragraphs"); 
            with (_radioParagraph) { 
              graphics.font = "dialog:13"; 
              helpTip = "Absätze"; 
            } 
            var _radioStory = add ("radiobutton", undefined, "Storys"); 
            with (_radioStory) { 
              graphics.font = "dialog:13"; 
              helpTip = "Textabschnitte"; 
            } 
            var _radioIP = add ("radiobutton", undefined, "Insertion Point"); 
            with (_radioIP) { 
              graphics.font = "dialog:13"; 
              helpTip = "Einfügemarke"; 
            }         
          } // END _ranges panel   
           
          var _properties = add ("statictext", undefined, "Listed Properties:"); 
          with (_properties) { 
            graphics.font = "dialog:10"; 
          } 
         
          var _props = add ("panel"); 
          with (_props) { 
            alignChildren = "left"; 
            spacing = 2; 
            margins = [10,10,15,13]; 
            var _checkName = add ("checkbox", undefined, "Font Name"); 
            with (_checkName) { 
              value = true; 
              graphics.font = "dialog:11"; 
              helpTip = "Schriftname"; 
            } 
            var _checkStyle = add ("checkbox", undefined, "Style"); 
            with (_checkStyle) { 
              graphics.font = "dialog:11"; 
              helpTip = "Schriftschnitt"; 
            } 
            var _checkType = add ("checkbox", undefined, "Type"); 
            with (_checkType) { 
              graphics.font = "dialog:11"; 
              helpTip = "Schrifttype"; 
            } 
            var _checkSize = add ("checkbox", undefined, "Size"); 
            with (_checkSize) { 
              graphics.font = "dialog:11"; 
              helpTip = "Schriftgröße"; 
            } 
            var _checkLeading = add ("checkbox", undefined, "Leading"); 
            with (_checkLeading) { 
              graphics.font = "dialog:11"; 
              helpTip = "Zeilenabstand"; 
            } 
            var _checkCaps = add ("checkbox", undefined, "Capitalization"); 
            with (_checkCaps) { 
              graphics.font = "dialog:11"; 
              helpTip = "Kapitälchen"; 
            } 
            var _checkKerning = add ("checkbox", undefined, "Kerning Method"); 
            with (_checkKerning) { 
              graphics.font = "dialog:11"; 
              helpTip = "Kerning Methode"; 
            } 
            var _checkTracking = add ("checkbox", undefined, "Tracking"); 
            with (_checkTracking) { 
              graphics.font = "dialog:11"; 
              helpTip = "Laufweite"; 
            } 
            var _checkHScale = add ("checkbox", undefined, "Horizontal Scale"); 
            with (_checkHScale) { 
              graphics.font = "dialog:11"; 
              helpTip = "Horizontale Skalierung"; 
            } 
            var _checkVScale = add ("checkbox", undefined, "Vertical Scale"); 
            with (_checkVScale) { 
              graphics.font = "dialog:11"; 
              helpTip = "Vertikale Skalierung"; 
            } 
            var _checkSkew = add ("checkbox", undefined, "Skew"); 
            with (_checkSkew) { 
              graphics.font = "dialog:11"; 
              helpTip = "Neigung (Pseudo-Kursiv)"; 
            } 
            var _checkNoBreak = add ("checkbox", undefined, "No Break"); 
            with (_checkNoBreak) { 
              graphics.font = "dialog:11"; 
              helpTip = "Kein Umbruch"; 
            } 
            var _checkPStyle = add ("checkbox", undefined, "Paragraph Style"); 
            with (_checkPStyle) { 
              graphics.font = "dialog:11"; 
              helpTip = "Absatzformat"; 
            } 
            var _checkCStyle = add ("checkbox", undefined, "Character Style"); 
            with (_checkCStyle) { 
              graphics.font = "dialog:11"; 
              helpTip = "Zeichenformat"; 
            } 
            var _checkLanguage = add ("checkbox", undefined, "Language"); 
            with (_checkLanguage) { 
              graphics.font = "dialog:11"; 
              helpTip = "Sprache"; 
            } 
          } // END _props panel        
        } // END _rangesAndProps group 
         
        var _startButton = add ("button", undefined, "Start", {name: "ok"}); 
       
      } // END _w window      
 
 
      // Callbacks +++ 
       
      _startButton.onClick = function() {   
         
        if (app.documents.length > 0) { 
           
          var _doc = app.activeDocument;   
          var _selectedRange = 0; 
          _selectedRange = selectedRange (_ranges); 
           
          function selectedRange (_ranges) { 
            for (var m = 0; m < _ranges.children.length; m++) 
              if (_ranges.children[m].value == true) 
            return m; 
          } // END function selectedRange       
           
          var _selectedProps = new Array(); 
          _selectedProps = selectedProps (_props,_selectedProps); 
           
          function selectedProps (_props,_selectedProps) { 
            for (var n = 0; n < _props.children.length; n++) { 
              _selectedProps[_props.children[n].text]=_props.children[n].value; 
            }     
            return _selectedProps; 
          } // END function selectedProps     
           
          var _horizontalMeasurementUnitsUser = _doc.viewPreferences.horizontalMeasurementUnits; 
          var _verticalMeasurementUnitsUser = _doc.viewPreferences.verticalMeasurementUnits; 
 
          _doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.MILLIMETERS; 
          _doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.MILLIMETERS;     
           
          try { 
            insertFontProps (_doc, _selectedRange,_selectedProps); 
          } catch (e) {        
            alert("Leider ist ein Fehler aufgetreten!\n" + e + "\nZeile: " + e.line + "\nSkript: " + e.fileName ); 
          }    
           
          var _paletteProgressbarAlive = Window.find("palette", "Progress"); 
          if (_paletteProgressbarAlive != null) { 
            _paletteProgressbarAlive.close(); 
          } 
           
          _doc.viewPreferences.horizontalMeasurementUnits = _horizontalMeasurementUnitsUser; 
          _doc.viewPreferences.verticalMeasurementUnits = _verticalMeasurementUnitsUser;        
        } else { 
          alert ("Kein Dokument geöffnet!"); 
        } 
         
      } // END _startButton.onClick 
       
      // END Callbacks +++     
        
    } // END if _w===null /* refresh UI */ 
         
    return _w; 
 
  } // END function appliedFontPalette  
   
   
  function insertFontProps (_doc, _selectedRange,_selectedProps) { 
     
    var _TSR = []; 
     
    switch (_selectedRange) { 
      case 1 :  /* Paragraphs */ 
        if (_doc.stories.firstItem().isValid == true) { 
          var _TSR = _doc.stories.everyItem().paragraphs.everyItem().getElements();       
          if (_doc.stories.everyItem().tables.firstItem().isValid == true) { 
            var _TSRInTables = _doc.stories.everyItem().tables.everyItem().cells.everyItem().paragraphs.everyItem().getElements(); 
            _TSR = _TSR.concat(_TSRInTables);   
          } 
          if (_doc.stories.everyItem().footnotes.firstItem().isValid == true) { 
            var _TSRInFootnotes = _doc.stories.everyItem().footnotes.everyItem().paragraphs.everyItem().getElements();   
            _TSR = _TSR.concat(_TSRInFootnotes); 
          } 
        } else { 
          alert("No paragraph in the Document!"); 
        }  
        break; 
      case 2 : /* Stories */ 
        if (_doc.stories.firstItem().isValid == true) 
          var _TSR = _doc.stories.everyItem().getElements(); 
        else  
          alert("No story in the Document!");       
        break; 
      case 3 : /* Insertion point */ 
        if ((app.selection.length > 0) && (app.selection[0].constructor.name == "InsertionPoint")) 
          if (app.selection[0].getElements()[0].textStyleRanges[0]!=null)           
            _TSR.push(app.selection[0].getElements()[0].textStyleRanges[0]);  
          else 
            alert ("No text style range at selected insertion point!"); 
        else 
          alert ("No insertion point selected!");         
        break; 
      default : /* Text Style Ranges */ 
        if ((_doc.stories.firstItem().isValid == true)&&(_doc.stories.everyItem().paragraphs.everyItem().textStyleRanges[0]!=null)) { 
          _TSR = _doc.stories.everyItem().paragraphs.everyItem().textStyleRanges.everyItem().getElements();        
          if (_doc.stories.everyItem().tables.firstItem().isValid == true) { 
            var _TSRInTables = _doc.stories.everyItem().tables.everyItem().cells.everyItem().textStyleRanges.everyItem().getElements(); 
            _TSR = _TSR.concat(_TSRInTables);   
          } 
          if (_doc.stories.everyItem().footnotes.firstItem().isValid == true) { 
            var _TSRInFootnotes = _doc.stories.everyItem().footnotes.everyItem().textStyleRanges.everyItem().getElements();   
            _TSR = _TSR.concat(_TSRInFootnotes); 
          } 
        } else { 
          alert("No style ranges in the Document!"); 
        } 
    }      
     
    var _fontFamily, _fontStyle, _fontType, _pointSize, _leading, _kerning, _tracking, _horizontalScale,  _verticalScale; 
    var _capitalization, _noBreak, _skew, _appliedLanguage, _appliedPS, appliedCS;    
    var _parentTF; 
    var _parentP; 
    var _TFi; 
    var _baselineTSRi; 
    var _y1TFi, _x1TFi, _y2TFi, _x2TFi; 
    var _y1Arrowi,_x1Arrowi,_y2Arrowi,_x2Arrowi; 
    var _arrowi;  
     
    var _widthTFi = 70; // Breite eingefuegter Textrahmen 
    var _heightTFi = 85; // Hoehe eingefuegter Textrahmen (vor der Anpassung durch das Skript) 
     
    var _pStyle = _doc.paragraphStyles.item(1); // Absatzformat für eingefuegten Textrahmen 
     
    if (_doc.layers.itemByName("Which font is it?").isValid == false) { 
      _fontDescriptionLayer = _doc.layers.add({name:"Which font is it?"}); 
      _fontDescriptionLayer.move(LocationOptions.AT_BEGINNING); 
      _fontDescriptionLayer.layerColor = UIColors.RED; 
    } else { 
      _fontDescriptionLayer = _doc.layers.itemByName("Which font is it?"); 
    } 
   
    // Progressbar 
    var _paletteProgressbar = new Window ("palette","Progress", undefined); 
    var _progress = progressbar (_paletteProgressbar, _TSR.length); 
     
    function progressbar (w, stop) {      
      var _pb = w.add ("progressbar", undefined, 1, stop); 
      _pb.preferredSize = [300,15]; 
      w.add ("statictext", undefined, "Just a moment please ..."); 
      w.show (); 
      return _pb; 
    } // END function progressbar  
     
    // Loop durch Formatbereiche 
    for (i=0; i<_TSR.length; i++) {  
       
      _progress.value = i+1; 
      var _output = []; 
       
      // Props ************* 
      //Family 
      if (_selectedProps["Font Name"]) { 
        if (_TSR[i].appliedFont.constructor.name == "Font")  
          _fontFamily = "Name: " + _TSR[i].appliedFont.fontFamily;      
        else  
          _fontFamily = "Name: " + _TSR[i].appliedFont;      
        _output.push (_fontFamily); 
      } 
     
      //Style 
      if (_selectedProps["Style"]) { 
        _fontStyle = "Style: " + _TSR[i].fontStyle; 
        _output.push (_fontStyle); 
      } 
     
      //Type 
      if (_selectedProps["Type"]) { 
        try { 
          switch (_TSR[i].appliedFont.fontType) { 
              case FontTypes.ATC : 
                _fontType = "Type: ATC"; 
                break; 
              case FontTypes.BITMAP : 
                _fontType = "Type: Bitmap"; 
                break; 
              case FontTypes.CID : 
                _fontType = "Type: CID"; 
                break; 
              case FontTypes.OCF : 
                _fontType = "Type: OCF"; 
                break; 
              case FontTypes.OPENTYPE_CFF : 
                _fontType = "Type: OpenType CFF"; 
                break; 
              case FontTypes.OPENTYPE_CID : 
                _fontType = "Type: OpenType CID"; 
                break; 
              case FontTypes.OPENTYPE_TT : 
                _fontType = "Type: OpenType TT"; 
                break; 
              case FontTypes.TRUETYPE : 
                _fontType = "Type: TrueType"; 
                break; 
              case FontTypes.TYPE_1 : 
                _fontType = "Type: Type 1"; 
                break; 
 
              default : 
                _fontType = "Type: unknown"; 
          } 
        } catch (e) { 
          _fontType = "Type: unknown"; 
        } 
        _output.push (_fontType); 
      } 
     
      // Size 
      if (_selectedProps["Size"]) { 
        _pointSize = "Size: " + _TSR[i].pointSize.toFixed(2) + " pt"; 
        _output.push (_pointSize); 
      } 
     
      // Leading 
      if (_selectedProps["Leading"]) { 
        if (_TSR[i].leading == Leading.AUTO) { 
          _leading = _TSR[i].pointSize*(_TSR[i].autoLeading/100) 
          _leading = "Leading: " + _leading.toFixed(2) + " pt"; 
        } 
        else { 
          _leading = "Leading: " + _TSR[i].leading.toFixed(2) + " pt"; 
        } 
        _output.push (_leading); 
      } 
     
      // Capitalization      
      if (_selectedProps["Capitalization"]) { 
        switch (_TSR[i].capitalization) { 
          case Capitalization.ALL_CAPS : 
            _capitalization = "Caps:  all uppercase"; 
            break; 
          case Capitalization.CAP_TO_SMALL_CAP : 
            _capitalization = "Caps: OpenType small caps"; 
            break; 
          case Capitalization.SMALL_CAPS : 
            _capitalization = "Caps: small caps for lowercase"; 
            break; 
 
          default : 
            _capitalization = "Caps: Normal"; 
        } 
        _output.push (_capitalization);       
      } 
     
      // Kerning     
      if (_selectedProps["Kerning Method"]) { 
        _kerning = "Kerning: " + _TSR[i].kerningMethod;       
        _output.push (_kerning); 
      } 
       
      // Tracking 
      if (_selectedProps["Tracking"]) { 
        _tracking = "Tracking: " + _TSR[i].tracking;       
        _output.push (_tracking); 
      }  
        
      // Scale 
      if (_selectedProps["Horizontal Scale"]) { 
        _horizontalScale = "Horizontal Scale: " + _TSR[i].horizontalScale; 
        _output.push (_horizontalScale); 
      }   
      if (_selectedProps["Vertical Scale"]) {   
        _verticalScale = "Vertical Scale: " + _TSR[i].verticalScale; 
        _output.push (_verticalScale); 
      } 
       
      // Skew 
      if (_selectedProps["Skew"]) { 
        _skew = "Skew: " + _TSR[i].skew;       
        _output.push (_skew); 
      } 
 
      // No Break 
      if (_selectedProps["No Break"]) { 
        _noBreak = "No Break: " + _TSR[i].noBreak;       
        _output.push (_noBreak); 
      } 
       
      // Applied Style      
      if (_selectedProps["Paragraph Style"]) { 
        _appliedPS = "PS: " + _TSR[i].appliedParagraphStyle.name; 
        _output.push (_appliedPS); 
      } 
      if (_selectedProps["Character Style"]) { 
        _appliedCS = "CS: " + _TSR[i].appliedCharacterStyle.name; 
        _output.push (_appliedCS); 
      } 
       
      // Applied Language 
      if (_selectedProps["Language"]) { 
        _appliedLanguage = "Language: " + _TSR[i].appliedLanguage.name;       
        _output.push (_appliedLanguage); 
      } 
       
      // END Props *************      
       
      // Abfrage Textueberlauf oder Objekt auf der Montageflaeache 
      // Wenn nicht, Zuweisung parentPage und parentTextFrame 
      switch (_TSR[i].constructor.name) { 
          case "TextStyleRange" : 
            // TF Overflow 
            if ((_TSR[i].parentTextFrames[0]!=null)&&(_TSR[i].parentTextFrames[0].constructor.name != "TextPath")) {   
              // Items on Pasteboard 
              if (_TSR[i].parentTextFrames[0].parentPage != null) {  
                _parentP = _TSR[i].parentTextFrames[0].parentPage; 
                _parentTF = _TSR[i].parentTextFrames[0]; 
                _noOverflow = true; 
              } else { 
                _noOverflow = false; 
              } 
            } else { 
              _noOverflow = false; 
            } 
            break; 
          case "Paragraph" : 
            // TF Overflow 
            if ((_TSR[i].parentTextFrames[0]!=null)&&(_TSR[i].parentTextFrames[0].constructor.name != "TextPath")) {   
              // Items on Pasteboard 
              if (_TSR[i].parentTextFrames[0].parentPage != null) {  
                _parentP = _TSR[i].parentTextFrames[0].parentPage; 
                _parentTF = _TSR[i].parentTextFrames[0]; 
                _noOverflow = true; 
              } else { 
                _noOverflow = false; 
              } 
            } else { 
              _noOverflow = false; 
            } 
            break; 
          case "Story" : 
            // TF Overflow 
            if ((_TSR[i].insertionPoints[0].parentTextFrames[0]!=null)&&(_TSR[i].insertionPoints[0].parentTextFrames[0].constructor.name != "TextPath")) { 
              // Items on Pasteboard 
              if (_TSR[i].insertionPoints[0].parentTextFrames[0].parentPage != null) {  
                  _parentP = _TSR[i].insertionPoints[0].parentTextFrames[0].parentPage; 
                  _parentTF = _TSR[i].insertionPoints[0].parentTextFrames[0]; 
                  _noOverflow = true; 
              } else { 
                _noOverflow = false; 
              } 
            } else { 
              _noOverflow = false; 
            }  
            break; 
          default : 
            _noOverflow = false; 
      } 
             
      if (_noOverflow) { 
         
        _TFi = _parentP.textFrames.add(_fontDescriptionLayer, {name:"Description "+i}); 
 
        _TFi.fillColor = _doc.swatches[2]; 
        _TFi.strokeColor = _doc.swatches[3]; 
        _TFi.strokeWeight = 2; 
           
        _baselineTSRi = _TSR[i].lines[0].baseline;        
           
        _y1TFi = _baselineTSRi; 
        _x1TFi = _parentTF.geometricBounds[1]-_widthTFi; 
        _y2TFi = _baselineTSRi+_heightTFi; 
        _x2TFi = _parentTF.geometricBounds[1]-10; 
           
        _TFi.geometricBounds = [_y1TFi,_x1TFi,_y2TFi,_x2TFi]; 
        _TFi.textFramePreferences.insetSpacing = [4,4,4,4]; 
 
        for (var j=0; j<_output.length; j++) {            
          _TFi.insertionPoints[-1].contents = _output[j] + "\r";          
          if (_TFi.paragraphs.item(j).isValid) 
            _TFi.paragraphs.item(j).applyParagraphStyle(_pStyle); 
        }        
         
        _TFi.geometricBounds = [_y1TFi,_x1TFi,_TFi.lines[-1].baseline+_TFi.textFramePreferences.insetSpacing[2]+_TFi.strokeWeight,_x2TFi]; 
 
        _y1Arrowi = _baselineTSRi; 
        _x1Arrowi = _TFi.geometricBounds[3]; 
        _y2Arrowi = _baselineTSRi; 
        _x2Arrowi = _TSR[i].insertionPoints[0].horizontalOffset; 
           
        _arrowi = _parentP.graphicLines.add(_fontDescriptionLayer, {name:"Arrow "+i, strokeWeight:2, strokeColor: _doc.swatches[3], rightLineEnd: ArrowHead.TRIANGLE_ARROW_HEAD, geometricBounds: [_y1Arrowi, _x1Arrowi, _y2Arrowi, _x2Arrowi]}); 
 
        _parentP.groups.add([_TFi,_arrowi],_fontDescriptionLayer, {name:"Group "+i}); 
           
      } /*else { 
        alert("Uebersatztext in einem der Textrahmen oder Text auf Montageflaeche!");
      } */   
    } // END loop TSR-Array 
   
    _progress.parent.close();   
   
  }// END insertFontProps 
} // END main 