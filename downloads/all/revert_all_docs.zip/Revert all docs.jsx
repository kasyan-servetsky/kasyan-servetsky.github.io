﻿var docs = app.documents;
app.scriptPreferences.userInteractionLevel = UserInteractionLevels.neverInteract;
app.documents.everyItem().revert();
//~ for (var i = docs.length-1; i >= 0; i--) {
//~ 	//docs[i].textPreferences.smartTextReflow = false;
//~ 	docs[i].revert();
//~ }
app.scriptPreferences.userInteractionLevel = UserInteractionLevels.interactWithAll;

//~ app.documents.everyItem().revert();