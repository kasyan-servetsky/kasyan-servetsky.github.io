if (app.documents.length > 0) {
	var myDoc = app.activeDocument;
	var myDocName = myDoc.name;
	if (myDocName.lastIndexOf("psd") > 0) {
		var myNewFolder = new Folder('~/Desktop/png'); // change location to your own folder
		if (!myNewFolder.exists) myNewFolder.create();
		var myNewName = myDocName.replace(/.psd$/, '.png');
		var myNewFile = new File(myNewFolder.fsName + '/' + myNewName);
		myNewFile = Uniquify(myNewFile);
		myDoc.saveAs(myNewFile, SaveDocumentType.PNG, true, Extension.LOWERCASE);
	}
	else {
		alert("The current document is not PSD-file.");
	}
}
else {
	alert("Please open a document and try again.");
}
//-----------------------------------------------------------------------------------------------
// Thanks Bob Stucky for the functions below (a little bit modified by me)
function Uniquify(myFile) {
	var sq = 1;
	var oldName = NameWithoutExtension( true, myFile );
	var oldExt = GetExtension( true, myFile );
	var aFile = new File( myFile.absoluteURI );
	while ( aFile.exists ) {
		aFile = new File( aFile.path + "/" + oldName + "(" + sq++ + ")." + oldExt );
	}
	return aFile;
}

	function GetExtension( noDecode, myFile ) {
		var idx = noDecode ? myFile.name.lastIndexOf( "." ) :  decodeURIComponent( myFile.name ).lastIndexOf( "." );
		var ext = undefined;
		if ( idx > -1 ) {
			if ( noDecode ) {
				ext = myFile.name.substr( ( idx + 1 ) );
			} else {
				ext = decodeURIComponent( myFile.name ).substr( ( idx + 1 ) );
			}
		}
		return ext;
	}

	function NameWithoutExtension( noDecode, myFile ) {
		var fName = noDecode ? myFile.name :  decodeURIComponent( myFile.name );
		var idx = fName.lastIndexOf( "." );
		if ( idx > -1 ) {
			fName = fName.substr( 0, idx );
		}
		return fName;
	}	