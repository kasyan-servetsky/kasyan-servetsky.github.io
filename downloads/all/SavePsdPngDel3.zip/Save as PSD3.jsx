if (app.documents.length > 0) {
	var myDoc = app.activeDocument;
	var myDocName = myDoc.name;
	var myFolder = new Folder('~/Desktop/psd'); // change location to your own folder
	if (!myFolder.exists) myFolder.create();
	var myDialog = new Window('dialog', 'Save file as PSD');
	myDialog.size = {width:300, height:90};
	var myEditText = myDialog.add('edittext');
	myEditText.active = true;
	myEditText.preferredSize = {width:200, height:20};
	var myNewName = myEditText.text;
	var myGroup = myDialog.add('group');
	myGroup.orientation = 'row';
	var myOkBtn = myGroup.add('button', undefined, 'Save', {name:'ok'});
	var myCancelBtn = myGroup.add('button', undefined, 'Cancel', {name:'cancel'});
	if (myDialog.show() == 1) {
		var myNewName = myEditText.text;
		if (myNewName != "") {
			myNewName += '.psd';
			var myNewFile = new File(myFolder.fsName + '/' + myNewName);
			var id51 = charIDToTypeID( "save" );
			var desc8 = new ActionDescriptor();
			var id52 = charIDToTypeID( "As  " );
			var desc9 = new ActionDescriptor();
			var id53 = stringIDToTypeID( "maximizeCompatibility" );
			desc9.putBoolean( id53, true );
			var id54 = charIDToTypeID( "Pht3" );
			desc8.putObject( id52, id54, desc9 );
			var id55 = charIDToTypeID( "In  " );
			desc8.putPath( id55, new File( myNewFile ) );
			var id56 = charIDToTypeID( "LwCs" );
			desc8.putBoolean( id56, true );
			executeAction( id51, desc8, DialogModes.NO );
			var myLastPsd = app.activeDocument.fullName.toSource();
			try {
				var myPrefsFolder = new Folder( Folder.userData.absoluteURI + '/TempScriptData' );	
				if (!myPrefsFolder.exists) myPrefsFolder.create();
				var myTempFile = new File(myPrefsFolder.fsName + '/TempData.txt');
				myTempFile.open("w");
				myTempFile.write(myLastPsd);
				myTempFile.close();
			}
			catch (err) {
				alert("Failed to create a temp file. -- Error: " + err.message);
				exit();
			}
		}
	}
}
else {
	alert("Please open a document and try again.");
}