try {
	var myPrefsFolder = new Folder( Folder.userData.absoluteURI + '/TempScriptData' );	
	var myTempFile = new File(myPrefsFolder.fsName + '/TempData.txt');
	if (myTempFile.exists) {
	myTempFile.open("r");
	var myDoc = eval(myTempFile.read());
	myTempFile.close();
		if (!IsDocOpen(myDoc)) {
			myDoc.remove();
		}
		else {
			myDocByName = app.documents.getByName(myDoc.name);
			myDocByName.close(SaveOptions.DONOTSAVECHANGES);
			myDoc.remove();
		}
	}
	else {
		alert("The last saved PSD-file: " + myDoc.fullName + " does not exist.");
	}
}
catch (err) {
	alert("Failed to delete PSD-file. -- Error: " + err.message);
}

function IsDocOpen(myDoc) {
	for (i = 0; i < app.documents.length; i++) {
		if (app.documents[i].fullName == myDoc.fullName) {
			return true;
		}
	}
	return false;
}
/*
	
	Documents.getByName (name:string): Document 
Get the first element in the collection with the provided name.
name: Data Type: string 


*/