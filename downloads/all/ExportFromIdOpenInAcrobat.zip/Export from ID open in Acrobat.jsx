#target indesign
var myIndesignDoc = app.activeDocument;
var myBaseName = GetFileNameOnly(myIndesignDoc.name);
var myFile = new File( "/C/" + myBaseName + ".pdf" ); 
myIndesignDoc.exportFile( ExportFormat.pdfType, myFile, false );

var myScript = 'var myAcrobatDoc = app.openDoc( "/C/' + myBaseName + '.pdf" );\n';
myScript += 'myAcrobatDoc.print( {bUI: false, bSilent: true} );\n';
myScript += 'myAcrobatDoc.closeDoc( true );';
var bt = new BridgeTalk;
bt.target = "acrobat";
bt.body = myScript;
bt.send();

function GetFileNameOnly(myFileName) {
	var myString = "";
	var myResult = myFileName.lastIndexOf(".");
	if (myResult == -1) {
		myString = myFileName;
	}
	else {
		myString = myFileName.substr(0, myResult);
	}
	return myString;
}