var myDoc = app.activeDocument;
if (myDoc.mode == DocumentMode.CMYK) {
	main();
	}
else {
	alert("Non-CMYK file.");
	}

function main() {
	//  Unsharp mask
	var id3 = charIDToTypeID( "UnsM" );
	var desc2 = new ActionDescriptor();
	var id4 = charIDToTypeID( "Amnt" );
	var id5 = charIDToTypeID( "#Prc" );
	desc2.putUnitDouble( id4, id5, 200.000000 );
	var id6 = charIDToTypeID( "Rds " );
	var id7 = charIDToTypeID( "#Pxl" );
	desc2.putUnitDouble( id6, id7, 0.400000 );
	var id8 = charIDToTypeID( "Thsh" );
	desc2.putInteger( id8, 7 );
	executeAction( id3, desc2, DialogModes.NO);
	//  Fade luminosity
	var id9 = charIDToTypeID( "Fade" );
	var desc3 = new ActionDescriptor();
	var id10 = charIDToTypeID( "Opct" );
	var id11 = charIDToTypeID( "#Prc" );
	desc3.putUnitDouble( id10, id11, 100.000000 );
	var id12 = charIDToTypeID( "Md  " );
	var id13 = charIDToTypeID( "BlnM" );
	var id14 = charIDToTypeID( "Lmns" );
	desc3.putEnumerated( id12, id13, id14 );
	executeAction( id9, desc3, DialogModes.NO );
}