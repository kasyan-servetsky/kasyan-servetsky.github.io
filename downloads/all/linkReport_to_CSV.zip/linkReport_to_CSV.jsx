﻿// LinksReport.jsx
// An Indesign CS3 JavaScript by Loic_aigon November 2008
// Amended 14 July 2009
// Edited by Kasyan Servetsky; September 24, 2017
// This script scans links in a document and produces a spreadsheet 
// (CSV) giving the document name, the linked file name, the page on which 
// it is found, its dimensions, effective PPI and scaling.
// Links in rotated frames may give odd results.
// See http://forums.adobe.com/thread/288626
// 
if(app.documents.length!=0)
{
 if(app.activeDocument.links.length!=0)
 {
  var s = "LinkName;Page;ImgWidth;ImgHeight;X-Res;Y-Res;X-Scale;Y-Scale;Path;";
  var doc = app.activeDocument;
  var doc_name = doc.name;
  var shortdocname = doc_name.split(".indd")[0];
  var lks = doc.links;
  var link_name; var pg_nb; var img_width; var img_height; 
  var x_res; var y_res; var x_scale; var y_scale; var lk; var feedAline; var lkPath;
  var myarr = [];
  var tempstring ="";
  for(i=0; i<lks.length; i++)
  {
   lk = lks[i];
   link_name = lk.name.replace(",","_");
   x_res = "N/A";
   y_res = "N/A"
   x_scale = lk.parent.horizontalScale;
   y_scale = lk.parent.verticalScale;
   lkPath=lk.filePath.split(link_name)[0];
   try{
    x_res = lk.parent.effectivePpi[0];
    y_res = lk.parent.effectivePpi[1];
   }
   catch(e){}

	try{
	   if(lk.parent.parent.parentPage.constructor.name=="Page")
	   {
		pg_nb = lk.parent.parent.parentPage.name;
	   }
	   else
	   {
		pg_nb = "N/A";
	   }
	}
	catch(e)
	{
	pg_nb = "N/A";
	}
   
   var gb = lk.parent.parent.geometricBounds;
   img_width = Math.round((gb[3]-gb[1])*100) / 100;
   img_height = Math.round((gb[2]-gb[0])*100) / 100;
   
   if(i<lks.length-1)
   {
    feedAline = "\r";
   }
   else
   {
    feedAline ="";
   }
   myarr.push(link_name + ";"+ pg_nb + ";"+ img_width 
   + ";" + img_height+ ";" + x_res + ";" + y_res+ ";" + x_scale + ";" + 
y_scale+";"+lkPath+";");
  }
  for(j=0; j<myarr.length;j++)
  {
   var x = String(myarr[j])+"\r";
   tempstring = tempstring.concat(x);
  }
//////////////////////////////////////////////////////////////////////////////// ////////
// Put the full path for the CSV file instead of G:/Documents/ on the following line: //
//////////////////////////////////////////////////////////////////////////////// ////////
  //var mycsv = new File("G:/Documents/"+shortdocname+".csv");
  var fo  = Folder.selectDialog("Choose a folder to save your csv file");
  if(fo){
	  var myCSVFile = new File(fo+"/"+shortdocname+".csv");
	  myCSVFile.open("w");
	  myCSVFile.write(s + "\r"+tempstring);
	  myCSVFile.execute();
	  alert(decodeURI(myCSVFile.name) +" has been generated here : \r"+decodeURI(fo.fullName));
	 }
 }
 else
 {
  alert("No pictures to work on!")
 }
}
else
{
 alert("No document open!");
}