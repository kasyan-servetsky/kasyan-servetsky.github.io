﻿var scriptName = "Make list of installed fonts";

Main();

function Main() {
	var arr = [],
	startTime = new Date();
	
	var fonts = app.fonts.everyItem().getElements();
	
	for (var i = 0; i < fonts.length; i++) {
		arr.push(fonts[i].name.replace("\t", " "));
	}
	
	var text = arr.join("\r");
	WriteToFile(text);
	
	var endTime = new Date();
	var duration = GetDuration(startTime, endTime);
	alert("Found " + arr.length + " fonts. (Time elapsed " + duration + ")", scriptName, false);
}

function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}

function WriteToFile(text) {
	var file = new File("~/Desktop/" + scriptName + ".txt");
	file.encoding = "UTF-8";
	file.open("w");
	file.write(text); 
	file.close();
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}