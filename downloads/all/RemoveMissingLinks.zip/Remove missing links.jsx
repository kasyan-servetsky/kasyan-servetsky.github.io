var doc = app.activeDocument;
var links = doc.links;

for (var i = links.length-1; i >= 0; i--) {
	if (links[i].status == LinkStatus.LINK_MISSING) {
		try {
			links[i].parent.remove();
		}
		catch (err) {
			$.writeln(i + " - " + err);
		}
	}
}