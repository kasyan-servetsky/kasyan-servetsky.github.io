﻿var myFolder = Folder.selectDialog( "Select a folder with InDesign files" );
if ( myFolder != null ) {
	var myFiles = [];
	var myAllFilesList = myFolder.getFiles();

	for (var f = 0; f < myAllFilesList.length; f++) {
		var myFile = myAllFilesList[f];
		if (myFile instanceof File && myFile.name.match(/\.indd$/i)) {
			myFiles.push(myFile);
		}
	}
	
	if ( myFiles.length > 0 ) {
		var mySortedFiles = myFiles.sort(sortFileNames);
		var myBookFileName = myFolder + "/"+ myFolder.name + ".indb";
		myBookFile = new File( myBookFileName );
		if ( myBookFile.exists ) {
			if ( app.books.item(myFolder.displayName + ".indb") == null ) {
				myBook = app.open( myBookFile );
			}
		}
		else {
			 myBook = app.books.add( myBookFile );
			 myBook.automaticPagination = false;
			 for ( i=0; i < mySortedFiles.length; i++ ) {
				myBook.bookContents.add( mySortedFiles[i] );
			 }
			 myBook.save( );
	 	}
	}
}

function sortFileNames(a, b) { 
	a = a.name;
	b = b.name;
	var regExp = new RegExp("^\\d+");
	var aObj = {num: a.match(regExp) != null ? a.match(regExp)[0] : "_", string: a.replace(/^\d+/, "")};
	var bObj = {num: b.match(regExp) != null ? b.match(regExp)[0] : "_", string: b.replace(/^\d+/, "")};
	// a and b are fully numeric :
	if (aObj.string =="" && bObj.string == "") { return a - b };
	// the numeric parts of a and b are equal :
	if (aObj.num == bObj.num ) { return aObj.string.toLowerCase() > bObj.string.toLowerCase() };
	if (aObj.num > bObj.num ) { return 1 };
}