﻿#target bridge     
if( BridgeTalk.appName == "bridge" ) {    
	fileToDesc = MenuElement.create("command", "Add FileName to Description", "at the end of Tools");  
} 

fileToDesc.onSelect  = function () {     
	var thumbs = app.document.selections;   
	if (ExternalObject.AdobeXMPScript == undefined)  ExternalObject.AdobeXMPScript = new ExternalObject("lib:AdobeXMPScript");

	for(var a =0;a<thumbs.length;a++){
		var selectedFile =  new Thumbnail(thumbs[a]);      
		app.synchronousMode = true;  
		var xmp = new XMPMeta(selectedFile.synchronousMetadata.serialize());  
		var Desc = getArrayItems(XMPConst.NS_DC, "description");  
		if(Desc != "") Desc+= ";";  
		xmp.deleteProperty(XMPConst.NS_DC, "description");   
		xmp.setLocalizedText( XMPConst.NS_DC, "description", null, "x-default", Desc +=  decodeURI(selectedFile.spec.name).replace(/\..+$/,""));  
		var newPacket = xmp.serialize(XMPConst.SERIALIZE_USE_COMPACT_FORMAT);  
		selectedFile.metadata = new Metadata(newPacket);   
	} 

	ExternalObject.AdobeXMPScript.unload();  
	ExternalObject.AdobeXMPScript = undefined; 

	function getArrayItems(ns, prop){
		var arrItem=[];  
		try{
			var items = xmp.countArrayItems(ns, prop);  
			for(var i = 1;i <= items;i++){  
				arrItem.push(xmp.getArrayItem(ns, prop, i));  
			}  
			return arrItem.toString();  
		}catch(e){alert(e +" Line: "+ e.line);}  
	}
}; 