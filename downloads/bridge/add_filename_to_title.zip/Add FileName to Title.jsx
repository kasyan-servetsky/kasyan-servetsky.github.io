﻿#target bridge     
if( BridgeTalk.appName == "bridge" ) {    
	FT = MenuElement.create("command", "Add FileName to Title", "at the end of Tools");  
} 

FT.onSelect = function () {   
	AddFilenameToTitle();  
}

function AddFilenameToTitle(){  
	var thumbs = app.document.selections;   
	if(!thumbs.length) return;  
	if (ExternalObject.AdobeXMPScript == undefined)  ExternalObject.AdobeXMPScript = new ExternalObject("lib:AdobeXMPScript"); 
	
	for(var a in thumbs){ 
		var selectedFile = thumbs[a].spec;      
		var Title = decodeURI(selectedFile.name).replace(/\.[^\.]+$/, '')  
		var myXmpFile = new XMPFile( selectedFile.fsName, XMPConst.UNKNOWN, XMPConst.OPEN_FOR_UPDATE);   
		var myXmp = myXmpFile.getXMP();  
		myXmp.deleteProperty(XMPConst.NS_DC, "title");  
		myXmp.appendArrayItem(XMPConst.NS_DC, "title", Title, 0, XMPConst.ALIAS_TO_ALT_TEXT);  
		myXmp.setQualifier(XMPConst.NS_DC, "title[1]", "http://www.w3.org/XML/1998/namespace", "lang", "x-default");
		
		if (myXmpFile.canPutXMP(myXmp)) {   
			myXmpFile.putXMP(myXmp);  
			myXmpFile.closeFile(XMPConst.CLOSE_UPDATE_SAFELY);   
		}   
	}
} 