 // Program Name:  New document from selection
 // 
 // Version 1.0
 //
 // Author:     Larry B. Ligon
 //
 // Purpose:  This script will create a new document from a selection.
 //                 The new document will be the same type and resolution as the original document.
 //   
 // Requirements:  Must have a document open and a selection made.  
 //
 // Limitations:   Photoshop CS and above only.  Will not work in Photoshop 7.
 //                       If the selection only covers part of the non-transparent part of the layer,
 //                       the resulting document will contain only the non-transparent section of the layer.
 //                       If the layer has effects, the effects will not be included.  You have to
 //                       rasterize the layer first.  If the layer is a text layer, the resulting layer in the
//                        new document will not be a text layer but a rasterized version of the selection.
 //                       Does not work with shape layer, you have to rasterize it first.  

// You must have a document open
if (documents.length > 0) 
 {
// No dialogs
displayDialogs = DialogModes.NO;

//Flag to indicate errors
var bolError = false;

// Save the original state so that we can return to it.
var originalHistoryState = activeDocument.activeHistoryState;

// In order to get the dimensions of the selection it has to be placed into a layer set.
// Then the bounds of the layer set can be read.  This is done by creating a dummy
// layerset and pasting the selection in the layer set.
// We then have something to measure.

var bounds = new Array();

// The selection width and height is calculated from the layer set bounds.
var selwidth , selheight;

// Create a reference to the active document.
var docRef = activeDocument;

// Save the current preferences for later restoration
var strtRulerUnits = app.preferences.rulerUnits;
var strtTypeUnits = app.preferences.typeUnits;

// Change the ruler unit to pixels so we can work in pixel units.
preferences.rulerUnits = Units.PIXELS;

// If no selection is made, an error will be generated when you try to copy from the clipboard.
// This error is trapped and a message is displayed telling the user that no selection has been made.
// If the selected area of the layer is empty this message will also be displayed.  Also, if the layer
// is a shape layer this message will be displayed.
try {

   // Copy selection to clipboard.
   app.activeDocument.selection.copy();

   // Can't make layerset in BITMAP mode.  Change to GRAYSCALE mode.
   var isBitmap = false;
   if (docRef.mode == DocumentMode.BITMAP) {
     // Save the current history state so that we can restore back to this current state.
     var savedHistoryState = docRef.activeHistoryState;

      // This boolean means that the history state has to be restored.
      isBitmap = true;

     //This is Script Listener code.  
     var id503 = charIDToTypeID( "CnvM" );
     var desc88 = new ActionDescriptor();
     var id504 = charIDToTypeID( "T   " );
     var desc89 = new ActionDescriptor();
      var id505 = charIDToTypeID( "Rt  " );
      desc89.putInteger( id505, 1 );
      var id506 = charIDToTypeID( "Grys" );
      desc88.putObject( id504, id506, desc89 );
      executeAction( id503, desc88, DialogModes.NO );
   }

   // Create the dummy layer set and paste the selection in the layer set.
   var layerSetRef = docRef.layerSets.add();
   var layerRef = layerSetRef.artLayers.add();
   docRef.activeLayer = layerRef;
   app.activeDocument.paste(); 
  
  // Find out the bounds of the selection and calculate the width and height
   bounds = layerSetRef .bounds;
   selwidth = bounds[2]-bounds[0];
   selheight = bounds[3]-bounds[1];
   
  // Get rid of the dummy layer set
   layerSetRef.remove();

   // Change back to BITMAP mode if necessary
   if (isBitmap ) {
       docRef.activeHistoryState = savedHistoryState ;
      }

   // Determine what the current document mode is.
    switch(docRef.mode) {
      case DocumentMode.RGB : newMode = NewDocumentMode.RGB; break;
      case DocumentMode.GRAYSCALE: newMode = NewDocumentMode.GRAYSCALE; break;
      case DocumentMode.CMYK: newMode = NewDocumentMode.CMYK; break;
      case DocumentMode.BITMAP: newMode = NewDocumentMode.BITMAP; break;
      case DocumentMode.LAB: newMode = NewDocumentMode.LAB; break;
   }

   // Create a new document based on the current document mode and resolution and 
  //  the selection width and height.

  // Create a document name using the current time
  var today = new Date();
  var newName = "Untitled-" + today.getHours() + "_" + today.getMinutes() + "_" + today.getSeconds();

  var docRef2 = app.documents.add(selwidth ,selheight ,docRef.resolution,newName ,newMode );

   // Paste the contents of the clipboard to the new file.
   app.activeDocument.paste(); }

// If no selection has been made, this catch will be executed and will display a message to user.
catch (e) {
     var strMessage = "No selection has been made or an empty part of the layer has been selected.\n"
     strMessage += "Or a shape layer is selected.  If a shape layer, rasterize the shape layer first.\n"
     strMessage += "Make a selection and try this script again.";
     alert(strMessage );
     bolError = true;
   }       

// Go back to the original state the document was in before running this script.
activeDocument = docRef;
docRef.activeHistoryState = originalHistoryState;

// Restore the preferences
app.preferences.rulerUnits = strtRulerUnits;
app.preferences.typeUnits = strtTypeUnits;

if ( !bolError ) {
// Make the new document the active document
activeDocument = docRef2;


// Release the object memory back to the system
docRef = null;
docRef2 = null;
}
}
else
 { alert("No document open.\nYou must have a document with layers open");
 }
