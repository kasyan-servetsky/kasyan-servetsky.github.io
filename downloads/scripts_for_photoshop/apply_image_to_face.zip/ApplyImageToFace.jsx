﻿var doc;
var scriptName = "Apply Green channel to Magenta and Yellow";
var cTID = function(s) { return app.charIDToTypeID(s); };
var sTID = function(s) { return app.stringIDToTypeID(s); };

main();

function main() {
	if (app.documents.length == 0) {
		alert("Please open a document and try again.", scriptName, true);
	}

	else {
		doc = app.activeDocument;
		
		if (doc.mode == DocumentMode.CMYK) {
			if (GetChannel("Green copy") != null) {
				if (doc.artLayers.length == 1) {
					makeSnapshot("Before Apply Image to Face");
					selectMagentaChannel();
					applyImageToMagentaChannel();
					selectYellowChannel();
					applyImageToYellowChannel();
					selectCMYK();
					makeSnapshot("After Apply Image to Face");
					copyAll();
					selectRelativeSnapshot();
					makeApplyLayer();
					makeSnapshot("Final");
				}
				else {
					alert("Please merge or flatten the document before using this script. It should have onl", scriptName, true);
				}				
			}
			else {
				alert("The current document has no \"Green copy\" channel.", scriptName, true);
			}
		}
		else {
			alert("The current document is not in CMYK.", scriptName, true);
		}
	}
}

function GetChannel(name) {
	var channel;
	
	try {
		channel = doc.channels.getByName(name);
	}
	catch(err) {
		channel = null;
	}

	return channel;
}

function makeSnapshot(name) {
	try {
		var desc1 = new ActionDescriptor();
		var ref1 = new ActionReference();
		ref1.putClass(cTID('SnpS'));
		desc1.putReference(cTID('null'), ref1);
		var ref2 = new ActionReference();
		ref2.putProperty(cTID('HstS'), cTID('CrnH'));
		desc1.putReference(cTID('From'), ref2);
		desc1.putString(cTID('Nm  '), name);
		desc1.putEnumerated(cTID('Usng'), cTID('HstS'), cTID('FllD'));
		executeAction(cTID('Mk  '), desc1);
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}

function selectMagentaChannel() {
	var desc1 = new ActionDescriptor();
	var ref1 = new ActionReference();
	ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Mgnt'));
	desc1.putReference(cTID('null'), ref1);
	executeAction(cTID('slct'), desc1, DialogModes.NO);
}

function applyImageToMagentaChannel() {
	var desc1 = new ActionDescriptor();
	var desc2 = new ActionDescriptor();
	var ref1 = new ActionReference();
	ref1.putName(cTID('Chnl'), "Green copy");
	desc2.putReference(cTID('T   '), ref1);
	desc2.putBoolean(cTID('PrsT'), true);
	desc1.putObject(cTID('With'), cTID('Clcl'), desc2);
	executeAction(sTID('applyImageEvent'), desc1, DialogModes.NO);
}

function selectYellowChannel() {
	var desc1 = new ActionDescriptor();
	var ref1 = new ActionReference();
	ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Yllw'));
	desc1.putReference(cTID('null'), ref1);
	executeAction(cTID('slct'), desc1, DialogModes.NO);
}

function applyImageToYellowChannel() {
	var desc1 = new ActionDescriptor();
	var desc2 = new ActionDescriptor();
	var ref1 = new ActionReference();
	ref1.putName(cTID('Chnl'), "Green copy");
	desc2.putReference(cTID('T   '), ref1);
	desc2.putBoolean(cTID('PrsT'), true);
	desc1.putObject(cTID('With'), cTID('Clcl'), desc2);
	executeAction(sTID('applyImageEvent'), desc1, DialogModes.NO);
}

function selectCMYK() {
	var desc1 = new ActionDescriptor();
	var ref1 = new ActionReference();
	ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID("CMYK"));
	desc1.putReference(cTID('null'), ref1);
	executeAction(cTID('slct'), desc1, DialogModes.NO);
}

function selectRelativeSnapshot() {
	try {
		var desc1 = new ActionDescriptor();
		var ref1 = new ActionReference();
		ref1.putName(cTID('SnpS'), "Before Apply Image to Face");
		desc1.putReference(cTID('null'), ref1);
		executeAction(cTID('slct'), desc1, DialogModes.NO);
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}

function copyAll() {
	doc.activeLayer.copy();
}

function makeApplyLayer() {
	var layer = doc.artLayers.add();
	layer.name = "Apply";
	doc.paste();
	addMask();
	disableMask();
	selectCMYKchannel();
}

function addMask() {
	var desc1 = new ActionDescriptor();
	desc1.putClass(cTID('Nw  '), cTID('Chnl'));
	var ref1 = new ActionReference();
	ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
	desc1.putReference(cTID('At  '), ref1);
	desc1.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('HdAl'));
	executeAction(cTID('Mk  '), desc1, DialogModes.NO);
}

function disableMask() {
	var desc1 = new ActionDescriptor();
	var ref1 = new ActionReference();
	ref1.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
	desc1.putReference(cTID('null'), ref1);
	var desc2 = new ActionDescriptor();
	desc2.putBoolean(cTID('UsrM'), false);
	desc1.putObject(cTID('T   '), cTID('Lyr '), desc2);
	executeAction(cTID('setd'), desc1, DialogModes.NO);
}

function selectCMYKchannel() {
	var desc1 = new ActionDescriptor();
	var ref1 = new ActionReference();
	ref1.putEnumerated(cTID('Chnl'), cTID('Chnl'), sTID("CMYK"));
	desc1.putReference(cTID('null'), ref1);
	desc1.putBoolean(cTID('MkVs'), false);
	executeAction(cTID('slct'), desc1, DialogModes.NO);
}