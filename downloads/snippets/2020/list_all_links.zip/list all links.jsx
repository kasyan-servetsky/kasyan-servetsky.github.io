﻿Main();

function Main() {
	var doc = app.activeDocument;
	var links = doc.links;
	
	for (var i = 0; i < links.length; i++) {
		$.writeln(links[i].name.replace(/\.[^\.]+$/, ""));
	}
	
	$.writeln("================");
}