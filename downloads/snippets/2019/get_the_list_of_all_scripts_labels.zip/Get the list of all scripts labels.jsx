﻿var txtfrm = app.selection[0];  
txtfrm.insertLabel ("key1", "value1");
txtfrm.insertLabel ("key2", "value2");
txtfrm.insertLabel ("key3", "value3");
  
var getLabels = function(item) {  
	var f = File(Folder.desktop+"/"+item.id+".idms" ),  
	x, a, o = {}, keys, n;  

	if  ( !(item.exportFile instanceof Function) ) return;  

	item.exportFile ( ExportFormat.INDESIGN_SNIPPET,  f );  

	if ( !f.exists ) return;  

	f.open("r");  
	x = XML ( f.read() );  
	f.close();  
	f.remove();  

	keys  = x..KeyValuePair;  
	n = keys.length();  
	if ( !n ) return;  

	while ( n-- )  {  
		o[String(keys[n].@Key)] = String(keys[n].@Value);  
	}  

	x = null;  
	return o;  
} 

var labels = getLabels ( txtfrm ); 
alert ( labels? labels.toSource() : "None" ); 