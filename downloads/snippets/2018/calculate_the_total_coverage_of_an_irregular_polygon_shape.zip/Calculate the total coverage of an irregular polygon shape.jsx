﻿    var pathArea = function(/*[x,y][3][]*/ep,  r,n,i,P,Q,xa,ya,xb,yb,xc,yc,xd,yd)  
    //----------------------------------  
    // Based on http://www.gust.org.pl/bachotex/2011-en/presentations/JackowskiB_3c_2011  
    // Return AREA x 20 ; result is signed.  
    {  
        for( r=0, n=ep.length, i=-1 ; ++i < n ; )  
        {  
            3 == (P=ep[i]).length ?  
                ( xa=P[1][0], ya=P[1][1], xb=P[2][0], yb=P[2][1] ) :  
                ( xa=xb=P[0], ya=yb=P[1]);  
      
            3 == (Q=ep[(1+i)%n]).length ?  
                ( xc=Q[0][0], yc=Q[0][1], xd=Q[1][0], yd=Q[1][1] ) :  
                ( xc=xd=Q[0], yc=yd=Q[1]);  
              
            r += (xb-xa)*(10*ya + 6*yb + 3*yc +    yd)  
              +  (xc-xb)*( 4*ya + 6*yb + 6*yc +  4*yd)  
              +  (xd-xc)*(   ya + 3*yb + 6*yc + 10*yd);  
        }  
      
        return r;  
    };  
      
    var splineArea = function(/*SplineItem*/o,  a,r,i,n,t)  
    //----------------------------------  
    // Visit every closed path and calculate the total area.  
    {  
        const CLOSED = +PathType.CLOSED_PATH;  
      
        a = o.paths.everyItem().getElements();  
        for( r=0, n=a.length, i=-1 ; ++i < n && (t=a[i]).pathType==CLOSED ; r+=pathArea(t.entirePath) );  
      
        if( i < n ) throw "All paths must be closed.";  
      
        return (r/=20), 0 < r ? r : -r;  
    };  
      
    var getArea = function(/*obj|obj[]*/a,t,mu,i,r)  
    //----------------------------------  
    // Main function. Return the area in the form "<value> <unit>²".  
    // This function does not address splines that auto-intersect.  
    {  
        callee.Q||(callee.Q={  
            Q:               'q',  
            U:               'u',  
            POINTS:          'pt',  
            PIXELS:          'px',  
            PICAS:           'p',  
            MILS:            'mils',  
            MILLIMETERS:     'mm',  
            INCHES_DECIMEL:  'in',  
            INCHES:          'in',  
            HA:              'ha',  
            CICEROS:         'c',  
            CENTIMETERS:     'cm',  
            BAI:             'bai',  
            AMERICAN_POINTS: 'ap',  
            AGATES:          'ag',  
            });  
      
        (a instanceof Array) || (a=[a]);  
      
        // Set consistent measurement unit.  
        // ---  
        while( 1 )  
        {  
            if( !(t=a[0]) || 'function' != typeof t.toSpecifier ) throw "Invalid input."  
            t = t.toSpecifier().match(/^\/document\[@id=\d+\]/);  
            if( !t || !(t=resolve(t[0])) || !(t instanceof Document) ) throw "Invalid input.";  
            t = t.viewPreferences.horizontalMeasurementUnits;  
            app.scriptPreferences.measurementUnit = t;  
            mu = callee.Q[t.toString()]||'';  
            mu && (mu = ' ' + mu + '\xB2');  
            break;  
        }  
          
        for( r=0, i=a.length ; i-- ; (o=a[i])&&o.hasOwnProperty('paths')&&(r+=splineArea(o)) );  
          
        return String(r) + mu;  
    };  
      
      
    // TEST. (Assuming something is selected.)  
    //========================================  
    var sel = app.selection;  
    alert( getArea(sel) );  