﻿function redefineScalingAs100(/*Image|<ImageContainer>*/sel,  img,p,orig,mx,pf,t)  
//----------------------------------  
// Emulate the "Redefine Scaling as 100%" menu action through  
// detailed transform steps. As shown by Loic Aigon, invoking  
// `app.menuActions.itemByName("$ID/RedefineScalingMenuString")`  
// does the entire job in one single command. The present snippet  
// attempts to reach the same outcome from pure transformations.  
{  
	// Checkpoint.  
	// ---  
	if( !sel ){ alert("Select an image."); return; }  
	// ---  
	( sel instanceof Image )  
	? ( p=(img=sel).parent )  
	: ( img=(p=sel).hasOwnProperty('images') && p.images[0] );  
	// ---  
	if( !img.isValid ){ alert("No image found."); return; }  
  
	// Constants.  
	// ---  
	const CS_REF = +CoordinateSpaces.parentCoordinates;  
	const CS_INN = +CoordinateSpaces.innerCoordinates;  
	const CS_PBD = +CoordinateSpaces.pasteboardCoordinates;  
	// ---  
	const BB_VIS = +BoundingBoxLimits.OUTER_STROKE_BOUNDS;  
	// ---  
	const WS_SCA = +WhenScalingOptions.adjustScalingPercentage;  
	const WS_RSZ = +WhenScalingOptions.applyToContent;  
	// ---  
	const MC_SCA = +MatrixContent.scaleValues;  
  
	// Visible box center in *pasteboard* coordinates (because  
	// we want that location to remain invariant.)  
	// ---  
	orig = p.resolve([AnchorPoint.centerAnchor, BB_VIS, CS_INN], CS_PBD)[0];  
	  
	// Matrix of `p` relative to its parent space--i.e, affine map.  
	// (The whole purpose of `mx` is to backup scaling factors.)  
	// ---  
	mx = p.transformValuesOf(CS_REF)[0];  
	if( 1==mx.horizontalScaleFactor && 1==mx.verticalScaleFactor ) return;  
  
	// 1. Reset `p` scaling to 100% relative to its parent space.  
	//    (`adjustScalingPercentage` is temporarily required.)  
	// ---  
	t = +(pf=app.transformPreferences).whenScaling;  
	t==WS_SCA ? ( t=0 ) : ( pf.whenScaling=WS_SCA );  
	p.transform( CS_REF, orig, [1,0,0,1,0,0], MC_SCA );  
	t && (pf.whenScaling=t);  
	  
	// 2. Recover the original size by applying `mx` scale values.  
	//    (`applyToContent` is temporarily required.)  
	// ---  
	t ? (t=0) : ( pf.whenScaling=t=WS_RSZ );  
	p.transform( CS_REF, orig, mx, MC_SCA );  
	t && (pf.whenScaling=t);  
}  
  
// Test.  
// ---  
redefineScalingAs100(app.selection[0]);  