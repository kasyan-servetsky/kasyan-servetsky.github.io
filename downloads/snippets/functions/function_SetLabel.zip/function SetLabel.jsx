// Set label to a file on Mac by JavaScript
// Pass the path to a file and a number for a color.
// Written by Kasyan Servetsky

function SetLabel(myPath, myLabel) {
   // myLabel: 0 — none, 1 — orange, 2 — red, 3 — yellow, 4 — blue, 5 - violet, 6 - green, 7 — gray 
   if (File.fs == "Macintosh") {
      if (new File(myPath).exists) {
         var myMacPath = myPath.replace("/", "").split("/").join(":");
            if (myMacPath.match("~Desktop") != null) {
               var myGetDiskNameScript = 'tell application \"Finder\"\r';
               myGetDiskNameScript += 'set myDisk to name of startup disk\r';
               myGetDiskNameScript += 'end tell\r';
               myGetDiskNameScript += 'tell application \"Adobe InDesign CS' + ((parseInt(app.version.substr(0, 1)) - 2) + "") + '\"\r';
               myGetDiskNameScript += 'tell script args\r';
               myGetDiskNameScript += 'set value name \"myDiskName\" value myDisk\r';
               myGetDiskNameScript +=  'end tell\r';
               myGetDiskNameScript +=  'end tell\r';
               app.doScript(myGetDiskNameScript, ScriptLanguage.applescriptLanguage);
               var myScriptArgument = app.scriptArgs.getValue("myDiskName");
               myMacPath = myMacPath.replace("~Desktop", myScriptArgument + $.getenv("USER") + ":Desktop")
            }
         var myScript = 'tell application \"Finder\"\r';
         myScript += 'set myFile to file \"' + myMacPath + '\" as alias\r';
         myScript += 'set label index of myFile to '+ myLabel + '\r';
         myScript += 'end tell\r';
         app.doScript(myScript, ScriptLanguage.applescriptLanguage);
      }
   }
}