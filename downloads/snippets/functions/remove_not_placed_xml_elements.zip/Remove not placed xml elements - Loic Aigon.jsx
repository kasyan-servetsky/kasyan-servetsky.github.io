﻿var main = function() {
	var doc = app.properties.activeDocument,
	xes, xe;
	if (!doc) return;
	xes = doc.xmlElements[0].evaluateXPathExpression(".//*");
	while ( xe = xes.pop() ) {
	xe.texts[0].isValid && !xe.texts[0].parentTextFrames.length && xe.remove();
	}
}
var u;
app.doScript("main();",u,u,UndoModes.ENTIRE_SCRIPT);