﻿var _xmlElement = app.activeDocument.xmlElements[0];
var _xmlPlaced = __isXMLElementPlaced(_xmlElement);
switch(_xmlPlaced) {
	case true :
		alert(_xmlElement.markupTag.name + " (or one of the children) placed");
		break;
	case false :
		alert(_xmlElement.markupTag.name + " not placed");
		break;
	default :
		alert("No valid XML Element.");
}
function __isXMLElementPlaced(_xmlElement) {
		
	if(!_xmlElement ||  !_xmlElement.isValid || !(_xmlElement instanceof XMLElement)) { 
		return null; 
	}
	var _xmlChildren;
	var _numOfXMLChildren;
	var _xmlChildPlaced;
	var i;
	
	if(_xmlElement.parentStory instanceof XmlStory && _xmlElement.xmlContent instanceof Text) {
		_xmlChildren = _xmlElement.xmlElements.everyItem().getElements();
		_numOfXMLChildren = _xmlChildren.length;
		for(i=0; i<_numOfXMLChildren; i++) {
			_xmlChildPlaced = __isXMLElementPlaced(_xmlChildren);
			if(_xmlChildPlaced === true) {
				return true;
			}
		}
		return false;
	} else {
		return true;
	}
} /* END function __isXMLElementPlaced */