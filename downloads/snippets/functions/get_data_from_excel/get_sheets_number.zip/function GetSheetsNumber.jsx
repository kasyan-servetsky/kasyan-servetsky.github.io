﻿var scriptName = "GetSheetsNumber";
var debug = true;

Main();

function Main() {
	var excelFilePath = "D:\\Ecclesall Print\\Christmas card project\\Schools\\Daily Snags 241023\\Daily Snags 241023.xlsm";
	var result = GetSheetsNumber(excelFilePath);
}

function GetSheetsNumber(excelFilePath) {
	try {
		var vbs = 'Public excelFilePath, SheetsNumber\r';
		vbs += 'Function CountSheets()\r';
		vbs += 'On Error Resume Next\r';
		vbs += 'Err.Clear\r';
		vbs += 'Set objExcel = CreateObject("Excel.Application")\r';
		vbs += 'Set objBook = objExcel.Workbooks.Open("' + excelFilePath + '")\r';
		vbs += 'objExcel.Visible = True\r';
		vbs += 'SheetsNumber = "" & objExcel.ActiveWorkbook.WorkSheets.Count\r';
		vbs += 'objBook.Close\r';
		vbs += 'Set objBook = Nothing\r';
		vbs += 'Set objExcel = Nothing\r';
		vbs += 'SetArgValue()\r';
		vbs += 'On Error Goto 0\r';
		vbs += 'End Function\r';
		vbs += 'Function SetArgValue()\r';
		vbs += 'Set objInDesign = CreateObject("InDesign.Application")\r';
		vbs += 'objInDesign.ScriptArgs.SetValue "sheetsNumber", SheetsNumber\r';
		vbs += 'End Function\r';
		vbs += 'CountSheets()\r';

		app.doScript(vbs, ScriptLanguage.VISUAL_BASIC, undefined, UndoModes.FAST_ENTIRE_SCRIPT);

		var str = app.scriptArgs.getValue("sheetsNumber");
		app.scriptArgs.clear();
		
		return  Number(str);
	}
	catch(err) {
		LogError("Error: " + err.message + ", function " + arguments.callee.toString().match(/function ([^\(]+)/)[1] + ", line: " + err.line);
		if (debug) $.writeln(err.message + ", function " + arguments.callee.toString().match(/function ([^\(]+)/)[1] + ", line: " + err.line);
	}
}

function LogError(text) {
	var file = new File("~/Desktop/" + scriptName + " - Error log.txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}

	file.write(GetDate() + "\r" + text + "\r==============================\r"); 
	file.close();
}

function GetDate() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}