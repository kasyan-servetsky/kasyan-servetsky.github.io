﻿Main();

function Main() {
	// [Required] The full path to the xlsx-file: either in POSIX format or HFS
	var excelFilePath = "Macintosh HD:My Folder:SampleBook.xlsx"; // HFS
	var excelFilePath = "/Users/kas/Library/CloudStorage/Dropbox/Mac/Documents/dummy_books.xlsx"; // POSIX
	
	var isPosix;
	// [Optional] true (default) -- if the path in POSIX format; false -- if HFS

	// [Optional] the character to use for splitting the rows in the spreadsheed.
	// If it isn't set, pipe (|) will be used by default	
	var splitCharRows = "|";
	
	// [Optional] the character to use for splitting the columns in the spreadsheed: e.g. semicolon (;) or tab (\t)
	// If it isn't set, semicolon will be used by default
	var splitCharColumns = ";";
	
	// [Optional] the worksheet number: either string or number. If it isn't set, the first worksheet will be used by default
	var sheetNumber = "1";
	
	// Returns an array in case of success; null -- if something went wrong: e.g. called on PC, too old version of InDesign.
	var data = GetDataFromExcelMac(excelFilePath, isPosix, splitCharRows, splitCharColumns, sheetNumber);
	// here, the only (first) required parameter is passed; for others, defaults are used
	var data = GetDataFromExcelMac(gExcelFilePath); 
}

function GetDataFromExcelMac(excelFilePath, isPosix, splitCharRows, splitCharColumns, sheetNumber) {
	if (File.fs != "Macintosh") return null;
	if (typeof isPosix === "undefined") isPosix = true;
	if (typeof splitCharRows === "undefined") splitCharRows = "|";
	if (typeof splitCharColumns === "undefined") splitCharColumns = ";";
	if (typeof sheetNumber === "undefined") sheetNumber = "1";

	var appVersion,
	appVersionNum = Number(String(app.version).split(".")[0]);
	
	switch (appVersionNum) {
		case 20:
			appVersion = "2025";
			break;
		case 19:
			appVersion = "2024";
			break;
		case 18:
			appVersion = "2023";
			break;
		case 17:
			appVersion = "2022";
			break;		
		case 16:
			appVersion = "2021";
			break;		
		case 15:
			appVersion = "2020";
			break;
		case 14:
			appVersion = "CC 2019";
			break;
		case 13:
			appVersion = "CC 2018";
			break;
		case 12:
			appVersion = "CC 2017";
			break;
		case 11:
			appVersion = "CC 2015";
			break;
		case 10:
			appVersion = "CC 2014";
			break;			
		case 9:
			appVersion = "CC";
			break;		
		case 8:
			appVersion = "CS 6";
			break;
		case 7:
			if (app.version.match(/^7\.5/) != null) {
				appVersion = "CS 5.5";
			}
			else {
				appVersion = "CS 5";
			}
			break;
		case 6:
			appVersion = "CS 4";
			break;
		case 5:
			appVersion = "CS 3";
			break;
		case 4:
			appVersion = "CS 2";
			break;
		case 3:
			appVersion = "CS";
			break;			
		default:
		return null;
	}

	var as = 'tell application "Microsoft Excel"\r';
	as += 'if (' + isPosix + ' is true) then\r';
	as += 'set excelFilePath to POSIX file \"' + excelFilePath + '\"\r';
	as += 'end if\r';
	as += 'open file excelFilePath\r';
	as += 'set theWorkbook to active workbook\r';
	as += 'set theSheet to sheet ' + sheetNumber + ' of theWorkbook\r';
	as += 'set theMatrix to value of used range of theSheet\r';
	as += 'set theRowCount to count theMatrix\r';
	as += 'set str to ""\r';
	as += 'set oldDelimiters to AppleScript\'s text item delimiters\r';
	as += 'repeat with countRows from 1 to theRowCount\r';
	as += 'set theRow to item countRows of theMatrix\r';
	as += 'set AppleScript\'s text item delimiters to \"' + splitCharColumns + '\"\r';
	as += 'set str to str & (theRow as string) & \"' + splitCharRows + '\"\r';
	as += 'end repeat\r';
	as += 'set AppleScript\'s text item delimiters to oldDelimiters\r';
	as += 'close theWorkbook saving no\r';
	as += 'end tell\r';
	as += 'tell application "Adobe InDesign ' + appVersion + '\"\r';
	as += 'tell script args\r';
	as += 'set value name "excelData" value str\r';
	as += 'end tell\r';
	as += 'end tell';
	
	if (appVersionNum > 5) { // CS4 and above
		app.doScript(as, ScriptLanguage.APPLESCRIPT_LANGUAGE, undefined, UndoModes.ENTIRE_SCRIPT);
	}
	else { // CS3 and below
		app.doScript(as, ScriptLanguage.APPLESCRIPT_LANGUAGE);
	}

	var str = app.scriptArgs.getValue("excelData");
	app.scriptArgs.clear();
	
	var tempArrLine, line,
	data = [],
	tempArrData = str.split(splitCharRows);
	
	for (var i = 0; i < tempArrData.length; i++) {
		line = tempArrData[i];
		if (line == "") continue;
		tempArrLine = line.split(splitCharColumns);
		data.push(tempArrLine);
	}
	
	return data;
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}

function GetRandomInt(max) {
	return Math.floor(Math.random() * Math.floor(max));
}

function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}