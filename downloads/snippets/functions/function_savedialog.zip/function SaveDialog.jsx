﻿myNewFile =  SaveDialog ("Name of New (Filtered) Swatch .ase File to Save" // The file save prompt --- Change as desired
                                              ,"Adobe swatch exchange files:*.ase" // The filter --- Change as desired
                                              , true) // OPTIONAL if true give warn on overwrite, defalt is FALSE 
 if (myNewFile)
    {
    myNewFile.open('w');
    myNewFile.close();
    }
 
function SaveDialog (myFilePromt, /* The file promt" */ Preset /* The desired suffix */, warning /* OPTIONAL if true give warn on overwrite, defalt is FALSE */)
           /* function by Trevor to apply a file filter for a Mac http://forums.adobe.com/message/4036767#4036767  */                  
    {
        var myFile = File.openDialog (myFilePromt, [Preset]);
        if (myFile)
            {
                var myFileName = myFile.name;
                var suffix = Preset.match(/[^.]*$/);
                var regSuffix = eval("/\." + suffix + "$/i");
                var regBaseName = /^[^.]*/;
                if (! regSuffix.test(myFileName)) myFile = File (myFile.path + "/" + myFileName += "." + suffix);        
                if (warning && myFile.exists) if (!confirm ("The file " + myFile.name + " exists, do want to overwrite it? ", false, "Comfirm Save")) SaveDialog (myFilePromt, [Preset], warning);
                return myFile;
            }
      }