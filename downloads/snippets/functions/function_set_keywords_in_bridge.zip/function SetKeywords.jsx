﻿main();

function main() {
	var sel = app.document.selections[0];
	var md = sel.metadata;
	var keywords = ["one", "two", "three"];
	SetKeywords(md, keywords);
}

function SetKeywords(metadata, keywords) { 
	var strTmpl = "TempTmpl"; 
	var strUser = Folder.userData.absoluteURI; 
	var filTmpl = new File(strUser + "/Adobe/XMP/Metadata Templates/" + strTmpl + ".xmp"); 
	var i = 0; 
	var fResult = false; 

try {
	if (filTmpl.exists) filTmpl.remove();
	fResult = filTmpl.open("w"); 
		if (fResult) {
			filTmpl.writeln("<x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"3.1.2-113\">"); 
			filTmpl.writeln(" <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">"); 
			filTmpl.writeln(" <rdf:Description rdf:about=\"\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\">"); 
			filTmpl.writeln(" <dc:subject>"); 
			filTmpl.writeln(" <rdf:Bag>");
			
			if (keywords != null) {
				for (i = 0; i < keywords.length; ++i) {
					filTmpl.writeln(" <rdf:li>", keywords[i], "</rdf:li>");
				}
			
				filTmpl.writeln(" </rdf:Bag>");
				filTmpl.writeln(" </dc:subject>");
				filTmpl.writeln(" </rdf:Description>");
				filTmpl.writeln(" </rdf:RDF>");
				filTmpl.writeln("</x:xmpmeta>");
				fResult = filTmpl.close();
				metadata.applyMetadataTemplate(strTmpl, "replace");
				filTmpl.remove();
			}
		}
	} 
	catch(e) {
		fResult = false;
	} 

	return fResult; 
}