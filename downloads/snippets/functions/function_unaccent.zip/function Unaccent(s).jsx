﻿function Unaccent(s) {
	return s.replace (/[_\x20]/g, "").
	replace (/[ÁÀÂÄÅĀĄĂÆ]/g, "A").
	replace (/[ÇĆČĊ]/g, "C").
	replace (/[ĎĐ]/g, "D").
	replace (/[ÉÈÊËĘĒĔĖĚ]/g, "E").
	replace (/[ĢĜĞĠ]/g, "G").
	replace (/[ĤĦ]/g, "H").
	replace (/[ÍÌÎÏĪĨĬĮİ]/g, "I").
	replace (/[Ĵ]/g, "J").
	replace (/[Ķ]/g, "K").
	replace (/[ŁĹĻĽ]/g, "L").
	replace (/[ÑŃŇŅŊ]/g, "N").
	replace (/[ÓÒÔÖŌŎŐØŒ]/g, "O").
	replace (/[ŔŘŖ]/g, "R").
	replace (/[ŚŠŜŞȘSS]/g, "S").
	replace (/[ŢȚŤŦ]/g, "T").
	replace (/[ÚÙÛÜŮŪŲŨŬŰŲ]/g, "U").
	replace (/[Ŵ]/g, "W").
	replace (/[ŸÝŶ]/g, "Y").
	replace (/[ŹŻŽ]/g, "Z");
}