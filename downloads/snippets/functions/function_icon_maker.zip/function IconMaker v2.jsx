﻿var scriptName = "My script - 1.0",
gTmpFileName = scriptName.replace(/\-\s\d+\.\d+$/, "").replace(/\s+/g, "_").toLowerCase(), // use script name without version; replace spaces with underscores
gTmpSubFolderName = "Kasyan";

Main();

function Main() {
	var iconBinReset = "\u0089PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\x14\x00\x00\x00\x14\b\x06\x00\x00\x00\u008D\u0089\x1D\r\x00\x00\x00\tpHYs\x00\x00\x0B\x13\x00\x00\x0B\x13\x01\x00\u009A\u009C\x18\x00\x00\x06\u00BEiTXtXML:com.adobe.xmp\x00\x00\x00\x00\x00<?xpacket begin=\"\u00EF\u00BB\u00BF\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?> <x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 7.1-c000 79.a8731b9, 2021/09/09-00:37:38        \"> <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"> <rdf:Description rdf:about=\"\" xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:photoshop=\"http://ns.adobe.com/photoshop/1.0/\" xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\" xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\" xmp:CreatorTool=\"Adobe Photoshop 22.5 (Windows)\" xmp:CreateDate=\"2022-02-17T08:23:36+02:00\" xmp:ModifyDate=\"2022-02-17T10:09:30+02:00\" xmp:MetadataDate=\"2022-02-17T10:09:30+02:00\" dc:format=\"image/png\" photoshop:ColorMode=\"3\" photoshop:ICCProfile=\"Adobe RGB (1998)\" xmpMM:InstanceID=\"xmp.iid:544ee920-4cda-6646-baa6-7edb9c0e5021\" xmpMM:DocumentID=\"adobe:docid:photoshop:c8774ef7-74f4-bc4f-a7c4-a4a0856a35a5\" xmpMM:OriginalDocumentID=\"xmp.did:1f6f5141-8461-414e-b95e-279858268f8e\"> <xmpMM:History> <rdf:Seq> <rdf:li stEvt:action=\"created\" stEvt:instanceID=\"xmp.iid:1f6f5141-8461-414e-b95e-279858268f8e\" stEvt:when=\"2022-02-17T08:23:36+02:00\" stEvt:softwareAgent=\"Adobe Photoshop 22.5 (Windows)\"/> <rdf:li stEvt:action=\"saved\" stEvt:instanceID=\"xmp.iid:d5ee5de3-dcd2-5944-9c5f-ceb7280a29eb\" stEvt:when=\"2022-02-17T10:08:12+02:00\" stEvt:softwareAgent=\"Adobe Photoshop 22.5 (Windows)\" stEvt:changed=\"/\"/> <rdf:li stEvt:action=\"saved\" stEvt:instanceID=\"xmp.iid:544ee920-4cda-6646-baa6-7edb9c0e5021\" stEvt:when=\"2022-02-17T10:09:30+02:00\" stEvt:softwareAgent=\"Adobe Photoshop 22.5 (Windows)\" stEvt:changed=\"/\"/> </rdf:Seq> </xmpMM:History> </rdf:Description> </rdf:RDF> </x:xmpmeta> <?xpacket end=\"r\"?>\u00EF\u009A\u0097B\x00\x00\x01.IDAT8\x11\u00AD\u00C1?nR\x01\x00\x07\u00E0/\u00C2\u00F3\x06N\f/u\x11\u00E8\t:9y\x01;iIpw\u00F0\x06\u00AE\u00A6\u00A6\x7F\u0088\u009B^\u00C0\u008Dn\x1A=\u00C2s\x11\u00B9\x05\x18:\u00B4I\x13\u0097\u009F\u008FHb\u00D3?\x01J\u00BF\u00CF-\x1E\u00E2\x15Np\u008E 8\u00C7\t\u00FA(\u00FC\u00F7\foQ\u00B8A\x0FS\x04\u00C1\x04\x15*L\x11\x04\x13\u00EC\u00F9\u00E73\u0082\u00B6+\x0E\x11\x04\u00EF\u00D0q]\x17\u00FB\b\u0082\u00D7\u00F8\u0088`\u00DB%\x1F\x10\u00FC\u00C4\x13\u00CB51D\u00F0\x07A\u00C7\u00C2.\u0082_hX\u00EE)>\u00E1\x0B\u0082 \u00D8Vk\u00E0\x14A\u00CBj\u00DE \b\u0082 \u00E8\u00A8\u00F5\x10\x1CZO\u0089\x12%J\u0094(\u00D4\u00BE#\u00D8rO.0s\u008F\u0082\u00CA\u0086\u0092Hb.\u00F8aCI$1w\u0081\u0099\u00CD=\u00C2\u008E\u00DA7\x04[\u00EE\u00EE1\u0082\u00AFj=\x04G\u00EE\u00EE\x18\u00C1K\u00B5\x06N\x11\u00B4\u00AC\u00AF\u0085`\u0086\x07\x16v\x11\u008C\u00D1\u00B4\u00BA&\u00C6\b\u009E\u00BBb\u0080`\u0084\u00B6\u00E5\u00DA\x18!\x18\u00B8\u00C5\x01\u0082`\x1F]\u00D7u\u00F1\x1EAp`\u0089=L\x10\x04ST\u00A8\u00F0\x1BA0\u00C1\x0B+*\u00D0\u00C7\x10g\b\u00823\f\u00D1G\u00E1\x06\x7F\x01\u00F8-r\u00F4G\x7F\x05t\x00\x00\x00\x00IEND\u00AEB`\u0082";
	var iconReset = IconMaker(iconBinReset, gTmpSubFolderName, gTmpFileName + "icon_reset"); // iconBin, tmpSubFolderName, imgFileName
}

function IconMaker(iconBin, tmpSubFolderName, imgFileName) {
	var iconFile = null;
	var tmpFolderPath = Folder.temp.absoluteURI + "/" + tmpSubFolderName +"/";
	var tmpFolder = new Folder(tmpFolderPath);
	if (!tmpFolder.exists) tmpFolder.create();
	iconFile = new File(tmpFolderPath + imgFileName + ".png");
	
	if (!iconFile.exists) {
		iconFile.encoding = "BINARY";
		iconFile.open("w");
		iconFile.write(iconBin);
		iconFile.close();
	}

	return iconFile;
}