﻿Main();

function Main() {
	var iconFile = new File("~/Desktop/triangle.png");
	
	if (iconFile.exists) {
		FileStringer(iconFile);
	}
}

function FileStringer( file ) {
	// read the image file
	file.encoding = "BINARY";
	file.open( "r" );
	var buf = file.read();
	file.close();
	// create an output file of the same name with the extension "txt"
	var outName = file.name.substr( 0, file.name.lastIndexOf( "." ) ) + ".txt";
	var outFile = new File( "~/Desktop/" + outName );
	outFile.open( "w" );
	// write the buffer to the text file using toSource(). The text in the file will be JSON, ready to copy and paste into your script
	outFile.write( buf.toSource() );
	outFile.close();
	// open the text file, copy the text in the file in a single line, paste it into your source code as a single line, something like this:
	// var myBinary = (newString("\u0089PNG\r\n\x\1\A\n\x00\x00\x00\riHDR\x00\x00\x00... ) );
	// it will be a very long string
}