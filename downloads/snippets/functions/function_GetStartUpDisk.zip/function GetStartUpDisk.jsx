// Written by Kasyan Servetsky

var myDisk = GetStartUpDisk();
alert("The name of my start up disk is \"" + myDisk + "\"");

function GetStartUpDisk() {
    if (File.fs == "Macintosh") {
        var myScript = 'tell application \"Finder\"\r'
        myScript += 'set myStartUpDisk to get name of startup disk\r';
        myScript += 'end tell\r';
        myScript += 'tell application \"Adobe InDesign CS' + ((parseInt(app.version.substr(0, 1)) - 2) + "") + '\"\r';
        myScript += 'tell script args\r';
        myScript += 'set value name \"myScriptArgument\" value myStartUpDisk\r';
        myScript += 'end tell\r';
        myScript += 'end tell\r';
        app.doScript(myScript, ScriptLanguage.applescriptLanguage);
        var myStartUpDisk = app.scriptArgs.getValue("myScriptArgument");
    }
    else if (File.fs == "Windows")  {
        var myStartUpDisk = String(Folder.system).charAt(1);
    }
    return myStartUpDisk;
}