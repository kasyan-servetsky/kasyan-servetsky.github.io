var myDoc = app.activeDocument;
removeFloppySymbols();

function removeFloppySymbols(){
	for(var myCounter = myDoc.paragraphStyles.length - 1; myCounter > 0; myCounter--){
		if (myDoc.paragraphStyles[myCounter].imported == true) {
			var myParProperties = myDoc.paragraphStyles[myCounter].properties;
			myDoc.paragraphStyles[myCounter].remove();
			var myNewParStyle = myDoc.paragraphStyles.add();
			myNewParStyle.properties = myParProperties;
		}
	} 

	for(var myCounter = myDoc.characterStyles.length - 1; myCounter > 0; myCounter--){
		if (myDoc.characterStyles[myCounter].imported == true) {
			var myCharProperties = myDoc.characterStyles[myCounter].properties;
			myDoc.characterStyles[myCounter].remove();
			var myNewCharStyle = myDoc.characterStyles.add();
			myNewCharStyle.properties = myCharProperties;
		}
	}
}