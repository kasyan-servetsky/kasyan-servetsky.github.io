﻿/* Table's Position
I've got a table within a text frame.
I'd like to my script to figure out the table's position (its x & y coordinates).
How do I do that?
https://adobe.ly/3DIsFmW
*/

/**
 * Gets the top left position of the selected table.
 * @author m1b
 * @discussion https://community.adobe.com/t5/indesign-discussions/table-s-position-amp-scripting/m-p/13555533
 */

function main() {

    var doc = app.activeDocument,
        selectedCell = getCell(app.selection[0]);

    if (
        selectedCell == undefined
        || !selectedCell.isValid
    ) {
        alert('Please select a table or inside a table and run script again.');
        return;
    }

    var table = selectedCell.parent;

    // get the first cell's bounds (change false to true if you want to include strokes)
    var bounds = getCellBounds(table.cells[0], false);

    // table position in points [x,y]
    var tablePosition = [bounds[1], bounds[0]];

    // draw a rectangle to match the bounds of the top left table cell
    var justForShowing = doc.rectangles.add({ geometricBounds: bounds, fillColor: doc.swatches[4] });

    alert('x: ' + tablePosition[0] + ' pts, y: ' + tablePosition[1] + ' pts');

}; // end main

app.doScript(main, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "Get Table Position Demo");


/**
 * Returns the geometricBounds of the cell;
 * @author m1b
 * @version 2023-02-06
 * @param {Cell} cell - an Indesign Table Cell.
 * @param {Boolean} [includeStroke] - whether to adjust bounds by strokeWidths (default: false).
 * @returns {Array<Number>}
 */
function getCellBounds(cell, includeStroke) {

    app.scriptPreferences.measurementUnit = MeasurementUnits.POINTS;

    if (!cell.hasOwnProperty('index'))
        throw Error('getCellBounds failed: bad cell parameter.');

    var cellIndex = cell.index,
        tableIndex = indexOf(cell.parent, cell.parent.storyOffset.parentTextFrames[0].tables),

        // duplicate the textframe because we are going to convert the cell
        dupTextFrame = cell.parent.storyOffset.parentTextFrames[0].duplicate(),
        dupCell = dupTextFrame.tables[tableIndex].cells[cellIndex];

    // convert cell to graphic, so we can get the bounds
    dupCell.convertCellType(CellTypeEnum.GRAPHIC_TYPE_CELL);
    var bounds = dupCell.rectangles[0].geometricBounds;

    // clean up
    dupTextFrame.remove();

    // add strokeWidths
    if (includeStroke === true) {
        bounds[0] -= cell.topEdgeStrokeWeight / 2;
        bounds[1] -= cell.leftEdgeStrokeWeight / 2;
        bounds[2] += cell.bottomEdgeStrokeWeight / 2;
        bounds[3] += cell.rightEdgeStrokeWeight / 2;
    }

    return bounds;

};


/**
 * Returns index of obj in arr.
 * Returns -1 if not found.
 * @param {any} obj
 * @param {Array} arr
 * @returns {Number}
 */
function indexOf(obj, arr) {
    for (var i = 0; i < arr.length; i++)
        if (arr[i] === obj)
            return i;
    return -1;
};


/**
 * Attempts to return a Cell, given an object.
 * @author m1b
 * @version 2023-02-06
 * @param {InsertionPoint|Text|Cells|Table} obj - an object related to a Cell.
 * @returns {Cell}
 */
function getCell(obj) {

    if (obj == undefined)
        return;

    if (obj.constructor.name == 'Cell')
        return obj;

    if (obj.parent.constructor.name == 'Cell')
        return obj.parent;

    if (
        obj.hasOwnProperty('cells')
        && obj.cells.length > 0
    )
        return obj.cells[0];

};