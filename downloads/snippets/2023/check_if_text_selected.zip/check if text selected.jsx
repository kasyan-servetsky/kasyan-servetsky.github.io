﻿function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	
	// check if text is selected and get the current story
	var msgWrongSelection = "One text frame or some text should be selected, or the cursor should be inserted into the text.";
	if (app.selection.length == 0 || app.selection.length > 1) ErrorExit(msgWrongSelection);
	var sel = app.selection[0];
		
	if (sel.constructor.name == "TextFrame") { // a text frame is selected
		story = sel.parentStory;
	}
	else if (sel.hasOwnProperty("baseline")) { // some text is selected or the cursor is placed in the text
		story = sel.parentStory;
	}
	else {
		ErrorExit(msgWrongSelection, true);
	}

	if (story == undefined || !story.isValid) ErrorExit("Can't find the selected story.", true);
	
	Main();
}