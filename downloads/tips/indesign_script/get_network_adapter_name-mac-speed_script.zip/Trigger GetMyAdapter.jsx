﻿// NOTE: GetMyAdapter.vbs should be in the same folder as this script
var activeScript = GetActiveScript();
app.doScript(File(activeScript.path+'/GetMyAdapter.vbs'), ScriptLanguage.visualBasic);
var myAdaptName = app.scriptArgs.getValue("myAdaptNameLink");
var myAdaptSpeed = app.scriptArgs.getValue("myAdaptSpeed");
var myAdapt = app.scriptArgs.getValue("myAdapt");
var myMAC = app.scriptArgs.getValue("myMAC");
alert ("myAdaptName: " + myAdaptName + " | myAdaptSpeed: " + myAdaptSpeed + " | myAdapt: " + myAdapt + "| myMAC: " + myMAC);

function GetActiveScript() {
    try {
        return app.activeScript;
    }
    catch(err) {
        return new File(err.fileName);
    }
}