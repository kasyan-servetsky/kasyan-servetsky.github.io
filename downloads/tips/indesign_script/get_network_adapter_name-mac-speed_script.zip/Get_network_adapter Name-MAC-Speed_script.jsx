﻿main(); 

function main() {
	callVbScript();
	var myAdaptName = app.scriptArgs.getValue("myAdaptNameLink");  
	var myAdaptSpeed = app.scriptArgs.getValue("myAdaptSpeed");  
	var myAdapt = app.scriptArgs.getValue("myAdapt");  
	var myMAC = app.scriptArgs.getValue("myMAC");  
	alert("myAdaptName: " + myAdaptName + " | myAdaptSpeed: " + myAdaptSpeed + " | myAdapt: " + myAdapt + "| myMAC: " + myMAC); 
}

function callVbScript() {
	var vbs = 'strComputer = "."\r';  
	vbs += 'Set objWMIService = GetObject("winmgmts:\\\\" & strComputer & "\\root\\cimv2")\r';  
	vbs += 'Set IPConfigSet = objWMIService.ExecQuery ("SELECT * FROM Win32_NetworkAdapterConfiguration WHERE IPEnabled = True")\r';  
	vbs += 'Set objWMI = GetObject("winmgmts:\\\\" & strComputer & "\\root\\WMI")\r';  
	vbs += 'Set AdaptInfo = objWMI.InstancesOf("MSNdis_LinkSpeed WHERE Active = True",48)\r';  
	vbs += 'For Each adaptInfo in AdaptInfo\r';  
	vbs += 'AdaptNameLink = AdaptNameLink & adaptInfo.InstanceName & vbNewLine\r';  
	vbs += 'AdaptSpeed = AdaptSpeed & adaptInfo.NdisLinkSpeed & vbNewLine\r';  
	vbs += 'Next\r';  
	vbs += 'For Each IPConfig in IPConfigSet\r';  
	vbs += 'If Not IsNull(IPConfig.Description) Then\r';  
	vbs += 'AdaptName = AdaptName + IPConfig.Description & vbNewLine\r';  
	vbs += 'End If\r';  
	vbs += 'If Not IsNull(IPConfig.MACAddress) Then\r';  
	vbs += 'MACadd = MACadd + IPConfig.MACAddress & vbNewLine\r';  
	vbs += 'End If\r';  
	vbs += 'Next\r';  
	vbs += 'app.scriptArgs.SetValue "myAdaptNameLink", AdaptNameLink\r';  
	vbs += 'app.scriptArgs.SetValue "myAdaptSpeed", AdaptSpeed\r';  
	vbs += 'app.scriptArgs.SetValue "myAdapt", AdaptName\r';  
	vbs += 'app.scriptArgs.SetValue "myMAC", MACadd\r';  

	app.doScript(vbs, ScriptLanguage.VISUAL_BASIC, undefined, UndoModes.FAST_ENTIRE_SCRIPT);  
}