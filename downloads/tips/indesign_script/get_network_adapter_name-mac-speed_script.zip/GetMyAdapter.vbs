﻿strComputer = "."
 
Set objWMIService = GetObject("winmgmts:\\" & strComputer & "\root\cimv2")
Set IPConfigSet = objWMIService.ExecQuery ("SELECT * FROM Win32_NetworkAdapterConfiguration WHERE IPEnabled = True")
 
Set objWMI = GetObject("winmgmts:\\" & strComputer & "\root\WMI") 
Set AdaptInfo = objWMI.InstancesOf("MSNdis_LinkSpeed WHERE Active = True",48)
 
For Each adaptInfo in AdaptInfo
    AdaptNameLink = AdaptNameLink & adaptInfo.InstanceName & vbNewLine
    AdaptSpeed = AdaptSpeed & adaptInfo.NdisLinkSpeed & vbNewLine
Next
 
For Each IPConfig in IPConfigSet
    If Not IsNull(IPConfig.Description) Then
        AdaptName = AdaptName + IPConfig.Description & vbNewLine
    End If
    If Not IsNull(IPConfig.MACAddress) Then
        MACadd = MACadd + IPConfig.MACAddress & vbNewLine
    End If
Next
 
app.scriptArgs.SetValue "myAdaptNameLink", AdaptNameLink
app.scriptArgs.SetValue "myAdaptSpeed", AdaptSpeed
app.scriptArgs.SetValue "myAdapt", AdaptName
app.scriptArgs.SetValue "myMAC", MACadd