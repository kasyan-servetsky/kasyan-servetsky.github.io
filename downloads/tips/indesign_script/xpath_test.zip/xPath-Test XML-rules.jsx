﻿var scriptName = "XML-rules test",
doc,
glueFile = new File(app.filePath + "/Scripts/xml rules/glue code.jsx"),
count = 0;

PreCheck();
app.doScript(glueFile, ScriptLanguage.JAVASCRIPT);
Main();

//===================================== FUNCTIONS  ======================================
function Main() {
	$.writeln("==================\r");
	var ruleSet = [new ProcessTag];
	with (doc) {
		var elements = xmlElements;
		try {
			__processRuleSet(elements[0], ruleSet);
		}
		catch(err) {
			$.writeln(err.message + ", line: " + err.line);
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessTag() {
	this.name = "ProcessTag";
	this.xpath = "/bookstore/book[last()]";
	this.apply = function(xmlElement, ruleProcessor) {
		ProcessAttributes(xmlElement);
		return true;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessAttributes(xmlElement) {
	count++;
	$.writeln(count + " - " + xmlElement.contents.substring(0, 30).replace(/\s+/g, " ") + "...");
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (!app.activeDocument.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (!glueFile.exists) ErrorExit("\"glue code.jsx\" should be located in the \"Scripts > xml rules\" folder for this script to work.", true);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}