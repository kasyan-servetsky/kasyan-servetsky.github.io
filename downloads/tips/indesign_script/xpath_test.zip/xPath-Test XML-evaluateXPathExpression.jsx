﻿var scriptName = "evaluateXPathExpression test",
doc;
Main();
//===================================== FUNCTIONS  ======================================
function Main() {
	var xmlElement;
	
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	
	var xmlRoot = doc.xmlElements[0];
	var xmlElements = xmlRoot.evaluateXPathExpression("/bookstore/book[last()]");

	if (xmlElements.length > 0) {
		$.writeln("==================\r");
	}
	else {
		$.writeln("No elements were found");
	}

	for (var i = 0; i < xmlElements.length; i++) {
		xmlElement = xmlElements[i];
		$.writeln((i + 1) + " - " + xmlElement.contents.substring(0, 30).replace(/\s+/g, " ") + "...");
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}