﻿var myDoc = app.documents.add();  
  
var myRectangle = myDoc.rectangles.add({geometricBounds:myDoc.pages[0].bounds}); 

myRectangle.ovals.add({geometricBounds:[0, 0,  100, 100], fillColor: "Yellow"});  
myRectangle.rectangles.add({geometricBounds:[0, 0, 75, 75], fillColor: "Magenta"}); 
myRectangle.polygons.add({geometricBounds:[0, 0,  48, 54], fillColor: "Yellow"});  
myRectangle.ovals.add({geometricBounds:[0, 0, 30, 30], fillColor: "Black"});
myRectangle.rectangles.add({geometricBounds:[0, 0, 15, 15], fillColor: "Cyan"});
  
// Should open the Layers Panel. If it will throw an error, the panel will not open
try {  
	app.panels.itemByName("$ID/#ImageLayersPanel").visible = true;  
} catch(e){};