﻿TextFrame.prototype.getPage = function()
// -----------------------------------------------
// Returns the containing Page of this TextFrame
// [Works also with grouped/embedded frame]
{
var p = this.parent,
	b = this.visibleBounds,
	x = (b[3]+b[1])/2,
	y = (b[0]+b[2])/2,
	pc = p.constructor,
	pgs, i;

if( pc == Page ) return p;

while( true )
	{
	if( pc == Page )
		{
		pgs = p.parent.pages; // spread pages
		for( i=pgs.length-1 ; i>=0 && p=pgs[i] ; --i )
			{
			b = p.bounds;
			if( x>=b[1] && x<=b[3] && y>=b[0] && y<=b[2] ) return p;
			}
		pc = Spread;
		}
	if( pc == Spread || pc == MasterSpread )
		throw Error("The textframe is placed on a spread!");
	if( 'parentTextFrames' in p && !(p=p.parentTextFrames[0]) )
		throw Error("The textframe's container overflows!");
	pc = (p=p.parent).constructor;
	}
}

function createReportItem(/*Word*/w, /*TextFrame[2]*/tf)
{
var p1,p2,
	ips=w.insertionPoints,i=ips.length-1,
	fid = tf[1].id;

try {
	p1 = tf[0].getPage();
	p2 = tf[1].getPage();
	}
catch(_){}

if( !p1 || !p2 || p1.id == p2.id ) return false;

while( i && fid == ips[i].parentTextFrames[0].id ) --i;
if( i<=0 ) return false;
(w=w.contents.split('')).splice(1+i,0,'/');

return "Pages [" + p1.name + "-" + p2.name + "] : " + w.join('');
}


Application.prototype.main = function()
{
if( !this.documents.length ) return;

var doc = this.activeDocument,
	stories = doc.stories,
	s = stories.length,
	tcs, t, tf, w,
	report = [];

while( s-- )
	{
	// skip the story if it's entirely contained in ONE textFrame
	if( (t=(tcs=stories[s].textContainers).length) < 2 ) continue;
	
	// ignore the last container
	--t;
	
	// check every last word
	while( t-- )
		{
		if( (w=tcs[t].words[-1]).parentTextFrames.length < 2 ) continue;
		if(! (w = createReportItem(w,[tcs[t],tcs[t+1]])) ) continue;
		report.unshift(w);
		}
	}
if( report.length ) alert( report.join('\r') );
}

app.main();