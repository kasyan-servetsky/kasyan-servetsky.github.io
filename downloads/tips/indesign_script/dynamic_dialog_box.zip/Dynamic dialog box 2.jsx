﻿var scriptName = "Dynamic dialog box 2.0",
set,
docsFolder = imgsFolder = null;

CreateDialog();
//=================================== FUNCTIONS =========================================
function CreateDialog() {
	GetDialogSettings();
	var w = new Window("dialog", scriptName);
	// Documents folder
	w.p = w.add("panel", undefined, "Documents folder:");
	w.p.alignment = "fill";
	w.p.st = w.p.add("statictext");
	if (docsFolder == null || !docsFolder.exists) { 
		w.p.st.text = "No folder has been selected";
	}
	else {
		w.p.st.text = TrimPath(docsFolder.absoluteURI);
		w.p.st.helpTip = docsFolder.fsName;
	}
	w.p.bt = w.p.add("button", undefined, "Select...");
	w.p.bt.onClick = function() {
		docsFolder = SelectFolder(this, "Pick a folder with documents.");
	}
	// Images folder
	w.p1 = w.add("panel", undefined, "Images folder:");
	w.p1.alignment = "fill";
	w.p1.st = w.p1.add("statictext");
	if (imgsFolder == null || !imgsFolder.exists) { 
		w.p1.st.text = "No folder has been selected";
	}
	else {
		w.p1.st.text = TrimPath(imgsFolder.absoluteURI);
		w.p1.st.helpTip = imgsFolder.fsName;
	}
	w.p1.bt = w.p1.add("button", undefined, "Select...");
	w.p1.bt.onClick = function() {
		imgsFolder = SelectFolder(this, "Pick a folder with images.");
	}
	// Buttons
	w.g = w.add("group");
	w.g.orientation = "row";   
	w.g.alignment = "center";
	w.g.ok = w.g.add("button", undefined, "OK", {name: "ok" });
	w.g.ok.onClick = function() { // Use 'children[0]' because the panel is dynamically rebuilt on selecting a new folder so the original references become invalid
		if ((w.p.children[0].text == "No folder has been selected" || docsFolder == null) && (w.p1.children[0].text == "No folder has been selected" || imgsFolder == null)) {
			alert("Neither 'Documents' nor 'Images' folders have been selected.", scriptName, true);
			return;			
		}
		else if (w.p.children[0].text == "No folder has been selected" || docsFolder == null) {
			alert("No 'Documents' folder has been selected.", scriptName, true);
			return;			
		}
		else if (w.p1.children[0].text == "No folder has been selected" || imgsFolder == null) {
			alert("No 'Images' folder has been selected.", scriptName, true);
			return;			
		}
		else if (docsFolder.absoluteURI == imgsFolder.absoluteURI) {
			alert("The 'Documents' and 'Images' folders should not be the same.", scriptName, true);
			return;				
		}
		else { // everythin's OK
			w.close(1);
		}
	}

	w.g.cancel = w.g.add("button", undefined, "Cancel", {name: "cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		with (set) {	
			docsFolderPath = (docsFolder != null) ? docsFolder.absoluteURI : "";
			imgsFolderPath = (imgsFolder != null) ? imgsFolder.absoluteURI : "";
		}
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}	
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function SelectFolder(button, prompt) {
	var folder = Folder.selectDialog(prompt);
	
	if (folder != null) {
		var panel = button.parent;
		var window = panel.parent;
		var children = panel.children;
		var staticText = children[0];
		var button = button;
		panel.remove(staticText);
		panel.remove(button);
		staticText = panel.add("statictext", undefined, TrimPath(folder.absoluteURI));
		staticText.helpTip = folder.absoluteURI;
		button = panel.add("button", undefined, "Select...");
		button.onClick = function() {
			SelectFolder(this);
		}
		window.layout.layout(true);
		return folder;		
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function TrimPath(path) {
	var theFile = new File(path);
	if (File.fs == "Macintosh") {
		var trimPath = "..." + theFile.fsName.split("/").splice(-3).join("/");
	}
	else if (File.fs == "Windows" ) {
		var trimPath = ((theFile.fsName.split("/").length > 3) ? ".../" : "") + theFile.fsName.split("/").splice(-3).join("/");
	}
	return trimPath;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {docsFolderPath: "", imgsFolderPath: ""};
	}

	docsFolder = new Folder(set.docsFolderPath);
	if (!docsFolder.exists) {
		docsFolder = null;
	}

	imgsFolder = new Folder(set.imgsFolderPath);
	if (!imgsFolder.exists) {
		imgsFolder = null;
	}

	return set;
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	$.writeln("Called Main");
}