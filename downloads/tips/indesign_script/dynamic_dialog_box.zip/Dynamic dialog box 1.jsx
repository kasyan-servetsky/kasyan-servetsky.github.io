// Globals
const gScriptName = "Dynamic dialog box";
const gScriptVersion = "1.0";
var gSet, gGraphicsFolder;
//=======================================================================================

Main() ;

//=================================== FUNCTIONS =========================================
function Main() {
	
	if (app.extractLabel("Kas_" + gScriptName + "_" + gScriptVersion) != "") {
		gSet = eval(app.extractLabel("Kas_" + gScriptName + "_" + gScriptVersion));
		gGraphicsFolder = new Folder(gSet.graphicsFolder);
	}
	else {
		gSet = {}
	}

	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	var win = new Window("dialog", gScriptName + " - " + gScriptVersion);

	var folderPanel = win.add("panel", undefined, "Graphics folder:");
	folderPanel.alignment = "fill";
	var stTxt = folderPanel.add("statictext");
	if (gGraphicsFolder == undefined || !gGraphicsFolder.exists) {
		stTxt.text = "No folder has been selected";
	}
	else {
		stTxt.text = TrimPath(gGraphicsFolder.fsName);
		stTxt.helpTip = gGraphicsFolder.fsName;
	}
	var button = folderPanel.add("button", undefined, "Select...", {name:"set"});
	button.onClick = SelectFolder;
	
	function SelectFolder() {
		gGraphicsFolder = Folder.selectDialog("Pick a folder with graphics");
		if (gGraphicsFolder != null) {
			folderPanel.remove(stTxt);
			folderPanel.remove(button);
			stTxt = folderPanel.add("statictext");
			stTxt.text = TrimPath(gGraphicsFolder.fsName);
			stTxt.helpTip = gGraphicsFolder.fsName;
			button = folderPanel.add("button", undefined, "Select...", {name:"set"});
			button.onClick = SelectFolder;
			win.layout.layout(true);
		}
	}
	
	var okCancelGroup = win.add("group");
	okCancelGroup.orientation = "row";
	var okBtn = okCancelGroup.add("button", undefined, "Ok", {name:"ok"});
	var cancelBtn = okCancelGroup.add("button", undefined, "Cancel", {name:"cancel"});

	var dialogResult = win.show();
	
	if (dialogResult== 1) {
		if (stTxt.text == "No folder has been selected" || gGraphicsFolder == undefined) ErrorExit("No graphics folder has been selected.", true);
		if (!gGraphicsFolder.exists)  ErrorExit("Folder '" + gGraphicsFolder.displayName + "' doesn't exist.", true);
			gSet.graphicsFolder = gGraphicsFolder.fsName;
			app.insertLabel("Kas_" + gScriptName + "_" + gScriptVersion, gSet.toSource());
	}
	else {
		exit();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function TrimPath(path) {
	var theFile = new File(path);
	if (File.fs == "Macintosh") {
		var trimPath = "..." + theFile.fsName.split("/").splice(-3).join("/");
	}
	else if (File.fs == "Windows" ) {
		var trimPath = ((theFile.fsName.split("\\").length > 3) ? "...\\" : "") + theFile.fsName.split("\\").splice(-3).join("\\");
	}
	return trimPath;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------