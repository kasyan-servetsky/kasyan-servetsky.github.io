﻿#targetengine "Kasyan"

var eventListener = app.addEventListener("afterOpen", setViewOptions, false);    

function setViewOptions() {
	try {
		with (app.windows[0]) {
			viewTab = ViewTabs.LAYOUT_VIEW;
			screenMode = ScreenModeOptions.PREVIEW_TO_PAGE;
		}
	
		var doc = app.documents[0];
		doc.guidePreferences.guidesShown = false;
		doc.viewPreferences.showRulers = false;
	
		if(doc.windows[0].activePage.appliedMaster == null) {
			doc.windows[0].activeSpread = doc.spreads[0];
		}
	}
	catch(err) {
		//$.writeln(err.message + ", line: " + err.line);
	}
}