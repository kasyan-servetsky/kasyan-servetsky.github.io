﻿var listenerHotFolder = function( event ) {  
	// IMPORTANT: $.hiresTimer > 180000 this will make sure to trigger only once on cached folders like the hot folder, because when a file is detected it trigers twice (start building cache and finishing building cache).  
	if ( event.object instanceof Document && event.type == 'loaded' && $.hiresTimer > 180000) {  
		// only works if the active folder name is "hotFolder" case sensitive  
		if (app.document.thumbnail.name.toLowerCase() == "hotfolder") {  
			var myFiles_array = [];  
			// if doesn't exist, creates a subfolder to move the active processing files  
			var processingFolder = Folder(app.document.presentationPath + "\\processing");  
			if (!processingFolder.exists) processingFolder.create();  
			// You can change the image kind you want to deal with, or other file kind  
			var items = Folder(app.document.presentationPath).getFiles( function(f) { return (f instanceof File && f.name.toLowerCase().match(/\.psd|png|jpe?g$/) != null);}); // JPG | CR2 | DNG  
			for (var a=0 ; a < items.length ; a++) {  
				var copied = File(decodeURI(items[a])).copy( File(File(decodeURI(items[a])).path + "/processing/" + File(decodeURI(items[a])).name ) );  
				if (copied) {  
					$.writeln(File(File(decodeURI(items[a])).path + "/processing/" + File(decodeURI(items[a])).name).fsName)  
					myFiles_array.push(File(File(decodeURI(items[a])).path + "/processing/" + File(decodeURI(items[a])).name).fsName);  
					File(decodeURI(items[a])).remove();  
				}  
			}  
			app.document.thumbnail.refresh();  
			// if files were dropped on the hotFolder, and were collected, any script can be running on each file.  
			if (myFiles_array.length > 0) {  
				for (var a=0 ; a < myFiles_array.length ; a++) { 
					//===========================================================================
					// Here begins the sample code
					createBridgeTalkMessage(myFiles_array[a]);
					
					function createBridgeTalkMessage(jpegFilePath) {
						var bt = new BridgeTalk();
						bt.target = "photoshop";
						var script = "resaveAsTif = " + resaveAsTif.toSource() + "\r";
						script += "resaveAsTif(\"" + jpegFilePath + "\");";
						bt.body = script;
						bt.send(100);
					}

					function resaveAsTif(jpegFilePath) {
						var jpegFile = new File(jpegFilePath);
						var folderPath = "~/Desktop/New Photos/";   
						var folder = new Folder(folderPath);
						if (!folder.exists) folder.create();
						app.displayDialogs = DialogModes.NO;
						var doc = app.open(jpegFile);
						var tifFile = new File(folderPath + doc.name.toLowerCase().replace(/\.psd|png|jpe?g$/, "tif"));
						tiffSaveOptions = new TiffSaveOptions();
						tiffSaveOptions.byteOrder = ByteOrder.IBM;
						tiffSaveOptions.imageCompression = TIFFEncoding.TIFFLZW;
						tiffSaveOptions.layers = false;
						doc.saveAs(tifFile, tiffSaveOptions, true, Extension.LOWERCASE);
						doc.close(SaveOptions.DONOTSAVECHANGES);
						app.displayDialogs = DialogModes.ALL;	
					}
					// END of the sample code
					//===========================================================================
				}  
			}  
		}  
		//  
		return {  
			// FALSE + block last path repetition  »»  só repete o evento numa numa pasta (não repete em F5 ou em cache rebuild) Resumo: sá actua se navegar numa nova pasta  
			// TRUE  + block last path repetition  »»  repete em várias situações: numa nova pasta, ao criar/apagar ficheiros/pastas no folder activo, ao reordenar a primeira vez (qd cria a primeira vez o file invisivel .bridgesort)  
			handled:true  
		}  
	}  
}  
app.eventHandlers.push( {handler: listenerHotFolder} );