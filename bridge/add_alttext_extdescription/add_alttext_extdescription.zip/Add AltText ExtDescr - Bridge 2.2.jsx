﻿/* Copyright 2024, Kasyan Servetsky
January 6, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Add Alt Text and Extended Description",
menuId = "kas_" + scriptName.replace(/\s+/g, "_"),
logCount,
log = true,
logOverwrite = true,
debug = false;

if (!debug) {
	var menu = MenuElement.find(menuId);
	
	if (menu != null) {
		alert("Error: Menu element already exists!\nRestart Bridge to run this script again.");
	}
	else {
		CreateMenuElement();
	}
}
else { // debug
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	try {
		app.synchronousMode = true;
		logCount = 0; // global - reset every time the script is run. It's in the Main function because of the persistent engine in Bridge
		
		var csvFile, row, fileName, altText, extDesc, index, thumbnail, 
		doc = app.documents[0],
		visibleThumbnails = doc.visibleThumbnails,
		visibleThumbnailsLength = doc.visibleThumbnailsLength,
		allFilesList = [];

		for (var f = 0; f < visibleThumbnailsLength; f++) {
			allFilesList.push(visibleThumbnails[f].name);
		}

		if (debug) {
			csvFile = new File("~/Desktop/AltText ExtDescrAccessibility.csv");
		}
		else {
			 if (File.fs == "Macintosh") {
				csvFile = File.openDialog("Select a CSV File", function (f) { return (f instanceof Folder) || f.name.match(/\.csv$/i);} );  
			 } else {  
				csvFile = File.openDialog("Select a CSV File","CSV files:*.csv;All files:*.*");  
			 }  
		}

		if (csvFile != null) {
			var fileArray = ReadInCSV(csvFile);

			for (var i = 0; i < fileArray.length; i++) {
				row = fileArray[i];

				fileName = row[0];
				altText = row[1];
				extDesc = row[2];
				
				index = GetArrayIndex(allFilesList, fileName, extDesc);
				
				if (index != -1) {
					thumbnail = visibleThumbnails[index];
					ApplyMetadata(thumbnail, altText, extDesc);
				}
			}
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ApplyMetadata(thumbnail, altText, extDesc) {
	try {
		if (xmpLib == undefined) { // Load the XMP Script library
			var pathToLib = (Folder.fs == "Windows") ? Folder.startup.fsName + "/AdobeXMPScript.dll" : Folder.startup.fsName + "/AdobeXMPScript.framework";
			var libfile = new File(pathToLib);  
			var xmpLib = new ExternalObject("lib:" + pathToLib);  
		}

		var md = thumbnail.synchronousMetadata;
		var xmp = new XMPMeta(md.serialize()); // Get the XMP packet as a string and create the XMPMeta object
		
		xmp.setLocalizedText(XMPConst.NS_IPTC_CORE, "AltTextAccessibility", null, "x-default", altText);
		xmp.setLocalizedText(XMPConst.NS_IPTC_CORE, "ExtDescrAccessibility", null, "x-default", extDesc);
		
		Log(thumbnail.name + " - Applied: Alt Text '" + altText + "' and Extended Description '" + extDesc + "'", false);		
		 
		var updatedPacket = xmp.serialize(XMPConst.SERIALIZE_OMIT_PACKET_WRAPPER | XMPConst.SERIALIZE_USE_COMPACT_FORMAT);
		thumbnail.metadata = new Metadata(updatedPacket);
	}
	catch(err) { 
		Log(err.message + ", line: " + err.line + " in ApplyMetadata", true);
	}
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------
function GetArrayIndex(arr, val) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] == val) {
			return i;
		}
	}
	return -1;
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------
function ReadInCSV(file) {
     var thisLine, csvArray,
	 fileArray = [];
	 
     file.open("r");
     file.seek(0, 0);
	 
     while (!file.eof) {
		thisLine = file.readln();
		csvArray = thisLine.split(";");
		fileArray.push(csvArray);
     }
 
     file.close();  

     return fileArray;  
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Log(text, err) {
	if (log) {
		if (typeof err == "undefined") err = false;
		if (typeof logOverwrite == "undefined") logOverwrite = false;

		var file = new File("~/Desktop/" + scriptName + " - " + ((err) ? "Error " : "") + "Log.txt");
		
		if (logOverwrite && logCount == 0) {
			if (file.exists) file.remove();
		}
	
		if (logCount == 0) { // add header before the first error during a session
			text = ((file.exists) ? "\r" : "") + "========== " + new Date().toLocaleString() + " ==========\r" + text;
		}

		file.encoding = "UTF-8";

		if (file.exists) {
			file.open("e");
			file.seek(0, 2);
		}
		else {
			file.open("w");
		}

		file.write(text + "\r"); 
		file.close();
		
		logCount++;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateMenuElement() {
	var menuElement = MenuElement.create("command", scriptName, "at the end of Tools", menuId);
	menuElement.onSelect = function() {
		Main();
	}
}