﻿/* Copyright 2024, Kasyan Servetsky
January 5, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Apply Alt Text or Extended Description",
debug = false, // for debugging only
doc, set;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var graphic, container,
		allGraphics = doc.allGraphics;
		
		for (var i = 0; i < allGraphics.length; i++) {
			graphic = allGraphics[i];
			container = graphic.parent;
			
			if (set.rbSelected == 0) {
				container.objectExportOptions.altTextSourceType = SourceType.SOURCE_XMP_ALT_TEXT;
			}
			else {
				container.objectExportOptions.altTextSourceType = SourceType.SOURCE_XMP_EXTENDED_DESCRIPTION;				
			}
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	GetDialogSettings();
	var w = new Window("dialog", scriptName);
	
	w.p = w.add("panel", undefined, "Apply");
	w.p.orientation = "column";
	w.p.alignment = "fill";
	w.p.alignChildren = "left";
	
	w.p.g = w.p.add("group");
	w.p.g.orientation = "column";
	w.p.g.alignChildren = "left";
	w.p.g.rb = w.p.g.add("radiobutton", undefined, "Alt Text");
	w.p.g.rb1 = w.p.g.add("radiobutton", undefined, "Extended Description");
	
	if (set.rbSelected == 0) {
		w.p.g.rb.value = true;
	}
	else {
		w.p.g.rb1.value = true;
	}

	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok"});
	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		if (w.p.g.rb.value) {
			set.rbSelected = 0;
		}
		else {
			set.rbSelected = 1;
		}
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}	
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {rbSelected: 0};
	}

	return set;
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	var appVersion = Number(String(app.version).split(".")[0]);
	if (appVersion < 19) ErrorExit("This script is for InDesign 2024 (version 19) or above.", true);	
	
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];

	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}