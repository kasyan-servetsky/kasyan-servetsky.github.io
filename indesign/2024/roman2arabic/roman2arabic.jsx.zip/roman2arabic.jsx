﻿/* Version 1.0
May 30, 2024
function roman2arabic was written by Kenshi Muto.
The rest was done by Kasyan Servetsky.
*/

var scriptName = "roman2arabic",
doc;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var foundItem, romanNum, arabicNum;
		
		app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
		app.findGrepPreferences.findWhat = "\\b[I|V|X|L|C|D|M]+\\b";
		var foundItems = doc.findGrep(true);
		
		for (var i = 0; i < foundItems.length; i++) {
			foundItem = foundItems[i];
			romanNum = foundItem.contents;
			arabicNum = String(roman2arabic(romanNum));
			foundItem.contents = arabicNum;
		}
	
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function roman2arabic(s)
{
  var i = 0;
  var v = 0;
  var n, c;
  s = s.toLowerCase();
  if (s.charAt(i) == "m") {
    for (n = 0; s.charAt(i) == "m"; n++) i++;
    if (n > 4) return 0;
    v += n * 1000;
  }
  if (s.charAt(i) == "d" || s.charAt(i) == "c") {
    if ((c = s.charAt(i)) == "d") {
      i++;
      v += 500;
    }
    if (c == "c" && s.charAt(i + 1) == "m") {
      i += 2;
      v += 900;
    } else if (c == "c" && s.charAt(i + 1) == "d") {
      i += 2;
      v += 400;
    } else {
      for (n = 0; s.charAt(i) == "c"; n++) i++;
      if (n > 4) return 0;
      v += n * 100;
    }
  }
  if (s.charAt(i) == "l" || s.charAt(i) == "x") {
    if ((c = s.charAt(i)) == "l") {
      i++;
      v += 50;
    }
    if (c == "x" && s.charAt(i + 1) == "c") {
      i += 2;
      v += 90;
    } else if (c == "x" && s.charAt(i + 1) == "l") {
      i += 2;
      v += 40;
    } else {
      for (n = 0; s.charAt(i) == "x"; n++) i++;
      if (n > 4) return 0;
      v += n * 10;
    }
  }
  if (s.charAt(i) == "v" || s.charAt(i) == "i") {
    if ((c = s.charAt(i)) == "v") {
      i++;
      v += 5;
    }
    if (c == "i" && s.charAt(i + 1) == "x") {
      i += 2;
      v += 9;
    } else if (c == "i" && s.charAt(i + 1) == "v") {
      i += 2;
      v += 4;
    } else {
      for (n = 0; s.charAt(i) == "i"; n++) i++;
      if (n > 4) return 0;
      v += n;
    }
  }
  return (s.charAt(i) == "" && v >= 1 && v <= 4999) ? v : 0;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}