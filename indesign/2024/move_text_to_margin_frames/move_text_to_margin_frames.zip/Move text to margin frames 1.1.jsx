﻿/* Copyright 2024, Kasyan Servetsky
September 10, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com  */
//======================================================================================
var scriptName = "Move text to margin frames - 1.1",
debug = false,
doc, set, objStyleApply, allObjStyles, allObjStyleNames;

//~ PreCheck();
app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");

//===================================== FUNCTIONS ======================================
function Main() {
	var startTime = new Date(),
	count = 0;
	
	var foundItem;
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = ((set.multiline) ? "(?s)" : "") + "\\s?" + set.openingTag + set.textBetweenTags + set.closingTag;
	var foundItems = doc.findGrep(true);
	var foundItemsCount = foundItems.length;
	if (foundItemsCount == 0) ErrorExit("Nothing was found.", true);
	
	progressWin = new Window("window", scriptName);
	progressBar = progressWin.add("progressbar" , undefined, 0, foundItemsCount);
	progressBar.preferredSize.width = 400;
	progressTxt = progressWin.add("statictext", undefined,  "");
	progressTxt.alignment = "fill";
	progressWin.show();
	
	for (var i = 0; i < foundItemsCount; i++) {
		foundItem = foundItems[i];
		progressBar.value = i + 1;
		progressTxt.text = (i + 1) + " out of " + foundItemsCount;
		MakeBox(foundItem);
		count++;
	}

	progressWin.close();

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	
	var endTime = new Date(),
	duration = GetDuration(startTime, endTime),
	report = count + " item" + ((count == 1) ? " was" : "s were") + " processed.\n(time elapsed: " + duration + ")";
	alert("Finished. " + report, scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeBox(foundItem) {
    var ip = foundItem.insertionPoints[0].index;
    var tf = foundItem.parentStory.insertionPoints[ip].textFrames.add();
    tf.applyObjectStyle(allObjStyles[set.objStyleApply[0]], true);
	setWidthHeight(tf, "28mm", "15mm");
	foundItem.move(LocationOptions.AT_BEGINNING, tf.texts[0]);
	CleanUp(tf.texts[0]);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CleanUp(txt) {
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	
	app.findGrepPreferences.findWhat = set.openingTag; // remove opening tag
	app.changeGrepPreferences.changeTo = "";
	var changed = txt.parentStory.changeGrep();
	
	app.findGrepPreferences.findWhat = set.closingTag; // remove closing tag
	changed = txt.parentStory.changeGrep();
	
	app.findGrepPreferences.findWhat = "^\\s+"; // remove space(s) at the end of a paragraph
	changed = txt.parentStory.changeGrep();
	
	app.findGrepPreferences.findWhat = "\\s+$"; // remove space(s) at the end of a paragraph
	changed = txt.parentStory.changeGrep();
	
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;	
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	GetDialogSettings();
	var w = new Window("dialog", scriptName);
	
	w.p = w.add("panel", undefined, "");
	w.p.orientation = "column";
	w.p.alignment = "fill";
	w.p.alignChildren = "right";

	// Find tag
	w.p.g = w.p.add("group");
	w.p.g.orientation = "row";	

	w.p.g.et = w.p.g.add("edittext", undefined, set.openingTag);
	w.p.g.et.preferredSize.width = 150; // width of the opening tag
	w.p.g.et.onChange = function() {
		if (this.text == "") {
			alert("The \"Opening tag\" text field should not be empty.", "Error", true);
			this.text = String(set.openingTag);
		}
	}
	w.p.g.et.helpTip = "Opening tag";
	
	w.p.g.et1 = w.p.g.add("edittext", undefined, set.textBetweenTags);
	w.p.g.et1.preferredSize.width = 150; // width of the text between tags
	w.p.g.et.onChange = function() {
		if (this.text == "") {
			alert("The \"Text between tags\" text field should not be empty.", "Error", true);
			this.text = String(set.textBetweenTags);
		}
	}
	w.p.g.et1.helpTip = "Text between tags";

	w.p.g.et2 = w.p.g.add("edittext", undefined, set.closingTag);
	w.p.g.et2.preferredSize.width = 150; // width of the closing tag
	w.p.g.et2.onChange = function() {
		if (this.text == "") {
			alert("The \"Closing tag\" text field should not be empty.", "Error", true);
			this.text = String(set.closingTag);
		}
	}
	w.p.g.et2.helpTip = "Closing tag";

	// Apply object style
	w.p.g1 = w.p.add("group");
	w.p.g1.orientation = "row";
	
	w.p.g1.st = w.p.g1.add("statictext", undefined, "Apply object style:");
	w.p.g1.ddl = w.p.g1.add("dropdownlist", undefined, allObjStyleNames);
	w.p.g1.ddl.preferredSize.width = 150;
	w.p.g1.ddl.selection = set.objStyleApply[0];
	w.p.g1.ddl.helpTip = "Apply this object style to the margin frames";	
	
	w.p.cb = w.p.add("checkbox", undefined, "Multiline");
	w.p.cb.value = set.multiline;
	w.p.cb.alignment = "left";
	w.p.cb.helpTip = "Set multiline on/off";

	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok"});
	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		set.openingTag = w.p.g.et.text;
		set.textBetweenTags = w.p.g.et1.text;
		set.closingTag = w.p.g.et2.text;		
		set.objStyleApply = [w.p.g1.ddl.selection.index, w.p.g1.ddl.selection.text];
		set.multiline = w.p.cb.value;
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}	
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {
					openingTag: "<",
					textBetweenTags: ".+?",
					closingTag: ">",
					multiline: true,
					objStyleApply: [0, "[None]"]
				};
	}

	if (allObjStyleNames[set.objStyleApply[0]] != set.objStyleApply[1]) {
		set.objStyleApply[0] = 0;
	}

	if (debug) var tmp = set;

	return set;
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	allObjStyles = doc.allObjectStyles;
	allObjStyleNames = [];
	for (var i = 0; i < allObjStyles.length; i++) {
		allObjStyleNames.push(allObjStyles[i].name);
	}
	
	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
// This function was borrowed from Marc Autret
function setWidthHeight(/*PageItem*/o, /*str*/w, /*str*/h, /*bool=false*/useVisibleBounds)
{
    if( !o.resize ) return;
    
    var CS_INNER = CoordinateSpaces.INNER_COORDINATES,
        BB = BoundingBoxLimits[(useVisibleBounds?'OUTER_STROKE':'GEOMETRIC_PATH') + '_BOUNDS'];
    
    var wPt = UnitValue(w).as('pt'),
        hPt = UnitValue(h).as('pt');
    
    if( 0 >= wPt || 0 >= hPt ) return;
    
    o.resize(
        [CS_INNER,BB],
        AnchorPoint.CENTER_ANCHOR,
        ResizeMethods.REPLACING_CURRENT_DIMENSIONS_WITH,
        [wPt,hPt,CS_INNER]
        );
}