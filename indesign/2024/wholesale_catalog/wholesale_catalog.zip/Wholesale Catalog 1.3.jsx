﻿/* Copyright 2024, Kasyan Servetsky
January 17, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Wholesale Catalog 1.3",
debug = false, // for debugging only
log = false,
logOverwrite = true,
logCount = 0, 
logErrCount = 0,
count = 0,
doc, parStTableBody;

PreCheck();
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var item, partNumber, price,
		data = NormalizeData();
		
		var progressWin = new Window("window", scriptName);
		var progressBar = progressWin.add("progressbar" , undefined, 0, data.length);
		progressBar.preferredSize.width = 600;
		var progressTxt = progressWin.add("statictext", undefined,  "");
		progressTxt.alignment = "fill";
		progressWin.show();
		
		var startTime = new Date();   
		
		for (var i = 0; i < data.length; i++) {
			item = data[i];
			partNumber = item[0];
			price = item[1];
			progressBar.value = (i + 1);
			progressTxt.text = "Updating price for part #" +  partNumber + " (" + (i + 1) + " out of " + data.length + ")";
			Log(i + " - partNumber = " + partNumber +  ", price = " + price);
			UpdatePrice(partNumber, price);
		}
		
		progressWin.close();
		var endTime = new Date();
		var duration = GetDuration(startTime, endTime);
		var report = count + " price" + ((count == 1) ? " was" : "s were") + " created.\n(time elapsed: " + duration + ")";
		alert(report, scriptName);
	}
	catch(err) {
		Log("ERROR: " + err.message + ", line: " + err.line, true);
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function UpdatePrice(partNumber, price) {
	try {
		app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
		app.findTextPreferences.findWhat = partNumber;
		app.findTextPreferences.appliedParagraphStyle = parStTableBody;
		
		var foundItems = doc.findText();

		if (foundItems.length > 0) {
			var foundItem = foundItems[0];
			var table =  foundItem.parent.parent;
			var cellPartNumber = foundItem.parent;
			var row = cellPartNumber.rows[0];
			var headerRowCont = table.rows[0].contents.toString();
			var matchPrice = headerRowCont.match(/List Price/g);
//~ 			debugger;
			
			if (matchPrice != null) {
				if (matchPrice.length == 1) { // last column
					var cellPrice = row.cells[row.cells.length - 1];
				}
				else if (matchPrice.length > 1) { // next column
					var cellPrice = row.cells.nextItem(cellPartNumber);
				}
			
				cellPrice.contents = "$" + price;
				cellPrice.insertionPoints[1].contents = SpecialCharacters.THIN_SPACE;
				Log("\tcellPrice.contents = " + cellPrice.contents);
				count++;		
			
			}
		}

		app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
	}
	catch(err) {
		Log("ERROR: " + err.message + ", line: " + err.line, true);
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function NormalizeData() {
	var row, partNumber, price,
	normData = [];
	
	if (debug) {
		var excelFile = new File("~/Desktop/Catalog Price Import.xlsx");
	}
	else {
		var excelFile = File.openDialog("Select an Excel File","Excel File(*.xlsx):*.xlsx;");
	}

	if (excelFile == null) exit();
	var excelFilePath = excelFile.fsName.replace(/\\/g, "\\\\");
	var splitChar = ";";
	var sheetNumber = "1";
	var rawData = GetDataFromExcelPC(excelFilePath, splitChar, sheetNumber);

	for (var i = 0; i < rawData.length; i++)  {
		row = rawData[i];
		partNumber = row[0];
		price = row[1];

		if (partNumber.match(/Part Number/i != null)) continue; // skip the header
		
		if (partNumber == "" || price == "") {
			Log("SKIP: empty cells: " + partNumber + " | " + price);
			continue; // skip empty cells
		}
		
		if (isNaN(price.replace(",", "."))) {
			Log("SKIP: price is not number: " + price);
			continue; // skip if second cell isn't a number
		}

		price = Number(price.replace(",", "."));
		price = RoundString(price, 2);
//~ 		price = price.replace(".", ",");
		
		if (price.match(/^\./) != null) {
			price = "0" + price;
		}

		if (price.match(/,\d{2}$/) == null) {
			if (price.match(/,\d{1}$/) != null) {
				price = price + "0";
			}
		}

		normData.push([partNumber, price]);
	}
	
	return normData;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDataFromExcelPC(excelFilePath, splitChar, sheetNumber) {
	try {
		if (typeof splitChar === "undefined") var splitChar = ";";
		if (typeof sheetNumber === "undefined") var sheetNumber = "1";
		var appVersionNum = Number(String(app.version).split(".")[0]),
		data = [];

		var vbs = 'Public s, excelFilePath\r';
		vbs += 'Function ReadFromExcel()\r';
		vbs += 'On Error Resume Next\r';
		vbs += 'Err.Clear\r';
		vbs += 'Set objExcel = CreateObject("Excel.Application")\r';
		vbs += 'Set objBook = objExcel.Workbooks.Open("' + excelFilePath + '")\r';
		vbs += 'Set objSheet =  objExcel.ActiveWorkbook.WorkSheets(' + sheetNumber + ')\r';
		vbs += 's = s & "[" & objSheet.Name & "]"\r';
		vbs += 'objExcel.Visible = True\r';
		vbs += 'matrix = objSheet.UsedRange\r';
		vbs += 'maxDim0 = UBound(matrix, 1)\r';
		vbs += 'maxDim1 = UBound(matrix, 2)\r';
		vbs += 'For i = 1 To maxDim0\r';
		vbs += 'For j = 1 To maxDim1\r';
		vbs += 'If j = maxDim1 Then\r';
		vbs += 's = s & matrix(i, j)\r';
		vbs += 'Else\r';
		vbs += 's = s & matrix(i, j) & "' + splitChar + '"\r';
		vbs += 'End If\r';
		vbs += 'Next\r';
		vbs += 's = s & vbCr\r';
		vbs += 'Next\r';
		vbs += 'objBook.Close\r';
		vbs += 'Set objSheet = Nothing\r';
		vbs += 'Set objBook = Nothing\r';
		vbs += 'Set objExcel = Nothing\r';
		vbs += 'SetArgValue()\r';
		vbs += 'On Error Goto 0\r';
		vbs += 'End Function\r';
		vbs += 'Function SetArgValue()\r';
		vbs += 'Set objInDesign = CreateObject("InDesign.Application")\r';
		vbs += 'objInDesign.ScriptArgs.SetValue "excelData", s\r';
		vbs += 'End Function\r';
		vbs += 'ReadFromExcel()\r';

		if (appVersionNum > 5) { // CS4 and above
			app.doScript(vbs, ScriptLanguage.VISUAL_BASIC, undefined, UndoModes.FAST_ENTIRE_SCRIPT);
		}
		else { // CS3 and below
			app.doScript(vbs, ScriptLanguage.VISUAL_BASIC);
		}

		var str = app.scriptArgs.getValue("excelData");
		app.scriptArgs.clear();
		
		var tempArrLine, line, match, name,
		tempArrData = str.split("\r");
		
		for (var i = 0; i < tempArrData.length; i++) {
			line = tempArrData[i];
			if (line == "") continue;
			
			match = line.match(/^\[.+\]/);
			
			if (match != null) {
				name = match[0].replace(/\[|\]/g, "");
				line = line.replace(/^\[.+\]/, "");
			}
			
			tempArrLine = line.split(splitChar);
			data.name = name;
			data.push(tempArrLine);
		}
		
		return data;
	}
	catch(err) {
		Log("ERROR: " + err.message + ", line: " + err.line, true);
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (File.fs == "Macintosh") ErrorExit("This script is for Windows only.", true);
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	parStTableBody = doc.paragraphStyles.itemByName("Table Body");
	if (!parStTableBody.isValid) ErrorExit("Paragraph style 'Table Body' is missing in the current document.", true);

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function RoundString(numVal, decimals) {
    var retVal = Math.round(numVal * Math.pow(10,decimals)) + "";
    retVal = retVal.substring(0,retVal.length-decimals) + "." + retVal.substring(retVal.length-decimals);
    return retVal;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Log(text, err) {
	if (log) {
		if (typeof err == "undefined") err = false;
		if (typeof logOverwrite == "undefined") logOverwrite = false;

		var file = new File("~/Desktop/" + scriptName + " - " + ((err) ? "Error " : "") + "Log.txt");
		
		if (logOverwrite && logCount == 0) {
			if (file.exists) file.remove();
		}
	
		if ((!err && logCount == 0) || (err && logErrCount == 0)) { // add header before the first error during a session
			text = ((file.exists) ? "\r" : "") + "========== " + new Date().toLocaleString() + " ==========\r" + text;
		}

		file.encoding = "UTF-8";

		if (file.exists) {
			file.open("e");
			file.seek(0, 2);
		}
		else {
			file.open("w");
		}

		file.write(text + "\r"); 
		file.close();
		
		if (err) {
			logErrCount++;
		}
		else {
			logCount++;
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}