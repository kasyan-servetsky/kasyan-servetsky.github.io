#target indesign

function isPrime(n) {
    if (n <= 1 || (n > 2 && n % 2 === 0)) return false;
    for (var i = 3; i <= Math.sqrt(n); i += 2) if (n % i === 0) return false;
    return true;
}

function getRedColorAndNotPrimeStyle(doc) {
    // Check for or create a blue color and NotPrime character style
    var blueColor = doc.colors.itemByName("Not Prime Blue");
    if (!blueColor.isValid) blueColor = doc.colors.add({name: "Not Prime Blue", colorValue: [100, 0, 0, 0]});
    
    var notPrimeStyle = doc.characterStyles.itemByName("NotPrime");
    if (!notPrimeStyle.isValid) notPrimeStyle = doc.characterStyles.add({name: "NotPrime", fillColor: blueColor});
    
    return notPrimeStyle;
}

function applyNotPrimeStyleInText(textRange, notPrimeStyle) {
    // Apply NotPrime style to all non-prime numbers in the specified text range
    app.findGrepPreferences.findWhat = '\\b\\d+\\b';
    var foundItems = textRange.findGrep();
    for (var i = 0; i < foundItems.length; i++) {
        var number = parseInt(foundItems[i].contents, 10);
        if (!isPrime(number)) {
            foundItems[i].applyCharacterStyle(notPrimeStyle);
        }
    }
}

function highlightNotPrimeNumbers() {
    app.scriptPreferences.enableRedraw = false;
    var scope = "the entire document"; // Default scope if nothing is selected
    
    try {
        var doc = app.activeDocument;
        var notPrimeStyle = getRedColorAndNotPrimeStyle(doc);
        var selection = app.selection;

        // Check if multiple text frames are selected
        var textFrameCount = 0;
        for (var i = 0; i < selection.length; i++) {
            if (selection[i].constructor.name === "TextFrame") {
                textFrameCount++;
            }
        }
        if (textFrameCount > 1) {
            alert("Please select text, a single text frame, or nothing for document-wide processing.");
            return;
        }

        if (selection.length === 0) {
            // If nothing is selected, process the entire document
            for (var i = 0; i < doc.stories.length; i++) {
                applyNotPrimeStyleInText(doc.stories[i], notPrimeStyle);
            }
        } else {
            var sel = selection[0];
            if (sel.constructor.name === "TextFrame") {
                // Case: a single text frame is selected
                applyNotPrimeStyleInText(sel.parentStory, notPrimeStyle);
                scope = "the text frame content";
            } else if (sel.hasOwnProperty("insertionPoints")) {
                // Case: cursor is placed within text or a single line of text is selected
                applyNotPrimeStyleInText(sel, notPrimeStyle);
                scope = "the selected text";
            } else if (sel.hasOwnProperty("contents")) {
                // Case: specific text is selected
                applyNotPrimeStyleInText(sel.texts[0], notPrimeStyle);
                scope = "the selected text";
            } else {
                alert("Invalid selection for this script.");
                return;
            }
        }
        
        alert("All non-prime numbers have been highlighted with the NotPrime style in " + scope + "!");
    } catch (error) {
        alert("Error: " + error);
    } finally {
        app.findGrepPreferences.findWhat = '';
        app.scriptPreferences.enableRedraw = true;
    }
}

app.doScript(highlightNotPrimeNumbers, ScriptLanguage.JAVASCRIPT, [], UndoModes.ENTIRE_SCRIPT, "Highlight Not Prime Numbers with NotPrime Style");
