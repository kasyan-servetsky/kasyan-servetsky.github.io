#target indesign

function isPrime(n) {
    if (n <= 1 || (n > 2 && n % 2 === 0)) return false;
    for (var i = 3; i <= Math.sqrt(n); i += 2) if (n % i === 0) return false;
    return true;
}

function getRedColorAndPrimeStyle(doc) {
    // Check for or create a red color and prime character style
    var redColor = doc.colors.itemByName("Prime Red");
    if (!redColor.isValid) redColor = doc.colors.add({name: "Prime Red", colorValue: [0, 100, 100, 0]});
    
    var primeStyle = doc.characterStyles.itemByName("Prime");
    if (!primeStyle.isValid) primeStyle = doc.characterStyles.add({name: "Prime", fillColor: redColor});
    
    return primeStyle;
}

function highlightPrimeNumbersInText(textRange, primeStyle) {
    // Highlight only prime numbers in the specified text range
    app.findGrepPreferences.findWhat = '\\b\\d+\\b';
    var foundItems = textRange.findGrep();
    for (var i = 0; i < foundItems.length; i++) {
        var number = parseInt(foundItems[i].contents, 10);
        if (isPrime(number)) foundItems[i].applyCharacterStyle(primeStyle);
    }
}

function highlightPrimeNumbers() {
    app.scriptPreferences.enableRedraw = false;
    var scope = "the entire document"; // Default scope if nothing is selected
    
    try {
        var doc = app.activeDocument;
        var primeStyle = getRedColorAndPrimeStyle(doc);
        var selection = app.selection;

        // Check if multiple text frames are selected
        var textFrameCount = 0;
        for (var i = 0; i < selection.length; i++) {
            if (selection[i].constructor.name === "TextFrame") {
                textFrameCount++;
            }
        }
        if (textFrameCount > 1) {
            alert("Please select text, a single text frame, or nothing for document-wide processing.");
            return;
        }

        if (selection.length === 0) {
            // If nothing is selected, process the entire document
            for (var i = 0; i < doc.stories.length; i++) {
                highlightPrimeNumbersInText(doc.stories[i], primeStyle);
            }
        } else {
            var sel = selection[0];
            if (sel.constructor.name === "TextFrame") {
                // Case: a single text frame is selected
                highlightPrimeNumbersInText(sel.parentStory, primeStyle);
                scope = "the text frame content";
            } else if (sel.hasOwnProperty("insertionPoints")) {
                // Case: cursor is placed within text or a single line of text is selected
                highlightPrimeNumbersInText(sel, primeStyle);
                scope = "the selected text";
            } else if (sel.hasOwnProperty("contents")) {
                // Case: specific text is selected
                highlightPrimeNumbersInText(sel.texts[0], primeStyle);
                scope = "the selected text";
            } else {
                alert("Invalid selection for this script.");
                return;
            }
        }
        
        alert("Prime numbers have been highlighted in " + scope + "!");
    } catch (error) {
        alert("Error: " + error);
    } finally {
        app.findGrepPreferences.findWhat = '';
        app.scriptPreferences.enableRedraw = true;
    }
}

app.doScript(highlightPrimeNumbers, ScriptLanguage.JAVASCRIPT, [], UndoModes.ENTIRE_SCRIPT, "Highlight Prime Numbers");
