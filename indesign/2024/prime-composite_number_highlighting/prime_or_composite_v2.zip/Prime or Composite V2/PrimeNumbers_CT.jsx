#target indesign

(function () {

    function addCondition(name, color) {
        // Remove existing condition if it exists
        if (app.documents[0].conditions.item(name).isValid) {
            app.documents[0].conditions.item(name).remove();
        }
        // Create and return a new condition
        return app.documents[0].conditions.add({
            name: name,
            indicatorColor: color,
            indicatorMethod: ConditionIndicatorMethod.USE_HIGHLIGHT,
        });
    }

    function isPrime(n) {
        if (n <= 1 || (n > 2 && n % 2 === 0)) return false;
        for (var i = 3; i <= Math.sqrt(n); i += 2) {
            if (n % i === 0) return false;
        }
        return true;
    }

    function highlightPrimeNumbers() {
        var condition = addCondition('Prime', [255, 0, 0]); // Red color for prime
        app.findGrepPreferences = app.changeGrepPreferences = null;
        app.findGrepPreferences.findWhat = '\\b\\d+\\b'; // Find all numbers
        
        var foundItems = app.activeDocument.findGrep();
        for (var i = 0; i < foundItems.length; i++) {
            var number = parseInt(foundItems[i].contents, 10);
            if (isPrime(number)) {
                foundItems[i].appliedConditions = [condition]; // Apply the condition
            }
        }

        alert("All prime numbers have been highlighted using the Prime condition!");
    }

    // Execute the highlighting function
    highlightPrimeNumbers();

})();
