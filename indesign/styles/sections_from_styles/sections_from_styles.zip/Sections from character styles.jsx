﻿var kAppVersion = parseFloat(app.version);
if ( app.documents.length < 1 )
	exit();
var doc=app.documents[0];

var allCharacterStyles =doc.allCharacterStyles;
var allCharacterStyleNames = [];
for (var w = 0; w < allCharacterStyles.length; w++) {
	allCharacterStyleNames.push(allCharacterStyles[w].name);
}

var d = app.dialogs.add( {name: "Sections from character styles", canCancel: true} );
d.dialogColumns.add().staticTexts.add( {staticLabel: "Character style:"} );
var characterStyleDD = d.dialogColumns.add().dropdowns.add( {stringList: allCharacterStyleNames, selectedIndex: 0} );
if ( !d.show() ){
	d.destroy();
	exit();
	}
var selectedCharStyle = allCharacterStyles[characterStyleDD.selectedIndex];
d.destroy();

ResetFindPrefs();

if(kAppVersion<5){
	app.findPreferences.appliedCharacterStyle = selectedCharStyle;
}
else{app.findTextPreferences.appliedCharacterStyle = selectedCharStyle}
for ( var i = 0; i < doc.pages.length; i++ ){
	var page = doc.pages[i];
	for ( var j = 0; j < page.textFrames.length; j++ ){
		try{
			if(kAppVersion<5){
				var myFinds = page.textFrames.item(j).search ("", false, false, undefined);
				}
			else{var myFinds = page.textFrames.item(j).findText()}
			if ( myFinds < 1 ){continue}
			else{
				var marker = myFinds[0].contents;
				var curSec = doc.pages.item(i).appliedSection;
				var name = curSec.name
				if ( curSec.pageStart == doc.pages.item(i) ){
					curSec.marker = marker;
					}
				else if(kAppVersion<4){
					doc.sections.add( LocationOptions.after, curSec, {pageStart: doc.pages.item(i), marker: marker , name: name} );
					}
				else{doc.sections.add({pageStart: doc.pages.item(i), marker: marker, name: name })}
				break;
			}
		} catch (e) {}
	}
}

function ResetFindPrefs(){
	if(kAppVersion<5){app.findPreferences = app.changePreferences = null}
	else{app.findTextPreferences = null;ResetFindChangeOptions();}
	}

function ResetFindChangeOptions(){
	app.findChangeTextOptions.properties = app.findChangeGrepOptions.properties = {
		includeLockedStoriesForFind:false,
		includeLockedLayersForFind:false,
		includeHiddenLayers:false,
		includeMasterPages:false,
		includeFootnotes:false,
		wholeWord:false,
		caseSensitive:false
		}
	}
