﻿var kAppVersion = parseFloat(app.version);
if ( app.documents.length < 1 ){exit()}
var doc = app.activeDocument;

var allParagraphStyles =doc.allParagraphStyles;
var allParagraphStyleNames = [];
for (var w = 0; w < allParagraphStyles.length; w++) {
	allParagraphStyleNames.push(allParagraphStyles[w].name);
}

var d = app.dialogs.add( {name: "Sections from paragraph styles", canCancel: true} );
d.dialogColumns.add().staticTexts.add( {staticLabel: "Paragraph style:"} );
var paragraphStyleDD = d.dialogColumns.add().dropdowns.add( {stringList: allParagraphStyleNames, selectedIndex: 0} );
if(!d.show()){d.destroy();exit()}
var selectedParStyle = allParagraphStyles[paragraphStyleDD.selectedIndex];
d.destroy();

for ( var i = 0; i < doc.pages.length; i++ ){
	for ( var j = 0; j < doc.pages.item(i).textFrames.length; j++ ){
		var aps, pc;
		
		with ( doc.pages.item(i).textFrames.item(j).paragraphs ){
			if ( length < 1 )
				continue;
			else {
				aps = [].concat( everyItem().appliedParagraphStyle );
				pc = [].concat( everyItem().contents );
			}
		}

		for ( var k = 0; k < aps.length; k++ ){
			if ( aps[k] == selectedParStyle ) {
				var marker = (pc[k] + "").replace( /\s+$/, "" );
				var curSec = doc.pages.item(i).appliedSection;
				var name = curSec.name;
				
				if ( curSec.pageStart == doc.pages.item(i) ){
					curSec.marker = marker;
				}else if(kAppVersion < 4){
					doc.sections.add( LocationOptions.after, curSec, {pageStart: doc.pages.item(i), marker: marker , name: name} );
				}else{
					doc.sections.add({pageStart: doc.pages.item(i), marker: marker , name: name } );
				}
				break;
			}
		}
	}
}