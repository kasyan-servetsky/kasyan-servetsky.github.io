﻿try {
	app.activeDocument.sections.itemByRange(1,-1).remove();
}
catch(err) {
	$.writeln(err.message + ", line: " + err.line);
}