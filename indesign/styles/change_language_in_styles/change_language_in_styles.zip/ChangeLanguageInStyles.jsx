﻿//(c) Eugenyus, 2010-2019, v.1.01

var myDoc = app.activeDocument;
var ParStyles = myDoc.paragraphStyles;
var ParStyleG = myDoc.paragraphStyleGroups;
var CharStyles = myDoc.characterStyles;


var myStylesCount = ParStyles.length + CharStyles.length;
if (ParStyleG.length > 0){
	for (i=0;i<ParStyleG.length;i++){
		myStylesCount += ParStyleG[i].paragraphStyles.length;
		}
	}



var myMaximumValue = 400;
var myProgressBarWidth = 400;
var myIncrement = myMaximumValue/myProgressBarWidth;
var myComment = "Стартуем";
var i = j =k = i1 = 0;
myCreateProgressPanel(400, 400, myComment);


var lang_find = myDoc.languages;
var lang_change = app.languagesWithVendors;
var myDialog = app.dialogs.add ({name:"Change Language In Styles. (c) Eugenyus, 2010-2019, v.1.01, eugenyusbudantsev@gmail.com", canCancel:true});
with (myDialog.dialogColumns.add()){
	var stText = staticTexts.add({staticLabel:"Find Language:"});
	var stText = staticTexts.add({staticLabel:"Change To Language:"});
}

with (myDialog.dialogColumns.add()){
	var myFLang = dropdowns.add({stringList:lang_find.everyItem().name, selectedIndex:0});
	var myCLang = dropdowns.add({stringList:lang_change.everyItem().name, selectedIndex:0});
	var pStyles = checkboxControls.add({staticLabel:"Paragraph Styles", checkedState:1});
	var cStyles = checkboxControls.add({staticLabel:"Character Styles", checkedState:1});
	var cText = checkboxControls.add({staticLabel:"Replace also throughout the text", checkedState:1});
	}

if (!myDialog.show()){exit();}
	var LF = myFLang.selectedIndex;
	var LC = myCLang.selectedIndex;
		myProgressPanel.show();
		var prstat = 0;
		var spisok = "Paragraph Styles:\r";
		var kolvozam = 0;
	if (pStyles.checkedState){
for (i = 1; i<ParStyles.length; i++){
	prstat = 400*i/myStylesCount;
	myProgressPanel.text = 'ParStyle: ' + app.activeDocument.paragraphStyles[i].name;
    myProgressPanel.myProgressBar.value = prstat/myIncrement;
	if (app.activeDocument.paragraphStyles[i].appliedLanguage.name == lang_find[LF].name){
		app.activeDocument.paragraphStyles[i].appliedLanguage = lang_change[LC];
		spisok += String(app.activeDocument.paragraphStyles[i].name) + "\r";
		kolvozam++;
		} //if
	}// for i
schet = 0;
for (j = 0; j<app.activeDocument.paragraphStyleGroups.length; j++){
	for (k = 0; k<app.activeDocument.paragraphStyleGroups[j].paragraphStyles.length; k++){
		schet++;
	prstat = 400*(i+j+k)/myStylesCount;
	myProgressPanel.text = 'ParStyle: ' + app.activeDocument.paragraphStyleGroups[j].name + ': ' +app.activeDocument.paragraphStyleGroups[j].paragraphStyles[k].name;
	myProgressPanel.myProgressBar.value = prstat/myIncrement;
		if (app.activeDocument.paragraphStyleGroups[j].paragraphStyles[k].appliedLanguage.name == lang_find[LF].name){
			app.activeDocument.paragraphStyleGroups[j].paragraphStyles[k].appliedLanguage = lang_change[LC];
			spisok += String(app.activeDocument.paragraphStyleGroups[j].name) + ": " + String(app.activeDocument.paragraphStyleGroups[j].paragraphStyles[k].name) + "\r";
			kolvozam++;
			} //if
		} // for k
	} // for j
} // if pStyles
if (cStyles.checkedState){
	spisok += "\rCharacter Styles:\r";
for (i1 = 1; i1<app.activeDocument.characterStyles.length; i1++){
    prstat = myProgressBarWidth/(myStylesCount-i-schet-i1);
	myProgressPanel.text = 'CharStyle: ' + app.activeDocument.characterStyles[i1].name;
	myProgressPanel.myProgressBar.value = 400*(i+j+k+i1)/myStylesCount;
	if (app.activeDocument.characterStyles[i1].appliedLanguage != null && app.activeDocument.characterStyles[i1].appliedLanguage.name == lang_find[LF].name){
		app.activeDocument.characterStyles[i1].appliedLanguage = lang_change[LC];
		spisok += String(app.activeDocument.characterStyles[i1].name) + "\r";
		kolvozam++;
		} //if
	}// for i
} // if cStyles
var txtReplLen = 0;
if (cText.checkedState){
	
	myProgressPanel.text = 'Replace in text';
	myProgressPanel.myProgressBar.value = prstat/myIncrement;
	app.findTextPreferences = app.changeTextPreferences = null;
    app.findGrepPreferences = app.changeGrepPreferences = null;

    app.findChangeTextOptions.caseSensitive = false
    app.findChangeTextOptions.includeFootnotes = true
    app.findChangeTextOptions.includeHiddenLayers = false
    app.findChangeTextOptions.includeLockedLayersForFind = true
    app.findChangeTextOptions.includeLockedStoriesForFind = true
    app.findChangeTextOptions.includeMasterPages = true
    app.findChangeTextOptions.wholeWord = false
	app.findTextPreferences.appliedLanguage = lang_find[LF];
	app.changeTextPreferences.appliedLanguage = lang_change[LC];
	var ftrez = app.activeDocument.findText ();
	app.activeDocument.changeText ();
	kolvozam += ftrez.length;
	txtReplLen = ftrez.length;
	app.findTextPreferences = app.changeTextPreferences = null;
	} // if cText
switch (kolvozam){
	case 0: alert ("Not found in any style and throughout the text",lang_find[LF].name+" -- "+lang_change[LC].name); break;
	case txtReplLen: alert ("Not found in styles, replaced in text " + String(txtReplLen) + " times",lang_find[LF].name+" -- "+lang_change[LC].name); break;
	default: alert ("Found and replaced in styles:\r" + spisok+"\r Replacements in text:  " + String(txtReplLen),lang_find[LF].name+" -- "+lang_change[LC].name);
	}

myProgressPanel.hide();
var MDLG = app.dialogs.add ({name:"Change Language in Styles. (c) Eugenyus, 2010-2016, eugenyusbudantsev@gmail.com", canCancel:true});
with (MDLG.dialogColumns.add()){
	var stText = staticTexts.add({staticLabel:"Completed. Replace again?"});
	}
if (MDLG.show()) {app.doScript(app.activeScript);} else {exit();}
function myCreateProgressPanel(myMaximumValue, myProgressBarWidth, myComment){
myProgressPanel = new Window('window', myComment);
with(myProgressPanel){
myProgressPanel.myProgressBar = add('progressbar', [12, 12,myProgressBarWidth, 24], 0, myMaximumValue);
myProgressPanel.text = myComment;
}

}