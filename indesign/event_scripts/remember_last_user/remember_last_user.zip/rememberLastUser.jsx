﻿#targetengine "Kasyan"

var eventListener = app.addEventListener("beforeSave", rememberLastUser, false);     

function rememberLastUser(event) {
	try {
		var doc = event.parent;
		doc.metadataPreferences.author = app.userName;
	}
	catch(err) {}
} 