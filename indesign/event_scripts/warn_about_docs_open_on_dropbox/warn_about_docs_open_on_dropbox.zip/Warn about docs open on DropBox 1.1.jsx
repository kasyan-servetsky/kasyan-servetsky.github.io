﻿#targetengine "kasyan"

var eventListenerOpen = app.addEventListener("afterOpen", createTxtFile);
var eventListenerClose = app.addEventListener("beforeClose", deleteTxtFile);
var userName = (app.userName != "Unknown User Name") ? app.userName : "unknown user";

function createTxtFile(event) {
	try {
		var doc = event.parent;
		var txtFilePath = decodeURI(doc.fullName.absoluteURI.replace(/indd$/i, "txt"));
		
		if (txtFilePath.match(/Dropbox/) != null) {
			var txtFile = new File(txtFilePath);
			txtFile.encoding = "UTF-8";
			
			if (!txtFile.exists) {
				txtFile.open("w");
				txtFile.write(userName);
				txtFile.close();
			}
			else {
				txtFile.open("r"); 
				var userNameSaved = txtFile.read();
				txtFile.close();
				
				if (userNameSaved != userName) {
					alert("File '" + txtFilePath + "' is already open by " + userNameSaved, "Warning!");
				}
			}
		}
	}
	catch(err) {}
}

function deleteTxtFile(event) {
	try {
		var doc = event.parent;
		var txtFilePath = decodeURI(doc.fullName.absoluteURI.replace(/indd$/i, "txt"));
		
		if (txtFilePath.match(/Dropbox/) != null) {
			var txtFile = new File(txtFilePath);
			
			if (txtFile.exists) {
				txtFile.open("r"); 
				var userNameSaved = txtFile.read();
				txtFile.close();
				
				if (userNameSaved == userName) {
					txtFile.remove();
				}
			}
		}
	}
	catch(err) {}
}