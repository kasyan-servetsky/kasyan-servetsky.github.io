﻿var charStyleDD, charStylesDD;

if(app.documents.length != 0){
	if(app.activeDocument.stories.length != 0){
		displayDialog();
	}else{
		alert("The current document contains no text. Please open a document containing text and try again.");
	}
} else{
	alert("No documents are open. Please open a document and try again.");
}

function displayDialog(){ 
        var myRange; 
        var myDialog = app.dialogs.add({name:"Character style to hyperlinks 1.1",canCancel:true}); 
        
        //create the dialog
        
        with(myDialog.dialogColumns.add()){ 
        
            with(dialogRows.add()){
                
				with ( dialogColumns.add() ){
				with(borderPanels.add()){
				
						with(dialogRows.add()){ 
                                staticTexts.add( {staticLabel: "Convert text with:"} );
                        } 
						with ( dialogRows.add() ){
								charStylesDD = ([].concat(app.activeDocument.characterStyles.everyItem().name));
								charStylesDD.shift();
								if (charStylesDD.length<1){err("You must have a least one character style");}
								charStyleDD = dialogColumns.add().dropdowns.add( {stringList: charStylesDD, selectedIndex: 0, minWidth:220} );
						} 
				}
				with(borderPanels.add()){
				with ( dialogColumns.add() ){
						with(dialogRows.add()){ 
                       			 staticTexts.add({staticLabel:"Add additional text to add to URL..."}); 
                       	}		 
                       	with(dialogRows.add()){ 		 
                       			staticTexts.add({staticLabel:"Before:"}); 
                       			beforeText = textEditboxes.add( {editContents: "http://www.", minWidth: 300} );
                       	}	
                       	with(dialogRows.add()){ 	 
                        		 staticTexts.add({staticLabel:"...URL.."});
                        }
                        with(dialogRows.add()){  		 
                       			staticTexts.add({staticLabel:"After:"}); 
                        		 afterText = textEditboxes.add( {editContents: ".com", minWidth: 300} );
                        }
                        }
                 }
                        with(dialogRows.add()){ 
                                staticTexts.add({staticLabel:"© www.Luxlucid.com"}); 
                        } 
                } 
              }
              
              
              
              
        } 
        
        
        var myResult = myDialog.show(); 
        if(myResult == true){ 
                charStyle = charStyleDD.selectedIndex+1;
                beforeText = beforeText.editContents;
                afterText = afterText.editContents;
                myDialog.destroy(); 
               createHyperlinks();
 		}else{ 
                myDialog.destroy(); 
        } 
} 


function createHyperlinks(){
	myDoc = app.activeDocument; 
	hyperlinks = 0;
	charStyleName = myDoc.characterStyles.item(charStyle);
	
	app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
	app.findTextPreferences.appliedCharacterStyle = charStyleName;
	foundTexts = myDoc.findText();
	
	for (i = foundTexts.length - 1; i >= 0; i--) { 
			status = 1;
			
 			 try {
	 			source = myDoc.hyperlinkTextSources.add(foundTexts[i]);
			 }
			 catch (e){
			 	status = 0;
			 }
				if (status){
					address = foundTexts[i].contents;
				
					if (beforeText.editContents != ""){
						address = beforeText + address;
					}
					if (afterText.editContents != ""){
						address += afterText;
					}
					
					
				try {
					url = myDoc.hyperlinkURLDestinations.add(address); 
					hyperlink = myDoc.hyperlinks.add(source, url); 
				}
					catch (e){
			 		break;
				 }
				
				
 			 	++hyperlinks;
 			 	 with(hyperlink) { 
 			 	 	
            		 highlight = HyperlinkAppearanceHighlight.none; 
   	        		 borderStyle = HyperlinkAppearanceStyle.solid;
		     		 visible = false;
		    		 name = foundTexts[i].contents + " :" + id;
 	 			}  
			}
		}
	
	if (hyperlinks == 0){
		alert("None converted");
	} else {
		alert(hyperlinks + " links converted");
	}
}



function removeHyperlinks(noMsg){
	var myDoc = app.activeDocument; 
	var hyperlinks = myDoc.hyperlinks.length;
	
	if (myDoc.hyperlinks.length > 0){
		sources = myDoc.hyperlinks.everyItem().source;
		for(i = sources.length-1; i>-1; i--){
				$.write(sources[i].sourceText.underline=0);
		}		
		myDoc.hyperlinks.everyItem().remove();
		//alert("hyperlinks:" + myDoc.hyperlinks.length);
	}
	if (myDoc.hyperlinkTextSources.length > 0){
		myDoc.hyperlinkTextSources.everyItem().remove();
		//alert("hyperlinkTextSources:" + myDoc.hyperlinkTextSources.length);
	}
	
	if (myDoc.hyperlinkURLDestinations.length > 0){
		myDoc.hyperlinkURLDestinations.everyItem().remove();
		//alert("hyperlinkURLDestinations:" + myDoc.hyperlinkURLDestinations.length);
	}


	if (noMsg){
		if (hyperlinks == 0){
			alert("None deleted");
		} else {
			alert("Done. " + hyperlinks + " links deleted");
	}
}
}

function err(e){
	alert(e);
	exit();
}
