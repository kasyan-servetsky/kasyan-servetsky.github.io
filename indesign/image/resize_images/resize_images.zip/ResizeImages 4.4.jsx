﻿/* Copyright 2026, Kasyan Servetsky
October 9, 2026
Written by Kasyan Servetsky
https://kasyan-servetsky.github.io/
e-mail: askoldich@yahoo.com */
//======================================================================================
//@include "log.jsxinc";

var scriptName = "Resize Images - 4.4",
debug = false;

//============= Logging =============
var _log = {
	logit: false,
	debugFuncList: ["preCheck","main","resizePhotoshop","resizeImage","setLink100pct","bridgeTalkMsg","whereIsTheLink","checkLink","collectImages"],
	debugListOnly: false,
	exportHTML: false,
	exportPDF: true,
	overwritePDF: false,
	overwriteLog: true,
	errOnly: false,
	showLineNumbers: false,
	logFolderPath: (app.documents.length == 0) ? null : decodeURI(app.documents[0].filePath) + "/Logs/",
	closeDocLogMode: 0, // 0 - close & don't save, 1 - close & save, 2 - leave open
	//=== DON'T CHANGE ANYTHING BELOW ===
	fullCount: 0,
	errCount: 0,
	headerAdded: false, // Header added to the full log
	msg: "err.message + ', function ' + arguments.callee.toString().match(/function ([^\(]+)/)[1] + ', line: ' + err.line",
	errArr: [],
	scriptName: scriptName,
	debug: debug,
	senderAppName: app.name,
	senderAppVersion: app.version
}
//===================================

var doc, set, storedTransPreferences, resampleMethods, resampleMethodsNames, resampleMethodsTips,
validLinkTypes, totalLinksCount, selectedLinks, storedPreserveBounds, allLinks, tmpFileName,
progWin, progBar, progTxt,
repProcessed = repLocked = repPsError = repSkipped = "";
imgFolder = null,
newLinksFolder = null,
completedLinks = [],
checkedLinks = [];

preCheck();

//===================================== FUNCTIONS ======================================
function main() {
	try {
		log(">");
		var startTime = new Date(),
		finalMsg;
		
		app.layoutWindows[0].transformReferencePoint = AnchorPoint.TOP_LEFT_ANCHOR;

		log("original app.imagePreferences.preserveBounds = " + app.imagePreferences.preserveBounds);
		storedPreserveBounds = app.imagePreferences.preserveBounds;
		app.imagePreferences.preserveBounds = true;
		log("new app.imagePreferences.preserveBounds = " + app.imagePreferences.preserveBounds);

		allLinks = getAllLinks();
		if (set.checkMissingCb) checkMissingLinks();
		if (set.checkResCb) checkEffectivePpi();

		updateAllOutdatedLinks();

		var links = collectImages(allLinks);

		if (links.length > 0) {
			setTransformPrefs();
			log("gonna process " + links.length + " links");

			processImages(links);

			// restore prefs
			app.transformPreferences.properties = storedTransPreferences;
			app.imagePreferences.preserveBounds = storedPreserveBounds;
			log("restored app.imagePreferences.preserveBounds = " + app.imagePreferences.preserveBounds);
		}

		if (completedLinks.length > 0) {
			updateAllOutdatedLinks();
			finalMsg = "Finished. " + completedLinks.length + " link" + ((completedLinks.length == 1) ? " was" : "s were") + " resized.\nTime elapsed: " + getDuration(startTime, new Date());
			alert(finalMsg, scriptName);
		}
		else {
			finalMsg = "Nothing has been resized. ";
			if (links.length == 0) finalMsg += "(No suitable images to resize.) "
			finalMsg += "\nTime elapsed: " + getDuration(startTime, new Date());
			alert(finalMsg, scriptName);
		}

		log(finalMsg, false, true);
		if (set.reportCb) createReport(finalMsg);
		if (_log.logit) {
			logExport();
		}

		log("<");
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function initGlobals() {
	try {
		log(">");
		resampleMethods = ["ResampleMethod.NEARESTNEIGHBOR", "ResampleMethod.BILINEAR", "ResampleMethod.BICUBIC", "ResampleMethod.BICUBICSMOOTHER", "ResampleMethod.BICUBICSHARPER"];
		resampleMethodsNames = ["Nearest Neighbor", "Bilinear", "Bicubic", "Bicubic Smoother", "Bicubic Sharper"];
		resampleMethodsTips = ["Preserve hard edges", "Adds pixels by averaging the color values of surrounding pixels - produces medium-quality results. ", "Best for smooth gradients", "Best for enlargement", "Best for reduction"];
		validLinkTypes = ["TIFF", "Photoshop", "JPEG", "Portable Network Graphics (PNG)", "ScitexCT", "PC PaintBrush", "CompuServe GIF", "Windows Bitmap", "WEBP ", "HEIC HEIF "];
		selectedLinks = getSelectedLinks();

		// progress bar
		progWin = new Window("window", scriptName);
		progBar = progWin.add("progressbar", undefined);
		progBar.preferredSize.width = 600;
		progTxt = progWin.add("statictext", undefined, "");
		progTxt.alignment = "fill";

		log("<");
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function preCheck() {
	try {
		log(">");
		initGlobals();
		if (app.documents.length == 0) errorExit("Please open a document and try again.", true);
		doc = app.activeDocument;
		if (app.activeDocument.allGraphics.length == 0) errorExit("The current document contains no images.");	
		if (doc.converted) errorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
		if (!doc.saved) errorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
		tmpFileName = scriptName.replace(/\-\s\d+\.\d+$/, "").replace(/\s+/g, "_").toLowerCase();

		checkPhotoshop();
		createDialog();
		log("<");
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function createDialog() {
	log(">");
	getSettings();

	var w = new Window("dialog", scriptName);
	w.orientation = "column";
	w.alignChildren = "fill";

	// Ignored folders	
	w.ignoredFoldersPnl = w.add("panel", undefined, "Ignored folders");
	w.ignoredFoldersPnl.orientation = "column";
	w.ignoredFoldersPnl.helpTip = "The files in these folders will not be resized";
	w.ignoredFoldersPnl.alignment = "fill";

	// Listbox
	w.ignoredFoldersPnl.listBox = w.ignoredFoldersPnl.add("listbox", undefined, set.ignoredFolders, {multiselect:true});
	w.ignoredFoldersPnl.listBox.alignment = "fill";

	// Buttons
	w.ignoredFoldersPnl.grp = w.ignoredFoldersPnl.add("group");
	w.ignoredFoldersPnl.grp.orientation = "row";
	w.ignoredFoldersPnl.grp.addBtn = w.ignoredFoldersPnl.grp.add("button", undefined, "Add");
	w.ignoredFoldersPnl.grp.addBtn.helpTip = "Add a folder to the list";
	w.ignoredFoldersPnl.grp.removeBtn = w.ignoredFoldersPnl.grp.add("button", undefined, "Remove");
	w.ignoredFoldersPnl.grp.removeBtn.helpTip = "Remove the selected folders from the list";
	w.ignoredFoldersPnl.grp.remAllBtn = w.ignoredFoldersPnl.grp.add("button", undefined, "Remove All");
	w.ignoredFoldersPnl.grp.remAllBtn.helpTip = "Remove all folders from the list";

	// Resize as copy panel
	w.resizeAsCopyPnl = w.add("panel", undefined, "Resize as copy and relink to new location");
	w.resizeAsCopyPnl.orientation = "row";

	w.resizeAsCopyPnl.leftGr = w.resizeAsCopyPnl.add("group");
	w.resizeAsCopyPnl.leftGr.orientation = "column";
	w.resizeAsCopyPnl.leftGr.minimumSize.width = 412;

	w.resizeAsCopyPnl.rightGr = w.resizeAsCopyPnl.add("group");
	w.resizeAsCopyPnl.rightGr.orientation = "column";

	// checkbox
	w.resizeAsCopyPnl.leftGr.resizeAsCopyCb = w.resizeAsCopyPnl.leftGr.add("checkbox", undefined, "Resize as copy");
	w.resizeAsCopyPnl.leftGr.resizeAsCopyCb.value = set.resizeAsCopyCb;
	w.resizeAsCopyPnl.leftGr.resizeAsCopyCb.alignment = "left";
	w.resizeAsCopyPnl.leftGr.resizeAsCopyCb.onClick = function() {
		if (this.value) {
			w.resizeAsCopyPnl.leftGr.grp.enabled = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.enabled = true;
			
			if (imgFolder == null || !imgFolder.exists) { // disabled
				w.btmGr.gr.resizeBtn.enabled = false;
				w.btmGr.gr.resizeBtn.helpTip = "The 'Resize' button is disabled because the 'Resize as copy' checkbox is ON, but no folder has been selected";;
				w.resizeAsCopyPnl.leftGr.grp.st.text = "No folder has been selected";
			}
			else {
				w.btmGr.gr.resizeBtn.enabled = true;
				w.resizeAsCopyPnl.leftGr.grp.st.text = trimPath(imgFolder.absoluteURI);
				w.resizeAsCopyPnl.leftGr.grp.st.helpTip = imgFolder.fsName;
				w.btmGr.gr.resizeBtn.helpTip = "Click the 'Resize' button to resize images";
			}
		}
		else { // disabled
			w.resizeAsCopyPnl.leftGr.grp.enabled = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.enabled = false;
			w.btmGr.gr.resizeBtn.enabled = true;
			w.btmGr.gr.resizeBtn.helpTip = "Click the 'Resize' button to resize images";
		}
	}

	// group - select image folder
	w.resizeAsCopyPnl.leftGr.grp = w.resizeAsCopyPnl.leftGr.add("group"); // Container for folder path and "Select" button
	w.resizeAsCopyPnl.leftGr.grp.orientation = "column";

	// statictext
	w.resizeAsCopyPnl.leftGr.grp.st = w.resizeAsCopyPnl.leftGr.grp.add("statictext");
	w.resizeAsCopyPnl.leftGr.grp.st.alignment = "center";
	
	if (imgFolder == null || !imgFolder.exists) {
		w.resizeAsCopyPnl.leftGr.grp.st.text = "No folder has been selected";
	}
	else {
		w.resizeAsCopyPnl.leftGr.grp.st.text = trimPath(imgFolder.absoluteURI);
		w.resizeAsCopyPnl.leftGr.grp.st.helpTip = imgFolder.fsName;
	}

	// 'Select' button
	w.resizeAsCopyPnl.leftGr.grp.bt = w.resizeAsCopyPnl.leftGr.grp.add("button", undefined, "Select ...");
	w.resizeAsCopyPnl.leftGr.grp.bt.alignment = "center";
	w.resizeAsCopyPnl.leftGr.grp.bt.onClick = function() {
		imgFolder = selectFolder("Pick a folder for new images.");
		if (imgFolder != null) {
			w.btmGr.gr.resizeBtn.helpTip = "Click the 'Resize' button to resize images";
			w.btmGr.gr.resizeBtn.enabled = true;
		}
	}

	selectFolder = function(promptStr) {
		var folder = Folder.selectDialog(promptStr);

		if (folder != null) {
			w.resizeAsCopyPnl.leftGr.grp.remove(w.resizeAsCopyPnl.leftGr.grp.st);
			w.resizeAsCopyPnl.leftGr.grp.remove(w.resizeAsCopyPnl.leftGr.grp.bt);
			w.resizeAsCopyPnl.leftGr.grp.st = w.resizeAsCopyPnl.leftGr.grp.add("statictext", undefined, trimPath(folder.fsName));
			w.resizeAsCopyPnl.leftGr.grp.st.helpTip = decodeURI(folder.fsName);
			w.resizeAsCopyPnl.leftGr.grp.bt = w.resizeAsCopyPnl.leftGr.grp.add("button", undefined, "Select ...");
			w.resizeAsCopyPnl.leftGr.grp.bt.onClick = function() {
				selectFolder(promptStr);
			}
			w.resizeAsCopyPnl.leftGr.layout.layout(true);
			return folder;
		}
	}

	// Color spaces panel
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl = w.resizeAsCopyPnl.rightGr.add("panel", undefined, "Color spaces");
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.orientation = "row";

	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.add("group");
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.orientation = "column";
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.alignChildren = "left";

	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.rgbCb = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.add("checkbox", undefined, "RGB");
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.rgbCb.value = set.rgbCb;
	
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.cmykCb = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.add("checkbox", undefined, "CMYK");
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.cmykCb.value = set.cmykCb;
	
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.add("group");
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.orientation = "column";
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.alignChildren = "left";
	
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.labCb = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.add("checkbox", undefined, "Lab");
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.labCb.value = set.labCb;
	
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.grayCb = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.add("checkbox", undefined, "Gayscale");
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.grayCb.value = set.grayCb;

	if (set.resizeAsCopyCb) {
		w.resizeAsCopyPnl.leftGr.grp.enabled = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.enabled = true;
	}
	else {
		w.resizeAsCopyPnl.leftGr.grp.enabled = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.enabled = false;
	}

	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.rgbCb.helpTip = 
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.cmykCb.helpTip = 
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.labCb.helpTip = 
	w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.grayCb.helpTip = 
	"Select the color spaces to process";
	
	// Group for the 'Options' & 'Resample method' panels
	w.btmGr = w.add("group");
	w.btmGr.orientation = "row";
	w.btmGr.alignChildren = "top";
	
	// Options panel 
	w.btmGr.optionsPnl = w.btmGr.add("panel", undefined, "Options");
	w.btmGr.optionsPnl.alignChildren = "left";
	
	w.btmGr.optionsPnl.masterPagesCb = w.btmGr.optionsPnl.add("checkbox", undefined, "Resize images on master pages");
	w.btmGr.optionsPnl.masterPagesCb.value = set.masterPagesCb;
	
	w.btmGr.optionsPnl.anchoredCb = w.btmGr.optionsPnl.add("checkbox", undefined, "Resize anchored images");
	w.btmGr.optionsPnl.anchoredCb.value = set.anchoredCb;
	
	w.btmGr.optionsPnl.pasteboardCb = w.btmGr.optionsPnl.add("checkbox", undefined, "Resize images on pasteboard");
	w.btmGr.optionsPnl.pasteboardCb.value = set.pasteboardCb;
	
	w.btmGr.optionsPnl.checkMissingCb = w.btmGr.optionsPnl.add("checkbox", undefined, "Check for missing links");
	w.btmGr.optionsPnl.checkMissingCb.value = set.checkMissingCb;
	
	w.btmGr.optionsPnl.reportCb = w.btmGr.optionsPnl.add("checkbox", undefined, "Create report on the desktop");
	w.btmGr.optionsPnl.reportCb.value = set.reportCb;
	w.btmGr.optionsPnl.reportCb.helpTip = "If checked, a text file containing report about the script operation will be created on the desktop";

	// Minimum resolution
	w.btmGr.optionsPnl.minResGr = w.btmGr.optionsPnl.add("group");
	w.btmGr.optionsPnl.minResGr.orientation = "row";
	w.btmGr.optionsPnl.minResGr.alignChildren = "bottom";
	w.btmGr.optionsPnl.minResGr.checkResCb = w.btmGr.optionsPnl.minResGr.add("checkbox", undefined, "Warn if effective ppi is less then");
	w.btmGr.optionsPnl.minResGr.checkResCb.value = set.checkResCb;
	w.btmGr.optionsPnl.minResGr.checkResCb.helpTip = "If resolution of some image is below the limit, the script will warn you about that.";
	w.btmGr.optionsPnl.minResGr.et = w.btmGr.optionsPnl.minResGr.add("edittext", undefined, set.minimumRes);
	w.btmGr.optionsPnl.minResGr.et.myName = "minimum resolution";
	w.btmGr.optionsPnl.minResGr.et.characters = 3;
	w.btmGr.optionsPnl.minResGr.et.value = set.minimumRes;
	w.btmGr.optionsPnl.minResGr.et.onChange = resEtOnChange;

	// Only selected ppi
	w.btmGr.optionsPnl.selImgCb = w.btmGr.optionsPnl.add("checkbox", undefined, "Resize only " + ((selectedLinks.length > 1) ? + selectedLinks.length + " selected images" : "the selected image"));

	// Desired actual ppi
	w.btmGr.optionsPnl.desiredResGr = w.btmGr.optionsPnl.add("group");
	w.btmGr.optionsPnl.desiredResGr.orientation = "row";
	w.btmGr.optionsPnl.desiredResGr.alignChildren = "bottom";
	w.btmGr.optionsPnl.desiredResGr.desiredResCb = w.btmGr.optionsPnl.desiredResGr.add("checkbox", undefined, "Desired actual ppi");
	w.btmGr.optionsPnl.desiredResGr.desiredResCb.value = set.desiredResCb;
	w.btmGr.optionsPnl.desiredResGr.et = w.btmGr.optionsPnl.desiredResGr.add("edittext", undefined, set.desiredRes);
	w.btmGr.optionsPnl.desiredResGr.et.characters = 3;
	w.btmGr.optionsPnl.desiredResGr.et.myName = "desired resolution";
	w.btmGr.optionsPnl.desiredResGr.et.onChange = resEtOnChange;

	// Don't downsample reduced images if effective ppi is less than desired
	w.btmGr.optionsPnl.reducedGr = w.btmGr.optionsPnl.add("group");
	w.btmGr.optionsPnl.reducedGr.orientation = "row";
	w.btmGr.optionsPnl.reducedGr.dontDownsampleReducedImgsCb = w.btmGr.optionsPnl.reducedGr.add("checkbox", undefined, "Don't downsample reduced images if effective ppi is less than desired");
	w.btmGr.optionsPnl.reducedGr.dontDownsampleReducedImgsCb.value = set.dontDownsampleReducedImgsCb;

	// Don't upsample enlarged images
	w.btmGr.optionsPnl.dontUpsampleEnlargedImgsCb = w.btmGr.optionsPnl.add("checkbox", undefined, "Don't upsample enlarged images");
	w.btmGr.optionsPnl.dontUpsampleEnlargedImgsCb.value = set.dontUpsampleEnlargedImgsCb;

	// Limit downsampling to XXX pixels
	w.btmGr.optionsPnl.limitGr = w.btmGr.optionsPnl.add("group");
	w.btmGr.optionsPnl.limitGr.orientation = "row";
	w.btmGr.optionsPnl.limitGr.alignChildren = "bottom";
	w.btmGr.optionsPnl.limitGr.limitDownsamplingCb = w.btmGr.optionsPnl.limitGr.add("checkbox", undefined, "Limit downsampling to");
	w.btmGr.optionsPnl.limitGr.limitDownsamplingCb.value = set.limitDownsamplingCb;
	w.btmGr.optionsPnl.limitGr.et = w.btmGr.optionsPnl.limitGr.add("edittext", undefined, set.downsamplingLimit);
	w.btmGr.optionsPnl.limitGr.et.characters = 4;
	w.btmGr.optionsPnl.limitGr.et.myName = "downsampling limit";
	w.btmGr.optionsPnl.limitGr.st = w.btmGr.optionsPnl.limitGr.add("statictext", undefined, "pixels");
	w.btmGr.optionsPnl.limitGr.st.alignment = "fill";

	w.btmGr.optionsPnl.limitGr.limitDownsamplingCb.helpTip = 
	w.btmGr.optionsPnl.limitGr.et.helpTip = 
	w.btmGr.optionsPnl.limitGr.st.helpTip = 
	"If this checkbox is on and the largest side of the downsampled image becomes below this value, it will be reduced only to this value";

	// Skip already processed images
	w.btmGr.optionsPnl.skipResizedGr = w.btmGr.optionsPnl.add("group");
	w.btmGr.optionsPnl.skipResizedGr.orientation = "row";
	w.btmGr.optionsPnl.skipResizedGr.alignChildren = "bottom";
	w.btmGr.optionsPnl.skipResizedGr.skipResizedCb = w.btmGr.optionsPnl.skipResizedGr.add("checkbox", undefined, "Skip already processed images");
	w.btmGr.optionsPnl.skipResizedGr.skipResizedCb.value = set.skipResizedCb;

	w.btmGr.optionsPnl.skipResizedGr.resetBtn = w.btmGr.optionsPnl.skipResizedGr.add("iconbutton");
	w.btmGr.optionsPnl.skipResizedGr.resetBtn.title = "R";
	w.btmGr.optionsPnl.skipResizedGr.resetBtn.alignment = "fill";
	w.btmGr.optionsPnl.skipResizedGr.resetBtn.preferredSize = [22, 22];

	w.btmGr.optionsPnl.skipResizedGr.resetBtn.helpTip = "Reset the list of processed links";
	w.btmGr.optionsPnl.skipResizedGr.resetBtn.onClick = function() {
		try {
			log("Clear the list of processed links", false, true);

			var link,
			links = doc.links.everyItem().getElements(),
			processedLinks = [];

			if (links.length > 0) {
				for (var i = 0; i < links.length; i++) {
					link = links[i];

					if (link.extractLabel("Status") == "Processed") {
						processedLinks.push(link.name);
					}
				}

				if (processedLinks.length > 0) {
					var answer = confirm(
							"Do you want to remove " + 
							processedLinks.length + 
							" link" + 
							((processedLinks.length > 1) ? "s" : "") + 
							" from the processed list? If you hit 'Yes' the script will close the main dialog box, reset the list and quit, so you'll have to run it again.\n\n" + 
							((processedLinks.length < 10) ? processedLinks.join(", ") : processedLinks.slice(0, 10).join(", ") + "\nand " + (processedLinks.length - 10) + " more links"),
							false, scriptName
						);

					if (answer) {
						w.close(3);
					}
				}
				else {
					alert("There are no links in the processed list.", scriptName);
				}
			}
			else {
				alert("There are no links in the current document.", scriptName);
			}
		}
		catch(err) {
			log(eval(_log.msg), true, true);
		}
	}

	// Selected links
	if (selectedLinks.length >= 1) {
		try {
			w.btmGr.optionsPnl.selImgCb.enabled = true;
			w.btmGr.optionsPnl.selImgCb.value = set.selImgCb;
		}	
		catch(err) {
			if (debug) $.writeln("Error: " + err.message);
			w.btmGr.optionsPnl.selImgCb.enabled = false;
			w.btmGr.optionsPnl.selImgCb.value = false;
		}
	}
	else {
		w.btmGr.optionsPnl.selImgCb.enabled = false;
		w.btmGr.optionsPnl.selImgCb.value = false;
		w.btmGr.optionsPnl.selImgCb.text = "Resize only selected images.";
	}

	w.btmGr.optionsPnl.selImgCb.addEventListener("click", selImgCbClick);
	
	if (w.btmGr.optionsPnl.selImgCb.value && w.btmGr.optionsPnl.selImgCb.enabled) {
		w.btmGr.optionsPnl.masterPagesCb.enabled = false;
		w.btmGr.optionsPnl.anchoredCb.enabled = false;
		w.btmGr.optionsPnl.pasteboardCb.enabled = false;
	}

	// group for the 'Resample method' panel and buttons
	w.btmGr.gr = w.btmGr.add("group");
	w.btmGr.gr.orientation = "column";
	
	// Resample method panel
	w.btmGr.gr.resamplePnl = w.btmGr.gr.add("panel", undefined, "Resample method:");
	w.btmGr.gr.resamplePnl.alignment = "left";
	w.btmGr.gr.resamplePnl.alignChildren = "left";

	w.btmGr.gr.resamplePnl.st1 = w.btmGr.gr.resamplePnl.add("statictext", undefined, "Reduced images");
	w.btmGr.gr.resamplePnl.reducedDropDownList = w.btmGr.gr.resamplePnl.add("dropdownlist", undefined, resampleMethodsNames);
	w.btmGr.gr.resamplePnl.reducedDropDownList.selection = w.btmGr.gr.resamplePnl.reducedDropDownList.items[set.reducedDropDownList];
	w.btmGr.gr.resamplePnl.reducedDropDownList.helpTip = resampleMethodsTips[set.reducedDropDownList];
	
	w.btmGr.gr.resamplePnl.st2 = w.btmGr.gr.resamplePnl.add("statictext", undefined, "Enlarged images");
	w.btmGr.gr.resamplePnl.enlargedDropDownList = w.btmGr.gr.resamplePnl.add("dropdownlist", undefined, resampleMethodsNames);
	w.btmGr.gr.resamplePnl.enlargedDropDownList.selection = w.btmGr.gr.resamplePnl.enlargedDropDownList.items[set.enlargedDropDownList];
	
	if (set.dontUpsampleEnlargedImgsCb) {
		w.btmGr.gr.resamplePnl.enlargedDropDownList.enabled = false;
		w.btmGr.gr.resamplePnl.enlargedDropDownList.helpTip = "This dropdown list is disabled because the 'Don't upsample enlarged images' check box is ON";
	}
	else {
		w.btmGr.gr.resamplePnl.enlargedDropDownList.enabled = true;
		w.btmGr.gr.resamplePnl.enlargedDropDownList.helpTip = resampleMethodsTips[set.enlargedDropDownList];
	}
	
	// Resize and Cancel buttons
	w.btmGr.gr.resizeBtn = w.btmGr.gr.add("button", undefined, "Resize");

	if (set.resizeAsCopyCb && imgFolder == null) {
		w.btmGr.gr.resizeBtn.helpTip = "The 'Resize' button is disabled because the 'Resize as copy' checkbox is ON, but no folder has been selected";
		w.btmGr.gr.resizeBtn.enabled = false;
	}
	else {
		w.btmGr.gr.resizeBtn.helpTip = "Click the 'Resize' button to resize images";
		w.btmGr.gr.resizeBtn.enabled = true;
	}

	w.btmGr.gr.cancelBtn = w.btmGr.gr.add("button", undefined, "Cancel");

	w.btmGr.gr.aboutBtn = w.btmGr.gr.add("button", undefined, "About");
	w.btmGr.gr.aboutBtn.onClick = function() {
		jumpToLink(tmpFileName);
	}

	// Functions
	function selImgCbClick() {
		if (this.value) {
			w.btmGr.optionsPnl.masterPagesCb.enabled = false;
			w.btmGr.optionsPnl.anchoredCb.enabled = false;
			w.btmGr.optionsPnl.pasteboardCb.enabled = false;
		}
		else {
			w.btmGr.optionsPnl.masterPagesCb.enabled = true;
			w.btmGr.optionsPnl.anchoredCb.enabled = true;
			w.btmGr.optionsPnl.pasteboardCb.enabled = true;
		}
	}

	w.ignoredFoldersPnl.grp.addBtn.onClick = function() {
		var folder = Folder.selectDialog ("Select a folder");
		if (folder != null) {
			if (!isInArray(folder.fsName, set.ignoredFolders)) {
				set.ignoredFolders.push(folder.fsName);
				var bounds = w.ignoredFoldersPnl.listBox.bounds;
				w.ignoredFoldersPnl.remove(w.ignoredFoldersPnl.listBox);
				w.ignoredFoldersPnl.listBox = w.ignoredFoldersPnl.add("listbox", bounds, set.ignoredFolders, {multiselect:true});
			}
			else {
				alert("This folder has been already added.");
			}
		}
	}

	w.ignoredFoldersPnl.grp.removeBtn.onClick = function() {
		if (w.ignoredFoldersPnl.listBox.selection != null) {
			for (var i = w.ignoredFoldersPnl.listBox.selection.length - 1; i >= 0; i --) {
				set.ignoredFolders.splice(w.ignoredFoldersPnl.listBox.selection[i].index, 1);
				w.ignoredFoldersPnl.listBox.remove(w.ignoredFoldersPnl.listBox.selection[i]);
			}
		}
	}

	w.ignoredFoldersPnl.grp.remAllBtn.onClick = function() {
		w.ignoredFoldersPnl.listBox.removeAll();
		set.ignoredFolders = [];
	}

	w.btmGr.gr.resizeBtn.onClick = function() {
		set.ignoredFolders = [];
		for (j = 0; j < w.ignoredFoldersPnl.listBox.items.length; j++) {
			set.ignoredFolders.push(w.ignoredFoldersPnl.listBox.items[j].text);
		}
		w.close(1);
	}

	w.btmGr.gr.cancelBtn.onClick = function() {
		w.close(0);
	}

	w.btmGr.gr.resamplePnl.reducedDropDownList.onChange = function() {
		this.helpTip = resampleMethodsTips[w.btmGr.gr.resamplePnl.reducedDropDownList.selection.index];
	}

	w.btmGr.gr.resamplePnl.enlargedDropDownList.onChange = function() {
		this.helpTip = resampleMethodsTips[w.btmGr.gr.resamplePnl.enlargedDropDownList.selection.index];
	}
	
	// when 'Don't resample enlarged images' is ON, it's disabled
	w.btmGr.optionsPnl.dontUpsampleEnlargedImgsCb.onClick = function() {
		if (this.value) {
			w.btmGr.gr.resamplePnl.enlargedDropDownList.enabled = false;
			w.btmGr.gr.resamplePnl.enlargedDropDownList.helpTip = "This dropdown list is disabled because the 'Don't resample enlarged images' check box is ON";
		}
		else {
			w.btmGr.gr.resamplePnl.enlargedDropDownList.enabled = true;
			w.btmGr.gr.resamplePnl.enlargedDropDownList.helpTip = resampleMethodsTips[set.enlargedDropDownList];
		}
	}

	function resEtOnChange() {
		if (parseInt(this.text).toString() == "NaN") {
			alert (this.text + " is not number!");

			if (this.myName == "minimum resolution") {
				this.text = set.minimumRes;
			}
			else if (this.myName == "desired resolution") {
				this.text = set.desiredRes;
			}
			else if (this.myName == "downsampling limit") {
				this.text = set.downsamplingLimit;
			}
			else { // though we will never reach here, just in case
				this.text = "300";	
			}		
		}
	}
	
	// Show dialog
	var showDialog = w.show();
	if (showDialog == 1 || showDialog == 3) {
		set.ignoredFolders = set.ignoredFolders;
		set.masterPagesCb = w.btmGr.optionsPnl.masterPagesCb.value;
		set.anchoredCb = w.btmGr.optionsPnl.anchoredCb.value;
		set.pasteboardCb = w.btmGr.optionsPnl.pasteboardCb.value;
		set.checkMissingCb = w.btmGr.optionsPnl.checkMissingCb.value;
		set.reportCb = w.btmGr.optionsPnl.reportCb.value;
		
		set.checkResCb = w.btmGr.optionsPnl.minResGr.checkResCb.value;
		set.minimumRes = parseInt(w.btmGr.optionsPnl.minResGr.et.text);
		if (set.minimumRes.toString() == "NaN") {
			set.minimumRes = 260;
		}

		set.selImgCb = w.btmGr.optionsPnl.selImgCb.value;

		set.desiredResCb = w.btmGr.optionsPnl.desiredResGr.desiredResCb.value;

		set.desiredRes = parseInt(w.btmGr.optionsPnl.desiredResGr.et.text);
		if (set.desiredRes.toString() == "NaN") {
			set.desiredRes = 300;
		}

		set.dontUpsampleEnlargedImgsCb = w.btmGr.optionsPnl.dontUpsampleEnlargedImgsCb.value;
		set.dontDownsampleReducedImgsCb = w.btmGr.optionsPnl.reducedGr.dontDownsampleReducedImgsCb.value;

		set.reducedDropDownList = w.btmGr.gr.resamplePnl.reducedDropDownList.selection.index;
		set.enlargedDropDownList = w.btmGr.gr.resamplePnl.enlargedDropDownList.selection.index;
		set.resizeAsCopyCb = w.resizeAsCopyPnl.leftGr.resizeAsCopyCb.value;
		set.imgFolderPath = (imgFolder != null) ? imgFolder.absoluteURI : "";
		set.rgbCb = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.rgbCb.value;
		set.cmykCb = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.leftColGrp.cmykCb.value;
		set.labCb = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.labCb.value;
		set.grayCb = w.resizeAsCopyPnl.rightGr.colorSpacesPnl.rightColGrp.grayCb.value;

		set.limitDownsamplingCb = w.btmGr.optionsPnl.limitGr.limitDownsamplingCb.value;

		set.downsamplingLimit = parseInt(w.btmGr.optionsPnl.limitGr.et.text);
		if (set.downsamplingLimit.toString() == "NaN") {
			set.downsamplingLimit = 3000;
		}
	
		set.skipResizedCb = w.btmGr.optionsPnl.skipResizedGr.skipResizedCb.value;

		app.insertLabel("Kas_" + scriptName, set.toSource());
		log("Saving settings, set = " + set.toSource());

		if (showDialog == 1) {
			log("After hitting OK, set = " + set.toSource());
			main();	
		}
		else if (showDialog == 3) { // reset the processed list
			log("Reset", false, true);
			doc.links.everyItem().insertLabel("Status", "");
		}
	}
	else if (showDialog == 2) {
		log("Cancelled", false, true);
	}

	log("<");
}

function getAnchoredContainer(obj) {
	try {
		log(">");
		var container = null;

		while (obj.constructor.name != "Application") {
			if ((obj.constructor.name == "Rectangle" || 
				obj.constructor.name == "Oval" || 
				obj.constructor.name == "Polygon") &&
				obj.parent.constructor.name == "Character" &&
				obj.parent.parent.constructor.name == "Story" &&
				obj.parent.parent.parent.constructor.name == "Document"
			) {
				container = obj;
				break;
			}

			obj = obj.parent;
		}

		log((container == null) ? "container = null" : "container = " + container.constructor.name + " |" + container.id);
		log("<");
		return container;
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function getContainer(obj) {
	try {
		log(">");
		var container = null;

		while (obj.constructor.name != "Application") {
			if (obj.constructor.name == "Rectangle" || 
				obj.constructor.name == "Oval" || 
				obj.constructor.name == "Polygon"
			) {
				container= obj;
				break;
			}

			obj = obj.parent;
		}

		log("container = " + container.constructor.name + " |" + container.id);
		log("<");
		return container;
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function whereIsTheLink(obj) {
	log(">");
	var result = null,
	container = null,
	item = obj;

	container = getAnchoredContainer(obj); // check if it's anchored (multiple nested levels are possible)
	if (container != null) {
		if (container.parentPage != null) {
			result = "anchored";
		}
		else {
			result = "anchored on pasteboard";
		}
	}
	else if (container == null) { // not anchored - get a regular container
		container = getContainer(obj);

		if (container != null) {
			if (container.parentPage != null) { // item is on a page
				if (container.parent.constructor.name == "Spread") {
					result = "page";
				}
				else if (container.parent.constructor.name == "MasterSpread") {
					result = "master page";
				}
			}
			else { // item is on the pasteboard (parentPage == null)
				if (container.parent.constructor.name == "Spread") {
					result = "pasteboard";					
				}
				else if (container.parent.constructor.name == "MasterSpread") {
					result = "pasteboard of master page";
				}
			}
		}
		else { // container == null
			log("container == null");
			result = "unknown";
		}
	}

	log("result = " + result);
	log("<");
	return result;
}

function findLargestLink(link) {
	var multyLinks = [];
	for (var counter = 0; counter < allLinks.length; counter++) {
		if (link.filePath == allLinks[counter].filePath) {
			multyLinks.push(allLinks[counter]);
		}
	}
	var largestLink = multyLinks[0];
	for (var k = 1; k < multyLinks.length; k++) {
		var theLink = multyLinks[k];
		var image = theLink.parent;
		var horScale = image.absoluteHorizontalScale;
		if (horScale > largestLink.parent.absoluteHorizontalScale) {
			largestLink = theLink;
		}
	}
	return largestLink;
}

function relink(oldLink, oldLinkFile, newFile) {
	try {
		log(">");
		var currentLink, currentLinkFile, allLinks,
		multiUsedLinks = [],	
		thisLinkUsedTimes = linkUsage(oldLink);

		oldLink.relink(newFile);
		log("relinked link");

		try {
			oldLink = oldLink.update();
			log("updated link");
		}
		catch(err) {
			log(err.message + ", line: " + err.line, true);
		}

		if (thisLinkUsedTimes > 1) {
			log("thisLinkUsedTimes > 1");
			allLinks = doc.links;

			for (var d = 0; d < allLinks.length; d++) {
				currentLinkFile = new File(allLinks[d].filePath);
				if (currentLinkFile.fsName == oldLinkFile.fsName) {
					multiUsedLinks.push(allLinks[d].id);
				}
			}

			for (var f = multiUsedLinks.length-1; f >= 0 ; f--) {
				currentLink = doc.links.itemByID(multiUsedLinks[f]);
				if (currentLink != null) {
					currentLink.relink(newFile);
					
					try {
						currentLink = currentLink.update();
					}
					catch(err) {
						if (debug) $.writeln(err.message + ", line: " + err.line);
					}
				}
			}
		}

		log("<");
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function linkUsage(link) {
	log(">");
	var counter = 0;
	
	for (var i = 0; i < allLinks.length; i++) {
		if (link.filePath == allLinks[i].filePath) {
			counter++;
		}
	}

	log("counter = " + counter);
	log("<");

	return counter;
}

function updateAllOutdatedLinks() {
	try {
		for (var counter = doc.links.length-1; counter >= 0; counter--) {
			var link = doc.links[counter];
			if (link.status == LinkStatus.linkOutOfDate) {
				link.update();
			}
		}
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function createReport(finalMsg) {
	var date = new Date(),
	report = date.toLocaleString() + "\rFile: " + doc.fullName.fullName + "\r\r";

	if (repProcessed != "") { // Normal
		report += "The following images were processed:\r" + repProcessed + "\r";
	}

	if (repSkipped != "") { // Skipped
		report += "The following images were skipped:\r" + repSkipped + "\r";
	}
	
	if (repLocked != "") { // Locked
		report += "The following images were not resized because they are locked:\r" + repLocked + "\r";
	}

	if (repPsError != "") { // Error
		report += "The following images were not processed because of an error that occurred (probably because they are damaged):\r" + repPsError + "\r";
	}

	if (finalMsg != null) {
		report += finalMsg + "\r";
	}

	report += "----------------------------------------------------\r";
	writeToFile(report);
}

function writeToFile(text) {
	logLibFile = new File("~/Desktop/Report.txt");
	
	if ( logLibFile.exists ) {
		logLibFile.open("e");
		logLibFile.seek(0, 2);
	}
	else {
		logLibFile.open("w");
	}

	logLibFile.encoding = "UTF-8";
	logLibFile.write(text); 
	logLibFile.close();
}

function isInArray(string, array) {
	log(">");
	for (x in array) {
		if (string == array[x]) {
			log("true");
			return true;
		}
	}
	log("false");
	log("<");
	return false;
}

function errorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}

function checkPhotoshop() { 
	log(">");
	var specifier = BridgeTalk.getSpecifier("photoshop");
	if (specifier == null) errorExit("The script can\"t run because Photoshop is not installed.");
	if (!BridgeTalk.isRunning ("photoshop")) {
		var answer = confirm("Photoshop is not running. Do you want to launch it?", false, scriptName);
		if (answer) {
			BridgeTalk.launch("photoshop");
			errorExit("Wait untill Photoshop finishes loading and run the script again.", false);
		}
		else {
			exit();
		}
	}
	log("<");
}

function checkInDesign() {
	log(">");
	if (app.documents.length == 0) {
		errorExit("No documents are open. Please open a document and try again.");
	}
	if (!app.activeDocument.saved) {
		errorExit("The current document has not been saved since it was created. Please save the document and try again.");
	}
	if (app.activeDocument.allGraphics.length == 0) {
		errorExit("The current document contains no images.");
	}
	log("<");
}

function setTransformPrefs() {
	storedTransPreferences = app.transformPreferences.properties;
	app.transformPreferences.transformationsAreTotals = true;
	app.transformPreferences.showContentOffset = true;
	app.transformPreferences.dimensionsIncludeStrokeWeight = true;
	app.transformPreferences.whenScaling = WhenScalingOptions.APPLY_TO_CONTENT;
}

function checkLink(link) {
	try {
		log(">");
		var linkName = decodeURI(link.name);
		var linkStatus = link.status;
		var linkFilePath = link.filePath;

		if (!isInArray(linkFilePath, checkedLinks)) {
			var startTime = new Date();
			var result = true;

			if (set.skipResizedCb && link.extractLabel("Status") == "Processed") {
				result = false;
				repSkipped += linkName + " - skipped: because the link was already processed and the 'Skip already processed images' check box is ON\r";
			}

			if (result && linkStatus != LinkStatus.NORMAL) { // modified links were already updated
				result = false;
				var linkStatusName = enumName(LinkStatus, linkStatus).replace(/^LINK_/, "");
				log("linkStatusName = " + linkStatusName);
				repSkipped += linkName + " - skipped: because the link status isn't normal - " + linkStatusName + "\r";
			}

			// link is inside of indd-file
			if (result && link.parent.constructor.name == "ImportedPage") {
				result = false;
				repSkipped += linkName + " - skipped: because the link is inside of an INDD-file\r";
			}

			// invalid link type
			if (result && !isInArray(link.linkType, validLinkTypes)) {
				result = false;
				repSkipped += linkName + " - skipped: because of invalid link type\r";
			}

			// bitmap
			if (result && link.parent.hasOwnProperty("space") && isPropAvail(link.parent, "space") && link.parent.space == "Black and White") {
				result = false; 
				repSkipped += linkName + " - skipped: because the link is Bitmap (only Black & White) - no sence to resize\r";
			}

			// in ignored folders
			if (result && isInArray(new File(link.filePath).parent.fsName, set.ignoredFolders)) {
				result = false;
				repSkipped += linkName + " - skipped: because the link is in an ignored folder\r";
			} 

			if (result) {
				var placement = whereIsTheLink(link);

				if (placement != null) {
					log("checkLink - placement = " + placement);

					if (!set.pasteboardCb && placement == "pasteboard") {
						result = false;
						repSkipped += linkName + " - skipped: because the link is on pasteboard, but the 'Resize images on pasteboard' check box is OFF\r";
					}

					if (!set.anchoredCb && placement == "anchored") {
						result = false;
						repSkipped += linkName + " - skipped: because the link is anchored, but the 'Resize anchored images' check box is OFF\r";
					}

					if ((set.anchoredCb && !set.pasteboardCb) && placement == "anchored on pasteboard") {
						result = false;
						repSkipped += linkName + " - skipped: because the link is anchored on pasteboard, but the 'Resize anchored images' check box is ON and the Resize images on pasteboard is OFF\r";
					}

					if (!set.masterPagesCb && placement == "master page") {
						result = false;
						repSkipped += linkName + " - skipped: because the link is on master page, but the 'Resize images on master pages' check box is OFF\r";
					}

					// both check boxes should be on, otherwise - false
					if ((!set.masterPagesCb || !set.pasteboardCb) && placement == "pasteboard of master page") {
						result = false;
						repSkipped += linkName + " - skipped: because the link is on the pasteboard of master page, but either the 'Resize images on master pages' or 'Resize images on pasteboard' check box is OFF\r";
					}
				}
				else {
					log("checkLink - placement == null");
				}
			}
		
			checkedLinks.push(linkFilePath);

			log("result = " + result + " | " + getDuration(startTime, new Date()));
			log("<");
			return result;			
		}
		else {
			log("already was checked");
			log("<");
		}
	}
	catch(err) {
		log(eval(_log.msg), true);
		repProcessed += decodeURI(link.name) + "Error in checkLink function: " + err.message + ", line: " + err.line + "\r";
	}
}

function collectImages() {
	try {
		log(">");
		var startTime = new Date();
		var link, checkLinkResult, progVal,
		links = [],
		multiUsedLinks = [],
		linksLength = allLinks.length;

		progBar.maxvalue = linksLength;
		progWin.show();

		for (var i = 0; i < linksLength; i++) {
			link = allLinks[i];
			log((i + 1) + " - link.name = " + link.name);

			progVal = i + 1;
			progBar.value = progVal;
			progTxt.text = "Checking: " + link.name + " (" + progVal + " out of " + linksLength + ")";

			checkLinkResult = checkLink(link);

			if (checkLinkResult) {
				log("checkLinkResult = true");
				var linkPlacedTimes = linkUsage(link);
				if (linkPlacedTimes == 1) {
					links.push(link);
				}
				else if (linkPlacedTimes > 1) {
					var largestLink = findLargestLink(link);
					if (!isObjInArray(largestLink, multiUsedLinks)) {
						multiUsedLinks.push(largestLink);
					}
				}
			}
		}

		progWin.close();
		
		if (multiUsedLinks.length > 0) {
			for (k = 0; k < multiUsedLinks.length; k++) {
				links.push(multiUsedLinks[k]);
			}
		}

		log(getDuration(startTime, new Date()), false, true);
		log("<");
		return links;
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function checkMissingLinks() {
	var missingLinks = [];
	for (var o = 0; o < allLinks.length; o++) {
		var link = allLinks[o];
		if (link.parent.constructor.name == "Image") {
			var link = doc.links[o];
			if (link.status == LinkStatus.linkMissing) {
				missingLinks.push(link);
			}
		}
	}

	if (missingLinks.length == 1) {
		missingLinks[0].show();
		var answer = confirm("This link is missing, do you want to stop the script and repair it?", false, scriptName);
		if (answer) {
			exit();
		}
	}
	else if (missingLinks.length > 1) {
		var img = " images";
		var message1 = "The document contains " + missingLinks.length + " missing" + img + ":";
		var message2 = "";
		for (var p = 0; p < missingLinks.length; p++) {
			var missingLink = missingLinks[p];
			var number = ( (p + 1) <10 ) ? " " + (p + 1) + ". " : (p + 1) + ". ";

			message2 += number + missingLink.name + "\r";
		}
		createCheckDialog(message1, message2, "Missing Links");
	}
}

function checkEffectivePpi() {
	var lowResImages = [];
	for (var o = 0; o < allLinks.length; o++) {
		var link = allLinks[o];
		if (link.parent.constructor.name == "Image") {
			if (link.linkType != "WEBP ") { // skip because of wrong eff. ppi
				var image = link.parent;
				if (image.effectivePpi[0] < set.minimumRes || image.effectivePpi[1] < set.minimumRes) {
					lowResImages.push(image);
				}
			}
		}
	}

	if (lowResImages.length == 1) {
		lowResImages[0].itemLink.show();
		var answer = confirm("Effective resolution of this link is below " + set.minimumRes + " ppi. Do you want to stop the script and repair it?", false, scriptName);
		if (answer) {
			exit();
		}
	}
	else if (lowResImages.length > 1) {
		var img = " images";
		var message1 = "The document contains " + lowResImages.length + img + ", effective resolution of which is below " + set.minimumRes + " ppi:";
		var message2 = "";
		for (p = 0; p < lowResImages.length; p++) {
			var lowResImage = lowResImages[p];
			if (lowResImages.length == 1) {
				var number = "";
			}
			else {
				var number = ( (p + 1) < 10 ) ? " " + (p + 1) + ". " : (p + 1) + ". ";
			}
			message2 += number + lowResImage.itemLink.name + " -- " + lowResImage.effectivePpi[0] + "x" + lowResImage.effectivePpi[1] + " ppi\r";
		}
		createCheckDialog(message1, message2, "Low resolution images");
	}
}

function createCheckDialog(message1, message2, title) {
	var dlg = new Window("dialog", title);
	dlg.st1 = dlg.add("statictext", undefined, message1);
	dlg.et = dlg.add("edittext", undefined, message2, {multiline:true, scrolling:true, readonly:true});
	dlg.et.alignment = "fill";
	dlg.et.maximumSize = [600, 350];
	dlg.st2 = dlg.add("statictext", undefined, "Do you want to interrupt the script and correct the problem?");
	// Group
	dlg.grp = dlg.add("group");
	dlg.grp.orientation = "row";
	dlg.grp.alignChildren = "top";
	// Ok and Cancel buttons
	dlg.grp.okBtn = dlg.grp.add("button", undefined, "Yes", {name:"ok"}); // 1
	dlg.grp.cancelBtn = dlg.grp.add("button", undefined, "No", {name:"cancel"}); // 2
	// Show dialog
	var dialogResult = dlg.show();
	if (dialogResult == 1) {
		exit();
	}
}

function getAllLinks() {
	var links = [];

	if (set.selImgCb) { // Process only selected images
		if (app.selection.length >= 1) {
			links = selectedLinks;
		}
	}
	else { // Process all images ('only selected' checkbox is off)
		links = doc.links.everyItem().getElements(); // much faster: 4 minutes, 45 seconds vs 18 minutes, 2 seconds
	}

	return links;
}

function isObjInArray(obj, array) {
	log(">");
	for (x in array) {
		if (obj.filePath == array[x].filePath) {
			return true;
		}
	}
	log("<");
	return false;
}

function getSettings() {
	try {
		log(">");
		set = eval(app.extractLabel("Kas_" + scriptName));

		if (set == undefined) {
			alert("Creating default settings", scriptName);
			
			set = {
					ignoredFolders:[], masterPagesCb:true, anchoredCb:true, pasteboardCb:false, checkMissingCb:true, reportCb:true, checkResCb:true , 
					minimumRes:260, selImgCb:false, desiredResCb:true, desiredRes:300, dontUpsampleEnlargedImgsCb:true, dontDownsampleReducedImgsCb:true, reducedDropDownList:4, enlargedDropDownList:3,
					resizeAsCopyCb:false, imgFolderPath:"", rgbCb:true, cmykCb:true, labCb:true, grayCb:true,
					limitDownsamplingCb:false, downsamplingLimit:3000, skipResizedCb:false
				}
		}

		imgFolder = new Folder(set.imgFolderPath);
		if (!imgFolder.exists) {
			imgFolder = null;
		}

		if (parseIntg(set.minimumRes) == 0) set.minimumRes = 260;
		if (parseIntg(set.desiredRes) == 0) set.desiredRes = 300;
		if (parseIntg(set.downsamplingLimit) == 0) set.downsamplingLimit = 3000;

		if (debug) var tmp = set;
		log("set = " + set.toSource());
		log("<");
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function processImages(links) {
	try {
		log(">");
		var colorMode, image,
		linksLength = links.length,
		progVal = 1;

		progBar.maxvalue = linksLength;
		progWin.show();

		// loop through the links
		for (var i = linksLength - 1; i >= 0; i --) {
			var link = links[i];
			log("link.name = " + link.name);

			progBar.value = progVal;
			progTxt.text = "Resizing: " + link.name + " (" + progVal + " out of " + linksLength + ")";
			progVal++;

			// Skip color spaces if a checkbox is OFF (Image mode panel)
			if (set.resizeAsCopyCb) {
				image = link.parent;
				var colorMode = image.space;

				if ((colorMode == "RGB" && !set.rgbCb) ||
					(colorMode == "CMYK" && !set.cmykCb) ||
					(colorMode == "Lab" && !set.labCb) ||
					(colorMode == "Grayscale" && !set.grayCb)) continue;
			}

			resizeImage(link);
		}

		progWin.close();
		log("<");
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function convertWebpLinkToJpeg(link) {
	try {
		log(">");

		var oldLinkFile = new File(link.filePath),
		imagePath = decodeURI(oldLinkFile.absoluteURI),
		// save into a dedicated subfolder rather than next to the original file, so a resaved WEBP
		// can never overwrite an unrelated, already-existing JPEG that happens to share its base name
		resavedFolder = new Folder(decodeURI(oldLinkFile.parent.absoluteURI) + "/Resaved WebP"),
		newFilePath = decodeURI(resavedFolder.absoluteURI) + "/" + link.name.replace(/\.[^.]+$/, ".jpg");

		if (!resavedFolder.exists) resavedFolder.create();

		log("imagePath = " + imagePath);
		log("newFilePath = " + newFilePath);

		var params = {imagePath: imagePath, newFilePath: newFilePath},
		result = bridgeTalkConvertMsg(params);

		if (result == null || result.error != null) {
			log("convertToJpeg failed: " + ((result == null) ? "no result" : result.error), true);
			log("<");
			return null;
		}

		var newFile = new File(result.newFilePath);
		if (!newFile.exists) {
			log("Converted JPEG doesn't exist: " + result.newFilePath, true);
			log("<");
			return null;
		}

		relink(link, oldLinkFile, newFile); // also relinks other instances of the same file, if used more than once
		if (link.status == LinkStatus.LINK_OUT_OF_DATE) link = link.update();

		log("<");
		return link;
	}
	catch(err) {
		log(eval(_log.msg), true);
		return null;
	}
}

// InDesign detects the link type by the file's content, not by its extension, so a JPEG saved
// with the .webp extension (e.g. downloaded from a web site) is reported as "JPEG". Photoshop,
// however, relies on the extension: it either can't open such a file or saves the resized copy
// under a different name than the script expects, so the link is never relinked to the resized
// image. Copy the file under the extension that matches its real type into a subfolder (byte copy,
// no recompression) and relink to it, then process it as usual.
// Returns the link (relinked or untouched), or null if copying/relinking failed.
function fixMisnamedLink(link) {
	try {
		log(">");

		var validExtensions = {
			"JPEG": ["jpg", "jpeg", "jpe"],
			"TIFF": ["tif", "tiff"],
			"Photoshop": ["psd", "psb"],
			"Portable Network Graphics (PNG)": ["png"],
			"WEBP ": ["webp"],
			"HEIC HEIF ": ["heic", "heif"]
		},
		extensions = validExtensions[link.linkType];

		if (extensions == undefined) {
			log("no extension list for this link type: " + link.linkType + " - returning");
			log("<");
			return link;
		}

		var oldLinkFile = new File(link.filePath),
		match = link.name.match(/\.([^.]+)$/),
		extension = (match == null) ? "" : match[1].toLowerCase();

		if (isInArray(extension, extensions)) {
			log("the extension matches the link type");
			log("<");
			return link;
		}

		var fixedFolder = new Folder(decodeURI(oldLinkFile.parent.absoluteURI) + "/Corrected extension"),
		newName = link.name.replace(/\.[^.]+$/, "") + "." + extensions[0],
		newFile = new File(decodeURI(fixedFolder.absoluteURI) + "/" + newName);

		log("'" + link.name + "' is actually " + link.linkType + " - copying it as '" + newName + "'");

		if (!fixedFolder.exists) fixedFolder.create();

		if (!oldLinkFile.copy(newFile) || !newFile.exists) {
			log("Couldn't copy the file to: " + decodeURI(newFile.fsName), true);
			log("<");
			return null;
		}

		relink(link, oldLinkFile, newFile); // also relinks other instances of the same file, if used more than once
		if (link.status == LinkStatus.LINK_OUT_OF_DATE) link = link.update();

		repProcessed += decodeURI(oldLinkFile.name) + " - is actually a " + link.linkType + " file with a wrong extension, so it was copied as '" + newName + "' to the 'Corrected extension' subfolder and relinked\r";

		log("<");
		return link;
	}
	catch(err) {
		log(eval(_log.msg), true);
		return null;
	}
}

function resizeImage(link) {
	try {
		log(">");

		var copiedFile,
		copiedFilePath = null,
		result = null,
		copyResult = null,
		oldLinkFolderPath = null,
		newLinkFolderPath = null,
		imagePath = link.filePath,
		image = link.parent,
		frame = link.parent.parent,
		linkName = link.name,
		linkType = link.linkType,
		linkPlacedTimes = linkUsage(link),
		changeLinkType = (linkType == "Portable Network Graphics (PNG)" || linkType == "WEBP " || linkType == "HEIC HEIF "),
		skipThisLink = false; // skip opening it in Photoshop (used more than once and not change type)

		// The file's extension doesn't match its real type (e.g. a JPEG named *.webp) - see fixMisnamedLink()
		var fixedLink = fixMisnamedLink(link);
		if (fixedLink == null) {
			repPsError += decodeURI(linkName) + " - the file extension doesn't match the file type (" + linkType + ") and the file couldn't be copied with the correct extension\r";
			log("fixMisnamedLink failed - returning");
			log("<");
			return;
		}

		if (fixedLink.filePath != imagePath) {
			link = fixedLink;
			imagePath = link.filePath;
			image = link.parent;
			frame = link.parent.parent;
			linkName = link.name;
			log("relinked to the file with the correct extension: " + linkName);
		}

		// InDesign misreads WEBP's actual ppi (defaults it to 72 because it can't parse WEBP's
		// resolution metadata), which corrupts absoluteHorizontalScale/verticalScale/effectivePpi
		// below and leads to wrong resize results. Convert it to JPEG and relink first - JPEG's
		// resolution IS read correctly - then fall through and treat it like a normal JPEG link
		// for the rest of this function (including the real resize, done further down as usual).
		if (linkType == "WEBP ") {
			log("linkType is WEBP - converting to JPEG and relinking before reading its scale/ppi");

			var convertedLink = convertWebpLinkToJpeg(link);
			if (convertedLink == null) {
				repPsError += decodeURI(linkName) + " - error converting WEBP to JPEG before resizing\r";
				log("WEBP-to-JPEG conversion failed - returning");
				log("<");
				return;
			}

			link = convertedLink;
			imagePath = link.filePath;
			image = link.parent;
			frame = link.parent.parent;
			linkName = link.name;
			linkType = link.linkType; // now "JPEG"
			changeLinkType = (linkType == "Portable Network Graphics (PNG)" || linkType == "WEBP " || linkType == "HEIC HEIF "); // now false

			log("WEBP relinked to JPEG: " + linkName + " | linkType is now " + linkType);
		}

		log("| === Before resizing ===");
		log("| " + doc.name);
		log("| Scaling: " + Math.round(link.parent.absoluteHorizontalScale) + "% x " + Math.round(link.parent.absoluteVerticalScale) + "%");
		var dims = getPxDimensions(link); // used for log
		var msg = (dims == null) ? "N/A" : dims[0] + " x " + dims[1]; // used for log
		log("| Dimensions: " + msg);

		log("| actualPpi: " + image.actualPpi);
		log("| effectivePpi: " + image.effectivePpi);
		log("| =======================\r");
		log("changeLinkType = " + changeLinkType);

		try {
			frame.redefineScaling();
		}
		catch(err) {
			log("Error in redefineScaling - " + eval(_log.msg), true);
		}

		if (frame.locked || frame.itemLayer.locked) {
			repLocked += imagePath + "\r";
			log("frame \ layer locked - returning");
			log("<");
			return;
		}

		var horScale = Math.abs(image.absoluteHorizontalScale);
		var verScale = Math.abs(image.absoluteVerticalScale);
		var effPpi = (image.effectivePpi[0] < image.effectivePpi[1]) ? image.effectivePpi[0] : image.effectivePpi[1];

		var oldLinkFile = new File(imagePath);
		imagePath = decodeURI(oldLinkFile.absoluteURI);

		if (changeLinkType) {
			if (linkType == "Portable Network Graphics (PNG)") {
				linkName = linkName.replace(/\.[^.]+$/, ".psd");
			}
			else if (linkType == "WEBP " || linkType == "HEIC HEIF ") {
				linkName = linkName.replace(/\.[^.]+$/, ".jpg");
			}
			log("changed link name: " + linkName);
		}

		// make a copy before resizing, but except for changed link type
		if (set.resizeAsCopyCb) { // resize as copy - ON
			log("resize as copy - ON");

			if (set.imgFolderPath != "") { // hardly possible, but just in case
				log("old path = " + imagePath);
				newLinkFolderPath = decodeURI(set.imgFolderPath) + "/";
				log("newLinkFolderPath = " + newLinkFolderPath);
				copiedFilePath = newLinkFolderPath + linkName;

				log("copiedFilePath = imagePath = " + copiedFilePath);
				copiedFile = new File(copiedFilePath);

				if (!changeLinkType && linkType != "JPEG") { // don't make a copy for new formats & jpeg
					if (oldLinkFile.absoluteURI != copiedFile.absoluteURI) {
						copyResult = oldLinkFile.copy(copiedFile);
						log("copyResult = " + copyResult);
					}
					else {
						log("oldLinkFile.absoluteURI == copiedFile.absoluteURI - copyResult = " + copyResult);
					}
				}
				else {
					log("don't copy the link because it's " + link.linkType);
				}
			}
			else {
				log("set.imgFolderPath is empty line", true);
			}
		}
		else { // resize as copy - OFF
			log("resize as copy - OFF");

			if (changeLinkType || linkType == "JPEG") { // resize in the same location, but using a new name
				var oldLinkFolder = oldLinkFile.parent;
				oldLinkFolderPath = decodeURI(oldLinkFolder.absoluteURI) + "/";
				copiedFilePath = oldLinkFolderPath + linkName;
			}		
		}

		// Prepare parameters for Photoshop script =========================================
		log("| (A) === Preparing parameters for Photoshop script ===");
		var params = {
			/* 01 */ imagePath: imagePath,
			/* 02 */ copiedFilePath: copiedFilePath,
			/* 03 */ horScale: horScale,
			/* 04 */ verScale: verScale,
			/* 05 */ desiredResCb: set.desiredResCb,
			/* 06 */ desiredResolution: set.desiredRes,
			/* 07 */ resampleMethod: null,
			/* 08 */ linkType: linkType,
			/* 09 */ limitDownsampling: set.limitDownsamplingCb,
			/* 10 */ downsamplingLimit: set.downsamplingLimit,
			/* 11 */ resizeAsCopy: set.resizeAsCopyCb,
			/* 12 */ changeLinkType: changeLinkType,
			/* 13 */ oldLinkFolderPath: oldLinkFolderPath,
			/* 14 */ newLinkFolderPath: newLinkFolderPath,
			/* 15 */ dontUpsampleEnlargedImgsCb: set.dontUpsampleEnlargedImgsCb,
			/* 16 */ scalingMode: null, // 0 - 100% | 1 - reduced | 2 - enlarged | 3 - unproportional | 4 - skip resizing
			/* 17 */ linkPlacedTimes: linkPlacedTimes,
			/* 18 */ effPpi: effPpi,
			/* 19 */ dontDownsampleReducedImgsCb: set.dontDownsampleReducedImgsCb
		}
		//=================================================================================

		if (Math.round(horScale) == Math.round(verScale)) { // Proportional
			log("1) Proportional");
			if (Math.round(horScale) == 100) { // 100%
				params.scalingMode = 0;
				log("1.1) 100%");
			}
			else if (horScale < 100) { // Reduced
				log("1.2) Reduced");
				params.scalingMode = 1;

				if (effPpi < set.desiredRes && set.dontDownsampleReducedImgsCb) { // Effective resolution is less then desired
					log("1.2.1) Effective resolution is less then desired");
					params.resampleMethod = "ResampleMethod.NONE";
				}
				else { // Effective resolution is more then desired
					log("1.2.2) Effective resolution is more then desired");
					params.resampleMethod = resampleMethods[set.reducedDropDownList];
				}
			}
			else if (horScale > 100) { // Enlarged
				log("1.3) Enlarged: set.dontUpsampleEnlargedImgsCb = " + set.dontUpsampleEnlargedImgsCb);
				params.scalingMode = 2;

				if (set.dontUpsampleEnlargedImgsCb) {
					log("1.3.1) set.dontUpsampleEnlargedImgsCb ON — Without resampling");
					params.resampleMethod = "ResampleMethod.NONE";
				}
				else {
					log("1.3.2) set.dontUpsampleEnlargedImgsCb OFF");
					params.resampleMethod = resampleMethods[set.enlargedDropDownList];
				}
			}
		}
		else if ((Math.round(horScale) != Math.round(verScale)) && linkPlacedTimes) { // Not proportional
			log("2) Not proportional ...");

			if (linkPlacedTimes == 1) { // used once
				log("2.1) ... and used once");
				params.scalingMode = 3;
				
				if (horScale < 100 && verScale < 100) {
					log("2.1.1) horScale < 100 && verScale < 100");
					params.resampleMethod = resampleMethods[set.reducedDropDownList];
				}
				else if (horScale > 100 && verScale > 100) {
					log("2.1.2) horScale > 100 && verScale > 100");
					params.resampleMethod = resampleMethods[set.enlargedDropDownList];
				}
				else { // One side reduced another enlarged
					log("2.1.3) One side reduced another enlarged");
					params.resampleMethod = "ResampleMethod.BICUBIC";
				}
			}
			else if (linkPlacedTimes > 1) { // used more than once and not change type
				log("2.2) ... but used " + linkPlacedTimes + " times");

				if (changeLinkType) {
					log("2.2.1) don't resize, but save as JPEG/PSD");
					params.scalingMode = 4;
				}
				else {
					log("2.2.2) skip from opening in PS");
					skipThisLink = true;
					if (!set.resizeAsCopyCb) repSkipped += decodeURI(linkName) + " - skipped: not proportional but used " + linkPlacedTimes + " times\r";
					result = {resized: false, error: null, description: linkName + " - skipped: not proportional but used " + linkPlacedTimes + " times. ", linkTypeChanged: false, undone: false}	
				}
			}
		}

		// A JPEG already placed at 100% has nothing to resize. Without 'Resize as copy' it would only be
		// opened and recompressed in place, so don't send it to Photoshop at all (same as version 3.2).
		if (params.scalingMode == 0 && linkType == "JPEG" && !changeLinkType && !set.resizeAsCopyCb) {
			log("JPEG at 100% and resize as copy is OFF - skip opening it in PS");
			skipThisLink = true;
			result = {resized: false, error: null, description: decodeURI(linkName) + " - was not resized, as it has already been placed at 100% ", linkTypeChanged: false, undone: false, newFilePath: null}
		}

		if (!skipThisLink) {
			log("\r----------------------------------------------------\rSending the script to Photoshop\nparams = " + params.toSource() + "\r----------------------------------------------------\r");
			result = bridgeTalkMsg(params); // Bridge Talk Message
			if (result != null) {
				log("----------------------------------------------------\rGetting the result:\n" + result.toSource() + "\r----------------------------------------------------\r");
			}
		}

		log("| (B) === Postprocessing the link ===");

		if (result != null) {
			log("1) result != null");

			if (result.resized ||
				result.newFilePath != null ||
				result.linkTypeChanged || // 100% but PNG/WEBP/HEICset.resizeAsCopyCb
				set.resizeAsCopyCb // as copy
			) {
				log("1.1) result.resized or result.linkTypeChanged (100% but PNG|WEBP|HEIC)");

				if (result.error == null) { // NO error
					log("1.1.1) result.error == null");

					if (result.newFilePath != null) { // first try to relink to the savedAs file
						log("| 1.1.1.1) first try to relink to the savedAs file");

						var newFile = new File(result.newFilePath);

						if (newFile.exists) {
							log("1.1.1.1.1) newFile.exists");
							relink(link, oldLinkFile, newFile); // relink to the new file
							log("new Link = " + link.filePath);
						}
						else {
							log("1.1.1.1.2) newFile DOESN'T exist", true);
						}
					}
					else if (set.resizeAsCopyCb || changeLinkType) { // then relink to the copied file
						log("| 1.1.1.2) set.resizeAsCopyCb is ON or changeLinkType is true - relinking to the copied file");

						if (changeLinkType) {
							log("1.1.1.3) copiedFile = " + copiedFilePath);
							copiedFile = new File(copiedFilePath);
						}

						if (copiedFile.exists) {
							log("1.1.1.2.1) copiedFile.exists");
							relink(link, oldLinkFile, copiedFile); // relink to the new file
							log("new Link = " + link.filePath);
							if (skipThisLink) result.description += "It wasn't resized, but was copied and relinked.";
						}
						else {
							log("1.1.1.2.2) copiedFile DOESN'T exist", true);
						}
					}
				
					// if resized without an error, update link & if wasn't undone, set to 100%
					if (link.status == LinkStatus.LINK_OUT_OF_DATE) link = link.update();

					if (linkPlacedTimes == 1 && !result.undone) { // link placed only once and resizing wasn't undone
						setLink100pct(link);
					}

					completedLinks.push(link);
					repProcessed += result.description + "\r";
					link.insertLabel("Status", "Processed");
				
				} else { // there IS an error, add it to the report
					log("1.1.2) An error occurred while resizing the link in Photoshop: " + result.error, true);
					repPsError += result.error + "\r";
				}
			}
			else if (result.error != null) { // e.g. the file wasn't found or couldn't be opened - report it too
				log("1.2) An error occurred in Photoshop: " + result.error, true);
				repPsError += result.error + "\r";
			}

			if (!result.resized) {
				log("the link wasn't resized", false);
			}
		}
		else { // result == null - problems: log what exactly went wrong
			if (debug) $.writeln("result == null");
			log("2) result == null");
		}

		// THE END (only logs) =================================
		log("\r| === After resizing ===");
		if (result != null && result.description != "") {
			log("| Description: " + result.description);
		}
		log("| Scaling: " + Math.round(link.parent.absoluteHorizontalScale) + "% x " + Math.round(link.parent.absoluteVerticalScale) + "%");
		log("| actualPpi: " + link.parent.actualPpi);
		log("| effectivePpi: " + link.parent.effectivePpi);
		log("| =======================");
		log("<");
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

// The BridgeTalk script below runs inside Photoshop, evaluated from a plain string - it has no
// "current script" of its own, so a bare @include "log.jsxinc" can't find the file next to
// ResizeImages.jsx the way the InDesign-side @include (top of this file) can. Read the lib's
// source here (InDesign always knows its own script's folder via $.fileName) and inline it into
// the BridgeTalk script body instead, the same way resizePhotoshop/convertToJpeg get inlined below.
function getLogLibSource() {
	var libFile = new File(File($.fileName).parent.fsName + "/log.jsxinc");
	libFile.encoding = "UTF-8";
	libFile.open("r");
	var src = libFile.read();
	libFile.close();
	return src;
}

function bridgeTalkMsg(params) {
	try {
		log(">");

		var script = "",
		bridgeTalkResult = null,
		bt = new BridgeTalk();

		bt.target = "photoshop";

		// log() is called unconditionally throughout resizePhotoshop/convertToJpeg (including their
		// catch blocks), so it must always be defined on the Photoshop side, or the very first call
		// throws "log is not defined" and the whole BridgeTalk call dies. log() already no-ops
		// internally when _log.logit is false, so skip the file read then and just stub it instead.
		script += (_log.logit ? getLogLibSource() : "function log(){}") + "\r";
		script += "var _log = " + _log.toSource() + "\r";

		script += resizePhotoshop.toString() + "\r";
		script += "resizePhotoshop(" + params.toSource() + ");\r";

		bt.body = script;
		// if (debug) $.writeln(script);
		// log(script);

		bt.onResult = function(resObj) {
			if (debug) $.writeln("BridgeTalk Result: " + resObj.body);
			bridgeTalkResult = eval(resObj.body);
		}

		bt.send(100);
		log("<");
		return bridgeTalkResult;
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

function bridgeTalkConvertMsg(params) {
	try {
		log(">");

		var script = "",
		bridgeTalkResult = null,
		bt = new BridgeTalk();

		bt.target = "photoshop";

		script += (_log.logit ? getLogLibSource() : "function log(){}") + "\r";
		script += "var _log = " + _log.toSource() + "\r";

		script += convertToJpeg.toString() + "\r";
		script += "convertToJpeg(" + params.toSource() + ");\r";

		bt.body = script;

		bt.onResult = function(resObj) {
			if (debug) $.writeln("BridgeTalk Result: " + resObj.body);
			bridgeTalkResult = eval(resObj.body);
		}

		bt.send(100);
		log("<");
		return bridgeTalkResult;
	}
	catch(err) {
		log(eval(_log.msg), true);
	}
}

// Runs in Photoshop (via bridgeTalkConvertMsg). Just converts a WEBP to a same-sized, same-quality
// JPEG - no resizing here. That happens afterwards, once relinked, via the normal resizePhotoshop().
function convertToJpeg(params) {
	// see the comment in resizePhotoshop()
	app.displayDialogs = DialogModes.NO;

	try {
		log(">");

		var result = {newFilePath: null, error: null},
		file = new File(params.imagePath);

		log("file = " + decodeURI(file.absoluteURI));
		log("file.exists = " + file.exists);

		if (!file.exists) {
			result.error = file.fsName + " - wasn't opened in Photoshop because the file wasn't found";
			log(result.error, true);
			log("<");
			app.displayDialogs = DialogModes.ALL;
			return result.toSource();
		}

		var psDoc = app.open(file);
		var hasColorProfile = (psDoc.colorProfileType != ColorProfile.NONE);

		var saveOptions = new JPEGSaveOptions();
		saveOptions.quality = 12;
		saveOptions.embedColorProfile = hasColorProfile;

		psDoc.saveAs(new File(params.newFilePath), saveOptions, true);
		psDoc.close(SaveOptions.DONOTSAVECHANGES);

		result.newFilePath = params.newFilePath;

		log("result = " + result.toSource());
		log("<");
		app.displayDialogs = DialogModes.ALL;
		return result.toSource();
	}
	catch(err) {
		// psDoc is undefined if app.open() itself failed
		try {
			if (psDoc) psDoc.close(SaveOptions.DONOTSAVECHANGES);
		}
		catch(e) {}

		app.displayDialogs = DialogModes.ALL;

		var errMsg = decodeURI("ERROR: " + err.message + ", line: " + err.line);
		log(errMsg, true);
		log("<");
		return {newFilePath: null, error: errMsg}.toSource();
	}
}

function resizePhotoshop(params) {
	// Turn dialogs off in this same script, right before app.open(). Setting NO once at the start of the
	// batch via a separate BridgeTalk message isn't reliable: if NO is lost by the time this runs, a file
	// Photoshop can't open pops up the File > Open dialog and stops the batch. Dialogs are set back to ALL
	// on every exit, so Photoshop is never left at NO, even if the InDesign side crashes mid-batch.
	app.displayDialogs = DialogModes.NO;

	try {
		log(">");

		function roundString(numVal, decimals) {
			var retVal = Math.round(numVal * Math.pow(10, decimals)) + "";
			retVal = retVal.substring(0, retVal.length - decimals) + "." + retVal.substring(retVal.length - decimals);
			return retVal;
		}

		function getSaveOptions(optName, embedProfile) {
			optName = optName.toLowerCase();

			var saveOptions = null;

			if (optName == "jpg" || optName == "jpeg") {
				saveOptions = new JPEGSaveOptions();
				saveOptions.quality = 12;
				saveOptions.embedColorProfile = embedProfile;
			}
			else if (optName == "psd" || optName == "photoshop") {
				saveOptions = new PhotoshopSaveOptions();
				saveOptions.embedColorProfile = embedProfile;
			}
			else if (optName == "tif" || optName == "tiff") {
				saveOptions = new TiffSaveOptions();
				saveOptions.transparency = true;
				saveOptions.embedColorProfile = embedProfile;
			}

			return saveOptions;
		}

		var saveOptions, horScale, verScale,
		newResolution = null,
		result = {resized: false, error: null, description: "", linkTypeChanged: false, undone: false, newFilePath: null}

		// prepare settings
		// DON'T USE null FOR SCALE
		// No need to convert params.dontDownsampleReducedImgsCb, params.desiredResolution, params.effPpi, etc.
		// They come as correct data types (Boolean, Number)
		if (typeof params.horScale == "undefined" || params.horScale == null) {
			horScale = undefined;
		}
		else {
			horScale = eval(new UnitValue(params.horScale, "%"));
		}
 
		if (typeof params.verScale == "undefined" || params.verScale == null) {
			verScale = undefined;
		}
		else {
			verScale = eval(new UnitValue(params.verScale, "%"));
		}

		var resampleMethod = eval(params.resampleMethod);
		var file = new File((params.resizeAsCopy && !params.changeLinkType && params.linkType != "JPEG") ? params.copiedFilePath : params.imagePath);

		log("");
		log("| === Resizing using parameters: ===");
		log("| 01 - imagePath = " + decodeURI(params.imagePath));
		log("| 02 - copiedFilePath = " + params.copiedFilePath);
		log("| 03 - horScale = " + horScale);
		log("| 04 - verScale = " + verScale);
		log("| 05 - desiredResCb = " + params.desiredResCb);
		log("| 06 - desiredResolution = " + params.desiredResolution); // Number
		log("| 07 - resampleMethod = " + params.resampleMethod);
		log("| 08 - linkType = " + params.linkType);
		log("| 09 - limitDownsampling = " + params.limitDownsampling);
		log("| 10 - downsamplingLimit = " + params.downsamplingLimit);
		log("| 11 - resizeAsCopy = " + params.resizeAsCopy);
		log("| 12 - changeLinkType = " + params.changeLinkType);
		log("| 13 - oldLinkFolderPath = " + params.oldLinkFolderPath);
		log("| 14 - newLinkFolderPath = " + params.newLinkFolderPath);
		log("| 15 - dontUpsampleEnlargedImgsCb = " + params.dontUpsampleEnlargedImgsCb);
		log("| 16 - scalingMode = " + params.scalingMode); // 0 - 100% | 1 - reduced | 2 - enlarged | 3 - unproportional | 4 - skip resizing
		log("| 17 - linkPlacedTimes = " + params.linkPlacedTimes);
		log("| 18 - effPpi = " + params.effPpi); // Number
		log("| 19 - dontDownsampleReducedImgsCb = " + params.dontDownsampleReducedImgsCb); // Boolean
		log("| ==================================");
		log("");

		// open file
		log("file = " + decodeURI(file.absoluteURI));
		log("file.exists = " + file.exists);

		if (!file.exists) {
			result.error = file.fsName + " - wasn't opened in Photoshop because the file wasn't found";
			result.description += decodeURI(file.name) + " - wasn't opened in Photoshop because the file wasn't found ";
			log(result.error, true);
			log("<");
			app.displayDialogs = DialogModes.ALL;
			return result.toSource();
		}

		var psDoc = app.open(file);
		var oriResolution = psDoc.resolution;
		var hasColorProfile = (psDoc.colorProfileType != ColorProfile.NONE);
		result.description += decodeURI(file.name) + " - ";
		log("file was opened: " + psDoc.name);
		log("width before = " + psDoc.width.as("px"));
		log("height before = " + psDoc.height.as("px"));
		log("resolution before = " + oriResolution);

		//============ RESIZE START ===============
		log("| (1) === Resize ===");

		if (params.scalingMode < 3) { // Proportional
			log("1) Proportional");

			if (params.scalingMode == 0) { // 100%
				log("1.1) 100%");
				result.description += "was not resized, as it has already been placed at 100% ";
			}
			else if (params.scalingMode == 1) { // Reduced
				log("1.2) Reduced");
				result.description += "(reduced) ";

				// the 'Resize reduced images without resampling if effective ppi is less than desired' check box
				if (params.dontDownsampleReducedImgsCb && params.effPpi < params.desiredResolution) {
					log("1.2.1) dontDownsampleReducedImgsCb-ON and Effective resolution (" + params.effPpi + ") is less then desired resolution (" + params.desiredResolution + ") - (res = effPpi, without resampling)");
					psDoc.resizeImage(undefined, undefined, params.effPpi, resampleMethod); // NONE - same as 1.3.1
					result.resized = true;
					result.description += "was resized without resampling using the effective resolution (" + params.effPpi + ") ";
				}
				else {
					log("1.2.2) dontDownsampleReducedImgsCb-OFF | dontDownsampleReducedImgsCb-On and Effective resolution is more then desired resolution");

					if (params.desiredResCb) {
						log("1.2.2.1) params.desiredResCb - ON: use desired resolution");
						newResolution = params.desiredResolution;
					}
					else { // effPpi - makes no sence: it just adds pixels
						log("1.2.2.2) params.desiredResCb - OFF: use original (actual) resolution (" + oriResolution + ")");
						newResolution = oriResolution;
					}

					psDoc.resizeImage(horScale, verScale, newResolution, resampleMethod);
					result.resized = true;
					result.description += "was resized " + roundString(params.horScale, 2) + " x " + roundString(params.verScale, 2) + ", using the " + ((params.desiredResCb) ? "desired": "original") + " resolution " + newResolution + " ppi, " + params.resampleMethod.replace("ResampleMethod.", "") + " ";
				}
			}
			else if (params.scalingMode == 2) { // Enlarged
				log("1.3) Enlarged");
				result.description += "(enlarged) ";

				// the 'Don't resample enlarged images' check box
				if (params.dontUpsampleEnlargedImgsCb) {
					log("1.3.1) params.dontUpsampleEnlargedImgsCb - ON (res = effPpi, Without resampling)");
					psDoc.resizeImage(undefined, undefined, params.effPpi, resampleMethod); // NONE - same as 1.2.1
					result.resized = true;
					result.description += "was resized without resampling using the effective resolution (" + params.effPpi + ") ";
				}
				else {
					log("1.3.2) params.dontUpsampleEnlargedImgsCb OFF");

					if (params.desiredResCb) {
						log("1.3.2.1) params.desiredResCb - ON: use desired resolution");
						newResolution = params.desiredResolution;
					}
					else { // resolution = null (undefined)
						log("1.3.2.2) params.desiredResCb - OFF: resolution = und-ed (null)");
					}

					psDoc.resizeImage(horScale, verScale, newResolution, resampleMethod);
					result.resized = true;
					result.description += "was resized " + roundString(params.horScale, 2) + " x " + roundString(params.verScale, 2) + ((params.desiredResCb) ? " using the desired resolution " + newResolution + " ppi" : " without resampling ");
				}
			}
		}
		else if (params.scalingMode > 2) { // Not proportional
			log("2) Not proportional");
			if (params.linkPlacedTimes == 1) { // used once
				log("2) used once");
				result.description += "(not proportional and used once) ";

				if (params.desiredResCb) {
					log("2.1) params.desiredResCb - ON: use desired resolution");
					newResolution = params.desiredResolution;
				}
				else { // effPpi - makes no sence: it just adds pixels
					log("2.2) params.desiredResCb - OFF: use original (actual) resolution (" + oriResolution + ")");
					newResolution = oriResolution;
				}

				psDoc.resizeImage(horScale, verScale, newResolution, resampleMethod);
				result.resized = true;
				result.description += "was resized " + roundString(params.horScale, 2) + " x " + roundString(params.verScale, 2) + ", using the " + ((params.desiredResCb) ? "desired": "original") + " resolution " + newResolution + " ppi, " + params.resampleMethod.replace("ResampleMethod.", "") + " ";
			}
			else {
				log("2) Not proportional, but used " + params.linkPlacedTimes + " times, so skipping it");
				result.description += "not proportional, but used " + params.linkPlacedTimes + " times, so skipping it. "
			}
		}
		else {
			// some unhandled situation
			log("=== !!! Some unhandled situation !!! ===", true);
			result.description += "Some unhandled situation happened! ";
			result.error = result.description;
		}
		//============ RESIZE END ===============

		log("width after = " + psDoc.width.as("px"));
		log("height after = " + psDoc.height.as("px"));
		log("resolution after = " + psDoc.resolution);

		// limit downsampling
		if (params.scalingMode == 1 && params.limitDownsampling) {
			log("| (2) === Limit downsampling is ON ===");
			
			if (result.resized) {
				log("was resized");
				var width = psDoc.width.as("px");
				var height = psDoc.height.as("px");
				var biggerSide = (width > height) ? {name: "width", value: width} : {name: "height", value: height};
				log("biggerSide = " + biggerSide.name + " | " + biggerSide.value);

				if (biggerSide.value < params.downsamplingLimit) {
					log("1) biggerSide.value < params.downsamplingLimit, so undoing resizing and result.resized = false");
					psDoc.activeHistoryState = psDoc.historyStates[psDoc.historyStates.length - 2]; // undo resize
					result.resized = false;
					result.undone = true;

					// reset description but keep the file name
					var pipePos = result.description.indexOf(" - ");
					if (pipePos != -1) {
						result.description = result.description.substring(0, pipePos + 3) + "The resulting resolution was below the downsampling limit, so resizing was undone, ";
					}

					newResolution = (params.desiredResCb) ? params.desiredResolution : oriResolution;
					var newResComment = (params.desiredResCb) ? "desired" : "original";
					log("newResolution = " + newResolution + " (" + newResComment + ")");

					if (biggerSide.name == "width" && psDoc.width.as("px") > params.downsamplingLimit) { // resize only if new doc width > limit
						log("1.1) resizing by width");
						psDoc.resizeImage(new UnitValue(params.downsamplingLimit, "px"), undefined, newResolution, eval(params.resampleMethod));
						result.resized = true;
						result.description += "and it was resized using the horizontal scale (" + horScale + ") and the " + newResComment + " resolution (@" + newResolution + " ppi), " + params.resampleMethod.replace("ResampleMethod.", "") + " ";
					}
					else if (biggerSide.name == "height" && psDoc.height.as("px") > params.downsamplingLimit) { // resize only if new doc height > limit
						log("1.2) resizing by height");
						psDoc.resizeImage(undefined, new UnitValue(params.downsamplingLimit, "px"), newResolution, eval(params.resampleMethod));
						result.resized = true;
						result.description += "and it was resized using the vertical scale (" + verScale + ") and the " + newResComment + " resolution (@" + newResolution + " ppi), " + params.resampleMethod.replace("ResampleMethod.", "") + " ";
					}
					else {
						log("1.3) wasn't resized because resulting image became less than downsampling limit.");
						result.description += "and it wasn't resized because resulting image became less than downsampling limit. ";
					}

					log(psDoc.width.as("px") + " - width after 2nd resize attempt");
					log(psDoc.height.as("px") + " - height after 2nd resize attempt");
				}
				else {
					log("2) biggerSide.value > params.downsamplingLimit: skip it");
				}
			}
			else {
				log("wasn't resized: skip it");
			}
		}
		else {
			log("| (2) === Limit downsampling is OFF ===");
		}

		// change link type
		// always save as a copy, even if it wasn't resized
		// JPEG - resave using max. quality and stripping the profile
		if ((params.changeLinkType || params.linkType == "JPEG")) {
			log("| (3) === Change link type or JPEG ===");
			log("1) - params.changeLinkType is true, or JPEG - save as a copy");
			
			if (params.scalingMode == 4) result.description += "It wasn't resized but ";

			if (params.linkType == "JPEG" || params.linkType == "WEBP " || params.linkType == "HEIC HEIF ") { // save as JPEG
				log("1.1) - JPEG/WEBP/HEIC HEIF - save as JPEG");
				result.description += "changed link type to JPEG, ";
				saveOptions = getSaveOptions("jpg", hasColorProfile);
			}
			else if (params.linkType == "Portable Network Graphics (PNG)") { // save as PSD
				log("1.2) - PNG - save as PSD");
				result.description += "changed link type to PSD, ";
				saveOptions = getSaveOptions("psd", hasColorProfile);
			}

			if (saveOptions != null) {
				log("Saving as in: " + params.copiedFilePath);
				psDoc.saveAs(new File(params.copiedFilePath), saveOptions, true);
				psDoc.close(SaveOptions.DONOTSAVECHANGES);
				result.linkTypeChanged = true;
				result.description += "saved as a copy: " + params.copiedFilePath;
				result.newFilePath = params.copiedFilePath;
			}
			else {
				log("Can't get saveOptions", true, true);
			}

			log("| ============== END =============");
		}
		else if (result.resized) { // just save it
			log("2) - was resized: save & close");
	
			if (params.resizeAsCopy && params.copiedFilePath == params.imagePath && file.exists) {
				log("params.resizeAsCopy && params.copiedFilePath == params.imagePath && file.exists");

				var newFilePath,
				increment = 1,
				fileName = file.displayName,
				lastDot = fileName.lastIndexOf("."),
				baseName = (lastDot === -1) ? fileName : fileName.substring(0, lastDot),
				extension = (lastDot === -1) ? "" : fileName.substring(lastDot + 1);

				saveOptions = getSaveOptions(extension, hasColorProfile);

				if (saveOptions == null) { // for rarely used file formats save as PSD
					log("saveOptions == null: for rarely used file formats save as PSD");
					extension = "psd";
					saveOptions = getSaveOptions(extension, hasColorProfile);
					newFilePath = params.newLinkFolderPath + baseName + "." + extension;
					log("newFilePath = " + newFilePath);
					file = new File(newFilePath);					
				}

				while (file.exists) {
					log("file.exists");
					newFilePath = params.newLinkFolderPath + baseName + "_(" + increment++ + ")." + extension;
					log("newFilePath = " + newFilePath);
					file = new File(newFilePath);
				}

				log("Saving as in: " + newFilePath);
				psDoc.saveAs(file, saveOptions, true);
				psDoc.close(SaveOptions.DONOTSAVECHANGES);
				result.description += " - saved as a copy adding the incrementing number: " + newFilePath + " (because the 'Resize as copy' check box is ON, and the file with this name already exists in the selected folder.)";
				result.newFilePath = newFilePath;
				log("result.newFilePath = " + newFilePath);
			}
			else { 
				log("save & close");
				psDoc.save();
				psDoc.close();
			}
		}
		else {
			log("3) - else wasn't resized: close without saving");
			psDoc.close(SaveOptions.DONOTSAVECHANGES);
		}

		log("result = " + result.toSource());
		log("<");
		app.displayDialogs = DialogModes.ALL;
		return result.toSource();
	}
	catch(err) {
		// psDoc is undefined if app.open() itself failed
		try {
			if (psDoc) psDoc.close(SaveOptions.DONOTSAVECHANGES);
		}
		catch(e) {}

		app.displayDialogs = DialogModes.ALL;

		var errMsg = decodeURI("ERROR: " + params.imagePath + " - " + err.message + ", line: " + err.line);
		result.error = errMsg;
		log(errMsg);
		result.description += "was closed without saving because an error occurred ";
		log("<");
		return result.toSource();
	}
}

function setLink100pct(link) {
	try {
		log(">");

		var image = link.parent;
		if (image instanceof Image) {
			if (link.parent.absoluteHorizontalScale > 0 && link.parent.absoluteVerticalScale > 0) {
				log("setting image to 100%");
				image.absoluteHorizontalScale = 100;
				image.absoluteVerticalScale = 100;
			}
		}

		log("<");
	}
	catch(err) {
		log(eval(_log.msg), true);
	}	
}

function getSelectedLinks() {
	var links = [];

	if (app.selection.length == 1) { // one object is selected
		if (app.selection[0].constructor.name == "Image") { // one image selected with white arrow
			links.push(app.selection[0].itemLink);
		}
		else if (app.selection.length == 1 && app.selection[0].allGraphics.length == 1) { // one image selected with black arrow - that is its container
			if (app.selection[0].allGraphics[0].constructor.name == "Image") {
				links.push(app.selection[0].allGraphics[0].itemLink);
			}
		}
	}
	else if (app.selection.length > 1) { // Process all graphics in all selections
		for (var l = 0; l < app.selection.length; l++) { // loop trough all selections
			var sel = app.selection[l];
			if (sel.constructor.name == "Image") {
				links.push(sel.itemLink);
			}
			else if (sel.allGraphics.length > 0) {
				for (var m = 0; m < sel.allGraphics.length; m++) {
					try {
						var currentLink = sel.allGraphics[m].itemLink;
						links.push(currentLink);
					}
					catch(e) {
						if (debug) $.writeln("Error -- " + e.message);
					}
				}
			}
		} // end loop trough all selections
	} // end process all graphics in all selections

	return links;
}

function trimPath(path) {
	var theFile = new File(path),
	fsName = theFile.fsName;
	
	if (File.fs == "Macintosh") {
		var trimPath = "..." + fsName.split("/").splice(-3).join("/");
	}
	else if (File.fs == "Windows" ) {
		var trimPath = ((fsName.split("\\").length > 3) ? "...\\" : "") + fsName.split("\\").splice(-3).join("\\");
	}

	return trimPath;
}

function parseIntg(str) {
	var parsed = parseInt(str);
	
	if (isNaN(parsed)) {
		return 0;
	}
	else {
		return parsed;
	}
}

// Used for logging only
function getPxDimensions(link) {
	try {
		var xmp = link.linkXmp;
		var tiffNS = "http://ns.adobe.com/tiff/1.0/";
		var width = xmp.getProperty(tiffNS, "ImageWidth");
		var height = xmp.getProperty(tiffNS, "ImageLength");

		if (width == "" || height == "" ) {
			return null;
		}
		else {
			return [width, height];
		}
	}
	catch(err) {
		return null;
	}
}

function isPropAvail(obj, prop) {
	try {
		var result = eval("obj." + prop);
		return true;
	}
	catch(err) {
		return false;
	}
}

function enumName(enumObj, enumId) {
	try {
		for (var p in enumObj) {
			if (p == enumId.toString()) {
				return(p);
			}
		}

		return("N/A");
	}
	catch(err) {
		alert(err.message + ", line: " + err.line);
	}
}

function getDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " : " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " : " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}

function jumpToLink() {
	var tmpFolder = new Folder(Folder.temp.absoluteURI + "/Kasyan");
	tmpFolder.create();
	var linkJumper = File(tmpFolder.absoluteURI + "/" + tmpFileName + "temp.html");
	
	// always overwrite - in case the page is updated
	linkJumper.open("w");
	var linkBody = '<html><head><META HTTP-EQUIV=Refresh CONTENT="0; URL=https://kasyan-servetsky.github.io/indesign/image/resize_images/resize_images.html"></head><body> <p></body></html>'
	linkJumper.write(linkBody);
	linkJumper.close();

	linkJumper.execute();
}