﻿/* Copyright 2023, Kasyan Servetsky
January 21, 2023
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//---------------------------------------------------------------------------------------------------------------------------------------------------------
function InitVariables() {
	// The tags and their associated object styles
	// You can edit this variable to change the existing or add new tags
	// Read instructions and technical details here: https://bit.ly/3D6617H
	delimitersList = [ // opening tag, closing tag, object style name
		[null, null, defaultObjStyleName], // Custom tags
		["@", "@", defaultObjStyleName],
		["#", "#", defaultObjStyleName],
		["<img>", "</img>", defaultObjStyleName] // DON’T ADD A COMMA AFTER THE LAST ELEMENT: commas are used as delimiters
	];
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
var scriptName = "Place inline images in nested folders - 3.0",
sampleFileName = "SomeName.jpg",
defaultLocaleIndependentObjStyleName = "$ID/[Normal Graphics Frame]",
debug = false,
selectionList = [],
allObjectStylesList = [],
logArr = [],
countSuccess = 0,
countMissingFiles = 0,
applyObjStyles = true,
imgsFolder = null,
extStr = "jpg|jpeg|pdf|psd|png|pcx|svg|gif|ai|eps|bmp|tif|tiff", // Here you can add/remove/change image formats used throughout the script
imgsExt = eval("/\\."+ extStr + "$/i"),
doc, set, objectStyles, allObjectStyles, defaultObjStyleName, defaultObjStyle, delimitersList;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	try {
		var startTime = new Date(),
		openingTag, closingTag, item,
		imgFiles = GetFiles(imgsFolder);
		
		if (imgFiles.length == 0) ErrorExit("No images in the selected folder.", true);
		logArr.push("=========================================================\rDate & time: " + GetDate());
		logArr.push("File: " + doc.name);
		
		for (var i = 0; i < delimitersList.length; i++) {
			item = delimitersList[i];

			if (ArrayContains(i, selectionList)) {
				if (i == 0) { // custom
					openingTag = set.openingTag;
					closingTag = set.closingTag;
				}
				else {
					openingTag = item[0];
					closingTag = item[1];				
				}
			
				FindTags(openingTag, closingTag, imgFiles, item[2]);
			}
		}

		var endTime = new Date();
		var duration = GetDuration(startTime, endTime);
		
		var missingImgMsg;
		if (countMissingFiles == 0) {
			missingImgMsg = "";
		}
		else {
			missingImgMsg = countMissingFiles + ((countMissingFiles == 1) ? " image wasn't placed because it is" : " images weren't placed because they are") + " missing.";
		}		
		
		var report = ((countSuccess > 1 && countMissingFiles == 0) ? "All " : "") + countSuccess + ((countSuccess == 1) ? " image was" : " images were") + " placed. " + missingImgMsg + "\rTime elapsed: " + duration + ". ";

		logArr.push(missingImgMsg + "\r" + report + "\r=========================================================\r\r");
		if (set.log) WriteToFile(logArr.join("\r"));
		alert("Finished. " + report, scriptName);

	}
	catch(err) {
		app.findObjectPreferences = app.changeGrepPreferences  = NothingEnum.NOTHING;
		alert(err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FindTags(openingTag, closingTag, imgFiles, objStyleName) {
	var foundItems, foundItem, foundItemCont, story, ipIndex, imgFileName, imgFile, img, objStyle,
	findWhat = "(?i)(" + openingTag + ")(.+?)(\\." + extStr + "*)(" + closingTag + ")";

	app.findGrepPreferences = app.changeGrepPreferences  = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = findWhat;
	foundItems = doc.findGrep(true);
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	
	// Progress bar
	var progressWin = new Window("window", scriptName);
	var progressBar = progressWin.add("progressbar" , undefined, 0, foundItems.length);
	progressBar.preferredSize.width = 400;
	var progressTxt = progressWin.add("statictext", undefined,  "");
	progressTxt.alignment = "fill";
	progressWin.show();	

	for (var i = 0; i < foundItems.length; i++) {
		foundItem = foundItems[i];
		foundItemCont = foundItem.contents;
		story = foundItem.parentStory;
		ipIndex = foundItem.insertionPoints[0].index;
	 
		if (set.selectedTags == 0) {
			imgFileName = foundItemCont.replace(set.openingTag, "").replace(set.closingTag, "");
		}
		else {
			imgFileName = foundItemCont.replace(eval("/" + openingTag.replace("/", "\\/") + "\/g"), "").replace(eval("/" + closingTag.replace("/", "\\/") + "\/g"), "");
		}	
	
		progressBar.value = (i + 1);
		progressTxt.text = imgFileName;

		imgFile = GetFile(imgFiles, imgFileName);
		
		if (imgFile != null) {
			foundItem.remove();
			story.recompose();
			
			if (foundItem.parent instanceof Cell) {
				img = foundItem.parent.insertionPoints[ipIndex].place(imgFile)[0];
			}
			else {
				img = story.insertionPoints[ipIndex].place(imgFile)[0];
			}
			
			// Apply the object style
			if (applyObjStyles) {
				objStyle = objectStyles.itemByName(objStyleName);
				if (objStyle.isValid) {
					img.parent.applyObjectStyle(objStyle);
				}
			}
			countSuccess++;
		}
		else {
			logArr.push("File doesn't exist '" + imgFileName + "'");
			countMissingFiles++;
		}
	}

	progressWin.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetFile(files, name) {
	var file = null;
	
	for (var i = 0; i < files.length; i++) {
		if (files[i].displayName.toLowerCase() == name.toLowerCase()) {
			file = files[i];
			break;
		}
	}

	return file;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ChooseObjStyleDialog(txt, index) {
	var w = new Window("dialog", scriptName);
	
	w.p = w.add("panel", undefined, "Select object style for " + txt.replace(/\s\(.+/, ""));
	w.p.orientation = "column";
	w.p.alignment = "fill";
	w.p.alignChildren = "center";
	
	w.p.ddl = w.p.add("dropdownlist", undefined, allObjectStylesList);
	w.p.ddl.selection = 1; // [Basic Graphics Frame]

	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok"});
	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		return w.p.ddl.selection.text;
	}
	else {
		return null;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	var item, tag, match;
	var arr = [];
	var w = new Window("dialog", scriptName);

	// Images folder
	w.p1 = w.add("panel", undefined, "Images folder:");
	w.p1.alignment = "fill";
	w.p1.st = w.p1.add("statictext");
	
	if (imgsFolder == null || !imgsFolder.exists) { 
		w.p1.st.text = "No folder has been selected";
	}
	else {
		w.p1.st.text = TrimPath(imgsFolder.absoluteURI);
		w.p1.st.helpTip = decodeURI(imgsFolder.fsName);
	}

	w.p1.bt = w.p1.add("button", undefined, "Select...");
	w.p1.bt.onClick = function() {
		imgsFolder = SelectFolder(this, "Pick a folder with images.");
	}

	// Tags
	var delimitersDisplayedList = [];
	
	for (var i = 0; i < delimitersList.length; i++) {
		if (i == 0) {
			tag = "Custom";
		}
		else {
			tag = delimitersList[i][0] + sampleFileName + delimitersList[i][1];
		}
	
		item = tag;
		item += " (" + delimitersList[i][2] + ")";
		delimitersDisplayedList.push(item);
	}

	w.p2 = w.add("panel", undefined, "Tags:");
	w.p2.alignment = "fill";
	w.p2.lbox = w.p2.add("listbox", undefined, delimitersDisplayedList, {multiselect: true});
	w.p2.lbox.alignment = "fill";
	w.p2.lbox.selection = set.selectedTags;
	w.p2.lbox.onDoubleClick = function() {
		var idx = this.selection[0].index;
		var result = ChooseObjStyleDialog(this.selection[0].text, idx);

		if (result != null) {
			delimitersList[idx][2] = result;
			
			if (idx > 0) {
				this.selection[0].text = delimitersList[idx][0] + sampleFileName + delimitersList[idx][1] + " (" + result + ")";
			}
			else {
				this.selection[0].text = "Custom (" + result + ")";
			}
		}
	}
	w.p2.lbox.onChange = function() {
		selectionList = GetSelectedItems(w.p2.lbox.selection); // update list on new selection
	}

	selectionList = GetSelectedItems(w.p2.lbox.selection); // make sure it's called even if the list was't changed

	w.p2.g = w.p2.add("group");
	w.p2.g.orientation = "row";
	w.p2.g.et = w.p2.g.add("edittext", undefined, set.openingTag);
	w.p2.g.et.helpTip = "The opening custom tag";
	w.p2.g.st = w.p2.g.add("statictext", undefined,  sampleFileName);
	w.p2.g.et1 = w.p2.g.add("edittext", undefined, set.closingTag);
	w.p2.g.et1.helpTip = "The closing custom tag";
	w.p2.g.et.minimumSize.width = w.p2.g.et1.minimumSize.width = 60;
	
	// Log
	w.p3 = w.add("panel", undefined, "");
	w.p3.alignment = "fill";
	w.p3.orientation = "row";
	w.p3.alignChildren = "left";
	w.p3.cb = w.p3.add("checkbox", undefined, "Make log");
	w.p3.cb.value = set.log;
	w.p3.cb.helpTip = "Make the log file on the desktop listing unplaced images.";
	w.p3.cb.onClick = function() {
		w.p3.cb1.enabled = this.value;
	}
	w.p3.cb1 = w.p3.add("checkbox", undefined, "Open log");
	w.p3.cb1.value = set.openLog;
	w.p3.cb1.helpTip = "Open the log file automatically in the default text editor.";
	w.p3.cb1.enabled = w.p3.cb.value;

	// Buttons
	w.g = w.add("group");
	w.g.orientation = "row";
	w.g.alignment = "center";
	w.g.ok = w.g.add("button", undefined, "OK", {name: "ok" });
	w.g.ok.onClick = function() { // Use 'children[0]' because the panel is dynamically rebuilt on selecting a new folder so the original references become invalid
		if (w.p1.children[0].text == "No folder has been selected" || imgsFolder == null) {
			alert("No 'Images' folder has been selected.", scriptName, true);
			return;		
		}
		else if (selectionList.length == 0) {
			alert("No tags have been selected in the list box.", scriptName, true);
			return;
		}
		else if (ArrayContains(0, selectionList) && w.p2.g.et.text == "" && w.p2.g.et1.text == "") {
			alert("Both the opening and closing custom tags are empty", scriptName, true);
			w.p2.g.et.text = set.openingTag;
			w.p2.g.et1.text = set.closingTag;
			return;
		}
		else if (ArrayContains(0, selectionList) && w.p2.g.et.text == "" && w.p2.g.et1.text != "") {
			alert("The opening custom tag is empty", scriptName, true);
			w.p2.g.et.text = set.openingTag;
			return;
		}
		else if (ArrayContains(0, selectionList) && w.p2.g.et.text != "" && w.p2.g.et1.text == "") {
			alert("The closing custom tag is empty", scriptName, true);
			w.p2.g.et1.text = set.closingTag;
			return;
		}
		else { // everythin's OK
			for (var j = 0; j < w.p2.lbox.items.length; j++) {
				if (w.p2.lbox.items[j].selected) {
					if (w.p2.lbox.items[j].text.match(/(\()(.+)(\))/) != null && !objectStyles.itemByName(w.p2.lbox.items[j].text.match(/(\()(.+)(\))/)[2]).isValid) {
						alert("Select an available object style for '" + w.p2.lbox.items[j].text.match(/(\()(.+)(\))/)[2] + "'.", scriptName, true);
					}
				}
			}
			w.close(1);
		}
	}

	w.g.cancel = w.g.add("button", undefined, "Cancel", {name: "cancel"});
	
	var showDialog = w.show();

	if (showDialog == 1) {
		with (set) {
			imgsFolderPath = (imgsFolder != null) ? imgsFolder.absoluteURI : "";
			
			if (selectionList.length != 0) {
				selectedTags = selectionList.toString();
			}
			else {
				w.p2.lbox.selection;
			}

			openingTag = w.p2.g.et.text;
			closingTag = w.p2.g.et1.text;
			log = w.p3.cb.value;
			openLog = w.p3.cb1.value;
		}
		
		for (var a = 0; a < w.p2.lbox.items.length; a++) {
			match = w.p2.lbox.items[a].text.match(/(\()(.+)(\))/);
			
			if (match != null) {
				arr.push(match[2]);
			}
		}
	
		set.ObjStylesList = arr.join(",");

		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {   imgsFolderPath: "",
					selectedTags: null, 
					openingTag: "<MyTag>", 
					closingTag: "</MyTag>", 
					ObjStylesList: [], // list of object styles selected in the 2-nd dialog for every tag
					log: true,
					openLog: false
				};
	}

	imgsFolder = new Folder(set.imgsFolderPath);
	if (!imgsFolder.exists) {
		imgsFolder = null;
	}

	if (typeof(set.selectedTags) == "string") { // not called for the 1st time
		if (set.selectedTags == "") { // nothing was selected so empty string
			set.selectedTags = null;
		}
		else {
			set.selectedTags = set.selectedTags.split(",");
		}
	}

	if (set.ObjStylesList != "") {
		set.ObjStylesList = set.ObjStylesList.split(",");
	}
	
	return set;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelectedItems(sel) {
	var arr = [];
	
	if (sel != null) { // something is selected
		for (var i = 0; i < sel.length; i++) {
			if (sel[i].selected) {
				arr.push(sel[i].index);
			}
		}
	}

	return arr;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function SelectFolder(button, prompt) {
	var folder = Folder.selectDialog(prompt);
	
	if (folder != null) {
		var panel = button.parent;
		var window = panel.parent;
		var children = panel.children;
		var staticText = children[0];
		var button = button;
		panel.remove(staticText);
		panel.remove(button);
		staticText = panel.add("statictext", undefined, TrimPath(folder.absoluteURI));
		staticText.helpTip = decodeURI(folder.absoluteURI);
		button = panel.add("button", undefined, "Select...");
		button.onClick = function() {
			SelectFolder(this);
		}
		window.layout.layout(true);
		return folder;		
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function TrimPath(path) {
	path = decodeURI(path);
	var trimPath = ((path.split("/").length > 3) ? ".../" : "") + path.split("/").splice(-3).join("/");
	return trimPath;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetFiles(theFolder) {
	var files = [],
	fileList = theFolder.getFiles(),
	i, file;
	
	for (i = 0; i < fileList.length; i++) {
		file = fileList[i];
		if (file instanceof Folder) {
			files = files.concat(GetFiles(file));
		}
		else if (file instanceof File && file.name.match(imgsExt)) {
			files.push(file);
		}
	}

	return files;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	allObjectStyles = doc.allObjectStyles;
	objectStyles = doc.objectStyles;
	
	for (var i = 0; i < allObjectStyles.length; i++) {
		allObjectStylesList.push(allObjectStyles[i].name);
	}
	
	defaultObjStyle = doc.objectStyles.itemByName(defaultLocaleIndependentObjStyleName);
	if (defaultObjStyle.isValid) {
		defaultObjStyleName = defaultObjStyle.name;
	}
	else {
		ErrorExit("Can’t get the default object style.", true);
	}
	
	InitVariables();
	GetDialogSettings();
	
	if (set.ObjStylesList.length > 0) { // update delimitersList
		for (var j = 0; j < set.ObjStylesList.length; j++) {
			if (set.ObjStylesList[j] != "" && objectStyles.itemByName(set.ObjStylesList[j]).isValid) {
				delimitersList[j][2] = set.ObjStylesList[j];
			}
		}
	}

	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ArrayContains(obj, arr) {
    var i = arr.length;
    while (i--) {
        if (arr[i] === obj) {
            return true;
        }
    }
    return false;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function WriteToFile(text) {
	file = new File("~/Desktop/" + scriptName + ".txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text); 
	file.close();
	if (set.openLog) file.execute();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDate() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}