﻿var scriptName = "Place inline images in nested folders - 3.0";
app.insertLabel("Kas_" + scriptName, "");