﻿/* Copyright 2022, Kasyan Servetsky
October 5, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com  */
//======================================================================================
var scriptName = "Place inline images and fit - 2.1",
debugMode = false,
imgsExt = /\.jpe*g|psd|png|gif|ai|eps|bmp|tiff*$/i,
doc, set;

var fitOptions = [
	FitOptions.APPLY_FRAME_FITTING_OPTIONS,
	FitOptions.CENTER_CONTENT,
	FitOptions.CONTENT_AWARE_FIT,
	FitOptions.CONTENT_TO_FRAME,
	FitOptions.FILL_PROPORTIONALLY,
	FitOptions.PROPORTIONALLY
];

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.FAST_ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var foundItems, foundItem, file, text, img, container, gb, width, height,
		imgFile, imgFiles, imgFileName, story, ipIndex,
		imgsFolder = (debugMode) ? new Folder("~/Desktop/Pictures") : Folder.selectDialog("Choose a folder with images"),
		count = 0,
		arr = [];

		if (imgsFolder != null) {
			imgFiles = GetFiles(imgsFolder);			
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
			app.findGrepPreferences.findWhat = "@.+?@";
			foundItems = doc.findGrep(true);
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;		
			
			for (var i = 0; i < foundItems.length; i++) {
				foundItem = foundItems[i];
				imgFileName = foundItem.contents.replace(/@/g, "");
				story = foundItem.parentStory;
				ipIndex = foundItem.insertionPoints[0].index;
				file = new File(imgsFolder.fsName + "/" + imgFileName);
				imgFile = GetFile(imgFiles, imgFileName);
				
				if (imgFile != null) {
					foundItem.remove();
					story.recompose();
					
					if (foundItem.parent instanceof Cell) {
						img = foundItem.parent.insertionPoints[ipIndex].place(imgFile)[0];
					}
					else {
						img = story.insertionPoints[ipIndex].place(imgFile)[0];
					}
				
					if (story.overflows) {
						if (debugMode) $.writeln("The story overflows");
						AddPages(story);
					}
				
					container = img.parent;
					gb = container.geometricBounds;
					width = gb[3] - gb[1];
					height = gb[2] - gb[0];
					
					if (width > set.maxHeight) {
						container.geometricBounds = [ container.geometricBounds[0], 
										container.geometricBounds[1], 
										gb[0] + set.maxHeight,
										gb[3] ];
					}
				
					if (width > set.maxWidth) {
						container.geometricBounds = [ container.geometricBounds[0], 
																container.geometricBounds[1], 
																container.geometricBounds[2], 
																container.geometricBounds[1] + set.maxWidth ];
					}

					if (set.fitOption > 1) { 
						container.fit(fitOptions[set.fitOption - 2]);
					}			
				
					count++;
				}
				else {
					arr.push("File doesn't exist '" + imgFileName + "'");
				}
			}
			
			if (arr.length > 0) {
				arr.push("------------------------------------------");
				text = arr.join("\r");
				WriteToFile(text);
			}
		}
	}
	catch(err) {
		alert(err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	var etWidth = 4;
					
	var fitOptionsList = [
		"Don't fit",
		"-",
		"Use frame fitting options",
		"Center content",
		"Content-aware fit",
		"Fit content to frame",
		"Fill frame proportionally",
		"Fit content proportionally"
	];
	
	GetDialogSettings();
	var w = new Window("dialog", scriptName);
	
	w.p = w.add("panel", undefined, "");
	w.p.orientation = "column";
	w.p.alignment = "fill";
	w.p.alignChildren = "right";
	
	w.p.g = w.p.add("group");
	w.p.g.orientation = "row";
	w.p.g.st = w.p.g.add("statictext", undefined, "Max. width:");
	w.p.g.et = w.p.g.add("edittext", undefined, set.maxWidth);
	w.p.g.et.characters = etWidth;
	
	w.p.g1 = w.p.add("group");
	w.p.g1.orientation = "row";
	w.p.g1.st = w.p.g1.add("statictext", undefined, "Max. height:");
	w.p.g1.et = w.p.g1.add("edittext", undefined, set.maxHeight);
	w.p.g1.et.characters = etWidth;

	w.p.dll = w.p.add("dropdownList", undefined, fitOptionsList);
	w.p.dll.selection = set.fitOption;

	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok"});
	w.bts.ok.onClick = function() {
		if (isNaN(w.p.g.et.text)) {
			alert ("Max. width is not a number.", scriptName, true);
			w.p.g.et.text = set.maxWidth;
			return;
		}
		else if (isNaN(w.p.g1.et.text)) {
			alert ("Max. height is not a number.", scriptName, true);
			w.p.g1.et.text = set.maxHeight;
			return;
		}
		else {
			w.close(1);
		}
	}
	
	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		set.maxWidth = Number(w.p.g.et.text);
		set.maxHeight = Number(w.p.g1.et.text);
		set.fitOption = w.p.dll.selection.index;
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}	
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));

	if (set == undefined) {
		set = {maxWidth: 30, maxHeight: 20, fitOption: 0};
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetFile(files, name) {
	var file = null;
	
	for (var i = 0; i < files.length; i++) {
		if (files[i].displayName.toLowerCase() == name.toLowerCase()) {
			file = files[i];
			break;
		}
	}

	return file;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetFiles(theFolder) {
	var files = [],
	fileList = theFolder.getFiles(),
	i, file;
	
	for (i = 0; i < fileList.length; i++) {
		file = fileList[i];
		if (file instanceof Folder) {
			files = files.concat(GetFiles(file));
		}
		else if (file instanceof File && file.name.match(imgsExt)) {
			files.push(file);
		}
	}

	return files;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function WriteToFile(text) {
	var file = new File("~/Desktop/" + scriptName + ".txt");
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text + "\r"); 
	file.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddPages(story) {
	var textFrame = story.textContainers[0],
	newPage, gb, newTextFrame, currentTextFrame,
	currentPage = textFrame.parentPage;

	while (story.overflows) {
		if (debugMode) $.writeln("currentPage.name = " + currentPage.name);
		newPage = doc.pages.add(LocationOptions.AFTER, currentPage);
		currentPage = newPage;
		gb = GetBounds(currentPage);
		newTextFrame = currentPage.textFrames.add({geometricBounds: gb});
		textFrame.nextTextFrame = newTextFrame;
		textFrame = newTextFrame;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetBounds(page) {
	var X1, X2, Y1, Y2,
	pageWidth = doc.documentPreferences.pageWidth,
	pageHeight = doc.documentPreferences.pageHeight;
	
	if (page.side == PageSideOptions.LEFT_HAND || page.side == PageSideOptions.SINGLE_SIDED) {
		X1 = page.marginPreferences.right;
		X2 = pageWidth - page.marginPreferences.left;
	}
	else if (page.side == PageSideOptions.RIGHT_HAND) {
		X1 = page.marginPreferences.left + pageWidth;
		X2 = pageWidth * 2 - page.marginPreferences.right;
	}

	Y1 = page.marginPreferences.top;
	Y2 = pageHeight - page.marginPreferences.bottom;
	
	return [Y1, X1, Y2, X2];
}