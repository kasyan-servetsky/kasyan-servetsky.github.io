﻿// Assuming that current ruler units are set to millimeters
main();

function main() {
	var doc = app.activeDocument,
	row, 
	tableWidthNew = 180; // new table width in millimeters

	for (var i = 0; i < doc.stories.length; i++) {
		story = doc.stories[i];

		for (var t = 0; t < story.tables.length; t++) {
			table = story.tables[t];
			tableWidthOld = table.width;
			
			for (var c = 0; c < table.cells.length; c++) {
				cell = table.cells[c];
				cell.texts[0].appliedParagraphStyle = "text in tables"; // apply the paragraph style to the text in cells
			}

			for (var k = 0; k < table.columns.length; k++) {
				column = table.columns[k];
				column.width = column.width * (tableWidthNew)/tableWidthOld;
			}

			for (var r = 0; r < table.rows.length; r++) {
				row = table.rows[r];
				row.height = 4; // make rows 4 mm high
			}

		}
	}
}