﻿/* Copyright 2021, Kasyan Servetsky
August 6, 2021
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com

This one should be like ‘Export pages from book’, but it exports 1st page.

Export as JPEG
Quality = Maximum
Resolution = 72 */
//======================================================================================
var scriptName = "Export 1st page from book as JPEG",
book;

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var bookContent, decodedPath, doc, pageName, pageNum, jpegFilePath, jpegFile,
		bookFilePath = decodeURI(book.fullName.absoluteURI).replace(/\.indb$/i, "");
		
		with (app.jpegExportPreferences) {
			exportingSpread = false;
			jpegExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
			exportResolution = 72; // The export resolution expressed as a real number instead of an integer. (Range: 1.0 to 2400.0)
			antiAlias = true; //  If true, use anti-aliasing for text and vectors during export
			embedColorProfile = false; // True to embed the color profile, false otherwise
			jpegColorSpace = JpegColorSpaceEnum.RGB; // One of RGB, CMYK or GRAY
			jpegQuality = JPEGOptionsQuality.MAXIMUM; // The compression quality: LOW / MEDIUM / HIGH / MAXIMUM
			jpegRenderingStyle = JPEGOptionsFormat.BASELINE_ENCODING; // The rendering style: BASELINE_ENCODING or PROGRESSIVE_ENCODING
			simulateOverprint = true; // If true, simulates the effects of overprinting spot and process colors in the same way they would occur when printing
			useDocumentBleeds = false; // If true, uses the document's bleed settings in the exported JPEG.
		}
				
		for (var i = 0; i < book.bookContents.length; i++) {
			bookContent = book.bookContents[i];
			decodedPath = decodeURI(bookContent.fullName.absoluteURI);

			if (bookContent.status != BookContentStatus.MISSING_DOCUMENT && bookContent.status != BookContentStatus.DOCUMENT_IN_USE) {
				doc = app.open(new File(decodedPath));
				pageName = doc.pages[0].name;
				pageNum = (isNaN(Number(pageName))) ? pageName : ZeroPad(Number(pageName), 2); // don't add zeroes if a section prefix is added and included
				app.jpegExportPreferences.pageString = pageName;
				jpegFilePath = bookFilePath + "_page" + pageNum + ".jpg";
				jpegFile = new File(jpegFilePath);
				doc.exportFile(ExportFormat.JPG, jpegFile);				
				doc.close(SaveOptions.NO);
			}
		}
	}
	catch(err) {
		//app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ZeroPad(num, digit) {
	var tmp = num.toString();
	while (tmp.length < digit) {
		tmp = "0" + tmp;
	}
	return tmp;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.books.length == 0) ErrorExit("Please open a book and try again.", true);		
	book = app.activeBook;
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------