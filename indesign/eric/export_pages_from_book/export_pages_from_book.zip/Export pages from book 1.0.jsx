﻿/* Copyright 2021, Kasyan Servetsky
August 1, 2021
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com

From an open book, export each page as PDF (Adobe PDF preset: High Quality Print) and save in the same directory as book.
Append book name to the beginning of each filename. Example, if book filenames in book are Page01, Page02, … and book name is lexpress_v46n29 2021-07-16, then:
lexpress_v46n29 2021-07-16_Page01
lexpress_v46n29 2021-07-16_page02
…
lexpress_v46n29 2021-07-16_page10
…etc. */
//======================================================================================
var scriptName = "Export pages from book",
book;

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var bookContent, decodedPath, doc, pdfPath, pageNum,
		pdfPreset = app.pdfExportPresets.item("[High Quality Print]"),
		bookFilePath = decodeURI(book.fullName.absoluteURI).replace(/\.indb$/i, "");
		
		app.pdfExportPreferences.viewPDF = false;
		
		for (var i = 0; i < book.bookContents.length; i++) {
			bookContent = book.bookContents[i];
			decodedPath = decodeURI(bookContent.fullName.absoluteURI);

			if (bookContent.status != BookContentStatus.MISSING_DOCUMENT && bookContent.status != BookContentStatus.DOCUMENT_IN_USE) {
				doc = app.open(new File(decodedPath));
				
				for (var p = 0; p < doc.pages.length; p++) {
					pageName = doc.pages[p].name;
					pageNum = (isNaN(Number(pageName))) ? pageName : ZeroPad(Number(pageName), 2); // don't add zeroes if a section prefix is added and included
					app.pdfExportPreferences.pageRange = pageName;
					pdfPath = bookFilePath + "_page" + pageNum + ".pdf";
					pdfFile = new File(pdfPath);
					app.scriptPreferences.userInteractionLevel = UserInteractionLevels.NEVER_INTERACT;
					doc.exportFile(ExportFormat.PDF_TYPE, pdfFile, false, pdfPreset);
					app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;					
				}
				
				doc.close(SaveOptions.NO);
			}
		}
	}
	catch(err) {
		app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ZeroPad(num, digit) {
	var tmp = num.toString();
	while (tmp.length < digit) {
		tmp = "0" + tmp;
	}
	return tmp;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.books.length == 0) ErrorExit("Please open a book and try again.", true);		
	book = app.activeBook;
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------