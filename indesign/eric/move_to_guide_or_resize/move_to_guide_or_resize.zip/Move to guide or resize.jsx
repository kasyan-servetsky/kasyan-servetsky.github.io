﻿/* Copyright 2024, L'Express de Toronto Inc.
May 21, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com 

Description:
With one object selected, move the object to the nearest horizontal guide. If it is already on a guideline, do not move it. 
Then, (depending on user choice) increase or decrease the width of the object to the nearest horizontal guide. 
The script should reference the horizontal guides on the current page. 
It's like the 'Move to column or resize' script, but object should resize vertically up or down according to horizontal guides instead. */
//======================================================================================

var scriptName = "Move to guide or resize",
debug = false,
doc, item, master, storedRulerOrigin, guidePositions,
page = app.layoutWindows[0].activePage;

if (typeof arguments == "undefined") {
	if (debug) {
		var mode = "MOVE";
	}
	else {
		ErrorExit("This is a secondary script which should be run from one of the following scripts:\n• Move\n• Increase to top\n• Increase to bottom\n• Decrease to top\n• Decrease to bottom", true);
	}
}
else {
	var mode = arguments[0];
	mode = mode.toUpperCase();
	mode = mode.replace(/\s/g, "_");
}
 
PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var storedZeroPoint = null;
		
		if (doc.zeroPoint[0] != 0 || doc.zeroPoint[1] != 0) {
			storedZeroPoint = doc.zeroPoint;
			doc.zeroPoint = [0, 0];
		}

		storedRulerOrigin = doc.viewPreferences.rulerOrigin;
		doc.viewPreferences.rulerOrigin = RulerOrigin.PAGE_ORIGIN;

		var vb = item.visibleBounds,
		itemTop = RoundWithDecimal(vb[0], 4),
		itemBottom = RoundWithDecimal(vb[2], 4),
		itemHeight = itemBottom - itemTop,
		itemCenter = itemTop + itemHeight / 2,
		guideTopPos = GetArrayIndex(guidePositions, itemTop),
		guideBottomPos = GetArrayIndex(guidePositions, itemBottom),
		nearestGuidePos = GetNearestHorGuides(itemTop, itemBottom);
		
		var topDist = itemTop - nearestGuidePos.top;
		var bottomDist = nearestGuidePos.bottom - itemBottom;

		if (mode == "MOVE") {
			if (guideTopPos != -1 && guideBottomPos != -1) {
				ErrorExit("The selected object is already aligned to both the top and bottom horizontal guides.", true);
			}
			else if (guideTopPos != -1) {
				ErrorExit("The selected object is already aligned to the top horizontal guide.", true);
			}
			else if (guideBottomPos != -1) {
				ErrorExit("The selected object is already aligned to the bottom horizontal guide.", true);
			}
	
			if (topDist <= bottomDist) { // move to the top -- if closer to top, or the distance is equal both to the top and bottom
				item.move([vb[1], nearestGuidePos.top]);
			}
			else if (topDist > bottomDist) { // move to the bottom
				item.move([vb[1], nearestGuidePos.bottom - itemHeight]);
			}
		}

		if (mode == "INCREASE_TO_TOP") {
			item.visibleBounds = [nearestGuidePos.top, vb[1], vb[2], vb[3]];
		}

		if (mode == "INCREASE_TO_BOTTOM") {
			item.visibleBounds = [vb[0], vb[1], nearestGuidePos.bottom, vb[3]];
		}

		if (mode == "DECREASE_TO_TOP") {
			if (guideTopPos != -1) { // alighned to top
				var newTopPosIndex = GetArrayIndex(guidePositions, itemTop) + 1;
			}
			else { // NOT alighned to top
				if (itemTop > guidePositions[0]) { // withing page
					var newTopPosIndex = GetArrayIndex(guidePositions,  nearestGuidePos.top) + 1;
				}
				else {
					var newTopPosIndex = 0; // on the pasteboard
				}
			}

			var newTopPos = null;
			
			if (newTopPosIndex < guidePositions.length) {
				newTopPos = guidePositions[newTopPosIndex];
			}
			 
			if (newTopPos != null && newTopPos < itemBottom) {
				item.visibleBounds = [newTopPos, vb[1], vb[2], vb[3]];
			}
			else {
				ErrorExit("No more space left to decrease the selected object.", true);
			}		
		}

		if (mode == "DECREASE_TO_BOTTOM") {
			if (guideBottomPos != -1) { // alighned to bottom
				var newBottomPosIndex = GetArrayIndex(guidePositions, itemBottom) - 1;
			}
			else { // NOT alighned to bottom
				if (itemBottom < guidePositions[guidePositions.length - 1]) { // withing page
					var newBottomPosIndex = GetArrayIndex(guidePositions,  nearestGuidePos.bottom) - 1;
				}
				else { // on the pasteboard
					var newBottomPosIndex = guidePositions.length - 1;
				}
			}

			var newBottomPos = null;
			
			if (newBottomPosIndex < guidePositions.length) {
				newBottomPos = guidePositions[newBottomPosIndex];
			}

			if (newBottomPos != null && newBottomPos > itemTop) {
				item.visibleBounds = [vb[0], vb[1], newBottomPos, vb[3]];
			}
			else {
				ErrorExit("No more space left to decrease the selected object.", true);
			}
		}
	
		if (storedZeroPoint != null) doc.zeroPoint = storedZeroPoint;
		doc.viewPreferences.rulerOrigin = storedRulerOrigin;
	}
	catch(err) {
		if (storedZeroPoint != null) doc.zeroPoint = storedZeroPoint;
		if (typeof storedRulerOrigin != "undefined") doc.viewPreferences.rulerOrigin = storedRulerOrigin;
		alert("Something went wrong. Error: " + err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetNearestHorGuides(itemTop, itemBottom) {
	var nearestTopGuidePos, nearestBottomGuidePos;

	// Top
	for (var t = 0; t < guidePositions.length; t++) {
		nearestTopGuidePos = guidePositions[t];
		
		if (guidePositions[t] >= itemTop) {
			if (t != 0) nearestTopGuidePos = guidePositions[t - 1];
			break;
		}
	}

	// Bottom
	for (var b = guidePositions.length - 1; b >= 0; b--) {
		nearestBottomGuidePos = guidePositions[b];
		
		if (guidePositions[b] <= itemBottom) {
			if (b != guidePositions.length - 1) nearestBottomGuidePos = guidePositions[b + 1];
			break;
		}
	}

 	return {top: nearestTopGuidePos, bottom: nearestBottomGuidePos};
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetArrayIndex(arr, val) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] == val) {
			return i;
		}
	}
	return -1;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetHorGuides() {
	var guide,
	guides = master.guides,
	arrLocation = [];
	
	for (var i = 0; i < guides.length; i++) {
		guide = guides[i];
		
		if (guide.orientation == HorizontalOrVertical.HORIZONTAL) {
			arrLocation.push(RoundWithDecimal(guide.location, 4));
		}
	}
	
	arrLocation.sort(function(a, b){return a-b});
	
	return arrLocation;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function RoundWithDecimal(number, decimals) {
	var multiplier = Math.pow(10, decimals);
	return Math.round(number * multiplier) / multiplier;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	if (app.selection.length == 0) {
		ErrorExit("Nothing is selected.", true);
	}
	else if (app.selection.length > 1) {
		ErrorExit("Only one object should be selected.", true);
	}
	else if (!app.selection[0].hasOwnProperty("geometricBounds")) {
		ErrorExit("Invalid selection.", true);
	}
	else {
		item = app.selection[0];
	}

	if (page.appliedMaster == null) {
		ErrorExit("You are on a master page. Go to a regular page and try again.", true);
	} 
	else {
		master = page.appliedMaster;
	}

	guidePositions = GetHorGuides();
	if (guidePositions.length == 0) {
		ErrorExit("There’s no horizontal guide on the active page..", true);
	}

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	if (typeof storedRulerOrigin != "undefined") doc.viewPreferences.rulerOrigin = storedRulerOrigin;
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
