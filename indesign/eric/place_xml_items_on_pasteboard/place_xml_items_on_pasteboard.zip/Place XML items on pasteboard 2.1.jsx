﻿/* Copyright 2024, Kasyan Servetsky
May 18 2024
Written by Kasyan Servetsky   
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com

I am going to switch to a single page document for my publication instead of using a book with for each page.
This affects the Place XML items on pasteboard script because items are always pasted on left side pages.
 
Here are the requested changes:
•	When in a page or when a page is selected from the Pages panel, paste to the outside of that page.
•	If pictures pasted on the pasteboard exceed the height of the document, then move those pictures to the outside. See screenshots 

05/05/24
Update: Place XML items on pasteboard
Currently the script places the XML items starting from Y coordinates of 1.561 in.
It should place them starting from the top most horizontal guide. */
//======================================================================================
var scriptName = "Place XML items on pasteboard", 
debug = false, // ($.getenv("USERNAME") == "kas") ? true : 
page = app.layoutWindows[0].activePage;

if (page.appliedMaster == null) {
	ErrorExit("You are on a master page. Go to a regular page and try again.", true);
}  

var master = page.appliedMaster,
isVerso = (page.side == PageSideOptions.LEFT_HAND) ? true : false,
pageBounds = page.bounds,
topBound = GetTopBound(master); // top bound of the title and the 1-st image - was 0.9167

if (topBound == null) {
	ErrorExit("The script can’t get the topmost guide. Probably, the applied master page has no guides.", true);
}
//======================================================================================
// Change the parameters below, if the need arises
var xslFilePath = "~/Documents/L'Express/InDesign/XSLT/convertv17.xsl", // path to the XSL file
leftPicsBound = -8.7534, // the left edge of  the image
spaceTitleText = 0.1839, // vertical space between title and text
spaceImageText = 0.1566,  // horizontal space between images and captions/text
imageFrameWidth = 2.0354, // width of each image = 2 columns
spaceImageCaption = 0.1443, // vertical space between the image and text
textFramesWidth = 6.4213, // width of title and text frames = 4 columns
imageFrameDefaultHeight = 7.874, // default height to fit the highest possible image
textFrameDefaultHeight = 1.9685, // starting height of text frames
shiftFromPage = 0.1398,  // shift from the page
// Don’t change anything below this line
//======================================================================================
glueFile = new File(app.filePath + "/Scripts/XML Rules/glue code.jsx"),
articleXml = null, 
titleXml = null,
textXml = null, 
pictureArr = [],
objStImage, objStCaption, objStTitle, objStText, // object styles
doc, xslFile;

app.doScript(glueFile, ScriptLanguage.JAVASCRIPT);
app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");

//===================================== FUNCTIONS ======================================
function Main() {
	var titleTextFrameBounds, leftTextBound,
	savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits, // Save & change units
	savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
	
	doc.viewPreferences.horizontalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.INCHES;

	try {
		if (doc.extractLabel("Kas_" + scriptName + "XMLTagsToStylesAreMapped") != "true") {
			doc.mapXMLTagsToStyles();
			doc.insertLabel("Kas_" + scriptName + "XMLTagsToStylesAreMapped", "true");
		}

		// place Title
		if (titleXml != null && textXml != null) {
			if (isVerso) {
				leftTextBound = pageBounds[1] - shiftFromPage - textFramesWidth;
			}
			else { // recto
				leftTextBound = pageBounds[3] + shiftFromPage;
			}

			var titleTextFrame = titleXml.placeIntoFrame(page, [topBound, leftTextBound, topBound + textFrameDefaultHeight, leftTextBound + textFramesWidth]); // [y1, x1, y2, x2]
			titleTextFrame.applyObjectStyle(objStTitle);
			titleTextFrame.recompose();
			titleTextFrame.fit(FitOptions.FRAME_TO_CONTENT);
			
			titleTextFrameBounds = {
				top: titleTextFrame.geometricBounds[0],
				bottom: titleTextFrame.geometricBounds[2], 
				left: titleTextFrame.geometricBounds[1],
				right: titleTextFrame.geometricBounds[3],
				width: (titleTextFrame.geometricBounds[3] - titleTextFrame.geometricBounds[1]),
				height: (titleTextFrame.geometricBounds[2] - titleTextFrame.geometricBounds[0])
			}
		
			if (debug) {
				$.writeln("================\ntitleTextFrameBounds");
				$.writeln("isVerso = " + isVerso);
				with (titleTextFrameBounds) {
					$.writeln("top = " + Round(top, 2)); 
					$.writeln("bottom = " + Round(bottom, 2));
					$.writeln("left = " + Round(left, 2));
					$.writeln("right = " + Round(right, 2));
					$.writeln("width = " + Round(width, 2));
					$.writeln("height = " + Round(height, 2));
				}
			}
		
			// place Text
			var textTextFrame = textXml.placeIntoFrame(page, [titleTextFrameBounds.bottom + spaceTitleText, titleTextFrameBounds.left, titleTextFrameBounds.bottom + 305, titleTextFrameBounds.right]); // [y1, x1, y2, x2]
			textTextFrame.applyObjectStyle(objStText);
			textTextFrame.recompose();
			textTextFrame.fit(FitOptions.FRAME_TO_CONTENT);	
		}
 
		ProcessPictures(titleTextFrameBounds);
		
		// Restore units 
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits; 
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
	} 
	catch(err) {
		// Restore units in case of an error
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------- 
function ProcessPictures(titleTextFrameBounds) {
	var xmlElPicture, xmlElImage, xmlElCaption, imageFrame, captionTextFrame, imageFrameBounds, captionTextFrameBounds;
	var pageHeight = pageBounds[2] - pageBounds[0];
	var pageBottom = pageBounds[2];
	var leftPicsBoundReset = false;
	
	for (var i = 0; i < pictureArr.length; i++) {
		xmlElPicture = pictureArr[i];
		xmlElImage = xmlElPicture.xmlElements.item("Image");
		xmlElCaption = xmlElPicture.xmlElements.item("Caption");
		if (i == 0) topPicBound = topBound;
		
		if (debug) {
			$.writeln("\n-------- # " + (i + 1) + " --------");
			$.writeln(xmlElCaption.xmlContent.contents);			
			var str = decodeURI(xmlElImage.xmlAttributes.itemByName("href").value);
			var arr = str.split("/");
			var name = arr[arr.length - 1];
			$.writeln(name);
		}

		if (!leftPicsBoundReset) {
			leftPicsBound = (isVerso) ? titleTextFrameBounds.left - imageFrameWidth - spaceImageText : titleTextFrameBounds.right + spaceImageText;
		}

		try {
			imageFrame = xmlElImage.placeIntoFrame(page, [topPicBound, leftPicsBound, topPicBound + imageFrameDefaultHeight, leftPicsBound + imageFrameWidth]); // [y1, x1, y2, x2]
		}
		catch(err) { 
			continue;
		}

		imageFrame.fit(FitOptions.PROPORTIONALLY); 
		imageFrame.fit(FitOptions.FRAME_TO_CONTENT);
		imageFrame.applyObjectStyle(objStImage);
		
		if (i == 0) { // the1st element
			if (debug) $.writeln("=== first image ===");
			imageFrame.move([leftPicsBound, topPicBound]); // [x, y]
		}
		else {
			if (imageFrame.geometricBounds[2] < pageBottom) {
				if (debug) $.writeln("=== whithin page height ===");
				imageFrame.move([leftPicsBound, captionTextFrameBounds.bottom + spaceImageCaption]);
			}
			else {
				if (debug) $.writeln("=== exceeds page height ===");
			}
		}

		imageFrameBounds = {        
			top: imageFrame.geometricBounds[0],
			bottom: imageFrame.geometricBounds[2],
			left: imageFrame.geometricBounds[1],
			right: imageFrame.geometricBounds[3],
			width: (imageFrame.geometricBounds[3] - imageFrame.geometricBounds[1]), 
			height: (imageFrame.geometricBounds[2] - imageFrame.geometricBounds[0])
		}
	
		if (debug) {
			$.writeln("----------------\nimageFrameBounds");
			with (imageFrameBounds) {
				$.writeln("top = " + Round(top, 2));
				$.writeln("bottom = " + Round(bottom, 2));
				$.writeln("left = " + Round(left, 2));
				$.writeln("right = " + Round(right, 2)); 
				$.writeln("width = " + Round(width, 2));
				$.writeln("height = " + Round(height, 2));
			}
		}

		if (imageFrame.geometricBounds[2] > pageBottom) {
			leftPicsBound = (isVerso) ? imageFrameBounds.left - spaceImageText - imageFrameWidth : imageFrameBounds.right + spaceImageText;
			leftPicsBoundReset = true; // reset left bound 
			topPicBound = topBound; // reset top bound 
			imageFrame.move([leftPicsBound, topPicBound]); // [x, y]
			
			imageFrameBounds = {
				top: imageFrame.geometricBounds[0],
				bottom: imageFrame.geometricBounds[2],
				left: imageFrame.geometricBounds[1],
				right: imageFrame.geometricBounds[3],
				width: (imageFrame.geometricBounds[3] - imageFrame.geometricBounds[1]),
				height: (imageFrame.geometricBounds[2] - imageFrame.geometricBounds[0])
			}
		
			if (debug) {
				$.writeln("=== reset and moved ===\nimageFrameBounds");
				with (imageFrameBounds) {
					$.writeln("top = " + Round(top, 2));
					$.writeln("bottom = " + Round(bottom, 2));
					$.writeln("left = " + Round(left, 2));
					$.writeln("right = " + Round(right, 2));
					$.writeln("width = " + Round(width, 2));
					$.writeln("height = " + Round(height, 2));
				}
			}
		}
		//============================================================== 
		captionTextFrame = xmlElCaption.placeIntoFrame(page, [
																			imageFrameBounds.bottom, // top
																			leftPicsBound, // left
																			imageFrameBounds.bottom + textFrameDefaultHeight, // bottom
																			leftPicsBound + imageFrameWidth // right
																		]); // [y1, x1, y2, x2]
		
		captionTextFrame.applyObjectStyle(objStCaption);
		captionTextFrame.recompose();
		captionTextFrame.fit(FitOptions.FRAME_TO_CONTENT);
	
		if (!ApproximatelyEquals(captionTextFrame, imageFrameWidth, 0.0394)) {
			captionTextFrame.geometricBounds = [ captionTextFrame.geometricBounds[0],
																captionTextFrame.geometricBounds[1],
																captionTextFrame.geometricBounds[2],
																captionTextFrame.geometricBounds[1] + imageFrameWidth
																];
		}

		captionTextFrameBounds = {
			top: captionTextFrame.geometricBounds[0],
			bottom: captionTextFrame.geometricBounds[2],
			left: captionTextFrame.geometricBounds[1],
			right: captionTextFrame.geometricBounds[3],
			width: (captionTextFrame.geometricBounds[3] - captionTextFrame.geometricBounds[1]),
			height: (captionTextFrame.geometricBounds[2] - captionTextFrame.geometricBounds[0])
		}
		
		if (debug) {
			$.writeln("----------------\ncaptionTextFrameBounds");
			with (captionTextFrameBounds) {
				$.writeln("top = " + Round(top, 2));
				$.writeln("bottom = " + Round(bottom, 2));
				$.writeln("left = " + Round(left, 2));
				$.writeln("right = " + Round(right, 2));
				$.writeln("width = " + Round(width, 2));
				$.writeln("height = " + Round(height, 2));
			}
		}
	}
}		
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ApproximatelyEquals(value1, value2, acceptableDifference) {
	return Math.abs(value1 - value2) <= acceptableDifference; 
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true); 
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (!glueFile.exists) ErrorExit("\"glue code.jsx\" should be located in the \"Scripts > XML rules\" folder for this script to work.", true);

	if (doc.activeLayer.locked) { // Make sure the layer is unlocked
		ErrorExit("The active layer - " + doc.activeLayer.name + " - is locked. Unlock it or select another one.", true);
	}

	// Check object styles 
	objStImage = doc.objectStyles.itemByName("image");
	if (!objStImage.isValid) ErrorExit("Object style 'image' is missing in the current document.", true);
	
	objStCaption = doc.objectStyles.itemByName("caption");
	if (!objStCaption.isValid) ErrorExit("Object style 'caption' is missing in the current document.", true);

	objStTitle = doc.objectStyles.itemByName("title");
	if (!objStTitle.isValid) ErrorExit("Object style 'title' is missing in the current document.", true);
	
	objStText = doc.objectStyles.itemByName("text");
	if (!objStText.isValid) ErrorExit("Object style 'text' is missing in the current document.", true);
	
	xslFile = new File(xslFilePath);
	if (!xslFile.exists) ErrorExit("The XSL file doesn't exist: " + xslFilePath, true);
	
	var rootXml = doc.xmlElements[0];

	if (rootXml.xmlElements.length == 0) { // the XML structure is not loaded yet
		LoadXML();
		CheckXmlStructure(rootXml);
	}
	else  { // the XML structure is already loaded
		CheckXmlStructure(rootXml);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckXmlStructure(rootXml) {
	var articleXmlArr = rootXml.evaluateXPathExpression("//article");
	
	if (articleXmlArr.length == 0) { // No 'article' elements
		ErrorExit("No 'article' elements in the XML structure.", true);
	}
	else if (articleXmlArr.length == 1) { // no need to select anything: only one 'article' element
		articleXml = articleXmlArr[0];
	}
	else if (articleXmlArr.length > 1) { // a few 'article' elements
		// correct selection
		if (app.selection.length == 1 && app.selection[0] instanceof XMLElement && app.selection[0].markupTag.name == "article") {
			articleXml = app.selection[0];
		}
		else if (app.selection.length == 0) { // Nothing is selected
			ErrorExit("Nothing is selected. Select one of the " + articleXmlArr.length +  " 'article' elements in the XML structure and try again", true);
		}
		else { // Wrong selection
			ErrorExit("Wrong selection: select one of the " + articleXmlArr.length +  " 'article' elements in the XML structure and try again.", true);
		}
	}	
	
	if (articleXml != null) {
		var titleArr = articleXml.evaluateXPathExpression("//h1");
		
		if (titleArr.length == 1) {
			titleXml = titleArr[0];
		}
		else if (titleArr.length == 0) {
			ErrorExit("No 'h1' element in the 'article' element.", true);
		}
		else {
			ErrorExit("There are " + titleArr.length + " 'h1' elements in the 'article' element: must be only one.", true);
		}

		var textArr = articleXml.evaluateXPathExpression("//content");

		if (textArr.length == 1) {
			textXml = textArr[0];
		}
		else if (textArr.length == 0) {
			ErrorExit("No 'content' element in the 'article' element.", true);
		}
		else {
			ErrorExit("There are " + textArr.length + " 'content' elements in the 'article' element: must be only one.", true);
		}

		pictureArr = articleXml.evaluateXPathExpression("//Picture"); // global

		if (pictureArr.length == 0) {
			ErrorExit("No 'content' element in the 'article' element.", true);
		}
	
		Main();
	}
	else  {
		ErrorExit("Something unforeseen occurred.", true);
	}	
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetTopBound(master) {
	var guide,
	top = null,
	guides = master.guides;
	
	for (var i = 0; i < guides.length; i++) {
		guide = guides[i];
		
		if (guide.orientation == HorizontalOrVertical.HORIZONTAL) {
			if (top == null || guide.location < top) {
				top = guide.location;
			}
		}
	}
	
	return top;
}
//===================================== Import XML and apply XSL ======================================
function LoadXML() {
	var xmlFile = File.openDialog("Choose an XML file", (File.fs == "Macintosh") ? FileFilter : "XML files:*.xml;All files:*.*");

	if (xmlFile != null && xmlFile.exists) {
		SetXMLPrefs();
		doc.importXML(xmlFile);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function SetXMLPrefs() {
	var xmlImportPreferences = doc.xmlImportPreferences;
	xmlImportPreferences.importStyle = XMLImportStyles.APPEND_IMPORT;
	xmlImportPreferences.allowTransform = true;
	xmlImportPreferences.transformFilename = xslFile;
	xmlImportPreferences.importCALSTables = true;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FileFilter(file) {
	var extention = ".xml";
	var lowerCaseName = file.name;
	lowerCaseName.toLowerCase();
	
	if (lowerCaseName.indexOf(extention) == file.name.length - extention.length) {
		return true;
	}
	else if (file instanceof Folder) {
		return true;
	}
	else {
		return false;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Round(number, decimals) {
    var multiplier = Math.pow(10, decimals);
    return Math.round(number * multiplier) / multiplier;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------