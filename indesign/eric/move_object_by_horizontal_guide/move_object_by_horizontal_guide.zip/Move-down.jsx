﻿var scriptName = "Move object by horizontal guide",
scriptFile = new File(app.activeScript.parent.absoluteURI + "/" + "Move object by horizontal guide.jsx");

if (scriptFile.exists) {
	app.doScript(scriptFile, ScriptLanguage.JAVASCRIPT, [true], UndoModes.ENTIRE_SCRIPT, "'\'" + scriptName + "\" script");
}
else {
	alert("The '" + scriptName + "' script should be located in the same folder as this script.", scriptName, true);
}