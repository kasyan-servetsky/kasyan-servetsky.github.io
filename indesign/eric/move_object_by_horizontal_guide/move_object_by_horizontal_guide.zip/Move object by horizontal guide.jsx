﻿/* Copyright 2024, L'Express de Toronto Inc.
May 23, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com

Warning: this script should be run from the 'Move-down/up.jsx'  */
//======================================================================================
var scriptName = "Move object by horizontal guide",
debug = false,
doc, master, selectedItems,
page = app.layoutWindows[0].activePage;

if (typeof arguments == "undefined") {
	ErrorExit("This script should be run from the 'Move-moveDown/down.jsx' script.", true);
}
else {
	var moveDown = arguments[0];
}

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	try {	
		var item, vb, height, oldPosition, newPosition;

		var guidePositions = GetHorGuides();
		
		for (var i = 0; i < selectedItems.length; i++) {
			item = selectedItems[i];

			vb = item.visibleBounds;
			height = RoundWithDecimal(vb[2] - vb[0], 4);
			oldPosition = (moveDown) ? vb[2] : vb[0];

			newPosition = GetNewPosition(guidePositions, oldPosition, height);
		
			if (newPosition != null) {
				item.move([vb[1], newPosition], undefined);
			}
		}		
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetHorGuides() {
	var guide, i,
	guides = master.guides,
	arrLocation = [];
	
	for (i = 0; i < guides.length; i++) {
		guide = guides[i];
		
		if (guide.orientation == HorizontalOrVertical.HORIZONTAL) {
			arrLocation.push(guide.location);
		}
	}

	guides = page.guides;
	
	for (i = 0; i < guides.length; i++) {
		guide = guides[i];
		
		if (guide.orientation == HorizontalOrVertical.HORIZONTAL) {
			arrLocation.push(guide.location);
		}
	}	

	arrLocation.sort(function(a, b){return a-b});
	
	return arrLocation;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetNewPosition(guidePositions, oldPosition, height) {
	var guidePosition,
	oldPosition = RoundWithDecimal(oldPosition, 4),
	newPosition = null;

	if (moveDown) { // down
		for (var i = 0; i < guidePositions.length; i++) {
			guidePosition = RoundWithDecimal(guidePositions[i], 4);

			if (guidePosition > oldPosition) {
				newPosition = guidePosition - height;
				break;
			}
		}
	}
	else { // up
		for (var i = guidePositions.length - 1; i >= 0; i--) {
			guidePosition = RoundWithDecimal(guidePositions[i], 4);
			
			if (guidePosition < oldPosition) {
				newPosition = guidePosition;
				break;
			}
		}		
	}

	return newPosition;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelection() {
	var selection = app.selection,
	selectedItems = [];
	
	for (var i = 0; i < selection.length; i++) {
		if (selection[i].hasOwnProperty("geometricBounds")) {
			selectedItems.push(selection[i]);
		}
	}

	return selectedItems;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function RoundWithDecimal(number, decimals) {
	var multiplier = Math.pow(10, decimals);
	return Math.round(number * multiplier) / multiplier;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	selectedItems = GetSelection();
	if (selectedItems.length == 0) ErrorExit("Invalid selection.", true);
	
	if (page.appliedMaster == null) {
		ErrorExit("You are on a master page. Go to a regular page and try again.", true);
	} 
	else {
		master = page.appliedMaster;
	}
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}