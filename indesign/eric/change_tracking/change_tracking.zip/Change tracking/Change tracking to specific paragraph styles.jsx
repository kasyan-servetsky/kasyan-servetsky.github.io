﻿/* Copyright 2021, Kasyan Servetsky
June 13, 2021
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Change tracking to specific paragraph styles",
doc;

if (typeof arguments == "undefined") {
	ErrorExit("This script should be run from the 'Increase tracking' or 'Decrease tracking' script located in the same folder.", true);
}
var mode = arguments[0];

PreCheck();

//===================================== FUNCTIONS ======================================
function Main(parStylesList) {
	try {
		var parStyle, foundItems, item, textStyleRange,
		count = 0;
		
		for (var i = 0; i < parStylesList.length; i++) {
			parStyle = doc.paragraphStyles.itemByName(parStylesList[i]);
			
			if (parStyle.isValid) {
				app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
				app.findTextPreferences.appliedParagraphStyle = parStyle;
				foundItems = txt.findText();
				app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
				
				for (var f = 0; f < foundItems.length; f++) {
					item = foundItems[f];

					for (var t = 0; t < item.textStyleRanges.length; t++) {
						textStyleRange = item.textStyleRanges[t];
						textStyleRange.tracking = eval(textStyleRange.tracking + mode);
						count++;
					}
				}
			}
		}
	
		if (count == 0) {
			alert("No changes have been made.", scriptName, false);
		}
	}
	catch(err) {
		alert(err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	if (app.selection.length > 1) ErrorExit("Some text or a text frame should be selected, or place the cursor into the text.", true);
	
	var sel = app.selection[0];

	if (sel.hasOwnProperty("baseline")) { // text selected
		if (sel instanceof InsertionPoint) { // cursor placed
			txt = sel.parentStory;
		}
		else {
			txt = sel;
		}
	}
	else if (sel instanceof TextFrame) { // text frame selected
		txt = sel.parentStory;
	}
	else { // wrong selection
		ErrorExit("Some text or a text frame should be selected, or place the cursor into the text.", true);
	}

	var activeScript = GetActiveScript();
	var scriptFolder = activeScript.parent;
	var scriptFolderPath = decodeURI(scriptFolder.absoluteURI);
	var parStylesListFilePath = scriptFolderPath + "/ParagraphStylesList.txt";
	var parStylesListFile = new File(parStylesListFilePath);
	var message = "The file 'ParagraphStylesList.txt', required by this script, doesn’t exist in the same folder.\rDo you want to create it automatically?\rIf you click 'Yes', the script will create and open it in the default application for txt-files. Then edit the list of paragraph styles, save, close the file and run the script again.";
	
	if (!parStylesListFile.exists) { // create the ParagraphStylesList.txt file
		if (confirm(message, false, scriptName)) {
			parStylesListFile.encoding = "UTF-8";
			parStylesListFile.open("w");
			parStylesListFile.write("Paragraph Style 1\rParagraph Style 2"); 
			parStylesListFile.close();
			parStylesListFile.execute();
		}
	}
	else {
		var parStylesListStr = ReadTxtFile(parStylesListFile);
		var parStylesList = parStylesListStr.split(/\n/);

		if (parStylesList.length == 0 || parStylesList.join(" ").replace(/\s+/g, "") == "") { // empty or only wite spaces: e,g, returns
			ErrorExit("The file 'ParagraphStylesList.txt' should not be empty.", true);
		}
		else {
			Main(parStylesList);
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetActiveScript() {
    try {
        return app.activeScript;
    }
    catch(err) {
        return new File(err.fileName);
    }
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ReadTxtFile(file) {
	file.open("r"); 
	var txt = file.read();
	file.close();
	return txt;
}