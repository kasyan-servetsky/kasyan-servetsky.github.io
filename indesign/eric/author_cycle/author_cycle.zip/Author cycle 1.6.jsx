﻿/* Copyright 2023, Kasyan Servetsky
March 19, 2023
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com

The latest version and description is here:
http://kasyan.ho.ua/indesign/eric/author_cycle/author_cycle.html

21.04.22 - This is a request for a revision to the Author cycle script.
The author snippet should be placed at the top left corner of the selected window (screenshot of desired placement is attached).

17.03.23 - On facing pages (spreads) on odd pages (3, 5, 7, etc.) author snippets are placed on the pasteboard. 
The Y coordinate looks good good, but the x is on the pasteboard.
*/
//======================================================================================
var scriptName = "Author cycle",
doc, story, folderPath_authors, textFrameContent,
xmlElArticle, xmlElContent, xmlAttrAuthor,
parSt_author, parSt_authorDetail, parSt_authorEnd;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");
   
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var snippetBox, firstChar, lastChar, textRange;
	
		// Attributes
		var xmlAttrAuthorDetail = xmlElArticle.xmlAttributes.item("authorDetail");
		var authorDetailExists = (xmlAttrAuthorDetail.isValid && xmlAttrAuthorDetail.value != "") ? true : false;
		
		// Elements
		var xmlElAuthor = GetNestedXmlElement(xmlElContent, "author");
		var xmlElAuthorDetail = GetNestedXmlElement(xmlElContent, "authorDetail");		
		var page = app.layoutWindows[0].activePage;

		// Tags - create if missing
		var xmlTagAuthor = doc.xmlTags.item("author");
		if (!xmlTagAuthor.isValid) {
			xmlTagAuthor = doc.xmlTags.add("author", UIColors.BURGUNDY);
		}
		
		var xmlTagAuthorDetail = doc.xmlTags.item("authorDetail");
		if (!xmlTagAuthorDetail.isValid) {
			xmlTagAuthorDetail = doc.xmlTags.add("authorDetail", UIColors.FIESTA);
		}

		var snippetFilePath = folderPath_authors +  xmlAttrAuthor.value + ".idms";
		var snippetFile = new File(snippetFilePath);
		
		if (story.label == "" || story.label == "4" || (story.label == "3" && authorDetailExists && !snippetFile.exists)) { // 1-st cycle
			if (story.label == "4") { // Remove snippet after 4-th cycle
				snippetBox = GetItemFromCollection(xmlAttrAuthor.value, doc.textFrames);
				if (snippetBox != null) {
					if (snippetBox.associatedXMLElement != null) {
						snippetBox.associatedXMLElement.remove();
					}
					snippetBox.remove();
				}

				if (xmlElAuthorDetail != null) { // Author Detail
					xmlElAuthorDetail = xmlElAuthorDetail.move(LocationOptions.AT_BEGINNING);
					InsertBeforeAfterXmlEl(xmlElAuthorDetail, "\r", true); // (xmlEl, what, after)
					xmlElAuthorDetail.applyParagraphStyle(parSt_authorDetail, true);
				}
			}
			else if (story.label == "3") { // Remove Author and Author Detail at the end after 3-rd cycle
				if (xmlElAuthor != null) {
					xmlElAuthor.remove();
					ChageGrep(story, ", ", "", parSt_authorEnd);
					xmlElAuthor = null;
				}

				if (xmlElAuthorDetail != null) {
					xmlElAuthorDetail.remove();
					xmlElAuthorDetail = null;
				}
			}

			// Author Detail
			if (xmlElAuthorDetail == null) { // wasn't created yet
				if (authorDetailExists) {
					xmlElAuthorDetail = xmlElContent.xmlElements.add(xmlTagAuthorDetail);					
					xmlElAuthorDetail.contents = xmlAttrAuthorDetail.value;
					xmlElAuthorDetail = xmlElAuthorDetail.move(LocationOptions.AT_BEGINNING);
					InsertBeforeAfterXmlEl(xmlElAuthorDetail, "\r", true);
					xmlElAuthorDetail.applyParagraphStyle(parSt_authorDetail, true);				
				}
			}
		
			// Author 
			if (xmlElAuthor == null) { // wasn't created yet
				xmlElAuthor = xmlElContent.xmlElements.add(xmlTagAuthor);
				xmlElAuthor.contents = xmlAttrAuthor.value;
				xmlElAuthor = xmlElAuthor.move(LocationOptions.AT_BEGINNING);
				InsertBeforeAfterXmlEl(xmlElAuthor, ((authorDetailExists) ? "\r" : "\r\r"), true);
				xmlElAuthor.applyParagraphStyle(parSt_author, true);
			}

			story.label = "1";
		}
		else if (story.label == "1" || (story.label == "3" && !authorDetailExists && !snippetFile.exists)) { // 2-nd cycle
			if (authorDetailExists) {
				if (xmlElAuthorDetail != null) {
					xmlElAuthorDetail = xmlElAuthorDetail.move(LocationOptions.AT_END);
					InsertBeforeAfterXmlEl(xmlElAuthorDetail, "\r", false);
					xmlElAuthorDetail.applyParagraphStyle(parSt_authorEnd, true);
				}
			}
			else { // no authorDetail
				if (xmlElAuthor != null) {
					xmlElAuthor = xmlElAuthor.move(LocationOptions.AT_END);
					InsertBeforeAfterXmlEl(xmlElAuthor, "\r", false);
					xmlElAuthor.applyParagraphStyle(parSt_authorEnd, true);
					ChageGrep(story, "\\r", "", parSt_author);
				}
			}
		
			story.label = "2";
		}
		else if (story.label == "2") { // 3-rd cycle
			if (authorDetailExists && xmlElAuthor != null) {
				xmlElAuthor = xmlElAuthor.move(LocationOptions.BEFORE, xmlElAuthorDetail);
				InsertBeforeAfterXmlEl(xmlElAuthor, "\r", false);
				xmlElAuthor.applyParagraphStyle(parSt_authorEnd, true);

				firstChar = xmlElAuthor.characters[0].index;
				lastChar = xmlElAuthorDetail.characters[-1].index;
				textRange = xmlElContent.parentStory.characters.itemByRange(firstChar, lastChar);
				ChageGrep(textRange, "\\r+", ", ");
				ChageGrep(story, "\\r", "", parSt_author); 
			}
			else { // no authorDetail
				if (xmlElAuthor != null) {
					xmlElAuthor = xmlElAuthor.move(LocationOptions.AT_BEGINNING);
					InsertBeforeAfterXmlEl(xmlElAuthor, "\r\r", true);				
					xmlElAuthor.applyParagraphStyle(parSt_author, true);
				}
			}

			story.label = "3";
		}
		else if (story.label == "3" && snippetFile.exists) { // 4-th cycle
			var x = textFrameContent.geometricBounds[1];
			var y = textFrameContent.geometricBounds[0];

			snippetBox = page.place(snippetFile, [x, y])[0];
			doc.align([snippetBox], AlignOptions.LEFT_EDGES, AlignDistributeBounds.KEY_OBJECT, textFrameContent);
			snippetBox.label = xmlAttrAuthor.value;
			
			if (xmlElAuthor != null) {
				xmlElAuthor.remove();
				ChageGrep(story, ", ", "", parSt_authorEnd);
			}

			story.label = "4";
		} // End of cycles
	
		TrimStory(story);
	
		if (textFrameContent.overflows) {
			textFrameContent.fit(FitOptions.FRAME_TO_CONTENT);
		}	
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ChageGrep(where, findWhat, changeTo, findParSt) {
	if (typeof findParSt == "undefined") {
		var findParSt = null;
	}
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = findWhat;
	if (findParSt != null) {
		app.findGrepPreferences.appliedParagraphStyle = findParSt;
	}
	app.changeGrepPreferences.changeTo = changeTo;
	var changed = where.changeGrep();
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function InsertBeforeAfterXmlEl(xmlEl, what, after) {
	var story = xmlEl.parentStory;
	var position = (after) ? -1 : 0;
	var index = xmlEl.insertionPoints[position].index;
	story.insertionPoints[((after) ? index + 1 : index - 1)].contents = what;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function TrimStory(story) { // remove empty paragraphs at the beginning and end of the story
	while (story.characters[0].contents == "\r") {
		story.characters[0].remove();
	}

	while (story.characters[-1].contents == "\r") {
		story.characters[-1].remove();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetNestedXmlElement(parentXml, nestedXmlTag) {
	var nestedXmlElement,
	xmlElement = null,
	parentXmlElements = parentXml.xmlElements;

	for (var i = 0; i < parentXmlElements.length; i++) {
		nestedXmlElement = parentXmlElements[i];

		if (nestedXmlElement.markupTag.name == nestedXmlTag) {
			xmlElement = nestedXmlElement;
			break;
		}
	}
	
	return xmlElement;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	// check if text is selected and get the current story
	var msgWrongSelection = "One text frame or some text should be selected, or the cursor should be inserted into the text.";
	if (app.selection.length == 0 || app.selection.length > 1) ErrorExit(msgWrongSelection);
	var sel = app.selection[0];
		
	if (sel.constructor.name == "TextFrame") { // a text frame is selected
		story = sel.parentStory;
	}
	else if (sel.hasOwnProperty("baseline")) { // some text is selected or the cursor is placed in the text
		story = sel.parentStory;
	}
	else {
		ErrorExit(msgWrongSelection, true);
	}

	if (story == undefined || !story.isValid) ErrorExit("Can't find the story.", true);
	textFrameContent = story.textContainers[0]; // the first text frame of the selected story
	
	var msgWrongTextSelected = "Wrong text is selected. The associated XML element of selected text should be either 'content' or 'h1' whose parent is 'article'.";
	
	// check XML elements and attributes
	if (story.associatedXMLElement != null) {
		xmlElArticle = story.associatedXMLElement.parent;
	}
	else {
		ErrorExit(msgWrongTextSelected, true);
	}

	if (!xmlElArticle.isValid || xmlElArticle.markupTag.name != "article") {
		ErrorExit(msgWrongTextSelected, true);
	}

	xmlElContent = GetNestedXmlElement(xmlElArticle, "content");
	if (xmlElContent == null) {
		ErrorExit("The XML element 'content' wasn't found in the 'article' XML element." , true);
	}

	xmlAttrAuthor = xmlElArticle.xmlAttributes.item("author");
	if (!xmlAttrAuthor.isValid) {
		ErrorExit("The XML attribute 'author' wasn't found in the 'article' XML element." , true);
	}
	else if (!xmlAttrAuthor.isValid || xmlAttrAuthor.value == "") {
		ErrorExit("The XML attribute 'author' is empty." , true);
	}

	if (story.associatedXMLElement.markupTag.name == "h1") { // the title is selected instead of content - redefine the story
		story = xmlElContent.parentStory;
	}

	// check paragraph styles
	parSt_author = doc.paragraphStyles.itemByName("author");
	if (!parSt_author.isValid) ErrorExit("Paragraph style 'author' is missing in the current document.", true);	
	
	parSt_authorDetail = doc.paragraphStyles.itemByName("authorDetail");
	if (!parSt_authorDetail.isValid) ErrorExit("Paragraph style 'authorDetail' is missing in the current document.", true);
	
	parSt_authorEnd = doc.paragraphStyles.itemByName("authorEnd");
	if (!parSt_authorEnd.isValid) ErrorExit("Paragraph style 'authorEnd' is missing in the current document.", true);
	
	// check folder 'authors'
	folderPath_authors = decodeURI(doc.filePath.absoluteURI) + "/authors/";
	var folder_authors = new Folder(folderPath_authors);
	if (!folder_authors.exists) ErrorExit("The folder 'authors' should be located in the same folder as the current document.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------