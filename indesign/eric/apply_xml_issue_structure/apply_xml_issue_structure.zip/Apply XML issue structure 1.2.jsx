﻿/* Copyright 2022, Kasyan Servetsky
July 2, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com 

With an indd document open and a XML file already imported (see attachment), the script looks in the XML publication element
•	For each 'section' element, insert a page and apply the master page attribute value to the page
•	Copy 'volume' attribute value and paste it in all 'volume' text variables
•	Copy 'number' attribute value and paste it in all 'number' text variables
•	Copy 'publish-date' attribute value and paste it in all 'publish-date' text variables. Format date in French as day month, year. Example 8 juin, 2022
*/
//======================================================================================
var scriptName = "Apply XML issue structure",
debug = false, // for debugging only
volume = "volume",
number = "number",
publishDate = "publish-date",
frontPageDate = "frontpage-date",
doc, root;

PreCheck();
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var xmlEl, atrMasterPage, masterPageName, masterPage;

		var xmlElPage = root.evaluateXPathExpression("//page");
		if (xmlElPage.length > 0) {
			xmlElPage = xmlElPage[0];
		}
		else {
			ErrorExit("The 'page' XML element is missing.", true);
		}
		
		var attrVolume = GetAttr(xmlElPage, volume);
		var attrNumber = GetAttr(xmlElPage, number);
		var attrPublishDate = GetAttr(xmlElPage, publishDate);
		var attrFrontPageDate = GetAttr(xmlElPage, frontPageDate);
		
		var textVarVolume = doc.textVariables.itemByName(volume);
		if (!textVarVolume.isValid) {
			textVarVolume = doc.textVariables.add({name: volume});
		}
		if (attrVolume != null) textVarVolume.variableOptions.contents = attrVolume;
		
		var textVarNumber = doc.textVariables.itemByName(number);
		if (!textVarNumber.isValid) {
			textVarNumber = doc.textVariables.add({name: number});
		}
		if (attrNumber != null) textVarNumber.variableOptions.contents = attrNumber;		
		
		var textVarPublishDate = doc.textVariables.itemByName(publishDate);
		if (!textVarPublishDate.isValid) {
			textVarPublishDate = doc.textVariables.add({name: publishDate});
		}
		if (attrPublishDate != null) textVarPublishDate.variableOptions.contents = attrPublishDate;
		
		var textVarFrontPageDate = doc.textVariables.itemByName(frontPageDate);
		if (!textVarFrontPageDate.isValid) {
			textVarFrontPageDate = doc.textVariables.add({name: frontPageDate});
		}
		if (attrFrontPageDate != null) textVarFrontPageDate.variableOptions.contents = attrFrontPageDate;		

		var xPath = "//section";
		var xmlElements = root.evaluateXPathExpression(xPath);
		
		for (var i = 0; i < xmlElements.length; i++) {
			xmlEl = xmlElements[i];
			atrMasterPage = xmlEl.xmlAttributes.itemByName("master-page");
			if (atrMasterPage.isValid) {
				masterPageName = atrMasterPage.value;
				masterPage = doc.masterSpreads.itemByName(masterPageName);
				
				if (i == 0) {
					page = doc.pages[0]; // the 1-st page already exists
				}
				else {
					page = doc.pages.add(LocationOptions.AT_END, doc);
				}
				
				if (masterPage.isValid) {
					page.appliedMaster = masterPage;
				}
				else {
					ErrorExit("The master page " + masterPageName + " doesn't exist in the current document.", true);
				}
			}
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetAttr(xmlEl, name) {
	var result = null;
	
	if (name == frontPageDate) {
		var attr = xmlEl.xmlAttributes.itemByName(publishDate);
	}
	else {
		var attr = xmlEl.xmlAttributes.itemByName(name);
	}
	
	if (!attr.isValid) {
		ErrorExit("The XML attribute " + name + " is missing in the XML structure.", true);
	}
	else if (name == publishDate || name == frontPageDate) {
		if (attr.value.match(/\d{4}-\d{2}-\d{2}/) != null) {
			if (name == "publish-date") {
				result = GetFrenchDate(attr.value);
			}
			else if (name == frontPageDate) {
				var arr = attr.value.split("-"),
				result = arr[2] + "/" + arr[1] + "/" + arr[0].slice(2);
			}
		}
		else {
			ErrorExit("The XML attribute " + name + " doesn't match the pattern: yyyy-mm-dd.", true);
		}
	}
	else if (name == "") {
		ErrorExit("The XML attribute " + name + " is empty.", true);
	}
	else {
		 result = attr.value;
	}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetFrenchDate(str) {
	var arr = str.split("-"),
	monthNum = Number(arr[1]),
	month;
	
	switch (monthNum) {
		case 1:
			month = "janvier";
			break;
		case 2:
			month = "février";
			break;
		case 3:
			month = "mars";
			break;
		case 4:
			month = "avril";
			break;			
		case 5:
			month = "mai";
			break;		
		case 6:
			month = "juin";
			break;		
		case 7:
			month = "juillet";
			break;		
		case 8:
			month = "août";
			break;		
		case 9:
			month = "septembre";
			break;		
		case 10:
			month = "octobre";
			break;		
		case 11:
			month = "novembre";
			break;		
		case 12:
			month = "décembre";
			break;			
		default:
		month = "N/A";
	}
	
	var frenchData = arr[2] + " " + month + ", " + arr[0];
	return frenchData;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	root = doc.xmlElements[0];
	if (root.evaluateXPathExpression("//*").length == 1) {
		ErrorExit("The document has no XML structure.", true);
	}

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------