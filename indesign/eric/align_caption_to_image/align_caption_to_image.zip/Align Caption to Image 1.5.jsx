﻿/* Copyright 2024, Kasyan Servetsky
May 24, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Align Caption to Image",
reduceHeightFromTop = 3, // reduce height from the top in points
reduceHeightFromBottom = 0 , // reduce height from the bottom in points
debug = false,
doc, rectangle, textFrame, objStCaption; 

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");

//===================================== FUNCTIONS ======================================
function Main() {
		// Save & change units
		var savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits;
		var savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
		doc.viewPreferences.horizontalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS;
		
	try {
		textFrame.applyObjectStyle(objStCaption, true, false); // Apply object style ‘caption’ to text frame
		
		var rectangleBounds = GetBounds(rectangle);
		var textFrameBounds = GetBounds(textFrame);
		
		// Make width of text frame equal to the width of graphic frame
		SetWidthHeight(textFrame, rectangleBounds.width, textFrameBounds.height, AnchorPoint.TOP_LEFT_ANCHOR);

		// Align text frame below graphic frame
		textFrame.move([rectangleBounds.left, rectangleBounds.bottom]);
		textFrame.recompose();
		textFrame.fit(FitOptions.FRAME_TO_CONTENT); // Fit content to frame for text frame		

		// Restore units
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
	}
	catch(err) {
		// Restore units in case of an error
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function SetWidthHeight(frame, width, height, anchorPoint) {
	frame.resize(CoordinateSpaces.INNER_COORDINATES, anchorPoint, ResizeMethods.REPLACING_CURRENT_DIMENSIONS_WITH, [width, height, CoordinateSpaces.INNER_COORDINATES]);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetBounds(frame) { // Get bounds considering reference point
	var gb, left, right, top, bottom, width, height, halfWidth, halfHeight;

	gb = frame.geometricBounds;
	left = RoundWithDecimal(gb[1], 3);
	right = RoundWithDecimal(gb[3], 3);
	top = RoundWithDecimal(gb[0], 3);
	bottom = RoundWithDecimal(gb[2], 3);
	width = right - left;
	height = bottom - top;
	halfWidth = width / 2;
	halfHeight = height / 2;

	return {width: width, height: height, left: left, right: right, top: top, bottom: bottom, halfWidth: halfWidth, halfHeight: halfHeight};
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function RoundWithDecimal(number, decimals) {
	var multiplier = Math.pow(10, decimals);
	return Math.round(number * multiplier) / multiplier;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	var wrongSelectionMsg = "A text frame and/or a graphic frame should be selected. Also, you can select some text or place the cursor in the caption.";
	
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	// Check object styles
	objStCaption = doc.objectStyles.itemByName("caption");
	if (!objStCaption.isValid) ErrorExit("Object style 'caption' is missing in the current document.", true);

	// Check selection
	if (app.selection.length == 0) {
		ErrorExit("Nothing is selected.", true);
	}
	else if (app.selection.length == 1) {
		if (app.selection[0] instanceof TextFrame || app.selection[0].hasOwnProperty("baseline")) {
			textFrame = (app.selection[0] instanceof TextFrame) ? app.selection[0] : app.selection[0].parentTextFrames[0];
			if (textFrame instanceof TextFrame == false) ErrorExit(wrongSelectionMsg, true);
			rectangle = GetSibling(textFrame);
			if (rectangle == null) ErrorExit("Can’t get the associated image frame.", true);
			Main();
		}
		else if (app.selection[0] instanceof Rectangle || app.selection[0] instanceof Image) {
			rectangle = (app.selection[0] instanceof Rectangle) ? app.selection[0] : app.selection[0].parent;
			textFrame = GetSibling(app.selection[0]);
			if (rectangle == null) ErrorExit("Can’t get the associated text frame.", true);
			Main();
		}
		else {
			ErrorExit(wrongSelectionMsg, true);
		}
	}
	else if (app.selection.length == 2) {
		if (app.selection[0] instanceof Rectangle && app.selection[1] instanceof TextFrame) {
			rectangle = app.selection[0];
			textFrame = app.selection[1];
			Main();
		}
		else if (app.selection[1] instanceof Rectangle && app.selection[0] instanceof TextFrame) {
			rectangle = app.selection[1];
			textFrame = app.selection[0];
			Main();
		}
	}
	else { // two wrong objects are selected
		ErrorExit(wrongSelectionMsg + " But you selected " + app.selection.length + " objects.", true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSibling(item) {
	var result = null;
	
	try {
		var xPath,	
		associatedXMLElement = item.associatedXMLElement;
		
		if (item instanceof TextFrame) {
			xPath = "Image";
		}
		else if (item instanceof Rectangle || item instanceof Image) {
			xPath = "Caption";
		}

		var xmlElements = associatedXMLElement.parent.evaluateXPathExpression(xPath);
		if (xmlElements.length > 0) {
			var xmlElement = xmlElements[0];
			var xmlContent = xmlElement.xmlContent;
			
			if (xmlContent.constructor.name == "Story") {
				result = xmlContent.textContainers[0];
			}
			else if (xmlContent.constructor.name == "Image") {
				result = xmlContent.parent;
			}
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line);
	}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
/* Align caption to image
With text frame and graphic frame selected:
Apply object style ‘caption’ to text frame
Apply object style ‘image’ to graphic frame
Make width of text frame equal to the width of graphic frame
Fit content to frame for text frame
Align text frame below graphic frame
REMOVED: For graphic frame, reduce height from the top by 3pt and reduce height from the bottom by 0pt (just in case I want to edit in the future)

17.03.23 - In addition to selecting an image and a caption text box, 
There should also be the option to just select an image and align the caption text box 
that is associate with the same <Picture> element.
Or select a caption and align it to the image that is associated within the same <Picture> element. 

21.03.23 - One more request is to remove the function that modifies the height of the image frame. Let's just leave the image alone.

05.05.24 - Update: Align Caption to Image
Please update the script to not apply 'image' object style.
*/
