﻿/* Copyright 2025, L'Express de Toronto Inc.
January 21, 2025
Written by Kasyan Servetsky
http://kasyan.ho.ua/indesign/eric/2025/cutoff_rule/cutoff_rule.html
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Cutoff rule",
tolerance = 1, // in points - can be changed by the user
debug = false,
log = false, // ============ Logging ============
logDebugFuncList = ["Main"],
logDebugListOnly = false,
logOverwrite = true,
logFullCount = 0, // DON'T CHANGE
logErrCount = 0, // DON'T CHANGE
logErrOnly = false,
logHeaderAdded = false, // DON'T CHANGE - Header added to the full log
logErrArr = [], // ========= End logging =========
doc, data, objStyleCutoffRule, stroke, page, pageWidth, columnGutterMiddle,
offset, selBounds,
explanation = "",
isAd = false,
countLine = 0,
storedUnits = null,
selectedItems = [],
selectedFrames = [],
groupItems = [];

if (typeof arguments == "undefined") {
	if (debug) {
		//var mode = "HORIZONTAL";
		var mode = "VERTICAL";
	}
	else {
		ErrorExit("This script can’t be used as it is. It should be triggered from one of the following scripts located in the same folder:\n• Horizontal.jsx\n• Vertical.jsx", true);
	}
}
else {
	var mode = arguments[0].toUpperCase().replace(/\s+/g, "_");
}

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		Log(">");
		Log(selectedFrames.length + " frame(s) selected");

		if (isAd) {
			ProcessAdd();
		}
		else {
			ProcessFrames();
		}

		if (groupItems.length > 0 && offset.groupObjectWithLine) {
			GroupIt();
		}
		
		if (!debug) app.selection = NothingEnum.NOTHING;
		Units();
		
		if (explanation != "") {
			alert(explanation, scriptName);
		}
	
		Log("<");
		//Log("EXE");
	}
	catch(err) {
		Log(err.message + ", line: " + err.line, true);
		Units();
	}
}		
//--------------------------------------------------------------------------------------------------------------------------------------------------------		
function ProcessAdd() {
	try {
		Log(">");
		
		var lgb, // line's new geometric bounds
		frame = selectedFrames[0],
		touchesMargin = CheckTouchMargins(page, frame),
		offsetHorVer;
		
		if (offset.groupObjectWithLine) {
			groupItems.push(selectedFrames[0]);
		}
		
		// Calculate horizontal offset from the gutter
		if (!touchesMargin.left) {
			offset.horizontal.left -= columnGutterMiddle;
		}

		if (!touchesMargin.right) {
			offset.horizontal.right += columnGutterMiddle;
		}			
	
		// HORIZONTAL - TOP
		if (!touchesMargin.top) {
			offsetHorVer = -offset.horizontal.vertical - stroke;

			lgb = [
					selBounds.top + offsetHorVer, // top
					selBounds.left + offset.horizontal.left, // left
					selBounds.top + offsetHorVer, // bottom
					selBounds.right + offset.horizontal.right // right
				];
				
			Log("HORIZONTAL - TOP | lgb = " + Str(lgb));
			AddLine(lgb);
		}

		// HORIZONTAL -  BOTTOM
		if (!touchesMargin.bottom) {
			offsetHorVer = offset.horizontal.vertical - stroke;
			
			lgb = [
					selBounds.bottom + offsetHorVer, // top
					selBounds.left + offset.horizontal.left, // left
					selBounds.bottom + offsetHorVer, // bottom
					selBounds.right + offset.horizontal.right // right
				];
		
			Log("HORIZONTAL -  BOTTOM | lgb = " +  Str(lgb));
			AddLine(lgb);
		}

		// VERTICAL - LEFT
		if (!touchesMargin.left) {
			lgb = [
					((touchesMargin.top) ? selBounds.top : selBounds.top + offset.vertical.top), // top
					selBounds.left - columnGutterMiddle + stroke, // left
					((touchesMargin.bottom) ? selBounds.bottom : selBounds.bottom + offset.vertical.bottom), // bottom
					selBounds.left - columnGutterMiddle + stroke // right
				];
				
			Log("VERTICAL - LEFT | lgb = " + Str(lgb));
			AddLine(lgb);
		}

		// VERTICAL - RIGHT
		if (!touchesMargin.right) {
			lgb = [
					((touchesMargin.top) ? selBounds.top : selBounds.top + offset.vertical.top), // top
					selBounds.right + columnGutterMiddle + stroke, // left
					((touchesMargin.bottom) ? selBounds.bottom : selBounds.bottom + offset.vertical.bottom), // bottom
					selBounds.right + columnGutterMiddle + stroke // right
				];
				
			Log("VERTICAL - RIGHT | lgb = " + Str(lgb));
			AddLine(lgb);
		}

		Log("<");
	}
	catch(err) {
		Log(err.message + ", line: " + err.line, true);
		Units();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessFrames() {
	try {
		Log(">");

		var lgb; // line's new geometric bounds
		
		if (offset.groupObjectWithLine) {
			groupItems.push(selectedFrames);
		}

		if (mode == "VERTICAL") { // Vertical
			Log("VERTICAL");
			Log(selectedFrames.length + " frame(s) selected");
			
			var side = GetSide(selBounds); // the side where to add the line: left/right
			Log("side = " + side);
			var verticallyAligned = VerticallyAligned(side);
			if (selectedFrames.length > 1) Log("VerticallyAligned = " + verticallyAligned);
				
			if (selectedFrames.length == 1 || selectedFrames.length > 1 && verticallyAligned) { // 1 - With one frame selected, or all frames vertically aligned
				Log("1) one frame / 2+ frames vertically aligned");
				
				if (side == "ADD_TO_LEFT") {
					lgb = [ // add to left
						selBounds.bottom + offset.vertical.bottom, // bottom
						selBounds.left - columnGutterMiddle - offset.vertical.horizontal + stroke, // right -- always '+ stroke' because it should be shifted to the right
						selBounds.top + offset.vertical.top, // top
						selBounds.left - columnGutterMiddle - offset.vertical.horizontal + stroke, // left
					];
				}
				else if (side == "ADD_TO_RIGHT") {
					lgb = [ // add to right
						selBounds.top + offset.vertical.top, // top
						selBounds.right + columnGutterMiddle + offset.vertical.horizontal + stroke, // left
						selBounds.bottom + offset.vertical.bottom, // bottom
						selBounds.right + columnGutterMiddle + offset.vertical.horizontal + stroke // right
					];
				}

				AddLine(lgb);
			} // 2 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			else if (selectedFrames.length == 2) { // Two frames selected
				Log("2) Two frames selected but not vertically aligned");
				var frameA = selectedFrames[0];
				var gbA = frameA.geometricBounds;
				var frameA_width = gbA[3] - gbA[1];
		
				var frameB = selectedFrames[1];
				var gbB = frameB.geometricBounds;				
				var frameB_width = gbB[3] - gbB[1];

				if (selBounds.width > frameA_width + frameB_width) { // two frames are located horizontally
					Log("2.1 - two frames are located horizontally: the line added between them in the gutter");
					if (gbA[3] < gbB[1]) {
						var rightEdge = gbA[3];
						var leftEdge = gbB[1];
					}
					else if (gbB[3] < gbA[1]) {
						var rightEdge = gbB[3];
						var leftEdge = gbA[1];
					}
					
					var betweenPosition = rightEdge + ((leftEdge - rightEdge) / 2) + stroke;

					lgb = [
						selBounds.top + offset.vertical.top, // top
						betweenPosition, // left
						selBounds.bottom + offset.vertical.bottom, // bottom
						betweenPosition // right
					];

					AddLine(lgb);
				}
				else {
					Log("2.2 - two frames are not located horizontally — skipping");
				}
			}
		}
		
		if (mode == "HORIZONTAL") { // Horizontal
			Log("HORIZONTAL");

			if (selectedFrames.length == 1 || (selectedFrames.length == 2 && InSameArticle())) { // one/two frames selected
				lgb = [
						selBounds.top + offset.horizontal.vertical, // top
						selBounds.left + offset.horizontal.left, // left
						selBounds.top + offset.horizontal.vertical, // bottom
						selBounds.right + offset.horizontal.right // right
					];
		
				AddLine(lgb);
			}
			else if (selectedFrames.length == 2 && !InSameArticle()) {
				explanation = "The selected two frames are not part of the same XML article so no line has been added.";
			}		
			else if (selectedFrames.length > 2) {
				explanation = "You selected " + selectedFrames.length + " frames. Select one or two.";
			}
		}
	}
	catch(err) {
		Log(err.message + ", line: " + err.line, true);
		Units();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddLine(lgb) {
	try {
		Log(">");
		var line = null;

		line = page.graphicLines.add({geometricBounds: lgb});

		if (line != null) {
			line.applyObjectStyle(objStyleCutoffRule);

			countLine++;
			if (debug) app.select(line);			
			Log("Line #" + countLine + " was added " + Str(line.geometricBounds));
			groupItems.push(line);
		}
		else {
			Log("No line has been added.");
		}

		Log("<");
		return line;		
	}
	catch(err) {
		Log(err.message + ", line: " + err.line, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GroupIt() {
	try {
		var group = doc.groups.add(groupItems);
	}
	catch(err) {
		Log(err.message + ", line: " + err.line, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckTouchMargins(page, frame) {
	try {
		Log(">");
		
		var verso = page.side == PageSideOptions.LEFT_HAND;
		Log("verso = " + verso);
		
		var result = {left: false, right: false, top: false, bottom: false},
		pageRight = (!verso && page.documentOffset > 0) ? page.bounds[3] - pageWidth : page.bounds[3],
		pageBottom = page.bounds[2],
		pageMargins = { top: page.marginPreferences.top,
								bottom: page.marginPreferences.bottom,
								inside: page.marginPreferences.left,
								outside: page.marginPreferences.right
								},		
		gb = frame.geometricBounds,
		left = gb[1],
		right = gb[3],
		top = gb[0],
		bottom = gb[2];
	
		Log("page.bounds.toString() = " + page.bounds.toString());
		Log("pageRight = " + pageRight);

		var leftMarginPosition = (verso) ? pageMargins.outside : pageMargins.inside;
		var rightMargin = (verso) ? pageMargins.inside : pageMargins.outside;
		Log("rightMargin = " + rightMargin);
		var rightMarginPosition = pageRight - rightMargin;
		Log("rightMarginPosition = " + rightMarginPosition);
		$.writeln("rightMarginPosition = " + rightMarginPosition);
		
		var topMarginPosition = pageMargins.top;
		var bottomMarginPosition = pageBottom - pageMargins.bottom;

		var leftMin = leftMarginPosition - tolerance,
		leftMax = leftMarginPosition + tolerance,
		rightMin = rightMarginPosition - tolerance,
		rightMax = rightMarginPosition + tolerance,
		topMin = topMarginPosition - tolerance,
		topMax = topMarginPosition + tolerance,
		bottomMin = bottomMarginPosition - tolerance,
		bottomMax = bottomMarginPosition + tolerance;
		
		Log("left = " + left);
		Log("leftMin = " + leftMin);
		Log("leftMax = " + leftMax);
		Log("right " + right);
		Log("rightMin = " + rightMin);
		Log("rightMax = " + rightMax);
		Log("top " + top);
		Log("topMin = " + topMin);
		Log("topMax = " + topMax);
		Log("bottom " + bottom);
		Log("bottomMin = " + bottomMin);
		Log("bottomMax = " + bottomMax);

		if (WithinTolerance(left, leftMin, leftMax)) {
			result.left = true;
			Log("left Side Within Tolerance");			
		}
	 
		if (WithinTolerance(right, rightMin, rightMax)) {
			result.right = true;
			Log("right Side Within Tolerance");			
		}

		if (WithinTolerance(top, topMin, topMax)) {
			result.top = true;
			Log("top Side Within Tolerance");			
		}
	
		if (WithinTolerance(bottom, bottomMin, bottomMax)) {
			result.bottom = true;
			Log("bottom Side Within Tolerance");			
		}

		Log("result: left = " + result.left + ", right = " + result.right + ", top = " + result.top + ", bottom = " + result.bottom);
		Log("<");		
		return result;
	}
	catch(err) {
		Log(err.message + ", line: " + err.line, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function WithinTolerance(value, min, max) {
	if (value >= min && value <= max) {
		return true;
	}
	else {
		return false;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetPageMargins(page) {
	var marginPreferences = page.marginPreferences;
	var margins = {
							top: marginPreferences.top,
							bottom: marginPreferences.bottom,
							inside: marginPreferences.left,
							outside: marginPreferences.right
							};
	return margins;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function InSameArticle() {
//~ return true; // !!!
	try {
		Log(">");
		var result = false;

		var selA = selectedFrames[0];
		var selB = selectedFrames[1];

		var xmlElSelA = selA.associatedXMLElement;
		var xmlElSelB = selB.associatedXMLElement;
		
		if (xmlElSelA != null && xmlElSelB != null) {
			var xmlElArtA = FindParentXmlEl(xmlElSelA, "article");
			var xmlElArtB = FindParentXmlEl(xmlElSelB, "article");

			if (xmlElArtA != null && xmlElArtB != null) {
				result = xmlElArtA == xmlElArtB;
			}
		}
		
		Log("result = " + result);
		Log("<");
		return result;
	}
	catch(err) {
		Log(err.message + ", line: " + err.line, true);
		return result;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetValue(objStyleName, objChildStr) {
	if (typeof objChildStr == "undefined") {
		objChildStr = null;
	}
	var result = null;
	var child = null;
	var objParentStr = "data['" + objStyleName + "']";
	var objParent = eval(objParentStr);
	
	if (objParent != null) {
		if (objChildStr != null) {
			child = eval(objParentStr + "." + objChildStr);
			if (child != null) {
				result = child;
			}
		}
		else {
			result = objParent;
		}
	}
	
	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ReadData(file) {
	try {
		data = {}; // global
		
		var item, id,
		txt = ReadTxtFile(file);

		eval("var arr = [" + txt + "];");
		
		for (var i = 0; i <arr.length; i++) {
			item = arr[i];
			id = item.objectStyle.toLowerCase().replace(/\s+/g, "_");
			data[id] = item;
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ReadTxtFile(file) {
	file.open("r"); 
	var txt = file.read();
	file.close();
	return txt;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelBounds() {
	var item, gb, left, right, top, bottom;
	
	for (var i = 0; i < selectedItems.length; i++) {
		item = selectedItems[i];
		
		if (item.hasOwnProperty("geometricBounds")) {
			if (item.constructor.name != "TextFrame" && item.constructor.name != "Rectangle") {
				$.writeln("WARNING: niether a TextFrame nor Rectangle");
				Log("WARNING: niether a TextFrame nor Rectangle");
			}

			gb = item.geometricBounds;
			
			if (left == undefined || gb[1] < left) left = gb[1];
			if (right == undefined || gb[3] > right) right = gb[3];
			if (top == undefined || gb[0] < top) top = gb[0];
			if (bottom == undefined || gb[2] > bottom) bottom = gb[2];
		}
	}
		
	var width = Math.floor((right-left)*100)/100;
	var height = Math.floor((bottom-top)*100)/100;
	var middle = left + (width/2);
	
	return { width : width, height : height, left : left, right : right, top : top, bottom : bottom, middle : middle };
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function VerticallyAligned(side) {
	Log(">");
	var frame, gb, left, right,
	leftSideWithinTolerance, rightSideWithinTolerance,
	leftMin = selectedFrames[0].geometricBounds[1] - tolerance,
	leftMax = selectedFrames[0].geometricBounds[1] + tolerance,
	rightMin = selectedFrames[0].geometricBounds[3] - tolerance,
	rightMax = selectedFrames[0].geometricBounds[3] + tolerance,
	result = true;
	
	Log("leftMin = " + leftMin);
	Log("leftMax = " + leftMax);
	Log("rightMin = " + rightMin);
	Log("rightMax = " + rightMax);
	
	for (var i = 1; i < selectedFrames.length; i++) {
		frame = selectedFrames[i];
		gb = frame.geometricBounds;
		left = gb[1];
		right = gb[3];
		Log("left = " + left);
		Log("right " + right);
		
		leftSideWithinTolerance = left >= leftMin && left <= leftMax;
		rightSideWithinTolerance = right >= rightMin && right <= rightMax;
		
		Log("leftSideWithinTolerance = " + leftSideWithinTolerance);
		Log("rightSideWithinTolerance = " + rightSideWithinTolerance);

		if (side == "ADD_TO_LEFT" && !leftSideWithinTolerance ||
			side == "ADD_TO_RIGHT" && !rightSideWithinTolerance)
		{
			result = false;
			Log("set result to " + result);
			break;
		}
	}

	Log("result = " + result);
	Log("<");
	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ApproximatelyEquals(value1, value2, acceptableDifference) {
	return Math.abs(value1 - value2) <= acceptableDifference; 
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSelection() {
	var sel,
	selection = app.selection;
	
	for (var i = selection.length - 1; i >= 0; i--) {
		sel = selection[i];
		
		if (sel.hasOwnProperty("geometricBounds")) {
			selectedItems.push(sel);

			if (sel.constructor.name == "GraphicLine") {
				if (sel.appliedObjectStyle.name == "Cutoff rule") {
					sel.remove();	
				}
			}
			else if (sel.constructor.name == "Rectangle" || sel.constructor.name == "TextFrame") { // !!!
				selectedFrames.push(sel);
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	Log(">");
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	GetSelection();
	if (app.selection.length == 0) ErrorExit("Nothing is selected.", true);
	if (selectedItems.length == 0) ErrorExit("Invalid selection.", true);
	if (selectedFrames.length == 0) ErrorExit("No frame is selected.", true);
	
	// Stroke style
	var objStyleCutoffRuleName;

	if (debug) {
		objStyleCutoffRuleName = "TMP_Cutoff rule";
	}
	else {
		objStyleCutoffRuleName = "Cutoff rule";
	}
	
	objStyleCutoffRule = doc.objectStyles.itemByName(objStyleCutoffRuleName);
	
	if (!objStyleCutoffRule.isValid) ErrorExit("Object style '" + objStyleCutoffRuleName + "' doesn't exist.", true);
	stroke = objStyleCutoffRule.strokeWeight / 2; // 1/2 stroke weight
	
	Units();
	page = app.activeWindow.activePage;
	pageWidth = page.bounds[3] - page.bounds[1];
	columnGutterMiddle = page.marginPreferences.columnGutter / 2;
		
	// Read settings from the txt-file
	var scriptFolderPath = GetActiveScript().parent.absoluteURI + "/";
	var dataFileName = scriptName + ".txt";
	var dataFilePath = scriptFolderPath + dataFileName;
	var dataFile = new File(dataFilePath);
	if (!dataFile.exists) ErrorExit("File '" + dataFileName + "' doesn't exist.", true);
	ReadData(dataFile);
	if (data.toSource() == "({})") ErrorExit("No valid data in the " + dataFileName + " file.", true);
	
	var selectedFrameStyleName = selectedFrames[0].appliedObjectStyle.name;
	Log("Selected frame style: " + selectedFrameStyleName + " | ID = " + selectedFrames[0].id);	
	if (selectedFrameStyleName == "advertisement") {
		if (selectedFrames.length > 1) ErrorExit("Only one 'Advertisement' frame should be selected.", true);
		isAd = true;
	}

	offset = GetValue(selectedFrameStyleName, null); // null to get parent object
	if (offset == null) ErrorExit("Can't get the offset settings for the '" + selectedFrameStyleName + "' object style. Probably you selected a wrong frame.", true);
	Log("offset = " + offset.toSource());
	
	selBounds = GetSelBounds(); // global
	Log("selBounds = " +  selBounds.toSource());
	Log("<");
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetActiveScript() {
    try {
        return app.activeScript;
    }
    catch(err) {
        return new File(err.fileName);
    }
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ParseInt(str) {
	var parsed = parseInt(str);
	
	if (isNaN(parsed)) {
		return 0;
	}
	else {
		return parsed;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Str(arr) {
	try {
	var arr = arr.slice(); // make a copy: don't spoil the original array
		for (var i = 0; i < arr.length; i++) {
			arr[i] = parseInt(arr[i]);
		}
		
		var str = arr.toString().replace(/,/g, "|");
		str = "[" + str + "]";

		return str;
    }
    catch(err) {
		Log(err.message + ", line: " + err.line, true);
    }
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Units() {
	if (storedUnits == null) { // Store current and set another units
		storedUnits = {horizontal: null, vertical: null, zeroPoint: null, rulerOrigin: null};
		
		if (doc.viewPreferences.horizontalMeasurementUnits != MeasurementUnits.POINTS) {
			storedUnits.horizontal = doc.viewPreferences.horizontalMeasurementUnits;
			doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.POINTS;
		}

		if (doc.viewPreferences.verticalMeasurementUnits != MeasurementUnits.POINTS) {
			storedUnits.vertical = doc.viewPreferences.verticalMeasurementUnits;
			doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS;
		}
		
		if (storedUnits.zeroPoint != [0, 0]) {
			storedUnits.zeroPoint = doc.zeroPoint.join();
			doc.zeroPoint = [0, 0];
		}
	
		var rulerOrigin = doc.viewPreferences.rulerOrigin;
		var rulerOriginStr = rulerOrigin.toString();
		var rulerOriginRestored = eval("RulerOrigin." + rulerOriginStr);
		
		if (doc.viewPreferences.rulerOrigin != RulerOrigin.PAGE_ORIGIN) {
			storedUnits.rulerOrigin = rulerOrigin.toString();
			doc.viewPreferences.rulerOrigin = RulerOrigin.PAGE_ORIGIN;
		}
	}
	else { // Restore original units
		if (storedUnits.horizontal != null) {
			doc.viewPreferences.horizontalMeasurementUnits = storedUnits.horizontal;
		}
		
		if (storedUnits.vertical != null) {
			doc.viewPreferences.verticalMeasurementUnits = storedUnits.vertical;
		}
		
		if (storedUnits.zeroPoint != null) {
			var arr = storedUnits.zeroPoint.split(",");
			doc.zeroPoint = [Number(arr[0]), Number(arr[1])];
		}
	
		if (storedUnits.rulerOrigin != null) {
			doc.viewPreferences.rulerOrigin = eval("RulerOrigin." + storedUnits.rulerOrigin);
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FindParentXmlEl(xmlEl, tag) {
	var result = null;
	
	while (xmlEl instanceof XMLElement) {
		if (xmlEl.markupTag.name == tag) {
			result = xmlEl;
			break;
		}
		xmlEl = xmlEl.parent;
	}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Log(text, err) {
	var header = null;
	
	var debugFunc = function (string) {
		for (var x in logDebugFuncList) {
			if (string == logDebugFuncList[x]) {
				return true;
			}
		}
		return false;
	}

	var callerName = function () {
		var arr = $.stack.split(/[\n]/),  
		caller = arr[arr.length - 3].replace(/\(.*\)/, "");
		return caller;  
	}

	if (log) { // log - everything | not in the list & not error | only errors & this is error
		var curFunc = callerName();
		
		if ((logErrOnly && err) || (!logErrOnly && !logDebugListOnly) || (!logErrOnly && logDebugListOnly && debugFunc(curFunc))) {
			if (typeof err == "undefined") err = false;
			if (typeof logOverwrite == "undefined") logOverwrite = false;
			var path = "~/Desktop/" + scriptName + " - ";
			var logFullFile = new File(path + "Log.txt");
			if (text == "EXE") {
				logFullFile.execute();
				return;
			}
			var logErrFile = new File(path + "Error Log.txt");


			if (logOverwrite) { // Remove existing files
				if (err) { // Error
					if (logErrFile.exists && logErrCount == 0) {
						logErrFile.remove();
					}
				}
				else { // Full
					if (logFullFile.exists && logFullCount == 0) {
						logFullFile.remove();
					}						
				}
			}

			if ((!err && logFullCount == 0) || (err && logErrCount == 0)) {
				header = "========== " + new Date().toLocaleString() + " ==========\rScript: " + scriptName + "\r";
				
				if (!logOverwrite) {
					header = "\r" + header;
				}
			}

			if (err) { // Error
				logErrArr.push(text);
				logErrCount++;
				WriteLog(logErrFile, "ERROR: " + text, header, curFunc);
				
				if (!logErrOnly) {
					WriteLog(logFullFile, "ERROR: " + text, ((!logHeaderAdded) ? header : null), curFunc);
				}
			}
			else { // Full
				logFullCount++;

				if (!logHeaderAdded) {
					WriteLog(logFullFile, text, header, curFunc);
					logHeaderAdded = true;
				}
				else {
					WriteLog(logFullFile, text, null, curFunc);
				}
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function WriteLog(file, text, header, curFunc) {
	file.encoding = "UTF-8";

	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}

	if (header != null) {
		file.write(header);
	}

	if (text == ">") {
		file.write("\r===>> " + curFunc + " ===\r");
	}
	else if (text == "<") {
		file.write("=== " + curFunc + " ===>>\r\r");
	}
	else {
		file.write(text + "\r");
	}
	
	file.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSide(selBounds) {
	Log(">");
	
	var pageCenter,
	result = null,
	pb = page.bounds,
	pageIsLeft = (page.side == PageSideOptions.LEFT_HAND) ? true : false;
	
	if (pageIsLeft) { // verso
		Log("verso");
		pageCenter = (pb[3] - pb[1]) / 2;
		Log("pageCenter = " + pageCenter);
		
		if (selBounds.middle < pageCenter) { // left part of the page
			Log("left part of the page");
			result = "ADD_TO_RIGHT";
		}
		else if (selBounds.middle > pageCenter) { // right part of the page
			Log("right part of the page");
			result = "ADD_TO_LEFT";
		}
	}
	else { // recto
		Log("recto");
		pageCenter = pb[1] + (pb[3] - pb[1]) / 2;
		
		// Correction for all rectos except for the 1-st page
		if (page.side == PageSideOptions.RIGHT_HAND && page.documentOffset > 0) { // page & pageWidth -- global
			pageCenter -= pageWidth;
		}

		Log("pageCenter = " + pageCenter);
		
		if (selBounds.middle < pageCenter) { // left part of the page
			Log("left part of the page");
			result = "ADD_TO_RIGHT";
		}
		else if (selBounds.middle > pageCenter) { // right part of the page
			Log("right part of the page");
			result = "ADD_TO_LEFT";
		}
	}

	Log("result = " + result);
	Log("<");	
	return result;
}