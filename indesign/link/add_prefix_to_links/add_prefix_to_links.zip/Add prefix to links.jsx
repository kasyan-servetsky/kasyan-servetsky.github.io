﻿var scriptName = "Add prefix to links",
doc;

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	var links = app.activeDocument.links;
	var p = prompt("What is the prefix to add?", "", scriptName);
	if (p == "") ErrorExit("You didn't enter the prefix.", true);

	if (p != null) {
		var lo = {};
		
		for (var i = 0; i < links.length; i++) {
			var f = File(links[i].filePath);
			var fName = f.name;
			try {
				if (!lo.hasOwnProperty(fName)) {
					f.rename(p + fName);
					lo[fName] = f;
					links[i].relink(f);
					f.close();
				}
				else {
					links[i].relink(lo[fName]);
					lo[fName].close();
				}
			}
			catch(err) {
				ErrorExit(err.message + ", line: " + err.line);
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------