﻿/* Copyright 2022, Kasyan Servetsky
November 6, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Copy selected links - 1.0",
debug = false, // for debugging only
count = 0,
doc, set, sel, folderNewLinks;

PreCheck();
//===================================== FUNCTIONS ======================================
function Main() {
	var item, image, link, file, story,
	imgTypes = ["TIFF", "JPEG", "Photoshop", "EPS", "InDesign Format Name", "CompuServe GIF", "Windows Bitmap", "Portable Network Graphics (PNG)", "Adobe Portable Document Format (PDF)"];

	for (var i = 0; i < sel.length; i++) {
		item = sel[i];
	
		try {			
			if (set.rbSelected == 0 && item.constructor.name != "TextFrame" && !item.hasOwnProperty("baseline") && item.hasOwnProperty("allGraphics") && item.allGraphics.length > 0) { // only images
				image = item.allGraphics[0];
				link = image.itemLink;
				CopyLink(link);
			}
			else if (set.rbSelected == 1) { // all links
				if (item.constructor.name == "TextFrame" || item.hasOwnProperty("baseline")) {
					story = item.parentStory;
					link = story.itemLink;
					CopyLink(link);
				}				
				else if (item.hasOwnProperty("allGraphics") && item.allGraphics.length > 0) {
					image = item.allGraphics[0];
					link = image.itemLink;
					CopyLink(link);
				}
			}
		}
		catch(err) {
			if (debug) $.writeln(err.message + ", line: " + err.line);
		}		
	} // end for
	
	if (set.report) {
		var report = count + " link" + ((count == 1) ? " was" : "s were") + " copied and relinked.";
		alert(report, scriptName, false);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CopyLink(link) {
	try {
		if (link != null && link.status == LinkStatus.NORMAL) {
			file = new File(set.newFolderPath + "/" + link.name);
			if (set.deleteExistingFiles && file.exists) {
				file.remove();
			}

			link.copyLink(folderNewLinks);
			count++;
			if (debug) $.writeln("Copied: " + link.name);
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line);
	}	
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		ErrorExit("The file path to the images folder hasn’t been defined yet. Run the ‘Set parameters’ script first to choose the folder where to copy the selected linked images.", true);
	}

	folderNewLinks = new Folder(set.newFolderPath);
	if (!folderNewLinks.exists) {
		ErrorExit("The selected folder doesn’t. Run the ‘Set parameters’ script first to choose another folder where to copy the selected linked images.", true);
	}
	
	sel = app.selection;
	if (sel.length == 0) ErrorExit("Nothing is selected.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function InArray(string, arr) {
	for (x in arr) {
		if (string == arr[x]) {
			return true;
		}
	}
	return false;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}