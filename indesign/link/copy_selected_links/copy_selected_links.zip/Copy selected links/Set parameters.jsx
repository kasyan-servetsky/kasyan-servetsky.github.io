﻿/* Copyright 2022, Kasyan Servetsky
November 6, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Copy selected links - 1.0",
folderNewLinks = null;

CreateDialog();
//===================================== FUNCTIONS ======================================
function CreateDialog() {
	GetDialogSettings();
	var w = new Window("dialog", scriptName);
	
	w.p = w.add("panel", undefined, "New links folder:");
	w.p.alignment = "fill";
	w.p.st = w.p.add("statictext");
	if (folderNewLinks == null || !folderNewLinks.exists) { 
		w.p.st.text = "No folder has been selected";
	}
	else {
		w.p.st.text = TrimPath(folderNewLinks.absoluteURI);
		w.p.st.helpTip = decodeURI(folderNewLinks.fsName);
	}
	w.p.bt = w.p.add("button", undefined, "Select...");
	w.p.bt.onClick = function() {
		var result = SelectFolder(this, "Select a folder with images.");
		if (result != null) {
			folderNewLinks = result;
		}
	}

	w.p1 = w.add("panel", undefined, "Relink");
	w.p1.alignment = "fill";
	w.p1.alignChildren = "left";
	w.p1.rb = w.p1.add("radiobutton", undefined, "only images");
	w.p1.rb1 = w.p1.add("radiobutton", undefined, "all links");
	if (set.rbSelected == 0) {
		w.p1.rb.value = true;
	}
	else {
		w.p1.rb1.value = true;
	}

	w.p2 = w.add("panel", undefined, "");
	w.p2.alignment = "fill";
	w.p2.alignChildren = "left";
	
	w.p2.cb = w.p2.add("checkbox", undefined, "Delete existing files");
	w.p2.cb.value = set.deleteExistingFiles;
	w.p2.cb.helpTip = "Before relinking, delete the file if it already exists.";
	
	w.p2.cb1 = w.p2.add("checkbox", undefined, "Report about relinked files");
	w.p2.cb1.value = set.report;
	w.p2.cb1.helpTip = "Report about the total number of relinked files.";	

	// Buttons
	w.g = w.add("group");
	w.g.orientation = "row";   
	w.g.alignment = "center";
	w.g.ok = w.g.add("button", undefined, "OK", {name: "ok" });
	w.g.ok.onClick = function() { // Use 'children[0]' because the panel is dynamically rebuilt on selecting a new folder so the original references become invalid
		if (w.p.children[0].text == "No folder has been selected") {
			alert("No 'Images' folder has been selected.", scriptName, true);
			return;			
		}
		else { // everythin's OK
			w.close(1);
		}
	}

	w.g.cancel = w.g.add("button", undefined, "Cancel", {name: "cancel"});
	
	var showDialog = w.show();
	 
	if (showDialog == 1) {
		set.newFolderPath = (folderNewLinks != null) ? folderNewLinks.absoluteURI + "/" : "";
		
		if (w.p1.rb.value) {
			set.rbSelected = 0;
		}
		else {
			set.rbSelected = 1;
		}
		
		set.deleteExistingFiles = w.p2.cb.value;
		set.report = w.p2.cb1.value;
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function SelectFolder(button, prompt) {
	var folder = Folder.selectDialog(prompt);
	
	if (folder != null) {
		var panel = button.parent;
		var window = panel.parent;
		var children = panel.children;
		var staticText = children[0];
		var button = button;
		panel.remove(staticText);
		panel.remove(button);
		staticText = panel.add("statictext", undefined, TrimPath(folder.absoluteURI));
		staticText.helpTip = decodeURI(folder.absoluteURI);
		button = panel.add("button", undefined, "Select...");
		button.onClick = function() {
			SelectFolder(this);
		}
		window.layout.layout(true);
		return folder;		
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function TrimPath(path) {
	path = decodeURI(path);
	var trimPath = ((path.split("/").length > 3) ? ".../" : "") + path.split("/").splice(-3).join("/");
	return trimPath;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {newFolderPath: "", rbSelected: 0, deleteExistingFiles: false, report: true};
	}

	folderNewLinks = new Folder(set.newFolderPath);
	if (!folderNewLinks.exists) {
		folderNewLinks = null;
	}

	return set;
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}