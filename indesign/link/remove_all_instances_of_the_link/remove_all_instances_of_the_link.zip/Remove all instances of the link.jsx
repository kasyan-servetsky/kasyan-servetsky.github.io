﻿#targetengine "kasyan"

var scriptName = "Remove all instances of the link";
var scriptMenuAction = app.scriptMenuActions.add(scriptName);
var eventListeners = scriptMenuAction.eventListeners.add("onInvoke", TriggerRemovAllInstanceOfTheLinkScript, false);

try {
	var linksPanelMenu = app.menus.item("$ID/#LinksUIPanelMenu"); // Links Panel Menu

	if (linksPanelMenu.isValid) {
		var removeLinksMenu = linksPanelMenu.menuItems.add(scriptMenuAction, LocationOptions.AFTER, linksPanelMenu.menuItems[3]);
	}
}
catch(err) {
	alert("ERROR: " + err.message + ", line: " + err.line);
}

function TriggerRemovAllInstanceOfTheLinkScript() {
	app.doScript(RemovAllInstanceOfTheLink, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" script");
}

function RemovAllInstanceOfTheLink() {
	if (app.documents.length == 0) ErrorExit("No documents are open. Please open a document and try again.", true);
	var doc = app.activeDocument;
	var links = doc.links;
	if (app.selection.length != 1) ErrorExit("Select one graphic frame with image.", true);
	var sel = app.selection[0];
	if (sel.graphics.length != 1) ErrorExit("Selected graphic frame should contain an image.", true);
	var selectedLink = sel.graphics[0].itemLink;
	var selectedLinkPath = selectedLink.filePath + "";
	if (selectedLink == null) ErrorExit("Selected item doesn't contain a link.", true);
	var allInstances = [];
	var counter = 0;
	 
	for (var j = 0; j < links.length; j++) {
		 if (links[j].filePath == selectedLink.filePath) {
			  allInstances.push(links[j]);
		 }
	}
	 
	if (allInstances.length == 1) {
		 if (!confirm("This link has only one instance. Do you want to delete it?", false, "Delete all instances of a link")) exit();
	}
	 
	for (var i = allInstances.length-1; i >= 0; i--) {
		 try {
			  var link = allInstances[i];
			  var image = link.parent;
			  var frame = image.parent;
			  frame.remove();
			  counter++;
		 }
		 catch(err) {}     
	}

	if (counter == 0) {
		 alert("No links have been removed", "Delete all instances of a link");
	}
	else if (counter == 1) {
		 alert("One clink has been removed", "Delete all instances of a link");
	}
	else if (counter > 1) {
		 alert(counter  + " links have been removed", "Delete all instances of a link");
	}
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}