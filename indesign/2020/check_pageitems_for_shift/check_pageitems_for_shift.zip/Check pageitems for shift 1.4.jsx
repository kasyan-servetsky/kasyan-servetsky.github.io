﻿/* Copyright 2020, Kasyan Servetsky
July 2, 2020
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//=======================================================================================
var scriptName = "Check pageitems for shift",
debugMode = false, // for debugging only
args = [],
calledFromBatchProcessor = (CalledFromBatchProcessor()) ? true : false;

if (calledFromBatchProcessor) { //  // called as a 'secondary' script from the batch processor
	if (typeof g.arguments != "undefined") {
		args = NormalizeArgs(g.arguments);
	}

	doc = app.activeDocument;
	Main();
}
else { // called as a 'regular' script
	if (app.documents.length > 0) Main();
}

//===================================== FUNCTIONS =======================================
function Main() {
	try {
		var item, xyNow, xyNowRounded, xyStrNow, where, shift, tfCont, xyStrExtracted, xyExtracted,
		readMode = (typeof args[0] === "undefined" || args[0] === null || args[0] === "") ? true : args[0], // true by default
		logArr = [],
		count = 0,
		page = null;
		var doc = app.activeDocument;
		var docName = doc.name;
		var allPageItems = doc.allPageItems;
		logArr.push("\r\r================");
		//logArr.push("readMode = " + readMode);
		if (debugMode) $.writeln("readMode = " + readMode);
		if (debugMode) $.writeln("================");
		
		logArr.push(docName + " — " + GetDate());

		// Save & change units
		var savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits;
		var savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
		doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.MILLIMETERS;
		doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.MILLIMETERS;

		for (var i = 0; i < allPageItems.length; i++) {
			item = allPageItems[i];
			
			if (item.hasOwnProperty("geometricBounds")) {
				xyNow = item.geometricBounds;
				
				xyNowRounded = [RoundString(xyNow[0], 1), RoundString(xyNow[1], 1)];
				
				xyStrNow = xyNowRounded.join();
				xyStrExtracted = item.extractLabel("bounds");
				xyExtracted = xyStrExtracted.split(",");

				if (debugMode) {
					$.writeln("i = " + i);
					$.writeln(xyStrNow + " (Now)");
					$.writeln((xyStrExtracted == "") ? "No label" : xyStrExtracted+ " (Before)");
				}
				
				if (readMode && xyStrExtracted != "" && xyStrNow != xyStrExtracted) { // Read & compare
					page = item.parentPage;
					//=============================================================================
					where = ((page != null) ? " — on page " + page.name : "") + " — ";
					
					shift = GetShift(xyExtracted[1], xyNowRounded[1], xyExtracted[0], xyNowRounded[0]); // xBefore, xNow, yBefore, yNow

					if (debugMode) $.writeln(i + " — " + item.constructor.name + " - Item.id " + item.id + where + " shifted" + shift);
					//=============================================================================
					
					if (item.constructor.name == "TextFrame") {
						tfCont = item.contents;
						
						if (tfCont.length > 50) {
							tfCont = tfCont.substr(0, 50) + "...";
						}
						
						if (!IsInArray("Text frame: " + tfCont + where + " shifted" + shift, logArr)) {
							logArr.push("Text frame: " + tfCont + where + " shifted" + shift);
							count++;
						}
					}
					else if (item.constructor.name == "Image") {
						if (!IsInArray("Image: " + item.itemLink.name + where + " shifted" + shift, logArr)) {
							logArr.push("Image: " + item.itemLink.name + where + " shifted" + shift);
							count++;
						}
					}
					else {
						if (item.hasOwnProperty("images") && item.images.length > 0) {
							if (!IsInArray("Image: " + item.images[0].itemLink.name + where + " shifted" + shift, logArr)) {
								logArr.push("Image: " + item.images[0].itemLink.name + where + " shifted" + shift);
							}
						}
						else {
							if (!IsInArray(item.constructor.name + " — Item.id — " + item.id + where + " shifted" + shift, logArr)) {
								logArr.push(item.constructor.name + " — Item.id — " + item.id + where + " shifted" + shift);
							}
						}

						count++;
					}
				}
				else if (!readMode) { // Write
					item.insertLabel("bounds", xyStrNow);
				}
			}
		} // end for
	
		// Restore units
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;

		logArr.push("---------------------------");
		var report = "Found " + count + " item" + ((count == 1) ? "" : "s") + " shifted";
		logArr.push(report);
		
		if (readMode && count > 0) {
			var logStr = logArr.join("\r");
			WriteToFile(logStr);
		}
	}
	catch(err) { // if an error occurs, catch it and write the  document's name, error message and line# where it happened into the log
		if (calledFromBatchProcessor) g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", Line: " + err.line + ", Time: " + GetTime());
		if (debugMode) $.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetShift(xBefore, xNow, yBefore, yNow) {
	xBefore = Number(xBefore);
	xNow = Number(xNow);
	yBefore = Number(yBefore);
	yNow = Number(yNow);
	var result = "";
	
	var xShift = xNow - xBefore;
	if (xShift != 0) {
		result += " horizontally by " + xShift + " mm";
	}

	var yShift = yNow - yBefore;
	if (yShift != 0) {
		result += ((xShift != 0) ? "," : "") + " vertically by " + yShift + " mm";
	}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IsInArray(string, arr) {
	for (x in arr) {
		if (string == arr[x]) {
			return true;
		}
	}
	return false;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function RoundString(numVal, decimals) {
    var retVal = Math.round(numVal * Math.pow(10,decimals)) + "";
    retVal = retVal.substring(0,retVal.length-decimals) + "." + retVal.substring(retVal.length-decimals);
    return retVal;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function WriteToFile(text) {
	file = new File("~/Desktop/Log.txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text); 
	file.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDate() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//=======================================================================================
function GetTime() { // get exact time for the log -- hr : min : sec -- so we could know when exactly an error occured
	var date = new Date();
	var dateString = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CalledFromBatchProcessor() { // Let's see if it's called as a 'secondary' (returns true) or as a 'regular' (returns false) script
	var result = false;
	
	try {
		var arr = $.stack.split(/[\n]/);
		if (arr.length > 0 && arr[0].match(/\[Batch processor/i) != null) {
			result = true;
		}
	}
	catch(err) {}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function NormalizeArgs(args) { // convert a string value read from the arguments file to actual boolen data type (or undefined)
	for (var i = 0; i < args.length; i++) {
		if (args[i] == "true" || args[i] == "false" || args[i] == "undefined" || args[i] == "null") {
			args[i] = eval(args[i]);
		}
	}

	return args;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) { // Something went totally wrong.
	alert(error, scriptName, icon); // Give a warning
	exit(); // and stop the script
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------