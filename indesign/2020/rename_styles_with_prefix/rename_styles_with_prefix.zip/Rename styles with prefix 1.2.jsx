﻿// Global variables are defined here
var scriptName = "Rename styles with prefix",
debugMode = true, // for debugging only
args = [],
calledFromBatchProcessor = (typeof arguments != "undefined" && CalledFromBatchProcessor()) ? true : false;

if (calledFromBatchProcessor) { // called as a 'secondary' from 
	var args = NormalizeArgs(arguments);
	main();
}
else { // called as a 'regular' script
	if (app.documents.length > 0) main();
}

//===================================== FUNCTIONS =======================================
function main() {
	try {
		var doc = app.activeDocument,
		prefix;
		
		if (args.length == 0 || // we have at least one argument
			typeof args[0] === "undefined" ||
			args[0] === null ||
			args[0] === "") // empty string
		{
			prefix = "MyPrefix_"; // set a default value
		}
		else {
			prefix = args[0];
		}
		
		renameParStyles(doc, prefix);
		renameCharStyles(doc, prefix);
		renameObjStyles(doc, prefix);
	}
	catch(err) { // if an error occurs, catch it and write the  document's name, error message and line# where it happened into the log
		if (calledFromBatchProcessor) g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", Line: " + err.line + ", Time: " + GetTime());
		if (debugMode) $.writeln(err.message + ", line: " + err.line); // in debugMode -- write the error message and line# to ESTK console
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function renameParStyles(doc, prefix) {
	var style,
	styles = doc.allParagraphStyles;
	
	for (var i = 0; i < styles.length; i++) {
		style = styles[i];

		if (style.name.match(/^\[.+\]$/) == null && style.name.indexOf(prefix) != 0) {
			style.name = prefix + style.name;
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function renameCharStyles(doc, prefix) {
	var style,
	styles = doc.allCharacterStyles;
	
	for (var i = 0; i < styles.length; i++) {
		style = styles[i];
		
		if (style.name.match(/^\[.+\]$/) == null && style.name.indexOf(prefix) != 0) {
			style.name = prefix + style.name;
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function renameObjStyles(doc, prefix) {
	var style,
	styles = doc.allObjectStyles;
	
	for (var i = 0; i < styles.length; i++) {
		style = styles[i];
		
		if (style.name.match(/^\[.+\]$/) == null && style.name.indexOf(prefix) != 0) {
			style.name = prefix + style.name;
		}
	}
}
//=======================================================================================
function GetTime() { // get exact time for the log -- hr : min : sec -- so we could know when exactly an error occured
	var date = new Date();
	var dateString = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CalledFromBatchProcessor() { // Let's see if it's called as a 'secondary' (returns true) or as a 'regular' (returns false) script
	var result = false;
	
	try {
		var arr = $.stack.split(/[\n]/);
		if (arr.length > 0 && arr[0].match(/\[Batch processor/i) != null) {
			result = true;
		}
	}
	catch(err) {}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function NormalizeArgs(args) { // convert a string value read from the arguments file to actual boolen data type (or undefined)
	for (var i = 0; i < args.length; i++) {
		if (args[i] == "true" || args[i] == "false" || args[i] == "undefined" || args[i] == "null") {
			args[i] = eval(args[i]);
		}
	}

	return args;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) { // Something went totally wrong.
	alert(error, scriptName, icon); // Give a warning
	exit(); // and stop the script
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------