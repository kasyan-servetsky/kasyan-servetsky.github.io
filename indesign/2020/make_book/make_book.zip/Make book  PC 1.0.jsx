﻿var scriptName = "Make book",
doc;

Main();

//===================================== FUNCTIONS ======================================
function Main() {
	var inddFile;
	if (File.fs == "Macintosh") ErrorExit("This script is for Windows only.", true);
	var excelFile = File.openDialog("Pick the excel file", "Excel files:*.xlsx;*.xlsm", false);
	if (excelFile != null) {
		var excelFilePath = excelFile.fsName.replace(/\\/g, "\\\\");
		var splitChar = ";";
		var sheetNumber = "1";
		var data = GetDataFromExcelPC(excelFilePath, splitChar, 1)
		var list = NormalizeData(data);
		
		if ( list.length > 0 ) {
			var myBookFileName = excelFilePath.replace(/xls(x|m)$/, "indb");
			myBookFile = new File( myBookFileName );
			if ( myBookFile.exists ) {
				ErrorExit("The book already exists in this location and with the same name: " + excelFilePath, true);
			}
			else {
				 myBook = app.books.add( myBookFile );
				 myBook.automaticPagination = false;
				 				 
				 for ( i=0; i < list.length; i++ ) {
					 inddFile = new File(list[i]);
					 if (inddFile.exists) {
						myBook.bookContents.add( File(list[i]) );
					}
				 }
				 myBook.save( );
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function NormalizeData(data) {
	var list = [];
	
	for (var i = 0; i < data.length; i++) {
		list.push(data[i][0]);
	}

	return list;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDataFromExcelPC(excelFilePath, splitChar, sheetNumber) {
	try {
		if (typeof splitChar === "undefined") var splitChar = ";";
		if (typeof sheetNumber === "undefined") var sheetNumber = "1";
		var appVersionNum = Number(String(app.version).split(".")[0]),
		data = [];

		var vbs = 'Public s, excelFilePath\r';
		vbs += 'Function ReadFromExcel()\r';
		vbs += 'On Error Resume Next\r';
		vbs += 'Err.Clear\r';
		vbs += 'Set objExcel = CreateObject("Excel.Application")\r';
		vbs += 'Set objBook = objExcel.Workbooks.Open("' + excelFilePath + '", 0, False, 1, "SCCP237A")\r';
		vbs += 'Set objSheet =  objExcel.ActiveWorkbook.WorkSheets(' + sheetNumber + ')\r';
		vbs += 's = s & "[" & Trim(objSheet.Name) & "]"\r';
		vbs += 'objExcel.Visible = True\r';
		vbs += 'matrix = objSheet.UsedRange\r';
		vbs += 'maxDim0 = UBound(matrix, 1)\r';
		vbs += 'maxDim1 = UBound(matrix, 2)\r';
		vbs += 'For i = 1 To maxDim0\r';
		vbs += 'For j = 1 To maxDim1\r';
		vbs += 'If j = maxDim1 Then\r';
		vbs += 's = s & matrix(i, j)\r';
		vbs += 'Else\r';
		vbs += 's = s & matrix(i, j) & "' + splitChar + '"\r';
		vbs += 'End If\r';
		vbs += 'Next\r';
		vbs += 's = s & vbCr\r';
		vbs += 'Next\r';
		vbs += 'objBook.close\r';
		vbs += 'Set objSheet = Nothing\r';
		vbs += 'Set objBook = Nothing\r';
		vbs += 'Set objExcel = Nothing\r';
		vbs += 'SetArgValue()\r';
		vbs += 'On Error Goto 0\r';
		vbs += 'End Function\r';
		vbs += 'Function SetArgValue()\r';
		vbs += 'Set objInDesign = CreateObject("InDesign.Application")\r';
		vbs += 'objInDesign.ScriptArgs.SetValue "excelData", s\r';
		vbs += 'End Function\r';
		vbs += 'ReadFromExcel()\r';

		if (appVersionNum > 5) { // CS4 and above
			app.doScript(vbs, ScriptLanguage.VISUAL_BASIC, undefined, UndoModes.FAST_ENTIRE_SCRIPT);
		}
		else { // CS3 and below
			app.doScript(vbs, ScriptLanguage.VISUAL_BASIC);
		}

		var str = app.scriptArgs.getValue("excelData");
		app.scriptArgs.clear();
		
		var tempArrLine, line, match, name,
		tempArrData = str.split("\r");
		
		for (var i = 0; i < tempArrData.length; i++) {
			line = tempArrData[i];
			if (line == "") continue;
			
			match = line.match(/^\[.+\]/);
			
			if (match != null) {
				name = match[0].replace(/\[|\]/g, "");
				line = line.replace(/^\[.+\]/, "");
			}
			
			tempArrLine = line.split(splitChar);
			data.name = name;
			data.push(tempArrLine);
		}
		
		return data;
	}
	catch(err) {
		alert(err.message + ", line: " + err.line, scriptName, true);
		exit();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------