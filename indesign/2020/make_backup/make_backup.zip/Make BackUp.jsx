﻿/* Copyright 2018, Kasyan Servetsky
November 9, 2018
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Make BackUp",
doc;

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	var docBasicName = doc.name.replace(/\.indd$/, ""); // remove the extension from the document's name
	var packageAllDocsFolderPath = "~/Documents/My Backups/";
	var packageAllDocsFolder = new Folder(packageAllDocsFolderPath);
	if (!packageAllDocsFolder.exists) packageAllDocsFolder.create(); // create if it doesn't exist yet
	var packageDocFolderPath = packageAllDocsFolderPath + docBasicName; // the path to the package folder. Used as the 'to' parameter of the 'packageForPrint' method  - Data Type: File - The folder, alias, or path in which to place the packaged files
	var packageDocFolder = new Folder(packageDocFolderPath); // the reference to the package folder
	
	if (!packageDocFolder.exists) { // create if it doesn't exist yet
		packageDocFolder.create();
	}
	else { // if exists, don't overwrite it: create a new folder with unique incrementin number at the end of the name
		var increment = 1;
		while (packageDocFolder.exists) {
			packageDocFolder = new Folder(packageAllDocsFolderPath  + "/" + docBasicName + "_(" + increment++ + ")");
		}
		packageDocFolder.create();
	}

	var result = doc.packageForPrint(packageDocFolder, 
													false, // copyingFonts, 
													true, // copyingLinkedGraphics, 
													false, // copyingProfiles, 
													true, // updatingGraphics, 
													true, // includingHiddenLayers, 
													true, // ignorePreflightErrors, 
													false, // creatingReport, 
													false, // includeIdml, 
													false, // includePdf, 
												);
	
	doc.viewPreferences.showRulers = false;
	doc.guidePreferences.guidesShown = false;
	
	with (doc.layoutWindows[0]) {
		zoom(ZoomOptions.fitSpread);
		viewDisplaySetting = ViewDisplaySettings.HIGH_QUALITY;
		overprintPreview = true;
		screenMode = ScreenModeOptions.PREVIEW_TO_PAGE;		
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------