﻿var scriptName = "Reflect the page number of a printed book to the eBook",
debugMode = false,
doc, charStyleHiddenText;

PreCheck();
//===================================== FUNCTIONS ======================================
function Main() {
	var page, pageName, mainFrame, column, columnNum;
	if (debugMode) $.writeln("======================");
		
	for (var i = doc.pages.length - 1; i >= 0; i--) {
		page = doc.pages[i];
		pageName = page.name;
		if (debugMode) $.writeln("page - " + pageName);
		mainFrame = GetItemFromCollection("main", page.textFrames);

		if (mainFrame != null) {
			var textColumns = mainFrame.textColumns;
			var textColumnsLength = textColumns.length;
			
			for (var c = textColumnsLength - 1; c >= 0; c--) {

				column = textColumns[c];
				columnNum = (c + 1) + "";
				if (debugMode) $.writeln("  column - " + columnNum);
				AddMarker(column, columnNum, pageName);
			}
			
			mainFrame.recompose();
		} 
		else {
			if (debugMode) $.writeln("mainFrame == null");
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddMarker(column, columnNum, pageName) {
	try {
		if (column.characters.length > 0) {
			var firstChar = column.characters[0];

			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
			app.findGrepPreferences.findWhat = ".";
			app.changeGrepPreferences.changeTo = "<!--page[" + pageName + "]c" + columnNum + "-->" + "$0";
			
			var changed_1 = firstChar.changeGrep();

			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
			app.findGrepPreferences.findWhat = "<!--page\\[\\d+\\]c\\d+-->";
			app.changeGrepPreferences.appliedCharacterStyle = charStyleHiddenText;
			var changed_2 = changed_1[0].changeGrep();
		}
	}
	catch(err) {
		if (debugMode) $.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeCharStyle(name, properties) {
	var charStyle = doc.characterStyles.item(name);
	if (!charStyle.isValid) {
		charStyle = doc.characterStyles.add({name: name});
		if (properties != undefined) charStyle.properties = properties;
	}
	return charStyle;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	charStyleHiddenText = MakeCharStyle("Hidden text", {pointSize: "0.1 pt", fillColor: "Paper"});
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
