﻿var scriptName = "List the fonts in the current doc",
doc;

PreCheck();
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var arr = [],
		fonts = doc.fonts.everyItem().getElements();
		
		for (var i = 0; i < fonts.length; i++) {
			arr.push(fonts[i].name.replace("\t", " "));
		}
		
		var text = arr.join("\r");
		WriteToFile(text);
		alert("Found " + arr.length + " fonts:\r\r" + text, scriptName, false);
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function WriteToFile(text) {
	var file = new File("~/Desktop/" + scriptName + ".txt");
	file.encoding = "UTF-8";
	file.open("w");
	file.write(text); 
	file.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------