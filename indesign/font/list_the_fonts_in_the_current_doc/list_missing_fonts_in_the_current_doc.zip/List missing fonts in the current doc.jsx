﻿var scriptName = "List missing fonts in the current doc",
doc;

PreCheck();
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var arr = [],
		fonts = doc.fonts.everyItem().getElements();
		
		for (var i = 0; i < fonts.length; i++) {
			if (fonts[i].status != FontStatus.INSTALLED) {
				arr.push(fonts[i].name.replace("\t", " "));
			}
		}
		
		var text = arr.join("\r");
		WriteToFile(text);
		alert("Found " + arr.length + " missing fonts:\r\r" + text, scriptName, false);
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}

function WriteToFile(text) {
	var file = new File("~/Desktop/" + scriptName + ".txt");
	file.encoding = "UTF-8";
	file.open("w");
	file.write(text); 
	file.close();
}

function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];

	Main();
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}