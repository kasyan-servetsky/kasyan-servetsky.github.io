﻿/* Copyright 2024, Kasyan Servetsky
March 28, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Change fonts CSV - 2.3",
doc,
set = GetDialogSettings();

CreateDialog();
//===================================== FUNCTIONS ======================================
function CreateDialog() {
	var w = new Window("dialog", scriptName);
	
	w.p = w.add("panel", undefined, "Process:");
	w.p.orientation = "column";
	w.p.alignment = "fill";
	
	w.p.g = w.p.add("group");
	w.p.g.orientation = "column";
	w.p.g.alignChildren = "left";
	
	w.p.g.cb = w.p.g.add("checkbox", undefined, "Paragraph styles");
	w.p.g.cb.value = set.parStyles;
	
	w.p.g.cb1 = w.p.g.add("checkbox", undefined, "Character styles");
	w.p.g.cb1.value = set.charStyles;
	
	w.p.g.cb2 = w.p.g.add("checkbox", undefined, "Find-Change");
	w.p.g.cb2.value = set.findChange;	
	
	w.p.g.cb3 = w.p.g.add("checkbox", undefined, "Text style ranges");
	w.p.g.cb3.value = set.textStyleRanges;
	
	w.p.g.cb4 = w.p.g.add("checkbox", undefined, "Only missing fonts");
	w.p.g.cb4.value = set.onlyMissingFonts;	

	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok"});
	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		with (set) {
			parStyles = w.p.g.cb.value;
			charStyles = w.p.g.cb1.value;
			findChange = w.p.g.cb2.value;
			textStyleRanges = w.p.g.cb3.value;
			onlyMissingFonts = w.p.g.cb4.value;
		}
	
		app.insertLabel("Kas_" + scriptName, set.toSource());
	}	
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {
					parStyles: true,
					charStyles: true,
					findChange: true,
					textStyleRanges: true,
					onlyMissingFonts: false
				};
	}
	//var tmp = set;

	return set;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------