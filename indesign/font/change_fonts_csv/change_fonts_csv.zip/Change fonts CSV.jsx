﻿/* Copyright 2024, Kasyan Servetsky
March 28, 2024
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
//$.level = 2;
var scriptName = "Change fonts CSV - 2.3",
csvFileName = "Change fonts list.csv", // CSV file name
doc, fontList,
progressBar, progressTxt,
countParStyles = countCharStyles = countFC = countTsrApplied = 0,
debugMode = false, // for debugging only true | false
args = [],
useArgs = false,
set = GetDialogSettings(),
calledFromBatchProcessor = CalledFromBatchProcessor();

if (calledFromBatchProcessor) { // called as a 'secondary' script from the batch processor
	if (typeof g.arguments != "undefined") {
		useArgs = true;
		args = NormalizeArgs(g.arguments);
	}

	if (g.doc != null) { // If the script is called from the batch processor and the g.doc variable is sent from it, the doc variable is set to g.doc.
		doc = g.doc; // With the all open documents option selected, make sure to use g.doc variable to send the current document from the batch processor to this script otherwise, it will not work correctly.
		Main();
	}
}
else { // called as a 'regular' script
	PreCheck();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	try {
		var report, csvFile,
		startTime = new Date();		
		
		// CSV file
		if (calledFromBatchProcessor) {
			if (useArgs) {
				g.WriteToFile("The arguments file is used: '" + decodeURI(g.argumentsFile.fsName));
				fontList = args;
			}
			else {
				csvFile = GetCsv();
				if (csvFile == null) {
					g.WriteToFile("ERROR: The CSV file '" + csvFileName + "' is missing.");
					return;
				}
				else {
					g.WriteToFile("The CSV file is used: '" + decodeURI(csvFile.fsName));
					fontList = ReadCsvData(csvFile); // global					
				}
			}
		}
		else { // used as a stanalone script
			csvFile = GetCsv(); // already checked in PreCheck
			fontList = ReadCsvData(csvFile); // global
		}
	
		// Progress bar
		if (!calledFromBatchProcessor) {
			var progressWin = new Window("window", scriptName);
			progressBar = progressWin.add("progressbar", undefined, 0, undefined); // global
			progressBar.preferredSize.width = 600;
			progressTxt = progressWin.add("statictext", undefined, ""); // global
			progressTxt.alignment = "fill";
			progressWin.show();
		}

		// Change in paragraph styles
		if (set.parStyles) ProcessParStyles();

		// Change in character styles
		if (set.charStyles) ProcessCharStyles();

		// Find - change
		if (set.findChange) ProcessFindChange();
		
		// Text style ranges	
		if (set.textStyleRanges) ProcessTextStyleRanges();

		// Finish
		if (!calledFromBatchProcessor)progressWin.close();
		var endTime = new Date();
		var duration = GetDuration(startTime, endTime);
		
		if (countParStyles == 0 && countCharStyles == 0 && countFC == 0 && countTsrApplied == 0) {
			report = "No changes have been made to the document.";
		}
		else {
			report = "Changed fonts in " + countParStyles + 
						" paragraph style" + ((countParStyles == 1)  ? ", " : "s, ") + 
						countCharStyles + " character style" + ((countCharStyles == 1)  ? "," : "s,") + 
						" and " + (countFC + countTsrApplied) + " instance" + 
						(((countFC + countTsrApplied) == 1)  ? "" : "s") + 
						" of locally formatted text (via find-change: " + countFC + ", and via text style ranges: " + countTsrApplied + 
						")\n(time elapsed: " + duration + ")";
		}
	
		if (calledFromBatchProcessor) {
			g.WriteToFile("\r" + report);
		}
		else {
			alert(report, scriptName);
		}
	}
	catch(err) { // if an error occurs, catch it and write the  document's name, error message and line# where it happened into the log
		if (calledFromBatchProcessor) {
			g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", Line: " + err.line + ", Time: " + GetTime());
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessParStyles() {
	var paragraphStyle, oldFont, newFont,
	paragraphStyles = doc.allParagraphStyles;
	
	if (calledFromBatchProcessor) {
		g.WriteToFile("\nProcessing paragraph styles");
	}
	else {
		progressTxt.text = "Processing paragraph styles";
		progressBar.minvalue = 0;
		progressBar.maxvalue = paragraphStyles.length;
	}
	
	for (var p = 1; p < paragraphStyles.length; p++) {
		if (!calledFromBatchProcessor) progressBar.value = p;
		paragraphStyle = paragraphStyles[p];
		oldFont = paragraphStyle.appliedFont;
		
		if (!set.onlyMissingFonts || (set.onlyMissingFonts && oldFont.status != FontStatus.INSTALLED)) {
			newFont = FindFont(oldFont.name, fontList);
			if (newFont != null) {
				paragraphStyle.appliedFont = newFont;
				countParStyles++;
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessCharStyles() {
	var characterStyle, oldFontFamilyName, oldFontStyle, oldFont, newFont,
	characterStyles = doc.allCharacterStyles;
	
	if (calledFromBatchProcessor) {
		g.WriteToFile("\nProcessing character styles");
	}
	else {
		progressTxt.text = "Processing character styles";
		progressBar.minvalue = 0;
		progressBar.maxvalue = characterStyles.length;
	}

	for (var c = 1; c < characterStyles.length; c++) {
		if (!calledFromBatchProcessor) progressBar.value = c;
		characterStyle = characterStyles[c];
		oldFontFamilyName = characterStyle.appliedFont;
		oldFontStyle = characterStyle.fontStyle;
		
		if (set.onlyMissingFonts) {
			oldFont = FindDocFont(oldFontFamilyName, oldFontStyle);
			if (oldFont != null) continue; // font installed -- skip it
		}
	
		newFont = FindFont(oldFontFamilyName + "\t" + oldFontStyle, fontList);
		if (newFont != null) {
			characterStyles[c].appliedFont = newFont;
			countCharStyles++;
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FindDocFont(fontFamilyName, fontStyle) {
	var font;
	var result = null;
	var name = fontFamilyName.replace(/\s+$/,"").replace(/^\s+/,"") + ((fontStyle != NothingEnum.NOTHING) ? "\t" + fontStyle : "");

	if (fontFamilyName != "") {
		font = doc.fonts.itemByName(name);
		
		if (font.isValid && font.status == FontStatus.INSTALLED) {
			result = font;
		}
	}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessFindChange() {
	var oldFont, newFont, changed;
	
	if (calledFromBatchProcessor) {
		g.WriteToFile("\nProcessing find-change");
	}
	else {
		progressTxt.text = "Processing find-change";
		progressBar.minvalue = 0;
		progressBar.maxvalue = fontList.length;
	}

	if (debugMode) { // for debugging
		var blue = MakeColor("=== Blue ===", ColorSpace.RGB, ColorModel.process, [0, 0, 255]);
	}

	with (app.findChangeTextOptions) {
		includeMasterPages = true;
		includeHiddenLayers = true;
		includeLockedLayersForFind = true;
		includeLockedStoriesForFind = true;
		includeFootnotes = true;
		wholeWord = false;
		caseSensitive = false;
	}

	for (var i = 0; i < fontList.length; i++) {
		if (!calledFromBatchProcessor) progressBar.value = i + 1;
		app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
//~ 		oldFont = app.fonts.itemByName(fontList[i][0]);
		oldFont = fontList[i][0];
//~ debugger;
		if (!set.onlyMissingFonts || (set.onlyMissingFonts && oldFont.status != FontStatus.INSTALLED)) {
//~ 			newFont = FindFont(fontList[i][1], fontList);
			newFont = FindFont(oldFont, fontList);
			
			if (newFont != null) {
				app.findTextPreferences.appliedFont = oldFont;
				app.changeTextPreferences.appliedFont = newFont;
				
				if (debugMode) { // for debugging
					app.changeTextPreferences.fillColor = blue;
				}

				changed = doc.changeText();
			
				countFC += changed.length;
				app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
			}
		}
	} // end for
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessTextStyleRanges() {
	var tsr, oldFontName, oldFont, newFont,
	countTsr = 0,
	textStyleRanges = doc.stories.everyItem().textStyleRanges.everyItem().getElements();
	
	if (calledFromBatchProcessor) {
		g.WriteToFile("\nProcessing text style ranges");
	}
	else {
		progressTxt.text = "Processing text style ranges";			
		progressBar.minvalue = 0;
		progressBar.maxvalue = textStyleRanges.length;
	}		

	if (debugMode) { // for debugging
		var red = MakeColor("=== Red ===", ColorSpace.RGB, ColorModel.process, [255, 0, 0]);
		var green = MakeColor("=== Green ===", ColorSpace.RGB, ColorModel.process, [0, 255, 0]);
	}

	while (tsr = textStyleRanges.shift()) {
		countTsr++;
		if (!calledFromBatchProcessor) progressBar.value = countTsr;
		oldFont = tsr.appliedFont;
		oldFontName = tsr.appliedFont.name;
	
		if (!set.onlyMissingFonts || (set.onlyMissingFonts && oldFont.status != FontStatus.INSTALLED)) {
			newFont = FindFont(oldFontName, fontList);

			if (newFont != null) {
				try {
					tsr.appliedFont = newFont;
					countTsrApplied++;
					if (debugMode) tsr.fillColor = green; // for debugging
				}
				catch(err) {
					if (calledFromBatchProcessor) {
						g.WriteToFile("ERROR: " + err.message + ", line: " + err.line);
					}
					else if (debugMode) { // for debugging
						tsr.fillColor = red;
					}
				}
			}
		}
	} // end while
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FindFont(oldFontName, list) {
	var newFontName, newFont;
	oldFontName = oldFontName.replace(/\s+$/,"").replace(/^\s+/,"");
	
	for (var x in list) {
		if (oldFontName == list[x][0].replace(/\s+$/,"").replace(/^\s+/,"")) {
			newFontName = list[x][1].replace(/\s+$/,"").replace(/^\s+/,"");
			newFont = app.fonts.itemByName(newFontName);
			
			if (newFont.isValid && newFont.status == FontStatus.INSTALLED) {
				return newFont;
			}
		}
	}

	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ReadCsvData(csvFile) {
	var line, temp, csvRecord, tempArr;
	var csvData = [];
	csvFile.open("r");
	
	while (!csvFile.eof) { 
		line = csvFile.readln();
		if (line == "") continue; // skip empty lines
		tempArr = line.split(";");
		if (tempArr[0] == "" || tempArr[1] == "") continue; // skip if one element is empty
		
		csvData.push([
							eval("\"" + tempArr[0] + "\""), // A -- Find
							eval("\"" + tempArr[1]+ "\"") // B -- Change to
							]);
	}

	csvFile.close();
	
	return csvData;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetCsv() {
	var scriptFile = GetActiveScript();
	var scriptFolderPath = decodeURI(scriptFile.path) + "/";
	var csvFilePath = scriptFolderPath + csvFileName;
	var csvFile = new File(csvFilePath);

	if (csvFile.exists) {
		return csvFile;
	}
	else {
		return null;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetActiveScript() {
    try {
        return app.activeScript;
    }
    catch(err) {
        return new File(err.fileName);
    }
}
//=======================================================================================
function GetTime() { // get exact time for the log -- hr : min : sec -- so we could know when exactly an error occured
	var date = new Date();
	var dateString = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CalledFromBatchProcessor() { // Let's see if it's called as a 'secondary' (returns true) or as a 'regular' (returns false) script
	var result = false;
	
	try {
		var arr = $.stack.split(/[\n]/);
		if (arr.length > 0 && arr[0].match(/\[Batch processor/i) != null) {
			result = true;
		}
	}
	catch(err) {}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function NormalizeArgs(args) {
	var line, temp, csvRecord, tempArr,
	csvData = [];
	
	for (var i = 0; i < args.length; i++) {
		line = args[i];
		if (line == "") continue; // skip empty lines
		tempArr = line.split(";");
		if (tempArr[0] == "" || tempArr[1] == "") continue; // skip if one element is empty
		
		csvData.push([
							eval("\"" + tempArr[0] + "\""), // A -- Find
							eval("\"" + tempArr[1]+ "\"") // B -- Change to
							]);
	}

	return csvData;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	if (GetCsv() == null) ErrorExit("The CSV file '" + csvFileName + "' is missing. It should be located in the same folder as this script.", true);
	
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) { // Something went totally wrong.
	alert(error, scriptName, icon); // Give a warning
	exit(); // and stop the script
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CharCodeString(str) { // for debugging only
	if (str.constructor.name == "Enumerator") return null;
	
	var s = "";
	
	for (var i = 0; i < str.length; i++) {
		s += ((i != 0) ? "|" : "") + str.charCodeAt(i);
	}

	return s;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeColor(colorName, colorSpace, colorModel, colorValue) { // for debugging only
	var doc = app.activeDocument;
	var color = doc.colors.item(colorName);
	if (!color.isValid) {
		color = doc.colors.add({name: colorName, space: colorSpace, model: colorModel, colorValue: colorValue});
	}
	return color;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {
					parStyles: true,
					charStyles: true,
					findChange: true,
					textStyleRanges: true,
					onlyMissingFonts: false
				};
	}

	return set;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------