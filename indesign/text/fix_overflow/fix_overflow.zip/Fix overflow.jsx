﻿/* Copyright 2022, Kasyan Servetsky
October 3, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Fix overflow - 2.0",
debug = false, // for debugging only
set, doc, tf;

if (!debug && typeof arguments == "undefined") {
	ErrorExit("This script should be run from the one of the following  scripts located in the same folder: Right, Left, Top, Bottom, Top-Right, Top-Left, Bottom-Right, Bottom-Left.", true);
}

var mode = (debug) ? "bottom" : arguments[0]; 

PreCheck();
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits;
		var savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
		doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.POINTS;
		doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS;

		var count = 0,
		gb = tf.geometricBounds,
		widthOriginal = gb[3] - gb[1],
		heightOriginal = gb[2] - gb[0];
		
		if (set.alignBaselineGridOff && tf.texts[0].alignToBaseline) {
			tf.texts[0].alignToBaseline = false;
		}

		while (tf.overflows && (gb[3] - gb[1]) < (widthOriginal + set.increaseLimit) && (gb[2] - gb[0]) < (heightOriginal + set.increaseLimit)) {
			if (mode == "right") {
				gb = [gb[0], gb[1], gb[2], gb[3] + set.increment];
			}
			else if (mode == "left") {
				gb = [gb[0], gb[1] - set.increment, gb[2], gb[3]];
			}
			else if (mode == "top") {
				gb = [gb[0] - set.increment, gb[1], gb[2], gb[3]];
			}
			else if (mode == "bottom") {
				gb = [gb[0], gb[1], gb[2] + set.increment, gb[3]];
			}
			else if (mode == "top-right") {
				(count % 2) ? gb = [gb[0] - set.increment, gb[1], gb[2], gb[3]] : gb = [gb[0], gb[1], gb[2], gb[3] + set.increment];
			}
			else if (mode == "top-left") { 
				(count % 2) ? gb = [gb[0] - set.increment, gb[1], gb[2], gb[3]] : gb = [gb[0], gb[1] - set.increment, gb[2], gb[3]];
			}
			else if (mode == "bottom-right") {
				(count % 2) ? gb = [gb[0], gb[1], gb[2] + set.increment, gb[3]] : gb = [gb[0], gb[1], gb[2], gb[3] + set.increment];
			}
			else if (mode == "bottom-left") {
				(count % 2) ? gb = [gb[0], gb[1], gb[2] + set.increment, gb[3]] : gb = [gb[0], gb[1] - set.increment, gb[2], gb[3]];
			}
			else if (mode == "top-bottom") {
				(count % 2) ? gb = [gb[0] - set.increment, gb[1], gb[2], gb[3]] : gb = [gb[0], gb[1], gb[2] + set.increment, gb[3]];
			}
			else if (mode == "left-right") {
				(count % 2) ? gb = [gb[0], gb[1] - set.increment, gb[2], gb[3]] : gb = [gb[0], gb[1], gb[2], gb[3] + set.increment];
			}
			else {
				ErrorExit("Incorrect 'mode' parameter: check the script's file name.", true);
			}

			tf.geometricBounds = gb;
			tf.recompose();
			count++;			
		} // while
	
		if (mode == "right") {
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.LEFT_CENTER_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[set.extraSpaceWidth, 0, CoordinateSpaces.INNER_COORDINATES]);
		}
		else if (mode == "left") {
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.RIGHT_CENTER_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[set.extraSpaceWidth, 0, CoordinateSpaces.INNER_COORDINATES]);
		}
		else if (mode == "top") {
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.BOTTOM_CENTER_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[0, set.extraSpaceHeight, CoordinateSpaces.INNER_COORDINATES]); 
		}
		else if (mode == "bottom") {
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.TOP_CENTER_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[0, set.extraSpaceHeight, CoordinateSpaces.INNER_COORDINATES]); 
		}
		else if (mode == "top-right") {
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.BOTTOM_LEFT_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[set.extraSpaceWidth, set.extraSpaceHeight, CoordinateSpaces.INNER_COORDINATES]); 
		}
		else if (mode == "top-left") { 
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.BOTTOM_RIGHT_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[set.extraSpaceWidth, set.extraSpaceHeight, CoordinateSpaces.INNER_COORDINATES]); 	
		}
		else if (mode == "bottom-right") {
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.TOP_LEFT_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[set.extraSpaceWidth, set.extraSpaceHeight, CoordinateSpaces.INNER_COORDINATES]);	
		}
		else if (mode == "bottom-left") {
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.TOP_RIGHT_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[set.extraSpaceWidth, set.extraSpaceHeight, CoordinateSpaces.INNER_COORDINATES]);
		}
		else if (mode == "top-bottom") {
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.CENTER_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[0, set.extraSpaceHeight, CoordinateSpaces.INNER_COORDINATES]);
		}
		else if (mode == "left-right") {
			tf.resize(CoordinateSpaces.INNER_COORDINATES,
				AnchorPoint.CENTER_ANCHOR,
				ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
				[set.extraSpaceWidth, 0, CoordinateSpaces.INNER_COORDINATES]);
		}
	
		tf.recompose(); // just in case
	
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;	
	}
	catch(err) {
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;		
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName).replace(/"/g, ""));
	if (set == undefined) {
		set = {
					increment: 3, 
					increaseLimit: 50,
					extraSpaceWidth: 5,
					extraSpaceHeight: 5,
					alignBaselineGridOff: false
				};
	}

	return set;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	
	if (app.selection.length == 0 || app.selection.length > 1 || app.selection[0].constructor.name != "TextFrame") ErrorExit("One text frame should be selected.", true);
	
	tf = app.selection[0];
	if (!tf.overflows) ErrorExit("The selected text frame doesn’t overflow.", true);
	
	GetDialogSettings();
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}