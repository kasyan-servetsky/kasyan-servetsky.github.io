﻿/* Copyright 2022, Kasyan Servetsky
October 3, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Fix overflow - 2.0",
debug = false, // for debugging only
doc,
set = GetDialogSettings();

CreateDialog();
//===================================== FUNCTIONS ======================================
function CreateDialog() {
	var w = new Window("dialog", scriptName);
	var editTextWidth = 3;
	
	w.p = w.add("panel", undefined, "Settings (in points):");
	w.p.orientation = "column";
	w.p.alignment = "fill";
	w.p.alignChildren = "right";
	
	w.p.g = w.p.add("group");
	w.p.g.orientation = "row";
	w.p.g.st = w.p.g.add("statictext", undefined, "Increment");
	w.p.g.et = w.p.g.add("edittext", undefined, set.increment);
	w.p.g.et.characters = editTextWidth;
	w.p.g.st.helpTip = w.p.g.et.helpTip = "The amount of space added in one step until the text fits the frame or the limit is reached.";
	w.p.g.et.onChange = function() {
		if (this.text == "") {
			alert("The \"Increment\" text edit field should not be empty.", "Error", true);
			this.text = set.increment;
		}
		else if (this.text == "0") {
			alert("Invalid value in the \"Increment\" text edit field should not be zero.", "Error", true);
			this.text = set.increment;
		}
		else if (this.text.match(/^[123456789]$/) == null) {
			alert("Invalid value in the \"Increment\" text edit field. It should be a number from 1 to 9.", "Error", true);
			this.text = set.increment;
		}
		if (debug) $.writeln("Changed Increment: " + this.text);	
	}
	
	w.p.g1 = w.p.add("group");
	w.p.g1.orientation = "row";
	w.p.g1.st = w.p.g1.add("statictext", undefined, "Increase limit");
	w.p.g1.et = w.p.g1.add("edittext", undefined, set.increaseLimit);
	w.p.g1.et.characters = editTextWidth;
	w.p.g1.st.helpTip = w.p.g1.et.helpTip = "The maximum amount of space that can be added.";
	w.p.g1.et.onChange = function() {
		if (this.text == "") {
			alert("The \"Increase limit\" text edit field should not be empty.", "Error", true);
			this.text = set.increaseLimit;
		}
		else if (this.text.match(/^\d+$/) == null || Number(this.text) < 10 || Number(this.text) > 500) {
			alert("Invalid value in the \"Increase limit\" text edit field. It should be a number from 10 to 500.", "Error", true);
			this.text = set.increaseLimit;
		}
		if (debug) $.writeln("Changed Increase limit: " + this.text);	
	}

	w.p.g2 = w.p.add("group");
	w.p.g2.orientation = "row";
	w.p.g2.st = w.p.g2.add("statictext", undefined, "Add extra width");
	w.p.g2.et = w.p.g2.add("edittext", undefined, set.extraSpaceWidth);
	w.p.g2.et.characters = editTextWidth;
	w.p.g2.st.helpTip = w.p.g2.et.helpTip = "The extra width space added after the text fits the frame.";
	w.p.g2.et.onChange = function() {
		if (this.text == "") {
			alert("The \"Add extra width\" text edit field should not be empty.", "Error", true);
			this.text = set.extraSpaceWidth;
		}
		else if (this.text.match(/^\d+$/) == null || Number(this.text) > 100) {
			alert("Invalid value in the \"Add extra width\" text edit field. It should be a number from 0 to 100.", "Error", true);
			this.text = set.extraSpaceWidth;
		}
		if (debug) $.writeln("Changed Add extra width: " + this.text);	
	}
	
	w.p.g3 = w.p.add("group");
	w.p.g3.orientation = "row";
	w.p.g3.st = w.p.g3.add("statictext", undefined, "Add extra height");
	w.p.g3.et = w.p.g3.add("edittext", undefined, set.extraSpaceHeight);
	w.p.g3.et.characters = editTextWidth;
	w.p.g3.st.helpTip = w.p.g3.et.helpTip = "The extra height space added after the text fits the frame.";
	w.p.g3.et.onChange = function() {
		if (this.text == "") {
			alert("The \"Add extra height\" text edit field should not be empty.", "Error", true);
			this.text = set.extraSpaceHeight;
		}
		else if (this.text.match(/^\d+$/) == null || Number(this.text) > 100) {
			alert("Invalid value in the \"Add extra height\" text edit field. It should be a number from 0 to 100.", "Error", true);
			this.text = set.extraSpaceHeight;
		}
		if (debug) $.writeln("Changed Add extra height: " + this.text);	
	}

	w.p.cb = w.add("checkbox", undefined, "Turn off align to baseline grid");
	w.p.cb.alignment = "left";
	w.p.cb.value = set.alignBaselineGridOff;
	
	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok"});
	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		with (set) {
			increment = w.p.g.et.text;
			increaseLimit = w.p.g1.et.text;
			extraSpaceWidth = w.p.g2.et.text;
			extraSpaceHeight = w.p.g3.et.text;
			alignBaselineGridOff = w.p.cb.value;
		}

		app.insertLabel("Kas_" + scriptName, set.toSource());
	}	
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {
					increment: 3, 
					increaseLimit: 50,
					extraSpaceWidth: 5,
					extraSpaceHeight: 5,
					alignBaselineGridOff: false
				};
	}
	
	return set;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------