﻿var scriptName = "Fix overflow",
activeScript = GetActiveScript(),
scriptFile = new File(activeScript.parent.absoluteURI + "/" + scriptName + ".jsx"),
mode = activeScript.displayName.replace(/\.jsx$/, "").toLowerCase();

if (scriptFile.exists) {
	app.doScript(scriptFile, ScriptLanguage.JAVASCRIPT, [mode], ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "'\'" + scriptName + "\" script");
}
else {
	alert("The '" + scriptName + "' script should be located in the same folder as this script.", scriptName, true);
}

function GetActiveScript() {
    try {
        return app.activeScript;
    }
    catch(err) {
        return new File(err.fileName);
    }
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}