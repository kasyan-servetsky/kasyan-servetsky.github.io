﻿#targetengine "kasyan"
var scriptAction = app.scriptMenuActions.add("Извлечь с сервера все материалы");
var eventListener_beforeDisplay = scriptAction.eventListeners.add("beforeDisplay", enableDisableMenuItem, false);
var eventListener_onInvoke = scriptAction.eventListeners.add("onInvoke", checkOutAllStories, false);
var menu = app.menus.item("$ID/Main").submenus.item("$ID/Edit").submenus.item("$ID/InCopy");
var menuItem = menu.menuItems.add(scriptAction, LocationOptions.AFTER, menu.menuItems.item("Извлечь с сервера"));

function enableDisableMenuItem(event) {
	if (app.documents.length > 0) {
		event.target.enabled = true;
	}
	else {
		event.target.enabled = false;
	}
}

function checkOutAllStories(event) {
    if (app.documents.length > 0) {
        var stories = app.documents[0].stories.everyItem().getElements();

        for (var i = 0; i < stories.length; i++) {
            stories[i].checkOut();
        }
    }
}