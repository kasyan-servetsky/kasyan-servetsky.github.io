﻿(function () {
	var stories = app.documents[0].stories.everyItem().getElements();
	var ix;
	for (var i = stories.length-1; i >= 0; i--) {
		while (stories[i].textFrames.length > 0) {
			ix = stories[i].textFrames[-1].parent.index;
			stories[i].textFrames[-1].texts[0].move (LocationOptions.AFTER, stories[i].insertionPoints[ix]);
			stories[i].textFrames[-1].locked = false;
			stories[i].textFrames[-1].remove();
		}
	}
}());