﻿/* Copyright 2023, Kasyan Servetsky
July 20, 2023
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//=======================================================================================
#targetengine "Kasyan"
Reset();
var scriptName = "Find Text in Location - 2.2",
foundLimit = 1000, // the limit of found items beyond which the script gives a warning offering to process text in chunks
reverseOrder = false, // process found items in reverse order 
debugMode = false,
doc, set, w, tmpFileName, found,
btnFind, btnChange, btnChangeAll, btnChangeFind,
macOS = (File.fs == "Macintosh"),
f = 0,
foundNum = 0,
textArr = [],
foundAll = false,
warning = false,
interrupt = false, // interrupt furter messages
look = false, // look behind / ahead. /K
hasSpaceAtLineEnd = null,
storyProcessed = null,
textProcessed = null,
tmpFindWhat = null,
counter = 1;

PreCheck();
//====================================== FUNCTIONS ======================================
function SmartMode(txt) {
	try {
		var txtContents = txt.contents,
		result = false,
		line = txt.lines[0],
		lineCharacters = line.characters,
		lineContNoMarkers = line.contents.replace(/\uFEFF/g, "").replace(/\uFFFC/g, ""), // 65279 = FEFF hyperlink anchor, index marker
		lineContNoSpaces = lineContNoMarkers.replace(/\r+$/, "").replace(/\n+$/, ""),
		regExp = null,
		match = null,
		regExpEnd = null,
		matchEnd = null,
		lastChar,
		firstChar = lineCharacters[0];
		
		if (set.cbIgnoreSpaces) {
			lineContNoSpaces = lineContNoSpaces.replace(/ +$/, "");
		}
		
		txtContents = EscapeSpecialChars(txtContents);

		if (hasSpaceAtLineEnd) {
			lastChar = lineCharacters[-1];
		}
		else {
			lastChar = lineCharacters[lineCharacters.length - (lineContNoMarkers.length - lineContNoSpaces.length) - 1];
		}

		if (lastChar.contents == "\r") {
			lastChar = lastChar.parentStory.characters[lastChar.index - 1];
		}

		if (set.ddlLocation == 0) { // Beginning
			if (look) {
				if (lineContNoSpaces.indexOf(tmpFindWhat) == 0) {
					result = true;
				}
			}
			else if (txt.contents.constructor.name == "Enumerator") {
				if (txt == firstChar) {
					result = true;
				}
			}
			else {
				regExp = eval("/^" + txtContents + "/");

				if (regExp != null) match = lineContNoSpaces.match(regExp);

				if (match != null && firstChar.index == txt.characters[0].index) {
					result = true;
				}
			}
		}
		else if (set.ddlLocation == 1) { // End
			if (look) {
				result = CompareLines(txt, true);
				if (!result) {
					if (lineContNoSpaces.indexOf(tmpFindWhat) == lineContNoSpaces.length - tmpFindWhat.length) {
						result = true;
					}
				}
			}
			else if (txt.contents.constructor.name == "Enumerator") {
				if (txt == lastChar) {
					result = true;
				}
			}
			else {
				// It only affects the behavior of ^ and $. In the multiline mode they match not only at the beginning and the end of the string, but also at start/end of line.
				regExp = eval("/" + txtContents + "$/m");

				if (regExp != null) match = (hasSpaceAtLineEnd) ? lineContNoMarkers.match(regExp) : lineContNoSpaces.match(regExp);

				if (match != null) {
					if (hasSpaceAtLineEnd) {
						var regExpEnd = eval("/" + txtContents + "$/m");
						var matchEnd = lineContNoMarkers.match(regExpEnd);

						if (matchEnd != null && lastChar.index == txt.characters[-1].index) {
							result = true;
						}
					}
					else if (!hasSpaceAtLineEnd && lastChar.index == txt.characters[-1].index) {
						result = true;
					}
				} // End match != null
			}
		}
		else if (set.ddlLocation == 2) { // Both
			if (look) {
				if (lineContNoSpaces.indexOf(tmpFindWhat) == 0) { // Beginning
					result = true;
				}
				else { // End
					result = CompareLines(txt, true);
					if (!result) {
						if (lineContNoSpaces.indexOf(tmpFindWhat) == lineContNoSpaces.length - tmpFindWhat.length) {
							result = true;
						}
					}
				}
			}
			else if (txt.contents.constructor.name == "Enumerator") {
				if (txt == firstChar) {
					result = true;
				}
				else if (txt == lastChar) {
					result = true;
				}
			}
			else {
				regExp = eval("/^" + txtContents + "/");
 
				if (regExp != null) match = lineContNoSpaces.match(regExp);

				if (match != null && firstChar.index == txt.characters[0].index) {
					result = true;
				}
				else { // not found at the beginning, then try at the end
					regExp = eval("/" + txtContents + "$/m");
				
					if (regExp != null) match = (hasSpaceAtLineEnd) ? lineContNoMarkers.match(regExp) : lineContNoSpaces.match(regExp);

					if (match != null) {
						if (hasSpaceAtLineEnd) {
							var regExpEnd = eval("/" + txtContents + "$/m");
							var matchEnd = lineContNoMarkers.match(regExpEnd);
				
							if (matchEnd != null && lastChar.index == txt.characters[-1].index) {
								result = true;
							}
						}
						else if (!hasSpaceAtLineEnd && lastChar.index == txt.characters[-1].index) {
							result = true;
						}
					} // End match != null
				}
			}
		} // Both

		return result;
	}
	catch(err) {
		ErrorExit(err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CompareLines(txt) {
	try {
		var result = false,
		line = txt.lines[0],
		lineCharacters = line.characters,
		lineCharLength = lineCharacters.length,
		lineFirstChar = lineCharacters[0],
		lineFirstCharIdx = lineFirstChar.index,
		lineLastChar = lineCharacters[lineCharacters.length - 1],
		lineLastCharIdx;
		
		if (lineLastChar.contents == SpecialCharacters.FORCED_LINE_BREAK || lineLastChar.contents == "\r") {
			lineLastChar = lineCharacters[lineCharacters.length - 2];
		}
		
		if (set.cbIgnoreSpaces) {
			lineLastCharIdx = GetLastCharIndex(line);
		}
		else {
			lineLastCharIdx = lineLastChar.index;
		}

		// Found text
		var txtCharLength = txt.characters.length,
		txtFirstCharIdx = txt.characters[0].index,
		txtLastCharIdx = txt.characters[txt.characters.length - 1].index;
		
		if (debugMode) {
			var lineCharLength = line.characters.length,			
			lineRange = lineFirstCharIdx + "-" + lineLastCharIdx,
			lineContents = VisualiseSpaces(line),
			lineCharCoded = CharCodeString(line.contents),
			lineFirstCharContents = VisualiseSpaces(line.characters[0]),
			lineLastCharContents = VisualiseSpaces(line.characters[line.characters.length - 1]),			
			txtRange = txtFirstCharIdx + "-" + txtLastCharIdx,
			txtContents = VisualiseSpaces(txt),		
			txtFirstCharContents = VisualiseSpaces(txt.characters[0]),
			txtLastCharContents = VisualiseSpaces(txt.characters[txt.characters.length - 1]);
		}
		
		if (set.ddlLocation == 0 || set.ddlLocation == 2) { // beginning
			if (lineFirstCharIdx == txtFirstCharIdx && txtCharLength <= lineCharLength && lineCharacters[txtCharLength - 1].index == txtLastCharIdx) {
				result = true;
			}
		}

		if (set.ddlLocation == 1 || (set.ddlLocation == 2 && result == false)) { // end
			if (txtCharLength <= lineCharLength && lineLastCharIdx + 1 - txtCharLength == txtFirstCharIdx && lineLastCharIdx == txtLastCharIdx) {
				result = true;
			}
		}
	
		return result;
	}
	catch(err) {
		ErrorExit(err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetLastCharIndex(line) {
	var character, contents,
	result = null,
	characters = line.characters.everyItem().getElements();

	for (var i = characters.length - 1; i >= 0; i--) {
		character = characters[i];
		contents = character.contents;
		
		if (contents != " " && contents != "\r" && contents != SpecialCharacters.FORCED_LINE_BREAK) {
			result = character.index;
			break;
		}
	}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function EscapeSpecialChars(txt) {
	if (txt.constructor.name == "String") {
		txt = txt.replace(/\uFEFF/g, "").replace(/\uFFFC/g, ""); // 65532 = FFFC anchored object
		txt = txt.replace(/\\/g, "\\\\");
		txt = txt.replace(/\//g, "\\/");		
		txt = txt.replace(/\./g, "\\.");	
		txt = txt.replace(/\(/g, "\\(");
		txt = txt.replace(/\[/g, "\\[");
		txt = txt.replace(/\^/g, "\\^");
		txt = txt.replace(/\$/g, "\\$");
		txt = txt.replace(/\?/g, "\\?");
		txt = txt.replace(/\*/g, "\\*");
		txt = txt.replace(/\+/g, "\\+");
		txt = txt.replace(/\{/g, "\\{");
	}

	return txt;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IsSpecialCharacter(character) {
	var result = false,
	item,
	str = "()*[]\^$.|?+{}",
	list = [];

	for (var j = 0; j < str.length; j++) {
		list.push(str[j]);
	}
	
	for (var i = 0; i < list.length; i++) {
		item = list[i];
		if (character == item) {
			result = true;
			break;
		}
	}
	
	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function HasSpaceAtLineEnd() { // check if findWhat has a space optionally followed by repeat
	var result = false,
	item, regex, match,
	findWhat = app.findGrepPreferences.findWhat,
	list = ["\\s", "\\\\t", "\\h", "~m", "~>", "~f", "~\\|", "~S", "~s", "~m", "~<", "~\\/", "~\\.", "~3", "~4", "~%"],
	repeat = ["\\?", "\\+", "\\*", "\\?\\?", "\\*\\?", "\\+\\?"];

	for (var i = 0; (i < list.length && !result); i++) {
		item = list[i];
		regex = new RegExp(item + "$");
		match = findWhat.match(regex);
		
		if (match != null) {
			result = true;
		}
		else {
			for (var j = 0; j < repeat.length; j++) {
				regex = item + repeat[j] + "$";
				
				if (findWhat.match(regex) != null) {
					result = true;
					break;
				}
			}
		}
	} // end for
	
	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ChangeAll() {
	var item,
	count = 0;
	
	for (var i = 0; i < textArr.length; i++) {
		item = textArr[i];
		count++;
		ProcessText(item);
	}

	btnFind.text = "Find";
	btnChange.enabled = btnChangeAll.enabled = btnChangeFind.enabled = false;
	alert("Search is completed. " + count + " replacement" + ((count == 1) ? " was" : "s were") + " made.", scriptName);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ChangeItem() {
	ProcessText(app.selection[0]);
	btnChange.enabled = false;
	if (f == textArr.length) {
		Reset();
		alert("Search is completed.", scriptName);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessText(txt) { // Workaround. Details are here: https://adobe.ly/3k81CXX
	try {
		var savedFindWhat;
		counter++;

		if (look) {
			savedFindWhat = app.findGrepPreferences.findWhat;
			app.findGrepPreferences.findWhat = txt.contents;
		}
		
		var changed = txt.changeGrep();
		
		if (look) {
			app.findGrepPreferences.findWhat = savedFindWhat;
		}
	}
	catch(err) {
		ErrorExit(err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IsLook() {
	var result = false,
	findWhat = app.findGrepPreferences.findWhat;
	if (debugMode) var local_tmpFindWhat = tmpFindWhat;

	if (findWhat.match(/\(\?<=/) != null) { // positive look behind
		tmpFindWhat = findWhat.replace(/\(\?<=/g, "").replace(/\)/g, "");
		if (debugMode) local_tmpFindWhat = tmpFindWhat;
	}
	else if (findWhat.match(/\(\?=/) != null) { /// positive look ahead
		tmpFindWhat = findWhat.replace(/\(\?=/g, "").replace(/\)/g, "");
		if (debugMode) local_tmpFindWhat = tmpFindWhat;
	}
	else if (findWhat.match(/\\K/) != null) { // /K
		tmpFindWhat = findWhat.replace(/\\K/g, "");
		if (debugMode) local_tmpFindWhat = tmpFindWhat;
	}

	if (findWhat.match(/\(\?<=/) != null ||
		findWhat.match(/\(\?=/) != null ||
		findWhat.match(/\\K/) != null
	) {
		result = true;
	}

	return result; 
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FindAll() {
	try {
		if (set.ddlSelection > 0) {
			CheckSelection();
			if ((set.ddlSelection == 1 && storyProcessed == null) || (set.ddlSelection == 2 && textProcessed == null)) return;
		}

		look = IsLook();

		var item, checkLocation,
		msgTooManyFound = "";
		
		if (set.ddlSelection == 1) { // story
			found = storyProcessed.findGrep(reverseOrder);
			msgTooManyFound += " items in the selected story. It may take very long to process all of them in one go. It’s recommended to process the text in chunks: select some text and choose ‘Selected text’ in the dialog box.";
		}
		else if (set.ddlSelection == 2) { // selected text
			found = textProcessed.findGrep(reverseOrder);
			msgTooManyFound += " items in the selected text. It may take very long to process all of them in one go. It’s recommended to select less text and try again.";
		}
		else { // the whole document
			found = app.documents[0].findGrep(reverseOrder);
			msgTooManyFound += " items in the whole document. It may take very long to process all of them in one go. It’s recommended to process the text in chunks: select some text and choose ‘Selected text’ in the dialog box.";
		}
	
		msgTooManyFound += " Do you want to continue with the script? Click ‘Yes’ to continue, click ‘No’ to stop, and change options.";

		foundNum = found.length;
		if (debugMode) $.writeln("foundNum = " + foundNum);
		
		if (foundNum > foundLimit) {
			var ask = confirm("Found " + foundNum + msgTooManyFound, true, scriptName);
			if (!ask) {
				interrupt = true;
				return;
			}
		}
		
		if (hasSpaceAtLineEnd === null) {
			hasSpaceAtLineEnd = HasSpaceAtLineEnd();
		}

		if (foundNum == 0) {
			btnFind.text = "Find";
		}
		else {
			if (debugMode) var startTime = new Date();

			app.doScript(CheckFound, ScriptLanguage.JAVASCRIPT, undefined, ((macOS) ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT));

			var endTime = new Date();
			var duration = GetDuration(startTime, endTime);
			
			if (debugMode) {
				$.writeln("For loop: time elapsed: " + duration);
				$.writeln("textArr.length = " + textArr.length);
			}

			btnFind.text = "Find Next";
			foundAll = true;
			btnChange.enabled = btnChangeAll.enabled = btnChangeFind.enabled = true;
		}
	}
	catch(err) {
		ErrorExit(err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckFound() {
	var item, checkLocation;
			
	if (debugMode) $.writeln("foundNum = " + foundNum);
	
	for (var i = 0; i < foundNum; i++) {
		item = found[i];
		checkLocation = (set.ddlMode == 0) ? SmartMode(item) : CompareLines(item);

		if (checkLocation) {
			textArr.push(item);
		}
	} // end for
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IterateFinds() { // Find / Find Next
	var item, msg,
	story = null;
	
	if (f == textArr.length && !interrupt) {
		if (foundNum == 0) {
			msg = "Found nothing.";
		}
		else if (textArr.length == 0) {
			msg = "Can't find a match at the beginning or end of the line.";
		}
		else {
			msg = "Search is completed.";
		}
	
		Reset();
		alert(msg, scriptName);
		return;
	}

	for ( ; f < textArr.length; ) {
		item = textArr[f];

		try { 
			story = item.parentStory;
		}
		catch(err) {
			if (debugMode) $.writeln(err.message + ", line: " + err.line);
		}

		if (story != null && story.overflows && !warning) {
			alert("The text in this story is partially overset. The changes in the overset text may lead to unexpected results.", scriptName);
			warning = true;
		}

		try {
			app.select(item, SelectionOptions.replaceWith);
			app.activeWindow.zoom = ZoomOptions.fitPage;
			app.activeWindow.zoomPercentage = set.etZoom;
		}
		catch(err) {
			app.activeWindow.zoomPercentage = 100;
			if (debugMode) $.writeln(err.message + ", line: " + err.line);
		}

		f++;
		btnChange.enabled = btnChangeFind.enabled = true;
		
		return;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IterateFindsChange() {
	if (f == textArr.length) {
		Reset();
		alert("Search is completed.", scriptName);
	}
	else {
		IterateFinds();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckSelection() {
	var msgNoText = "One text frame or some text should be selected, or the cursor should be inserted into the text.";

	// check if text is selected
	if (app.selection.length == 0 || app.selection.length > 1) { // nothing is selected or more than one selection
		alert(msgNoText, scriptName, true);
		interrupt = true;
	}
	else {
		var sel = app.selection[0];
			
		if (sel.constructor.name == "TextFrame") { // a text frame is selected
			storyProcessed = sel.texts[0].parentStory;
			textProcessed = sel.texts[0];
		}
		else if (sel.hasOwnProperty("baseline")) { // some text is selected or the cursor is placed in the text
			storyProcessed = sel.parentStory;
			if (set.ddlSelection == 1) { // story
				storyProcessed = sel.parentStory;
			}
			else { // selected text
				if (sel.constructor.name == "InsertionPoint") { // give a warning
					alert("You chose the 'Selected text' in the dialog box, but instead of selecting the text, you placed the cursor. Select some text and try again.", scriptName, true);
					interrupt = true;
					return;
				}
				else { // OK
					textProcessed = sel;
				}
			}
		}
		else {
			alert(msgNoText, scriptName, true);
			interrupt = true;
		}

		if (set.ddlSelection == 1 && storyProcessed != null && storyProcessed.contents == "") { // story is empty
			storyProcessed = null;
			alert("The selected story is empty.", scriptName, true);
		}
		else if (set.ddlSelection == 2) {
			if (textProcessed != null && textProcessed.contents == "") { // text is empty
				textProcessed = null;
				alert("The selected text is empty.", scriptName, true);
			}
			else if (typeof textProcessed == "undefined" || !textProcessed.isValid) {
				alert("Can't get the selected text.", scriptName, true); // something went wrong
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	GetDialogSettings();
	w = new Window("palette", scriptName.replace(/\-\s\d+\.\d+$/, "")); // global | remove ver number from dialog
	if (set.dlgLocation != null) {
		w.location = set.dlgLocation;
	}
	w.onClose = function() {
		try {
			set.dlgLocation = String(w.location);
			set.ddlLocation = ddlLocation.selection.index;
			set.ddlMode = ddlMode.selection.index;
			set.ddlSelection = ddlSelection.selection.index;
			set.etZoom = etZoom.text;
			set.cbIgnoreSpaces = cbIgnoreSpaces.value;
			app.insertLabel("Kas_" + scriptName, set.toSource());
		}
		catch(err) {
			ErrorExit(err.message + ", line: " + err.line, scriptName, true);
		}
	}
	
	var pnlLocation = w.add("panel", undefined, "");
	pnlLocation.orientation = "column";
	pnlLocation.alignment = "fill";
	pnlLocation.alignChildren = "right";
	
	// Beginning / End / Both
	var ddlLocation = pnlLocation.add("dropdownlist", undefined, ["Beginning", "End", "Both"]);
	ddlLocation.helpTip = "Location on the line";
	ddlLocation.selection = set.ddlLocation;
	ddlLocation.alignment = "fill";
	ddlLocation.onChange = function() {
		set.ddlLocation = this.selection.index;
		Reset();
	}

	// Mode
	var ddlMode = pnlLocation.add("dropdownlist", undefined, ["Smart mode", "Compare lines"]);
	ddlMode.helpTip = "Mode";
	ddlMode.selection = set.ddlMode;
	ddlMode.alignment = "fill";

	var ddlSelection = pnlLocation.add("dropdownlist", undefined, ["Document", "Selected story", "Selected text"]);
	ddlSelection.helpTip = "What should be processed";
	ddlSelection.selection = set.ddlSelection;
	ddlSelection.alignment = "fill";
	ddlSelection.onChange = function() {
		if (this.selection.index == 0) {
			set.ddlSelection = 0;
		}
		else if (this.selection.index == 1) {
			set.ddlSelection = 1;
		}
		else if (this.selection.index == 2) {
			set.ddlSelection = 2;
		}
	}

	// Zoom
	var grZoom = pnlLocation.add("group");
	grZoom.orientation = "row";
	
	var iconBinReset = "\u0089PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\x14\x00\x00\x00\x14\b\x06\x00\x00\x00\u008D\u0089\x1D\r\x00\x00\x00\tpHYs\x00\x00\x0B\x13\x00\x00\x0B\x13\x01\x00\u009A\u009C\x18\x00\x00\x06\u00BEiTXtXML:com.adobe.xmp\x00\x00\x00\x00\x00<?xpacket begin=\"\u00EF\u00BB\u00BF\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?> <x:xmpmeta xmlns:x=\"adobe:ns:meta/\" x:xmptk=\"Adobe XMP Core 7.1-c000 79.a8731b9, 2021/09/09-00:37:38        \"> <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"> <rdf:Description rdf:about=\"\" xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:photoshop=\"http://ns.adobe.com/photoshop/1.0/\" xmlns:xmpMM=\"http://ns.adobe.com/xap/1.0/mm/\" xmlns:stEvt=\"http://ns.adobe.com/xap/1.0/sType/ResourceEvent#\" xmp:CreatorTool=\"Adobe Photoshop 22.5 (Windows)\" xmp:CreateDate=\"2022-02-17T08:23:36+02:00\" xmp:ModifyDate=\"2022-02-17T10:09:30+02:00\" xmp:MetadataDate=\"2022-02-17T10:09:30+02:00\" dc:format=\"image/png\" photoshop:ColorMode=\"3\" photoshop:ICCProfile=\"Adobe RGB (1998)\" xmpMM:InstanceID=\"xmp.iid:544ee920-4cda-6646-baa6-7edb9c0e5021\" xmpMM:DocumentID=\"adobe:docid:photoshop:c8774ef7-74f4-bc4f-a7c4-a4a0856a35a5\" xmpMM:OriginalDocumentID=\"xmp.did:1f6f5141-8461-414e-b95e-279858268f8e\"> <xmpMM:History> <rdf:Seq> <rdf:li stEvt:action=\"created\" stEvt:instanceID=\"xmp.iid:1f6f5141-8461-414e-b95e-279858268f8e\" stEvt:when=\"2022-02-17T08:23:36+02:00\" stEvt:softwareAgent=\"Adobe Photoshop 22.5 (Windows)\"/> <rdf:li stEvt:action=\"saved\" stEvt:instanceID=\"xmp.iid:d5ee5de3-dcd2-5944-9c5f-ceb7280a29eb\" stEvt:when=\"2022-02-17T10:08:12+02:00\" stEvt:softwareAgent=\"Adobe Photoshop 22.5 (Windows)\" stEvt:changed=\"/\"/> <rdf:li stEvt:action=\"saved\" stEvt:instanceID=\"xmp.iid:544ee920-4cda-6646-baa6-7edb9c0e5021\" stEvt:when=\"2022-02-17T10:09:30+02:00\" stEvt:softwareAgent=\"Adobe Photoshop 22.5 (Windows)\" stEvt:changed=\"/\"/> </rdf:Seq> </xmpMM:History> </rdf:Description> </rdf:RDF> </x:xmpmeta> <?xpacket end=\"r\"?>\u00EF\u009A\u0097B\x00\x00\x01.IDAT8\x11\u00AD\u00C1?nR\x01\x00\x07\u00E0/\u00C2\u00F3\x06N\f/u\x11\u00E8\t:9y\x01;iIpw\u00F0\x06\u00AE\u00A6\u00A6\x7F\u0088\u009B^\u00C0\u008Dn\x1A=\u00C2s\x11\u00B9\x05\x18:\u00B4I\x13\u0097\u009F\u008FHb\u00D3?\x01J\u00BF\u00CF-\x1E\u00E2\x15Np\u008E 8\u00C7\t\u00FA(\u00FC\u00F7\foQ\u00B8A\x0FS\x04\u00C1\x04\x15*L\x11\x04\x13\u00EC\u00F9\u00E73\u0082\u00B6+\x0E\x11\x04\u00EF\u00D0q]\x17\u00FB\b\u0082\u00D7\u00F8\u0088`\u00DB%\x1F\x10\u00FC\u00C4\x13\u00CB51D\u00F0\x07A\u00C7\u00C2.\u0082_hX\u00EE)>\u00E1\x0B\u0082 \u00D8Vk\u00E0\x14A\u00CBj\u00DE \b\u0082 \u00E8\u00A8\u00F5\x10\x1CZO\u0089\x12%J\u0094(\u00D4\u00BE#\u00D8rO.0s\u008F\u0082\u00CA\u0086\u0092Hb.\u00F8aCI$1w\u0081\u0099\u00CD=\u00C2\u008E\u00DA7\x04[\u00EE\u00EE1\u0082\u00AFj=\x04G\u00EE\u00EE\x18\u00C1K\u00B5\x06N\x11\u00B4\u00AC\u00AF\u0085`\u0086\x07\x16v\x11\u008C\u00D1\u00B4\u00BA&\u00C6\b\u009E\u00BBb\u0080`\u0084\u00B6\u00E5\u00DA\x18!\x18\u00B8\u00C5\x01\u0082`\x1F]\u00D7u\u00F1\x1EAp`\u0089=L\x10\x04ST\u00A8\u00F0\x1BA0\u00C1\x0B+*\u00D0\u00C7\x10g\b\u00823\f\u00D1G\u00E1\x06\x7F\x01\u00F8-r\u00F4G\x7F\x05t\x00\x00\x00\x00IEND\u00AEB`\u0082";
	var iconReset = IconMaker(iconBinReset, tmpFileName + "icon_reset");
	var btnReset = grZoom.add("iconbutton", undefined, iconReset);
	btnReset.preferredSize = [20, 20];
	btnReset.helpTip = "Reset settings";
	btnReset.onClick = function() {
		if (debugMode) $.writeln("Reset");
		Reset();
	}

	var stZoom = grZoom.add("statictext", undefined, "Zoom:");
	var etZoom = grZoom.add("edittext", undefined, set.etZoom);
	etZoom.characters = 3;
	etZoom.onChange = function() {
		if (this.text == "") {
			alert("The \"Zoom\" text field should not be empty.", "Error", true);
			this.text = String(set.etZoom);
		}
		else if (isNaN(this.text)) {
			alert("\"Zoom\" should be a number.", "Error", true);
			this.text = String(set.etZoom);
		}
		else {
			set.etZoom = Number(this.text);
		}
	}
	stZoom.helpTip = etZoom.helpTip = "Zoom level for the found text";

	var cbIgnoreSpaces = pnlLocation.add("checkbox", undefined, "Ignore spaces");
	cbIgnoreSpaces.value = set.cbIgnoreSpaces;
	cbIgnoreSpaces.alignment = "left";
	cbIgnoreSpaces.helpTip = "Ignore spaces at the end of lines";
	cbIgnoreSpaces.onClick = function() {
		set.cbIgnoreSpaces = this.value;
	}
	
	// Buttons
	var pnlButtons = w.add("panel", undefined, "");
	pnlButtons.orientation = "column";
	pnlButtons.alignment = "fill";
	
	var buttonWidth = 100;
	btnFind = pnlButtons.add("button", undefined, "Find");
	btnFind.preferredSize.width = buttonWidth;
	btnFind.onClick = function() {
		if (app.findGrepPreferences.findWhat == "") {
			alert("Please select your find/change settings and try again.", scriptName, true);
			return;
		}
	
		if (!foundAll) {
			FindAll();
			IterateFinds();
		} 
		else {
			IterateFinds();
		}
	}
		
	btnChange = pnlButtons.add("button", undefined, "Change");
	btnChange.preferredSize.width = buttonWidth;
	btnChange.enabled = false;
	btnChange.onClick = function() {
		ChangeItem();
	}
	
	btnChangeAll = pnlButtons.add("button", undefined, "Change All");
	btnChangeAll.preferredSize.width = buttonWidth;
	btnChangeAll.enabled = false;
	btnChangeAll.onClick = function() {
		app.doScript(ChangeAll, ScriptLanguage.JAVASCRIPT, undefined, ((macOS) ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
	}
	
	btnChangeFind = pnlButtons.add("button", undefined, "Change/Find");
	btnChangeFind.preferredSize.width = buttonWidth;
	btnChangeFind.enabled = false;	
	btnChangeFind.onClick = function() {
	
		if (app.selection.length == 1 && app.selection[0].hasOwnProperty("baseline")) {
			ProcessText(app.selection[0]);
			IterateFindsChange();
		}
		else {
			alert("Something went wrong: no text was selected.", scriptName, true);
			return;
		}
	} 
	
	var btnClose = pnlButtons.add("button", undefined, "Close");
	btnClose.preferredSize.width = buttonWidth;
	btnClose.onClick = function() { 
		w.close();
	}

	var btnAbout = pnlButtons.add("button", undefined, "About");
	btnAbout.preferredSize.width = buttonWidth;
	btnAbout.onClick = function() {
		JumpToLink(tmpFileName);
	}

	w.show();
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {dlgLocation: null, etZoom: 100, ddlLocation: 0, ddlMode: 0, ddlSelection: 0, cbIgnoreSpaces: true};
	}

	if (set.dlgLocation != null) {
		set.dlgLocation = set.dlgLocation.split(","); // location is array of numbers
		set.dlgLocation[0] = Number(set.dlgLocation[0]);
		set.dlgLocation[1] = Number(set.dlgLocation[1]);
	}

	set.etZoom = Number(set.etZoom);

	if (isNaN(set.etZoom) || set.etZoom == 0) { // if something goes, wrong reset to 100%
		set.etZoom = 100;
	}

	return set;
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	tmpFileName = scriptName.replace(/\-\s\d+\.\d+$/, "").replace(/\s+/g, "_").toLowerCase();
	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Reset() { // reset global variables
	doc = textProcessed = null;
	f = 0;
	counter = 1;
	foundNum = 0;
	textArr = [];
	foundAll = warning = interrupt = false;

	try {
		if (btnFind != null && typeof btnFind != "undefined") {
			btnFind.text = "Find";
		}

		if (btnFind != null && typeof btnChange != "undefined") {
			btnChange.enabled = false;
		}
		
		if (btnFind != null && typeof btnChangeAll != "undefined") {
			btnChangeAll.enabled = false;
		}

		if (btnFind != null && typeof btnChangeFind != "undefined") {
			btnChangeFind.enabled = false;
		}
	}
	catch(err) {
		if (debugMode) $.writeln(err.message + ", line: " + err.line);
		btnFind = btnChange = btnChangeAll = btnChangeFind = null;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IconMaker(icon, name) {
	var iconFile = null;
	var tmpFolderPath = Folder.temp.absoluteURI + "/Kasyan/";
	var tmpFolder = new Folder(tmpFolderPath);
	if (!tmpFolder.exists) tmpFolder.create();
	iconFile = new File(tmpFolderPath + name + ".png");
	
	if (!iconFile.exists) {
		iconFile.encoding = "BINARY";
		iconFile.open( "w" );
		iconFile.write(icon);
		iconFile.close();
	}

	return iconFile;
} 
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function JumpToLink() {
	var tmpFolder = new Folder(Folder.temp.absoluteURI + "/Kasyan");
	tmpFolder.create();
	var linkJumper = File(tmpFolder.absoluteURI + "/" + tmpFileName + "temp.html");
	
	if (!linkJumper.exists) {
		linkJumper.open("w");
		var linkBody = '<html><head><META HTTP-EQUIV=Refresh CONTENT="0; URL=http://kasyan.ho.ua/indesign/text/find_text_in_location/find_text_in_location.html"></head><body> <p></body></html>'
		linkJumper.write(linkBody);
		linkJumper.close();
	}

	linkJumper.execute();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function VisualiseSpaces(txt) { // for debugging only
	try {
		var str = "",
		contents,
		characters = txt.characters;
		
		for (var i = 0; i < characters.length; i++) {
			contents = characters[i].contents;
			
			if ("" + contents.constructor.name == "Enumerator") {
				if (contents == SpecialCharacters.FORCED_LINE_BREAK) {
					str += "\\n";
				}
				else {
					str += "{" + contents.toString().toLowerCase().replace(/_/g, " ") + "}";
				}
			}
			else {
				str += contents.replace(/\t/g, "\\t").replace(/\r/g, "\\r").replace(/ /g, "◊");
			}
		} 

		return str;
	}
	catch(err) {
		ErrorExit(err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CharCodeString(str) { // for debugging only
	var s = "";
	
	for (var i = 0; i < str.length; i++) {
		s += ((i != 0) ? "|" : "") + str.charCodeAt(i);
	}

	return s;
}