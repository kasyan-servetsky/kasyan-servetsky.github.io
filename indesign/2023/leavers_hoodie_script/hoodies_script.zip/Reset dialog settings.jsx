﻿var doc = app.activeDocument;
var version = "1.2";
doc.insertLabel("Fill in boxes " + version, "");
doc.insertLabel("Prepare template " + version, "");
$.writeln("=== RESET ==="); 