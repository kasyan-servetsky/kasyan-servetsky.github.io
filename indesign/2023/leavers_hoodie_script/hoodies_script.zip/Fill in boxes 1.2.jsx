﻿/* Copyright 2023, Kasyan Servetsky
July 14, 2023
Written by Kasyan Servetsky
Current version: http://kasyan.ho.ua/indesign/2023/leavers_hoodie_script/leavers_hoodie_script.html
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Fill in boxes 1.2",
debug = false, // for debugging only
log = true,
doc;

var gTxtFile, gSortedNames, gShortestWord, gObjectStyleTempBox,
gCountInserted = 0,
gCountCycles = 0,
gSwatches = [],
gInsertedNames = [];

if (debug) {
	PreCheck(); // if temp colors are created
}
else {
	app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
}
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var startTime = new Date(),
		count = 0,
		tempTxtBox = PlaceTempText(),
		box, boxSpace,
		allTxtFrames = app.layoutWindows[0].activePage.textFrames,
		boxes = [],
		boxSpaceList = [],
		count = 1,
		countBox = 1;		

		// Store & change units: this script works in points
		var savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits;
		var savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
		doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.POINTS;
		doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS;

		gSortedNames = SortNames(tempTxtBox);
		if (debug) LogMessage("gSortedNames.length = " + gSortedNames.length);
		var longestWord = gSortedNames[0];
		gShortestWord = gSortedNames[gSortedNames.length - 1];

		do { // get labeled boxes created by the 'Prepare template' script
			box = GetItemFromCollection(String(count), allTxtFrames);
			
			if (box != null) {
				boxes.push(box);
				boxSpaceList.push(Number(RoundString(box.geometricBounds[3] - box.geometricBounds[1], 1)));
			}
		
			count++;
		} while (box != null);

		var boxSpaceListSorted = boxSpaceList.slice().sort();
		var longestBox = boxSpaceListSorted[0];
		var shortestBox = boxSpaceListSorted[boxSpaceListSorted.length - 1];
		
		if (longestWord < longestBox) {
			ErrorExit("The longest word can't fit the longest box", icon);
		}
		
		if (debug) LogMessage("\r===== START PROCESS BOXES =====\r");

		// process boxes
		for (var i = 0; i < boxes.length; i++) {
			box = boxes[i];
			boxSpace = boxSpaceList[i];

			if (debug) LogMessage("---------------\rBox #" + (i + 1) + " | boxSpace = " + boxSpace);
			
			if (gCountInserted == gSortedNames.length) {
				if (debug) LogMessage("Inserted all names");
				break;
			}
			
			if (!box.overflows) {
				ProcessBox(box, boxSpace);
			}
		} // end for
	
		tempTxtBox.remove();
	
		if (debug) LogMessage("\r===== END PROCESS BOXES =====\r");

		// Restore units
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;

		doc.insertLabel(scriptName, "processed");
		var endTime = new Date();
		var duration = GetDuration(startTime, endTime);
		var report = count + " box" + ((count == 1) ? " was" : "es were") + " filled in.\n(time elapsed: " + duration + ")";

		if (debug) {
			$.writeln(report);
		}
		else {
			alert(report, scriptName, false);
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessBox(box, boxSpace) {
	var sortedName, fixed;

	for (var j = 0; j < gSortedNames.length; j++) {
		sortedName = gSortedNames[j];

		if (boxSpace < gShortestWord.nameWidth) {
			if (debug) LogMessage("no space left");
			break;
		}
		
		if (box.overflows) {
			if (debug) LogMessage("box overflows");
			break;
		}

		if (sortedName.processed == null) {
			if (sortedName.nameWidth <= boxSpace) {
				if (debug) LogMessage("before - boxSpace = " + boxSpace);
				if (box.insertionPoints.length > 1) box.insertionPoints[-1].contents = " ";
				box.insertionPoints[-1].contents = sortedName.name;
				boxSpace -= sortedName.nameWidth;
				boxSpace -= 5; // space
				sortedName.processed = true;
				gCountInserted++;			
				if (debug) LogMessage("==> inserted j = " + j + " | " + sortedName.name + " | gCountInserted = " + gCountInserted);
				if (debug) LogMessage("after - boxSpace = " + boxSpace);

				if (box.overflows) {
					fixed = FixOverflow(box);
					if (!fixed) {
						sortedName.processed = false;
						box.parentStory.words.lastItem().remove(); // !!!
						return;
					}
				}

				if (gSortedNames.length == gCountInserted) {
					gCountCycles++;
					ResetSortedNames();
					if (debug) LogMessage("\r===== Reset gSortedNames =====\r");
					ProcessBox(box, boxSpace);
				}
			}
			else {
				if (debug) LogMessage("skipped -- sortedName.nameWidth > boxSpace (" + sortedName.name + ")");
			}
		}
		else {
			if (debug) LogMessage("skipped sortedName.processed == true (" + sortedName.name + ")");
		}
	} // end for gSortedNames
	
	if (box.contents.length > 0) {
		if (debug) {
			LogMessage("Success: box.contents = " + box.contents);
			box.texts[0].fillColor = gSwatches[gCountCycles];
			box.texts[0].fillTint = 100;
		}
	}
	else {
		var tmp = box.label;
		
		if (debug) { // Show the problematic box & log error
			LogMessage("No solution: box #" + box.label + " can't fit any available name.");

			try {
				app.select(box, SelectionOptions.REPLACE_WITH);
				app.activeWindow.zoom = ZoomOptions.FIT_PAGE;
				app.activeWindow.zoomPercentage = 100;
			}
			catch(err) {
				$.writeln(err.message + ", line: " + err.line);
			}
		}
		else { // revert the doc
			app.scriptPreferences.userInteractionLevel = UserInteractionLevels.NEVER_INTERACT;
			doc.revert();		
			app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;
		}

		ErrorExit("No solution: box #" + tmp + " can't fit any available name.", true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ResetSortedNames() {
	var sortedName;

	for (var j = 0; j < gSortedNames.length; j++) {
		sortedName = gSortedNames[j];
		sortedName.processed = null;
	}

	gCountInserted = 0;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function SortNames(textFrame) {
	var n, j, nameWidth, sortedNames,
	names = textFrame.lines.everyItem().getElements(),
	unsortedNames = [];

	if (debug) LogMessage("\r===== START SORT NAMES =====\r--------------- Unsorted ---------------");
	
	for (n = 0; n < names.length; n++) {
		name = names[n];
		nameWidth = GetTextWidth(name);
		if (debug) LogMessage(ZeroPad((n + 1), 2) + " - " + name.contents.replace(/\r$/, "") + " | " + nameWidth);
		
		unsortedNames.push({
			name: name.contents.replace(/\r$/, ""),
			nameWidth: nameWidth
		});
	}

	sortedNames = unsortedNames.sort(function(a, b) {return b.nameWidth - a.nameWidth;});
	
	if (debug) LogMessage("--------------- Sorted ---------------");
	
	for (j = 0; j < sortedNames.length; j++) {
		item = sortedNames[j];
		if (debug) LogMessage(ZeroPad((j + 1), 2) + " - " + item.name.replace(/\r$/, "") + " | " + item.nameWidth);
	}

	if (debug) LogMessage("\r===== END SORT NAMES =====\r");
	return sortedNames;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetTextWidth(txt) {
	try {
		var left =txt.horizontalOffset;
		var right = (txt.characters[-1].contents.match(/[\r\n]$/) != null) ? txt.characters[-2].endHorizontalOffset : txt.endHorizontalOffset;
		var width = right - left;
		width = RoundString(width, 1);		

		return width;
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FixOverflow(box) {
	var result = false,
	count = 0,
	gb = box.geometricBounds,
	widthOriginal = gb[3] - gb[1],
	increaseLimit = 10,
	increment = 3,
	extraSpaceWidth = 5; 
	
	while (box.overflows && (gb[3] - gb[1]) < (widthOriginal + increaseLimit)) {
		(count % 2) ? gb = [gb[0], gb[1] - increment, gb[2], gb[3]] : gb = [gb[0], gb[1], gb[2], gb[3] + increment];
		box.geometricBounds = gb;
		box.recompose();
		count++;	
	}

	box.resize(CoordinateSpaces.INNER_COORDINATES,
		AnchorPoint.CENTER_ANCHOR,
		ResizeMethods.ADDING_CURRENT_DIMENSIONS_TO,
		[extraSpaceWidth, 0, CoordinateSpaces.INNER_COORDINATES]);
		
		if (!box.overflows) result = true;
		if (debug) LogMessage("Fixed box overflow = " + result + " (Box #" + box.label + ")");
		
		return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PlaceTempText() {
	var tempTxtBox = GetItemFromCollection("temp", doc.textFrames);
	
	if (tempTxtBox == null) {	
		var page = doc.pages[0];
		var b = page.bounds;
		tempTxtBox = page.textFrames.add();
		tempTxtBox.geometricBounds = [b[0], b[2] + 10, b[2], b[3] + 510];
	}

	tempTxtBox.place(gTxtFile);
	tempTxtBox.applyObjectStyle(gObjectStyleTempBox, true);
	
	// Replace regular spaces with nonbreaking spaces
	app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
	app.findTextPreferences.findWhat = " ";
	app.changeTextPreferences.changeTo = "^S";
	var changedItems = tempTxtBox.changeText();
	app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;	

	return tempTxtBox;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function RoundString(numVal, decimals) {
    var retVal = Math.round(numVal * Math.pow(10,decimals)) + "";
    retVal = retVal.substring(0, retVal.length - decimals) + "." + retVal.substring(retVal.length - decimals);
    return retVal;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function LogMessage(msg) {
	if (log) {
		var file = new File("~/Desktop/" + scriptName + " log.txt");
		file.encoding = "UTF-8";
		
		if (file.exists) {
			file.open("e");
			file.seek(0, 2);
		}
		else {
			file.open("w");
		}
	
		file.write(msg + "\r"); 
		file.close();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ZeroPad(num, digit) {
	var tmp = num.toString();
	while (tmp.length < digit) {
		tmp = "0" + tmp;
	}
	return tmp;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	
	if (doc.extractLabel(scriptName) == "processed") {
		var answer = confirm ("This document has been already processed by the '" + scriptName + "' script. Do you want to continue?", true, scriptName);
		if (!answer) exit();
	}

	// Check object styles
	var objectStyleBoxes = doc.objectStyles.itemByName("Boxes");
	if (!objectStyleBoxes.isValid) ErrorExit("Object style 'Boxes' is missing in the current document.", true);
	
	gObjectStyleTempBox = doc.objectStyles.itemByName("Temporary box");
	if (!gObjectStyleTempBox.isValid) ErrorExit("Object style 'Temporary box' is missing in the current document.", true);	
	
	// Check paragraph styles
	var parStyleNames = doc.paragraphStyles.itemByName("Names");
	if (!parStyleNames.isValid) ErrorExit("Paragraph style 'Names' is missing in the current document.", true);
	        
	var folder = new Folder(doc.filePath);

	if (debug) {
		// Apply a different color to every cycle
		var list = [
			"0,100,0,0",
			"50,50,0,0",
			"0,50,50,0",
			"15,100,100,0",
			"75,5,100,0",
			"0,0,50,0",
			"50,0,0,0",
			"0,50,0,0",
			"100,50,0,0"
			];
			
		AddColorsFromList(list);
	
//~ 		gTxtFile = new File(doc.filePath + "/first names.txt");
		gTxtFile = folder.openDlg("Choose a text file", GetFileFilter("All Files:*.* , Text Import:*.txt, Rich Text Format:*.rtf, Microsoft Word 2007:*.docx, Microsoft Word:*.doc"));
	}
	else {
		gTxtFile = folder.openDlg("Choose a text file", GetFileFilter("All Files:*.* , Text Import:*.txt, Rich Text Format:*.rtf, Microsoft Word 2007:*.docx, Microsoft Word:*.doc"));
	}

	if (gTxtFile == null) exit(); // No file was selected
	
	var logFile = new File("~/Desktop/" + scriptName + " log.txt");
	if (logFile.exists) logFile.remove();

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetFileFilter(fileFilter) {
    if (fileFilter == undefined || File.fs == "Windows") {
        return fileFilter;
    }
    else {
        // Mac
        var extArray = fileFilter.split(":")[1].split(",");
        return function fileFilter(file) {
            if (file.constructor.name === "Folder") return true;
            if (file.alias) return true;
            for (var e = 0; e < extArray.length; e++) {
                var ext = extArray[e];
                ext = ext.replace(/\*/g, "");
                if (file.name.slice(ext.length * -1) === ext) return true;
            }
        }
    }
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddColorsFromList(list) {
	var item, arr, color;
	for (var i = 0; i < list.length; i++) {
		item = list[i];
		arr = item.split(",");
		for (var j = 0; j < arr.length; j++) {
			arr[j] = Number(arr[j]);
		}

		color = MakeColor(arr);
		if (color.isValid) gSwatches.push(color);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeColor(colorName, colorSpace, colorModel, colorValue) {
	if (arguments.length == 1 && arguments[0] instanceof Array) {
		colorValue = arguments[0];
		colorName = colorSpace = colorModel = null;
	}
	
	if (colorName == null || colorName == "") {
		if (colorValue.length == 3) {
			colorName = "R=" + colorValue[0] + " G=" + colorValue[1] + " B=" + colorValue[2];
		}
		else if (colorValue.length == 4) {
			colorName = "C=" + colorValue[0] + " M=" + colorValue[1] + " Y=" + colorValue[2] + " K=" + colorValue[3];
		}
	}

	if (colorSpace == null || colorSpace == "") {
		if (colorValue.length == 3) {
			colorSpace = ColorSpace.RGB;
		}
		else if (colorValue.length == 4) {
			colorSpace = ColorSpace.CMYK;
		}
	}

	if (colorModel == null || colorModel == "") colorModel = ColorModel.PROCESS;

	if (doc == null) var doc = app.documents[0];

	var color = doc.colors.item(colorName);
	if (!color.isValid) {
		color = doc.colors.add({name: colorName, space: colorSpace, model: colorModel, colorValue: colorValue});
	}

	return color;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------