﻿/* Copyright 2023, Kasyan Servetsky
July 14, 2023
Written by Kasyan Servetsky
Current version: http://kasyan.ho.ua/indesign/2023/leavers_hoodie_script/leavers_hoodie_script.html
e-mail: askoldich@yahoo.com */
//======================================================================================
// Parameters that can be changed by the user
// In a future version, I’m planning to make a dialog box for these settings.
var extraSpaceWidth = 0,
extraSpaceTop = 10,
verticalShift = -3.115,
extraSpaceBottom = 4,
charDistanceLimit = 20; // The maximum distance between two adjacent characters 
//======================================================================================
var scriptName = "Prepare template 1.2",
debug = false, // for debugging only
doc, textFrame, placeholderTxt, objectStyleBoxes,
count = 1;

PreCheck();
//~ app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var startTime = new Date(),
		lineSplit, line, ranges;
		
		// Store & change units: this script works in points
		var savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits;
		var savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
		doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.POINTS;
		doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS;
		
		// Fill with placeholder text
		textFrame.contents = placeholderTxt;
		var oversetText = GetOversetText(textFrame.parentStory);
		oversetText.remove();

		var lines = textFrame.lines;
		
		progressWin = new Window("window", scriptName);
		progressBar = progressWin.add("progressbar" , undefined, 0, lines.length);
		progressBar.preferredSize.width = 600;
		progressWin.show();
		
		for (var i = 0; i < lines.length; i++) {
			line = lines[i];
			progressBar.value = i + 1;
			lineSplit = CheckLine(line);
			
			if (lineSplit.length == 0) {
				MakeBox(line);
			}
			else {
				ranges = GetRanges(line, lineSplit);
				
				for (var r = 0; r < ranges.length; r++) {
					MakeBox(ranges[r]);
				}
			}
		}

		textFrame.contents = "";
		progressWin.close();
		
		// Restore units
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
		
		doc.insertLabel(scriptName, "processed");
		
		var endTime = new Date();
		var duration = GetDuration(startTime, endTime);
		var report = count + " box" + ((count == 1) ? " was" : "es were") + " created.\n(time elapsed: " + duration + ")";

		if (debug) {
			$.writeln(report);
		}
		else {
			alert(report, scriptName, false);
		}		
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetRanges(line, lineSplit) {
	var tsr, prevIdx, thisIdx,
	story = line.parentStory,
	startLineIdx = line.index,
	endLineIdx = line.characters[line.characters.length - 1].index,
	tsrLength = 0,
	arr = [];

	for (var j = 0; j < lineSplit.length; j++) {
		if (j > 0) {
			prevIdx = thisIdx;
		}
		else {
			prevIdx = startLineIdx;
		}
	
		thisIdx = lineSplit[j];
		tsr = story.characters.itemByRange(prevIdx, thisIdx - 1);
		tsrLength = tsr.length[0];
		arr.push(tsr);
	}
 
	tsr = story.characters.itemByRange(thisIdx, endLineIdx);
	arr.push(tsr);
	
	return arr;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeBox(line) {
	try {
		var pi = line.createOutlines(false)[0];
		
		if (line.constructor.name == "Character") {
			pi = pi[0];
		}

		var gb = pi.geometricBounds;
		gb = [gb[0] - extraSpaceTop + verticalShift, gb[1] - extraSpaceWidth, gb[2] + extraSpaceBottom, gb[3] + extraSpaceWidth];
		pi.remove();
		var layer = MakeLayer("Boxes", UIColors.CUTE_TEAL);
		var page = app.layoutWindows[0].activePage;
		var box = page.textFrames.add(layer, {geometricBounds: gb, appliedObjectStyle: objectStyleBoxes, label: String(count)}); // , contents: "XXX"
		count++;
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckLine(line) {
	try {
		var character, prevCharEnd, thisChar, thisCharStart,
		characters = line.characters.everyItem().getElements(),
		distance = 0,
		prevChar = null,
		arr =[];
			
		for (var i = 0; i < characters.length; i++) {
			if (i > 0) {
				prevChar = thisChar;
				prevCharEnd = prevChar.horizontalOffset;
			}
		
			thisChar = characters[i];
			thisCharStart = thisChar.horizontalOffset;
			
			if (prevChar != null) {
				distance = thisCharStart - prevCharEnd;
				
				if (distance > charDistanceLimit) {
					arr.push(thisChar.index);
				}
			}
		}	
		
		return arr;
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeLayer(name, layerColor) {
	var layer = doc.layers.item(name);
	if (!layer.isValid) {
		layer = doc.layers.add({name: name});
		if (layerColor != undefined) layer.layerColor = layerColor;
	}
	return layer;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetOversetText(textFlow) { 
	if (!textFlow.overflows) return null;
	var start = textFlow.characters[0];
	if (textFlow instanceof Cell) {
		if (textFlow.characters.length > 0) {
			start = textFlow.texts[0].characters[textFlow.contents.length];
		} 
	} else {   
		if (Number(String(app.version.split(".")[0])) > 4) {
					var myTFs = textFlow.textContainers;   
				} else {
					var myTFs = textFlow.textFrames;
				}
			for (var j = myTFs.length - 1; j >= 0; j--) {    
				if (myTFs[j].characters.length > 0) {       
					start = textFlow.characters[myTFs[j].characters[-1].index + 1];
					break;     
				}
			}
		} 
	return textFlow.texts.itemByRange(start, textFlow.texts[0].characters[-1]);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];

	if (doc.extractLabel(scriptName) == "processed") {
		var answer = confirm ("This document has been already processed by the '" + scriptName + "' script. Do you want to continue?", true, scriptName);
		if (!answer) exit();
	}
	 
	// Check object styles
	objectStyleBoxes = doc.objectStyles.itemByName("Boxes");
	if (!objectStyleBoxes.isValid) ErrorExit("Object style 'Boxes' is missing in the current document.", true);
	
	var wrongSelectionMsg = "A text frame should be selected.";
	
	// Check selection
	if (app.selection.length == 0) {
		ErrorExit("Nothing is selected. " + wrongSelectionMsg, true);
	}
	else if (app.selection.length == 1 && app.selection[0] instanceof TextFrame) {
		textFrame = app.selection[0];
	}
	else {
		ErrorExit(wrongSelectionMsg, true);
	}

	InitVars();
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function InitVars() {
	placeholderTxt = "IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII";
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------