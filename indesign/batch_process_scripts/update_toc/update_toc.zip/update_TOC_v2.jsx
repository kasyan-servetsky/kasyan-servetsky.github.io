﻿updateToc();

function updateToc() {
	try {
		var contentsTextFrame = getItemFromCollection("contents", g.doc.textFrames);
		
		if (contentsTextFrame != null) {
			app.select(contentsTextFrame);
			app.scriptMenuActions.itemByID(71442).invoke();
		}
	}
	catch(err) {
		g.WriteToFile("ERROR: " + g.doc.name + " - " + err.message + ", line: " + err.line);
	}
}

function getItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		if (label == collection[i].label) return collection[i];
	}
	return null;
}