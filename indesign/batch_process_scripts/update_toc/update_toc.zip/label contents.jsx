﻿main();

function main() {
	try {
		if (app.documents.length > 0 &&
			app.selection.length == 1 && 
			app.selection[0].constructor.name == "TextFrame")
		{
			app.selection[0].label = "contents";
			app.documents[0].close(SaveOptions.YES);
		}
	}
	catch(err) {
		alert(err.message + ", line: " + err.line, true);
	}
}