﻿changeSwatch();

function changeSwatch() {
	var doc = app.documents[0];
	var swatch = doc.swatches.item("PANTONE 293 U");
	
	if (swatch != null) {
		app.findColorPreferences = app.changeColorPreferences = NothingEnum.NOTHING;
		app.findColorPreferences.findWhat = swatch;
		app.findColorPreferences.tint = 25;
		app.changeColorPreferences.changeTo = swatch;
		app.changeColorPreferences.tint = 10;
		var changed = doc.changeColor();
		app.findColorPreferences = app.changeColorPreferences = NothingEnum.NOTHING;
	}
}