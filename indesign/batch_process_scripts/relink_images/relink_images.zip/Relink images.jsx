﻿// Global variables are defined here
var scriptName = "Relink images",
doc,
debugMode = false, // for debugging only
args = [],
calledFromBatchProcessor = (CalledFromBatchProcessor()) ? true : false;

if (calledFromBatchProcessor) { // called as a 'secondary' script from the batch processor
	if (typeof g.arguments != "undefined") {
		args = NormalizeArgs(g.arguments);
	}
	
	if (g.doc != null) {
		doc = g.doc;
		Main();
	}
	else {
		g.WriteToFile("ERROR: 'g.doc == null' - Failed to get the document to process.");
	}
}
else { // called as a 'regular' script
	app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");
}

//===================================== FUNCTIONS =======================================
function Main() {
	try {
		var  arr = [],
		list = [];
		
		if (args.length == 0) { // empty array
			var  list = [
					["MyOldLogo.ai", "MyNewLogo.ai"],
					["Image-1.png", "Image-2.png"]
				];
		}
		else {
			for (var j = 0; j < args.length; j++) {
				arr = args[j].split(",");
	
				if (arr.length == 2 && arr[0] != "" && arr[1] != "") { // make sure the both elements are not empty
					list[j] = [Trim(arr[0]), Trim(arr[1])]; // delete leading and trailing white space
				}
			}
		}
	
		var link, oldFilePath, newFilePath, newFile, listItem, container, layer,
		links = doc.links.everyItem().getElements();
		
		for (var i = 0; i < links.length; i++) {
			link = links[i];
			oldFilePath = link.filePath;
			
			for (var j = 0; j < list.length; j++) {
				listItem = list[j];

				if (oldFilePath.indexOf(listItem[0]) != -1) {
					newFilePath = oldFilePath.replace(listItem[0], listItem[1]);
					newFile = new File(newFilePath);
					
					if (newFile.exists) {
						container = link.parent.parent;
						if (container.locked) {
							container.locked = false;
						}
					
						layer = container.itemLayer;
						if (layer.locked) {
							layer.locked = false;
						}
					
						link.relink(newFile);

						container.fit(FitOptions.PROPORTIONALLY);
					}
				}
			}
		}
	}
	catch(err) { // if an error occurs, catch it and write the  document's name, error message and line# where it happened into the log
		if (calledFromBatchProcessor) g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", Line: " + err.line + ", Time: " + GetTime());
		if (debugMode) $.writeln(err.message + ", line: " + err.line); // in debugMode -- write the error message and line# to ESTK console
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Trim(str) {  
  return str.replace(/^\s+/,'').replace(/\s+$/,'');  
}
//=======================================================================================
function GetTime() { // get exact time for the log -- hr : min : sec -- so we could know when exactly an error occured
	var date = new Date();
	var dateString = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CalledFromBatchProcessor() { // Let's see if it's called as a 'secondary' (returns true) or as a 'regular' (returns false) script
	var result = false;
	
	try {
		var arr = $.stack.split(/[\n]/);
		if (arr.length > 0 && arr[0].match(/\[Batch processor/i) != null) {
			result = true;
		}
	}
	catch(err) {}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function NormalizeArgs(args) { // convert a string value read from the arguments file to actual boolen data type (or undefined)
	for (var i = 0; i < args.length; i++) {
		if (args[i] == "true" || args[i] == "false" || args[i] == "undefined" || args[i] == "null") {
			args[i] = eval(args[i]);
		}
	}

	return args;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) { // Something went totally wrong.
	alert(error, scriptName, icon); // Give a warning
	exit(); // and stop the script
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------