﻿var doc = app.activeDocument;
var docPathNoExt = doc.fullName.absoluteURI.replace(/\.[^\.]+$/, "");

// PDF Export
function exportPDF() {
	var pdfFile = new File(docPathNoExt  + ".pdf");
	var pdfPreset = app.pdfExportPresets.item("[PDF/X-4:2008]");
	doc.exportFile(ExportFormat.PDF_TYPE, pdfFile, false, pdfPreset);
}

// PNG Export
function exportPNG() {
	var pngExportPrefs = app.pngExportPreferences;
	
	with (pngExportPrefs) {
		pngQuality = PNGQualityEnum.MAXIMUM;
		transparentBackground = true;
		exportResolution = 72;
		pngExportRange = PNGExportRangeEnum.EXPORT_ALL;
		pngSuffix = "_page_^P";		
	}

	var pngFile = new File(docPathNoExt  + ".png");
	doc.exportFile(ExportFormat.PNG_FORMAT, pngFile, false);
}

// Call the functions
exportPDF();
exportPNG();