﻿/* Copyright 2026, Kasyan Servetsky
March 26, 2026
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Relink images",
debug = false,
doc, folder,
arr = [],
countTotal = 0;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" script");

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var link, startNewIteration,
		startTime = new Date(),
		links = doc.links.everyItem().getElements(),
		linksLength = links.length;

		if (folder.exists) {
			var jpegFiles = folder.getFiles("*.jpg");
			var progressWin, progressBar, progressTxt, countProgressBar;
			progressWin = new Window("window", scriptName);
			progressBar = progressWin.add("progressbar" , undefined, 0, linksLength);
			progressBar.preferredSize.width = 800;
			progressTxt = progressWin.add("statictext", undefined,  "");
			progressTxt.alignment = "fill";
			progressWin.show();

			arr.push(GetDate());
			arr.push("\r\r------------------------------------------\rDocument name: " + doc.name + 
				"\rDocument path: " + new File(doc.filePath).fsName + 
				"\rFolder with JPEG files: " + folder.fsName + 
				"\r------------------------------------------");

			for (var i = 0; i < linksLength; i++) {
				startNewIteration = new Date();
				link = links[i];

				countProgressBar = i + 1;
				progressBar.value = countProgressBar;
				progressTxt.text = "Relinking images: " + link.name + " (" + countProgressBar + " out of " + linksLength + ")";

				if (link.status == LinkStatus.LINK_MISSING) {
					var newFile = GetApproxNameFile(link, jpegFiles);
					
					if (newFile != null) {
						link.relink(newFile);
						countTotal++;
						arr.push("\r" + link.name + "\r" + "\tOld path: " + new File(link.filePath).fullName);
						arr.push("\tNew path: " + newFile.fullName);
					}
					else {
						arr.push("\rCan't get an image with approximate name for '" + link.name + "'");
					}
				}
			}

			progressWin.close();

			var duration = GetDuration(startTime, new Date());
			var report = countTotal + ((countTotal == 1) ? " link was" : " links were") + " relinked.\n(time elapsed: " + duration + ")";	
			arr.push("\r=========================================================\r" + report + "\r=========================================================\r\r\r");
			var text = arr.join("\r");
			WriteToFile(text);
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line);
	}
}

function GetApproxNameFile(oldLink, jpegFiles) {
	try {
		
		var startTime = new Date(),
		jpegFile, newName, patt2, patt3, res1, res2, res3, str,
		patt1 = /(.+?)([A-Z]{2,4})(.+?)(_(\d|X)(\d|X)(\d|X)(\d|X)\.(\d|X)(\d|X)\.(\d|X)(\d|X)_)(B[A-Z]{0,2}\d{1,4}.+?_)*(.+)/,
		countTmp = 0,
		foundFile = null,
		oldName = decodeURI(oldLink.name);

		for (var i = 0; i < jpegFiles.length; i++) {
			startNewIteration = new Date();
			jpegFile = jpegFiles[i];
			newName = decodeURI(jpegFile.name);
			countTmp++;
			res1 = oldName.match(patt1);

			if (res1 == null) {
				continue;
			}

			str = decodeURI(res1[1] + "[A-Z]{2,4}" + res1[3] + res1[4] + "B[A-Z]{0,2}\\d{1,4}.+?_" + res1[14].replace(/^B[A-Z]{0,2}\d{1,4}.+?_/, ""));
			patt2 = new RegExp(str);
			res2 = newName.match(patt2);

			if (res2 != null) {
				foundFile = jpegFile;
				break;
			}
			else {
				str = decodeURI(res1[1] + "[A-Z]{2,4}" + res1[3] + res1[4] + res1[14]);
				patt3 = new RegExp(str);
				res3 = newName.match(patt3);

				if (res3 != null) {
					foundFile = jpegFile;
					break;
				}
			}
		}

		return foundFile;
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line);
	}
}

function PreCheck() {
	try {
		if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
		doc = app.activeDocument;
		if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
		if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
		if (doc.links.length == 0) ErrorExit("The current document has no links.", true);

		folder = Folder.selectDialog("Please select path to JPEG files"); // global
		if (folder != null) {
			Main();
		}
	}
	catch(err) {}
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}

function GetDuration(startTime, endTime, round) {
	if (typeof round == "undefined") round = true;
	var str;
	var duration = (endTime - startTime)/1000;
	if (round) duration = Math.round(duration, 2);

	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}

function GetDate() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}

function WriteToFile(text) {
	var file = new File("~/Desktop/" + scriptName + ".txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text); 
	file.close();
}