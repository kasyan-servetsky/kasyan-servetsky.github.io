﻿/* Copyright 2026, Kasyan Servetsky
March 27, 2026
Written by Kasyan Servetsky
Edits by Eugene Tyson
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Relink images",
debug = false,
doc, folder,
arr = [],
countTotal = 0,
folderCache = {}; // Global cache

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" script");

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var link,
		startTime = new Date(),
		links = doc.links.everyItem().getElements(),
		linksLength = links.length;

		if (folder.exists) {
			var jpegFiles = folder.getFiles("*.jpg");
			var progressWin, progressBar, progressTxt, countProgressBar;
			progressWin = new Window("window", scriptName);
			progressBar = progressWin.add("progressbar" , undefined, 0, linksLength);
			progressBar.preferredSize.width = 800;
			progressTxt = progressWin.add("statictext", undefined,  "");
			progressTxt.alignment = "fill";
			progressWin.show();

			arr.push(GetDate());
			arr.push("\r\r------------------------------------------\rDocument name: " + doc.name + 
				"\rDocument path: " + new File(doc.filePath).fsName + 
				"\rFolder with JPEG files: " + folder.fsName + 
				"\r------------------------------------------");

			for (var i = 0; i < linksLength; i++) {
				link = links[i];

				countProgressBar = i + 1;
				progressBar.value = countProgressBar;
				progressTxt.text = "Relinking images: " + link.name + " (" + countProgressBar + " out of " + linksLength + ")";

				if (link.status == LinkStatus.LINK_MISSING) {
					var newFile = GetApproxNameFile(link, jpegFiles);
					
					if (newFile != null) {
						link.relink(newFile);
						countTotal++;
						arr.push("\r" + link.name + "\r" + "\tOld path: " + new File(link.filePath).fullName);
						arr.push("\tNew path: " + newFile.fullName);
					}
					else {
						arr.push("\rCan't get an image with approximate name for '" + link.name + "'");
					}
				}
			}

			progressWin.close();

			var duration = GetDuration(startTime, new Date());
			var report = countTotal + ((countTotal == 1) ? " link was" : " links were") + " relinked.\n(time elapsed: " + duration + ")";	
			arr.push("\r=========================================================\r" + report + "\r=========================================================\r\r\r");
			var text = arr.join("\r");
			WriteToFile(text);
			folderCache = null; // Clean memory
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line);
	}
}

// Helper prevents regex characters in filenames breaking script
function escapeRegExp(str) {
	return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function GetApproxNameFile(oldLink) {
	var file = new File(oldLink.filePath),
		folder = file.parent,
		oldName = decodeURI(oldLink.name);

	if (!folder.exists) return null;

	var key = folder.absoluteURI;

	// OPTIMISE CACHE FOLDERS PRE-DECODE NAMES
	if (!folderCache[key]) {
		var files = folder.getFiles("*.jpg");
		var prepared = [];
		for (var f = 0; f < files.length; f++) {
			prepared.push({
				file: files[f],
				name: decodeURI(files[f].name)
			});
		}
		folderCache[key] = prepared;
	}

	var jpegFiles = folderCache[key];

	// EXTRACT PARTS FROM OLD NAME
	var patt1 = /(.+?)([A-Z]{2,4})(.+?)(_(\d|X)(\d|X)(\d|X)(\d|X)\.(\d|X)(\d|X)\.(\d|X)(\d|X)_)(B[A-Z]{0,2}\d{1,4}.+?_)*(.+)/;
	var res1 = oldName.match(patt1);
	if (!res1) return null;

	// Escape parts don't break regex
	var b1 = escapeRegExp(res1[1]);
	var b3 = escapeRegExp(res1[3]);
	var b4 = escapeRegExp(res1[4]);
	var b14 = escapeRegExp(res1[14]);
	var tail = b14.replace(/^B[A-Z]{0,2}\d{1,4}.+?_/, "");

	// Possible patterns
	var p2 = new RegExp(b1 + "[A-Z]{2,4}" + b3 + b4 + "B[A-Z]{0,2}\\d{1,4}.+?_" + tail, "i");
	var p3 = new RegExp(b1 + "[A-Z]{2,4}" + b3 + b4 + b14, "i");

	// THE SEARCH
	for (var i = 0; i < jpegFiles.length; i++) {
		var entry = jpegFiles[i];

		// Speed Enhancement Possibly
		if (entry.name.indexOf(res1[3]) === -1) continue;

		if (p2.test(entry.name) || p3.test(entry.name)) {
			return entry.file;
		}
	}
	return null;
}

function Relink(oldLink, newFile) {
	var oldPath = new File(oldLink.filePath).fullName;
	oldLink.relink(newFile);
	count++;
	arr.push("\rRelinked: " + oldLink.name + "\r\t-> " + newFile.fullName);
}

function PreCheck() {
	try {
		if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
		doc = app.activeDocument;
		if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
		if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
		if (doc.links.length == 0) ErrorExit("The current document has no links.", true);

		folder = Folder.selectDialog("Please select path to JPEG files"); // global
		if (folder != null) {
			Main();
		}
	}
	catch(err) {}
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}

function GetDuration(startTime, endTime, round) {
	if (typeof round == "undefined") round = true;
	var str;
	var duration = (endTime - startTime)/1000;
	if (round) duration = Math.round(duration, 2);

	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}

function GetDate() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}

function WriteToFile(text) {
	var file = new File("~/Desktop/" + scriptName + ".txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text); 
	file.close();
}