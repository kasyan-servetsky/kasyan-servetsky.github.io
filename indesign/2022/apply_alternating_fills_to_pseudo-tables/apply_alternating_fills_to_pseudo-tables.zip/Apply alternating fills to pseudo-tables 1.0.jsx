﻿/* Copyright 2022, Kasyan Servetsky
December 2, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Apply alternating fills to pseudo-tables - 1.0",
doc, set, pars, allParStyles,
allParStyleNames = [];

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.FAST_ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var par,
		count = 0,
		countTotal = 0;
		 
		for (var i = 0; i < pars.length; i++) {
			par = pars[i];
			if (par.appliedParagraphStyle == allParStyles[set.applytoParStyle[0]]) {
				if (count % 2 == 0 ) {
					par.appliedParagraphStyle = allParStyles[set.evenParStyle[0]];
					count++;
					countTotal++;
				}
				else {
					par.appliedParagraphStyle = allParStyles[set.oddParStyle[0]];
					count++;
					countTotal++;
				}
			}
			else {
				count = 0;
			}		
		}
	
		alert ("Finished: " + countTotal + ((countTotal == 1) ? " paragraph was" : " paragraphs were") +"  processed.", scriptName);
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	GetDialogSettings();
	var w = new Window("dialog", scriptName);

	w.p = w.add("panel", undefined, "Paragraph styles:");
	w.p.orientation = "column";
	
	w.p.g = w.p.add("group");
	w.p.g.orientation = "row";
	w.p.g.alignment = "right";
	w.p.g.st = w.p.g.add("statictext", undefined, "Apply to");
	w.p.g.ddl = w.p.g.add("dropdownlist", undefined, allParStyleNames);
	w.p.g.ddl.selection = set.applytoParStyle[0];

	w.p.g1 = w.p.add("group");
	w.p.g1.orientation = "row";
	w.p.g1.alignment = "right";
	w.p.g1.st = w.p.g1.add("statictext", undefined, "Odd");
	w.p.g1.ddl = w.p.g1.add("dropdownlist", undefined, allParStyleNames);
	w.p.g1.ddl.selection = set.oddParStyle[0];
	
	w.p.g2 = w.p.add("group");
	w.p.g2.orientation = "row";
	w.p.g2.alignment = "right";
	w.p.g2.st = w.p.g2.add("statictext", undefined, "Even");
	w.p.g2.ddl = w.p.g2.add("dropdownlist", undefined, allParStyleNames);
	w.p.g2.ddl.selection = set.evenParStyle[0];
	
	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok"});
	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		with (set) {
			applytoParStyle = [w.p.g.ddl.selection.index, w.p.g.ddl.selection.text],
			oddParStyle = [w.p.g1.ddl.selection.index, w.p.g1.ddl.selection.text],
			evenParStyle = [w.p.g2.ddl.selection.index, w.p.g2.ddl.selection.text]
		}
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {
					applytoParStyle: [0, "[Basic Paragraph]"], 
					oddParStyle: [0, "[Basic Paragraph]"], 
					evenParStyle: [0, "[Basic Paragraph]"]
				};
	}
	
	if (allParStyleNames[set.applytoParStyle[0]] != set.applytoParStyle[1]) {
		set.applytoParStyle[0] = 0;
	}

	if (allParStyleNames[set.oddParStyle[0]] != set.oddParStyle[1]) {
		set.oddParStyle[0] = 0;
	}

	if (allParStyleNames[set.evenParStyle[0]] != set.evenParStyle[1]) {
		set.evenParStyle[0] = 0;
	}

	return set;
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	// check if text is selected and get the current story
	var msgWrongSelection = "One text frame or some text should be selected, or the cursor should be inserted into the text.";
	if (app.selection.length == 0 || app.selection.length > 1) ErrorExit(msgWrongSelection, true);
	var sel = app.selection[0];
	
	if (sel.constructor.name == "TextFrame" || sel.constructor.name == "InsertionPoint") { // a text frame is selected
		story = sel.parentStory;
		pars = story.paragraphs;
	}
	else if (sel.hasOwnProperty("baseline")) { // some text is selected or the cursor is placed in the text
		pars = sel.paragraphs;
	}
	else {
		ErrorExit(msgWrongSelection, true);
	}

	if (pars.length == 0) {
		ErrorExit("Selection contains no paragraphs.", true);
	}
	else if (pars.length >= 1 && pars.length <= 3) {
		if (!confirm("Selection contains only " + pars.length + " paragraphs. Do you really want to continue?", true, scriptName)) {
			exit();
		}
	}

	allParStyles = doc.allParagraphStyles;
	allParStyles.shift();
	
	for (var i = 0; i < allParStyles.length; i++) allParStyleNames.push(allParStyles[i].name);
	
	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}