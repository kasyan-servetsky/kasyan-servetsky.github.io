﻿/* Copyright 2022, Kasyan Servetsky
December 3, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Apply alternating pattern to quasi-tables - 1.3",
debug = false, // for debugging only
doc, set, pars, allParStyles, colors, colorsSuccess,
allParStyleNames = [],
allSwatches = [],
allSwatchNames = [];

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" Script");

//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var par,
		count = 0,
		countTotal = 0;
		
		var parStyle = allParStyles[set.parStyle[0]];
		 
		for (var i = 0; i < pars.length; i++) {
			par = pars[i];
			if (debug) $.writeln("\n" + i + "-" + par.contents.replace(/\t+/g, " ").replace(/\n/, " "));
 
			if (par.appliedParagraphStyle == parStyle) {
				par.clearOverrides(OverrideType.ALL);
				
				if (count % 2 == 0) { // Odd
					if (debug) $.writeln("Odd");
					par.paragraphShadingOn = true;
					par.paragraphShadingColor = allSwatches[set.oddSwatchColor[0]];
					par.paragraphShadingTint = set.oddSwatchTint;
					count++;
					countTotal++;
				}
				else { // Even
					if (debug) $.writeln("Even");
					par.paragraphShadingOn = true;
					par.paragraphShadingColor = allSwatches[set.evenSwatchColor[0]];
					par.paragraphShadingTint = set.evenSwatchTint;
					count++;
					countTotal++;
				}
			}
			else {
				if (set.reset && count != 0) {
					count = 0;
				}
			
				if (debug) $.writeln("Another style");
			}		
		}
	
		if (debug) {
			$.writeln("\n----------------------------------\nFinished: " + countTotal + ((countTotal == 1) ? " paragraph was" : " paragraphs were") +"  processed.");
		}
		else {
			alert("Finished: " + countTotal + ((countTotal == 1) ? " paragraph was" : " paragraphs were") +"  processed.", scriptName);
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CreateDialog() {
	GetDialogSettings();	
	var colorsLength = (colors != null) ? colors.length : 0;
	
	var w = new Window("dialog", scriptName);
	w.g = w.add("group");
	w.g.orientation = "row";
	w.g.alignment = "right";	
	w.g.st = w.g.add("statictext", undefined, "Paragraph style:");
	w.g.ddl = w.g.add("dropdownlist", undefined, allParStyleNames);
	w.g.ddl.selection = set.parStyle[0];
	w.cb = w.add("checkbox", undefined, "reset to odd after another style");
	w.cb.value = set.reset;
	w.cb.alignment = "right";

	w.g1 = w.add("group");
	w.g1.orientation = "row";

	// ODD
	w.g1.pl = w.g1.add("panel", undefined, "Odd");
	w.g1.pl.orientation = "column";
	w.g1.pl.alignment = "fill";

	w.g1.pl.ddl = w.g1.pl.add("dropdownlist", undefined, ((!colorsSuccess) ? allSwatchNames : undefined));
	if (colorsSuccess) {
		for (i = 0 ; i < colorsLength ; ++i) {
			 (w.g1.pl.ddl.add("item", "\xa0"+colors[i].name)).image = colors[i].png; 
		}
	}
	w.g1.pl.ddl.selection = set.oddSwatchColor[0];
	
	// edit text
	w.g1.pl.et = w.g1.pl.add("edittext", undefined, String(set.oddSwatchTint));
	w.g1.pl.et.alignment = "center";
	w.g1.pl.et.characters = 3;
	w.g1.pl.et.onChange = function() {
		w.g1.pl.sl.value = Number(this.text);
	}
	
	// slider
	w.g1.pl.sl = w.g1.pl.add("slider", undefined, set.oddSwatchTint, 0, 100);
	w.g1.pl.sl.alignment = "fill";
	w.g1.pl.sl.onChange = function() {
		w.g1.pl.et.text = Math.floor(this.value);
	}

	// EVEN
	w.g1.pr = w.g1.add("panel", undefined, "Even");
	w.g1.pr.orientation = "column";
	w.g1.pr.alignment = "fill";

	w.g1.pr.ddl = w.g1.pr.add("dropdownlist", undefined, ((!colorsSuccess) ? allSwatchNames : undefined));
	if (colorsSuccess) {
		for (j = 0 ; j < colorsLength ; ++j) {
			 (w.g1.pr.ddl.add("item", "\xa0"+colors[j].name)).image = colors[j].png; 
		}
	}
	w.g1.pr.ddl.selection = set.evenSwatchColor[0];

	// edit text
	w.g1.pr.et = w.g1.pr.add("edittext", undefined, String(set.evenSwatchTint));
	w.g1.pr.et.alignment = "center";
	w.g1.pr.et.characters = 3;
	w.g1.pr.et.onChange = function() {
		w.g1.pr.sl.value = Number(this.text);
	}

	// slider
	w.g1.pr.sl = w.g1.pr.add("slider", undefined, set.evenSwatchTint, 0, 100);
	w.g1.pr.sl.alignment = "fill";
	 w.g1.pr.sl.onChange = function() {
		w.g1.pr.et.text = Math.floor(this.value);
	}

	w.g1.pl.et.helpTip = w.g1.pl.sl.helpTip = w.g1.pr.et.helpTip = w.g1.pr.sl.helpTip = "Tint";

	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok"});
	
	w.bts.ok.onClick = function() {
		if (w.g1.pl.et.text == "" || isNaN(w.g1.pl.et.text)) {
			alert("Odd swatch tint field is empty or not a number.", scriptName, true);
			w.g1.pl.et.text = set.oddSwatchTint;
			return;
		}
	
		if (w.g1.pr.et.text == "" || isNaN(w.g1.pr.et.text)) {
			alert("Even swatch tint field is empty or not a number.", scriptName, true);
			w.g1.pr.et.text = set.evenSwatchTint;
			return;
		}	
	
		w.close(1);
	}
	
	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		with (set) {
			parStyle = [w.g.ddl.selection.index, w.g.ddl.selection.text];
			oddSwatchColor = [w.g1.pl.ddl.selection.index, w.g1.pl.ddl.selection.text.replace(/^\s/, "")];
			oddSwatchTint = parseInt(w.g1.pl.sl.value);
			evenSwatchColor = [w.g1.pr.ddl.selection.index, w.g1.pr.ddl.selection.text.replace(/^\s/, "")];
			evenSwatchTint = parseInt(w.g1.pr.sl.value);
			reset = w.cb.value;
		}
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}	
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {   parStyle: [0, "[Basic Paragraph]"],
					oddSwatchColor: [0, "[None]"],
					oddSwatchTint: 20,
					evenSwatchColor: [0, "[None]"],
					evenSwatchTint: 20,
					reset: true
				};
	}

	if (set.parStyle[0] >= allParStyleNames.length || allParStyleNames[set.parStyle[0]] != set.parStyle[1]) {
		set.parStyle[0] = 0;
	}

	if (set.oddSwatchColor[0] >= allSwatches.length || allSwatches[set.oddSwatchColor[0]].name != set.oddSwatchColor[1]) {
		set.oddSwatchColor[0] = 0;
	}

	if (set.evenSwatchColor[0] >= allSwatches.length || allSwatches[set.evenSwatchColor[0]].name != set.evenSwatchColor[1]) {
		set.evenSwatchColor[0] = 0;
	}

	return set; 
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	// check if text is selected and get the current story
	var msgWrongSelection = "One text frame or some text should be selected, or the cursor should be inserted into the text.";
	if (app.selection.length == 0 || app.selection.length > 1) ErrorExit(msgWrongSelection, true);
	var sel = app.selection[0];
	
	if (sel.constructor.name == "TextFrame" || sel.constructor.name == "InsertionPoint") { // a text frame is selected
		pars = sel.parentStory.paragraphs;
	}
	else if (sel.hasOwnProperty("baseline")) { // some text is selected or the cursor is placed in the text
		pars = sel.paragraphs;
	}
	else {
		ErrorExit(msgWrongSelection, true);
	}
	
	if (pars.length == 0) {
		ErrorExit("Selection contains no paragraphs.", true);
	}
	else if (pars.length >= 1 && pars.length <= 3) {
		if (!confirm("Selection contains only " + pars.length + " paragraphs. Do you really want to continue?", true, scriptName)) {
			exit();
		}
	}

	allParStyles = doc.allParagraphStyles;
	allParStyles.shift();
	
	for (var i = 0; i < allParStyles.length; i++) allParStyleNames.push(allParStyles[i].name);

	// Swatches
	colors = GetColors(); // get colors after pre-check to make run script faster
	colorsSuccess = (colors != null) ? true : false;
	if (!colorsSuccess) {
		if (debug) $.writeln("GetColors function returned null");
		colors = doc.swatches;
	}

	var swatch, colorName;
	
	for (var s = 0; s < colors.length; s++) {
		if (colorsSuccess) { // collection of swatches for drop downs in dialog box
			colorName = colors[s].name.replace(/\[/,"").replace(/\]/,"");
			swatch = doc.swatches.itemByName(colorName);
			
			if (swatch.isValid) {
				allSwatches.push(swatch);
				allSwatchNames.push(swatch.name);
			}
			else {
				if (debug) $.writeln(s + "- Oops!: " + colorName);
			}
		}
		else { // failed to get colors, proceed without them
			swatch = doc.swatches[s];
			allSwatches.push(swatch);
			allSwatchNames.push(swatch.name);			
		}
	} // end for

	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetColors() {
	try { // The following code was borrowed from 'See Your Swatches in ScriptUI' by Marc Autret
			var pngSwatch = (function()
		{  
			 // Table of CRCs of 8-bit messages  
			 var CRC_256 = [0, 0x77073096, 0xee0e612c, 0x990951ba, 0x76dc419, 0x706af48f, 0xe963a535, 0x9e6495a3, 0xedb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988, 0x9b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2, 0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7, 0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9, 0xfa0f3d63, 0x8d080df5, 0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172, 0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 0x35b5a8fa, 0x42b2986c, 0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59, 0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423, 0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924, 0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 0x76dc4190, 0x1db7106, 0x98d220bc, 0xefd5102a, 0x71b18589, 0x6b6b51f, 0x9fbfe4a5, 0xe8b8d433, 0x7807c9a2, 0xf00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x86d3d2d, 0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e, 0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950, 0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65, 0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7, 0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0, 0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa, 0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f, 0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81, 0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x3b6e20c, 0x74b1d29a, 0xead54739, 0x9dd277af, 0x4db2615, 0x73dc1683, 0xe3630b12, 0x94643b84, 0xd6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0xa00ae27, 0x7d079eb1, 0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb, 0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc, 0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e, 0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b, 0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55, 0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236, 0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28, 0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d, 0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x26d930a, 0x9c0906a9, 0xeb0e363f, 0x72076785, 0x5005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0xcb61b38, 0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0xbdbdf21, 0x86d3d2d4, 0xf1d4e242, 0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777, 0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69, 0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2, 0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc, 0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9, 0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693, 0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94, 0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d];  
			   
			 // PNG Cyclic Redundancy Code algorithm -- http://www.w3.org/TR/PNG/#D-CRCAppendix  
			 var crc32 = function(/*uint[]*/buf)  
				  {  
				  var c = 0xffffffff >>> 0,  
					   n = buf.length >>> 0,  
					   i;  
				  for( i=0 ; i < n ; ++i )  
					   c = CRC_256[( ( c>>>0 ) ^ buf[i]) & 0xff] ^ (c >>> 8);  
			   
				  return (c ^ 0xffffffff)>>>0;  
				  };  
		  
			 var PNG_PROLOG = "\x89PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\r\x00\x00\x00\r\b\x03\x00\x00\x00E5\x14N\x00\x00\x00\x06",  
				  PNG_EPILOG = "\x00\x00\x00\x16IDATx\xDAb`D\x06\f\x8C\f\b0\xC8x\xC8\x00 \xC0\x00\x11\xC6\x001{U\x93\xB6\x00\x00\x00\x00IEND\xAEB`\x82";  
		  
			 return function(/*uint[3]*/rgb)  
				  {  
				  var buf = [0x50,0x4C,0x54,0x45, rgb[0], rgb[1], rgb[2], 0, 0, 0],  
					   crc = crc32(buf),  
					   i, r;  
					
				  buf = buf.concat([ (crc>>>24)&0xFF, (crc>>>16)&0xFF, (crc>>>8)&0xFF, (crc>>>0)&0xFF ]);  
				  i = buf.length;  
				  while( i-- )  
					   buf[i] = String.fromCharCode(buf[i]);  
					
				  r = PNG_PROLOG + buf.join('') + PNG_EPILOG;  
					
				  buf.length = 0;  
				  buf = null;  
				  return r;  
				  };  
		})();  
		  
		var PNG_NONE = "\x89PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\r\x00\x00\x00\r\b\x03\x00\x00\x00E5\x14N\x00\x00\x00\fPLTE\xFF\xFF\xFF\x00\x00\x00\xFF\xBC\xBC\xFF\x00\x00 C\x89[\x00\x00\x002IDATx\xDAL\xC7\xC9\x01\x000\b\x020\xD4\xFDwn\xF1\xC2\xFC\x02\xBB`\x18\x1Eg\x1E\xAE\xFD`\xC7\xEC2\xB3J\xAFS\x9B\xE46\x9C\xC2)\xDC\xF5\x04\x18\x00+\xB9\x00z\xA7\xBDj\x1B\x00\x00\x00\x00IEND\xAEB`\x82";  
		  
		var localeColor = function(/*str*/name)  
		{  
			 return '['+app.translateKeyString('$ID/'+name)+']';  
		};  
		  
		// Parse the app|doc Swatches  
		//----------------------------------------------------------  
		var RGB = ColorSpace.RGB,  
			 SPOT = ColorModel.SPOT,  
			 REGISTRATION = ColorModel.REGISTRATION,  
			 MIXEDINK = ColorModel.MIXEDINKMODEL;  
		  
		var target = (app.documents.length&&app.activeDocument)||app,  
			 swatches = target.swatches.everyItem().getElements(),  
			 n = swatches.length,  
			 color, rgbValues,  
			 colors = [],
			 sp, md, nm,  
			 i, t, error;
			 
			 colors = [];  	 
		  
		for( i=n-1 ; i>=0 ; i-- )  
			 {
			 error = false;
			 color = swatches[i];
			// if (debug) $.writeln("===============\r" + i + " - color.name: " + color.name); //  + ", color.space: " + color.space
		  
			 if( !(color instanceof Color) ) continue;  
			   
			 color = color.getElements()[0];  
			 sp = color.space;  
			 md = color.model;  
			 nm = color.name;  
		  
			 if( MIXEDINK==md ) continue;     // TODO  
		  
			 switch( -(REGISTRATION==md||"Black" == nm) || + (RGB==sp) )  
				  {  
				  case -1:  
					   rgbValues = [0,0,0];  
					   nm = localeColor(nm);  
					   break;  
				  case 1:  
					   rgbValues = color.colorValue;  
					   break;  
				  default:  
					   // backup the color value  
					   t = color.colorValue;
					   
						try {
							// convert to rgb  
							color.space = RGB;
						}
						catch(err) {// skip this color: can't change in placed graphics
							// if (debug) $.writeln(err.message + ", line: " + err.line + ", color.name: " + color.name + ", color.space: " + color.space);
							error = true;
							break; // jump out of the switch statement.
						}
				   
					   rgbValues = color.colorValue;  
					   // revert to the color space  
					   color.space = sp;  
					   color.colorValue = t;  
				  } // end switch
			  
			 if (error) continue; // skip this color in for loop
			 if( nm=="Paper" ) nm = localeColor(nm);  
		  
			 colors.unshift({  
				  name: nm,  
				  png: pngSwatch(rgbValues),  
				  id: color.id  
				  });
			 } // end for
		  
		colors.unshift({  
			 name: localeColor("None"),  
			 png: PNG_NONE,  
			 id: target.swatches.itemByName('None').id  
			 });
	}
	catch(err) {
		colors = null;
	}
 
	return colors;
 }