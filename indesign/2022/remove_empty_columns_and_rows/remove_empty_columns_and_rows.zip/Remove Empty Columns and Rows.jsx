﻿function main() {


    // process all tables in active document
    removeEmptyTableRowsAndColumns(app.activeDocument);


    /**
     * Removes empty Rows and Columns from
     * all tables in a document, or a single
     * table.
     * @author m1b
     * @version 2022-09-27
     * @param {Document|Table} docOrTable - an Indesign Document or Table.
     */
    function removeEmptyTableRowsAndColumns(docOrTable) {

        if (docOrTable.constructor.name == 'Document') {

            // process all tables in the document

            var tables = docOrTable.stories.everyItem().tables.everyItem().getElements();

            for (var i = 0; i < tables.length; i++)
                removeEmptyTableRowsAndColumns(tables[i]);

            return;

        }

        if (docOrTable.constructor.name !== 'Table')
            return;

        var table = docOrTable;

        // remove empty rows
        for (var r = table.rows.length - 1; r >= 0; r--)
            if (table.rows[r].cells.everyItem().contents.join('').length == 0)
                table.rows[r].remove();

        // remove empty columns
        for (var c = table.columns.length - 1; c >= 0; c--)
            if (table.columns[c].cells.everyItem().contents.join('').length == 0)
                table.columns[c].remove();

    };


} // end main

app.doScript(main, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, 'Remove Empty Columns and Rows');