﻿var scriptName = "Fit column width",
maxColumnWidth = 300, // Maximum column width
debugMode = false, // for debugging only
doc;
//~ preCheck();
app.doScript(preCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
//===================================== FUNCTIONS ======================================
function snapColumn(column, textFrame) {
	try {
		var cell, insertionPoint, horizontalOffset,
		cells = column.cells;
		
		// Save & change units
		var savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits;
		var savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
		doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.POINTS;
		doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS;

		column.width = maxColumnWidth;
		// get horizontal offset of last insertion point in each cell
		if (debugMode) $.writeln("---------------------------");
		
		var myRightPosArray = [];
		
		try { 
			for (var i = 0; i < cells.length; i++) {
				cell = cells[i];
//~ 				if (debugMode) $.writeln(i + " | " + cell.contents);
				
				if (!textFrame.overflows) {
					insertionPoint = cell.insertionPoints[-1];
					horizontalOffset = insertionPoint.horizontalOffset;
//~ 					if (debugMode) $.writeln("horizontalOffset = " + horizontalOffset);
					myRightPosArray.push(horizontalOffset);
				}
				else {
					errorExit("The text frame containing the table became overset while running the script. Make it larger and try again.", true);
				}
			}
		}
		catch(err) {
			// Restore units
			doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
			doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
			if (debugMode) {
				$.writeln("ERROR: " + err.message + ", line: " + err.line);
			}
		}

		// find the biggest value
		var longest = maxArray(myRightPosArray);
		// get position of left side of column
		var leftPos = column.cells[0].insertionPoints[0].horizontalOffset;
		// set column width
		column.width = (longest - leftPos);
		
		checkCells(column);
		
		// Restore units
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
function checkCells(column) {
	var cell, count,
	cells = column.cells;

	for (var i = 0; i < cells.length; i++) {
		cell = cells[i];
		cell.recompose();
		if (debugMode) $.writeln(i + " | " + cell.contents);

		if (cell.overflows) {
			while (cell.overflows && column.width < maxColumnWidth) {
				column.width = column.width + 1;
				cell.recompose();
				if (debugMode) $.writeln("column.width =" + column.width);
			}
		}
	}
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
function maxArray(myArray) {
	var temp = 0
	for (var i in myArray) {
		temp = Math.max(temp, myArray[i]);
	}
	return temp;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function preCheck() {
	try {
		if (app.documents.length == 0) errorExit("Please open a document and try again.", true);
		doc = app.documents[0];
		if (doc.converted) errorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
		if (!doc.saved) errorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
		
		if (app.selection.length == 0) errorExit("Nothing is selected.", true);
		var sel = app.selection[0];
		
		if (sel.constructor.name == "Cell") {
			if (sel.columnSpan == 1) {
				var column = sel.parentColumn;
			}
			else {
				errorExit(sel.columnSpan + " columns are selected. Select only one column in the table or several cells in the same column.", true);
			}
		}
		else {
			errorExit("Wrong selection! Select a column in the table or several cells in the same column.", true);
		}

		var textFrame = column.parent.parent;
		if (textFrame.constructor.name != "TextFrame") errorExit("Can't get the text frame containing the table.", true);
		
		snapColumn(column, textFrame);
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function errorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}