﻿/* Copyright 2022, Kasyan Servetsky
December 14, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Remove not placed xml elements",
debug = false, // for debugging only
doc;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var xmlElement,
		count = 0,
		progressCount = 0,
		xmlElements = app.activeDocument.xmlElements[0].xmlElements.everyItem().getElements();
		
		var progressWin = new Window("window", scriptName);
		var progressBar = progressWin.add("progressbar" , undefined, 0, xmlElements.length);
		progressBar.preferredSize.width = 400;
		var progressTxt = progressWin.add("statictext", undefined,  "Removing not placed xml elements");
		progressTxt.alignment = "fill";
		progressWin.show();
		
		for (var i = xmlElements.length - 1; i >= 0; i--) {
			xmlElement = xmlElements[i];			
			progressCount++;
			progressBar.value = progressCount;				
			
			if (xmlElement.parentStory.constructor.name === "XmlStory") {
				xmlElement.remove();
				count++;
			}
		}
	
		progressWin.close();

		var report = count + " XML element" + ((count == 1) ? " was" : "s were") + " removed.";
		alert(report, scriptName);		
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------