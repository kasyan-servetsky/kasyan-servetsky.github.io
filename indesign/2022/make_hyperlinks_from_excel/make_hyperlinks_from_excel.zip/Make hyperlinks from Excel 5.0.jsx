﻿/* Copyright 2022, Kasyan Servetsky
August 7, 2022 
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Make hyperlinks from Excel - 5.0",
doc, set, story, firstTextFrame, progressWin, progressBar, progressTxt, excelFiles, excelFileNames,
paragraphTitleStyle, paragraphTextStyle, paragraphCourseTitleStyle,
allParStyles, allParStyleNames, countryCodesStr, abridgementsStr, businessUnits, swatchAbridgedText,
byMonthExcelFile, byLocationExcelFile, byBusinessUnitExcelFile,
labeledObjects, regExPattFullMonthes, regExPattAbridgedMonthes,
debug = false , // for debugging only
errorsArr = [],
allSwatches = [],
allSwatchNames = [],
abridgedCourseNames =[],
colors = GetColors(),
colorsSuccess = (colors != null) ? true : false,
count = 0;

//~ PreCheck();
app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, "\"" + scriptName + "\" script");
//===================================== FUNCTIONS ======================================
function CreateDialog() {
	var currentFunction = arguments.callee.toString().match(/function ([^\(]+)/)[1];
	var tabsNumList = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"],
	charsNumList = ["40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "71", "72", "73", "74", "75"];
	
	GetDialogSettings();
	var w = new Window("dialog", scriptName);
	
	// Tabs
	var tabbedPanel = w.add("tabbedpanel");
	tabbedPanel.alignment = "fill";
	tabbedPanel.onChange = function() {
		if (this.selection.text == "By Month") {
			if (leftCol.ddl.selection.index == 0) w.bts.ok.enabled = false;
			altPtrnPnl.enabled = true;
		}
		else if (this.selection.text == "By Location") {
			if (leftCol1.dll.selection.index == 0) w.bts.ok.enabled = false;
			altPtrnPnl.enabled = true;
		}
		else if (this.selection.text == "By Business Unit") {
			if (tab2.g.ddl.selection.index == 0) w.bts.ok.enabled = false;
			altPtrnPnl.enabled = false;
		}	
		else {
			w.bts.ok.enabled = true;
		}
	}

	var tab = tabbedPanel.add("tab", undefined, "By Month");
	tab.orientation = "column";
	tab.alignChildren = "left";
	
	var tab1 = tabbedPanel.add("tab", undefined, "By Location"); 
	tab1.orientation = "column";
	tab1.alignChildren = "left";
	
	var tab2 = tabbedPanel.add("tab", undefined, "By Business Unit");
	tab2.orientation = "column";
	tab2.alignChildren = "left";

	tabbedPanel.selection = set.tabSelIndex; // remember selected tab
	
	// 1st tab ===============================================================================
	var cont = tab.add("group"); // main container
	cont.orientation = "row";
	
	var leftCol = cont.add("group");
	leftCol.orientation = "column";
	leftCol.alignChildren = "left";
	
	var rightCol = cont.add("group");
	rightCol.orientation = "column";
	rightCol.alignment = "bottom";
	rightCol.alignChildren = "left";

	leftCol.ddl = leftCol.add("dropdownlist", undefined, excelFileNames);
	leftCol.ddl.selection = set.byMonthExcelDdl[0];
	leftCol.ddl.onChange = DisEnableOk;

	leftCol.g = leftCol.add("group"); // sub-container
	leftCol.g.orientation = "row";
	
	leftCol.g.g = leftCol.g.add("group"); // left column
	leftCol.g.g.orientation = "column";
	leftCol.g.g.alignChildren = "left";
	leftCol.g.g.st = leftCol.g.g.add("statictext", undefined, "Choose Paragraph Title");
	leftCol.g.g.ddl = leftCol.g.g.add("dropdownlist", undefined, allParStyleNames);
	leftCol.g.g.ddl.selection = set.byMonthParTitleDdl[0];
	leftCol.g.g.ddl.alignment = "fill";	
	
	leftCol.g.g1 = leftCol.g.add("group"); // right column
	leftCol.g.g1.orientation = "column";
	leftCol.g.g1.alignChildren = "left";
	leftCol.g.g1.st = leftCol.g.g1.add("statictext", undefined, "Choose Paragraph Text");
	leftCol.g.g1.ddl = leftCol.g.g1.add("dropdownlist", undefined, allParStyleNames);
	leftCol.g.g1.ddl.selection = set.byMonthParTextDdl[0];
	leftCol.g.g1.ddl.alignment = "fill";
	
	leftCol.g1 = leftCol.add("group");
	leftCol.g1.orientation = "row";
	leftCol.g1.st = leftCol.g1.add("statictext", undefined, "Course Description is after tab");
	leftCol.g1.ddl = leftCol.g1.add("dropdownlist", undefined, tabsNumList);
	leftCol.g1.ddl.selection = set.byMonthCourseDescriptionPosDdl;
	
	leftCol.g2 = leftCol.add("group");
	leftCol.g2.orientation = "row";
	leftCol.g2.cb = leftCol.g2.add("checkbox", undefined, "Replace Country Code");
	leftCol.g2.cb.value = set.byMonthReplaceCountryCodeCb;
	
	leftCol.g3 = leftCol.add("group");
	leftCol.g3.orientation = "row";
	leftCol.g3.cb = leftCol.g3.add("checkbox", undefined, "Cut Course Description");
	leftCol.g3.cb.value = set.byMonthCutCourseDescriptionCb;

	leftCol.g4 = leftCol.add("group");
	leftCol.g4.orientation = "row";
	// Month ===============================================================
	leftCol.g4.cb = leftCol.g4.add("checkbox", undefined, "Add Hyperlinks");
	leftCol.g4.cb.value = set.byMonthAddHyperlinksCb;
	leftCol.g4.cb.onClick = function() {
		if (this.value) {
			leftCol.g4.cb1.enabled = true;
		}
		else {
			leftCol.g4.cb1.enabled = false;
		}
	}

	leftCol.g4.cb1 = leftCol.g4.add("checkbox", undefined, "Add location & date to hyperlink path");
	leftCol.g4.cb1.value = set.byMonthAdvHyperlinkPathCb;
	if (leftCol.g4.cb.value) {
		leftCol.g4.cb1.enabled = true;
	}
	else {
		leftCol.g4.cb1.enabled = false;
	}

	var rdBtnsGr = rightCol.add("group");
	rdBtnsGr.orientation = "column";
	rdBtnsGr.alignChildren = "left";
	rdBtnsGr.rb = rdBtnsGr.add("radiobutton", undefined, "No page");
	rdBtnsGr.rb1 = rdBtnsGr.add("radiobutton", undefined, "Add page number only");
	rdBtnsGr.rb2 = rdBtnsGr.add("radiobutton", undefined, "Add page number & hyperlink");
	
	if (set.byMonthPageRb == 0) {
		rdBtnsGr.rb.value = true;
	}
	else if (set.byMonthPageRb == 1) {
		rdBtnsGr.rb1.value = true;
	}	
	else if (set.byMonthPageRb == 2) {
		rdBtnsGr.rb2.value = true;
	}

	// 2nd tab ===============================================================================
	var cont1 = tab1.add("group"); // main container
	cont1.orientation = "row";
	
	var leftCol1 = cont1.add("group");
	leftCol1.orientation = "column";
	leftCol1.alignChildren = "left";
	
	var rightCol1 = cont1.add("group");
	rightCol1.orientation = "column";
	rightCol1.alignment = "bottom";
	rightCol1.alignChildren = "left";

	leftCol1.dll = leftCol1.add("dropdownlist", undefined, excelFileNames);
	leftCol1.dll.selection = set.byLocationExcelDdl[0];
	leftCol1.dll.onChange = DisEnableOk;

	leftCol1.g = leftCol1.add("group"); // sub-container
	leftCol1.g.orientation = "row";
	
	leftCol1.g.g = leftCol1.g.add("group"); // left column
	leftCol1.g.g.orientation = "column";
	leftCol1.g.g.alignChildren = "left";
	leftCol1.g.g.st = leftCol1.g.g.add("statictext", undefined, "Choose Paragraph Title");
	leftCol1.g.g.ddl = leftCol1.g.g.add("dropdownlist", undefined, allParStyleNames);
	leftCol1.g.g.ddl.selection = set.byLocationParTitleDdl[0];
	leftCol1.g.g.ddl.alignment = "fill";	
	
	leftCol1.g.g1 = leftCol1.g.add("group"); // right column
	leftCol1.g.g1.orientation = "column";
	leftCol1.g.g1.alignChildren = "left";
	leftCol1.g.g1.st = leftCol1.g.g1.add("statictext", undefined, "Choose Paragraph Text");
	leftCol1.g.g1.ddl = leftCol1.g.g1.add("dropdownlist", undefined, allParStyleNames);
	leftCol1.g.g1.ddl.selection = set.byLocationParTextDdl[0];
	leftCol1.g.g1.ddl.alignment = "fill"; // just added
	
	leftCol1.g1 = leftCol1.add("group");
	leftCol1.g1.orientation = "row";
	leftCol1.g1.st = leftCol1.g1.add("statictext", undefined, "Course Description is after tab");
	leftCol1.g1.ddl = leftCol1.g1.add("dropdownlist", undefined, tabsNumList);
	leftCol1.g1.ddl.selection = set.byLocationCourseDescriptionPosDdl;
	leftCol1.g1.ddl.alignment = "fill";
	
	leftCol1.g2 = leftCol1.add("group");
	leftCol1.g2.orientation = "row";
	leftCol1.g2.cb = leftCol1.g2.add("checkbox", undefined, "Cut Course Description");
	leftCol1.g2.cb.value = set.byLocationCutCourseDescriptionCb;

	leftCol1.g3 = leftCol1.add("group");
	leftCol1.g3.orientation = "row";
	leftCol1.g3.cb = leftCol1.g3.add("checkbox", undefined, "Add Hyperlinks");
	leftCol1.g3.cb.value = set.byLocationAddHyperlinksCb;
	leftCol1.g3.cb.onClick = function() {
		if (this.value) {
			leftCol1.g3.cb1.enabled = true;
		}
		else {
			leftCol1.g3.cb1.enabled = false;
		}
	}

	leftCol1.g3.cb1 = leftCol1.g3.add("checkbox", undefined, "Add location & date to hyperlink path");
	leftCol1.g3.cb1.value = set.byLocationAdvHyperlinkPathCb;
	if (leftCol1.g3.cb.value) {
		leftCol1.g3.cb1.enabled = true;
	}
	else {
		leftCol1.g3.cb1.enabled = false;
	}
	
	var rdBtnsGr1 = rightCol1.add("group");
	rdBtnsGr1.orientation = "column";
	rdBtnsGr1.alignChildren = "left";

	rdBtnsGr1.rb = rdBtnsGr1.add("radiobutton", undefined, "No page");
	rdBtnsGr1.rb1 = rdBtnsGr1.add("radiobutton", undefined, "Add page number only");
	rdBtnsGr1.rb2 = rdBtnsGr1.add("radiobutton", undefined, "Add page number & hyperlink");
	
	if (set.byLocationPageRb == 0) {
		rdBtnsGr1.rb.value = true;
	}
	else if (set.byLocationPageRb == 1) {
		rdBtnsGr1.rb1.value = true;
	}	
	else if (set.byLocationPageRb == 2) {
		rdBtnsGr1.rb2.value = true;
	}

	// 3rd tab ===============================================================================
	tab2.g = tab2.add("group");  // main container
	tab2.g.orientation = "column";
	tab2.g.alignChildren = "left";

	tab2.g.ddl = tab2.g.add("dropdownlist", undefined, excelFileNames);
	tab2.g.ddl.selection = set.byBusinessUnitExcelDdl[0];
	tab2.g.ddl.onChange = DisEnableOk;
	
	tab2.g.g = tab2.g.add("group"); // sub-container
	tab2.g.g.orientation = "row";
	tab2.g.g.alignChildren = "top";
	
	tab2.g.g.p = tab2.g.g.add("panel", undefined, "Choose Business Unit Title"); // left column
	tab2.g.g.p.orientation = "column";
	tab2.g.g.p.alignChildren = "left";	
	tab2.g.g.p.ddl = tab2.g.g.p.add("dropdownlist", undefined,allParStyleNames);
	tab2.g.g.p.ddl.selection = set.byBusinessUnitTitleDdl;
	tab2.g.g.p.ddl.alignment = "fill";
	tab2.g.g.p.et = tab2.g.g.p.add("edittext", undefined, set.byBusinessUnitTitleTint);
	tab2.g.g.p.et.alignment = "center";
	tab2.g.g.p.et.characters = 3;
	tab2.g.g.p.et.onChange = function() {
		tab2.g.g.p.sl.value = Number(this.text);
	}

	tab2.g.g.p.sl = tab2.g.g.p.add("slider", undefined, set.byBusinessUnitTitleTint, 0, 100);
	tab2.g.g.p.sl.alignment = "fill";
	tab2.g.g.p.sl.onChange = function() {
		tab2.g.g.p.et.text = Math.floor(this.value);
	}
	
	if (!set.byBusinessUnitTitleUseBUcolorsCb) tab2.g.g.p.et.enabled = tab2.g.g.p.sl.enabled = false;
	
	tab2.g.g.p.cb = tab2.g.g.p.add("checkbox", undefined, "Use Business Unit Colors");
	tab2.g.g.p.cb.value = set.byBusinessUnitTitleUseBUcolorsCb;
	tab2.g.g.p.cb.onClick = function() {
		if (this.value) {
			tab2.g.g.p.et.enabled = tab2.g.g.p.sl.enabled = true;
		}
		else {
			tab2.g.g.p.et.enabled = tab2.g.g.p.sl.enabled = false;
		}		
	}

	tab2.g.g.p1 = tab2.g.g.add("panel", undefined, "Choose Course Title"); // middle column
	tab2.g.g.p1.orientation = "column";
	tab2.g.g.p1.alignChildren = "left";
	tab2.g.g.p1.ddl = tab2.g.g.p1.add("dropdownlist", undefined, allParStyleNames);
	tab2.g.g.p1.ddl.selection = set.byBusinessUnitCourseTitleDdl;
	tab2.g.g.p1.ddl.alignment = "fill";
	tab2.g.g.p1.et = tab2.g.g.p1.add("edittext", undefined, set.byBusinessUnitCourseTitleTint);
	tab2.g.g.p1.et.alignment = "center";
	tab2.g.g.p1.et.characters = 3;
	tab2.g.g.p1.et.onChange = function() {
		tab2.g.g.p1.sl.value = Number(this.text);
	}

	tab2.g.g.p1.sl = tab2.g.g.p1.add("slider", undefined, set.byBusinessUnitCourseTitleTint, 0, 100);
	tab2.g.g.p1.sl.alignment = "fill";
	tab2.g.g.p1.sl.onChange = function() {
		tab2.g.g.p1.et.text = Math.floor(this.value);
	}

	if (!set.byBusinessUnitCourseTitleUseBUcolorsCb) tab2.g.g.p1.et.enabled = tab2.g.g.p1.sl.enabled = false;
	
	tab2.g.g.p1.cb = tab2.g.g.p1.add("checkbox", undefined, "Use Business Unit Colors");
	tab2.g.g.p1.cb.value = set.byBusinessUnitCourseTitleUseBUcolorsCb;
	tab2.g.g.p1.cb.onClick = function() {
		if (this.value) {
			tab2.g.g.p1.et.enabled = tab2.g.g.p1.sl.enabled = true;
		}
		else {
			tab2.g.g.p1.et.enabled = tab2.g.g.p1.sl.enabled = false;
		}		
	}

	tab2.g.g.p2 = tab2.g.g.add("panel", undefined, "Choose Paragraph Text"); // right column
	tab2.g.g.p2.orientation = "column";
	tab2.g.g.p2.alignChildren = "left";	
	tab2.g.g.p2.ddl = tab2.g.g.p2.add("dropdownlist", undefined, allParStyleNames);
	tab2.g.g.p2.ddl.selection = set.byBusinessUnitParTextDdl;
	tab2.g.g.p2.ddl.alignment = "fill";
	tab2.g.g.p2.et = tab2.g.g.p2.add("edittext", undefined, set.byBusinessUnitTextTint);
	tab2.g.g.p2.et.alignment = "center";
	tab2.g.g.p2.et.characters = 3;
	tab2.g.g.p2.et.onChange = function() {
		tab2.g.g.p2.sl.value = Number(this.text);
	}

	tab2.g.g.p2.sl = tab2.g.g.p2.add("slider", undefined, set.byBusinessUnitTextTint, 0, 100);
	tab2.g.g.p2.sl.alignment = "fill";
	tab2.g.g.p2.sl.onChange = function() {
		tab2.g.g.p2.et.text = Math.floor(this.value);
	}

	if (!set.byBusinessUnitTextUseBUcolorsCb) tab2.g.g.p2.et.enabled = tab2.g.g.p2.sl.enabled = false;
	
	tab2.g.g.p2.cb = tab2.g.g.p2.add("checkbox", undefined, "Use Business Unit Colors");
	tab2.g.g.p2.cb.value = set.byBusinessUnitTextUseBUcolorsCb;
	tab2.g.g.p2.cb.onClick = function() {
		if (this.value) {
			tab2.g.g.p2.et.enabled = tab2.g.g.p2.sl.enabled = true;
		}
		else {
			tab2.g.g.p2.et.enabled = tab2.g.g.p2.sl.enabled = false;
		}		
	}
	
	tab2.g.g1 = tab2.g.add("group");
	tab2.g.g1.orientation = "row";
	
	tab2.g.g1.cb = tab2.g.g1.add("checkbox", undefined, "Add Hyperlinks");
	tab2.g.g1.cb.value = set.byBusinessUnitAddHyperlinksCb;
	tab2.g.g1.cb.onClick = function() {
		if (this.value) {
			tab2.g.g1.cb1.enabled = true;
		}
		else {
			tab2.g.g1.cb1.enabled = false;
		}
	}

	tab2.g.g1.cb1 = tab2.g.g1.add("checkbox", undefined, "Add location & date to hyperlink path");
	tab2.g.g1.cb1.value = set.byBusinessUnitAdvHyperlinkPathCb;
	if (tab2.g.g1.cb.value) {
		tab2.g.g1.cb1.enabled = true;
	}
	else {
		tab2.g.g1.cb1.enabled = false;
	}

	//  End of the 3rd tab ======================================================================
	// START Apply alternating pattern ==============================================
	var altPtrnPnl = w.add("panel", undefined, "Apply alternating pattern");
	altPtrnPnl.alignment = "fill";
	altPtrnPnl.orientation = "column";
	altPtrnPnl.alignChildren = "left";

	if (tabbedPanel.selection.text == "By Month") {
		altPtrnPnl.enabled = true;
	}
	else if (tabbedPanel.selection.text == "By Location") {
		altPtrnPnl.enabled = true;
	}
	else if (tabbedPanel.selection.text == "By Business Unit") {
		altPtrnPnl.enabled = false;
	}	
	
	var altPtrnGr = altPtrnPnl.add("group");
	altPtrnGr.orientation = "row";

	// ODD
	var oddPnl = altPtrnGr.add("panel", undefined, "Odd");
	oddPnl.orientation = "column";
	oddPnl.alignment = "fill";

	oddPnl.ddl = oddPnl.add("dropdownlist", undefined, ((!colorsSuccess) ? allSwatchNames : undefined));
	if (colors != null) {
		var n = colors.length;
		for (i = 0 ; i < n ; ++i) {
			 (oddPnl.ddl.add("item", "\xa0"+colors[i].name)).image = colors[i].png; 
		}
	}
	oddPnl.ddl.selection = set.oddSwatchColor[0];
	
	// edit text
	oddPnl.et = oddPnl.add("edittext", undefined, String(set.oddSwatchTint));
	oddPnl.et.alignment = "center";
	oddPnl.et.characters = 3;
	oddPnl.et.onChange = function() {
		oddPnl.sl.value = Number(this.text);
	}
	
	// slider
	oddPnl.sl = oddPnl.add("slider", undefined, set.oddSwatchTint, 0, 100);
	oddPnl.sl.alignment = "fill";
	oddPnl.sl.onChange = function() {
		oddPnl.et.text = Math.floor(this.value);
	}

	// EVEN
	var evenPnl = altPtrnGr.add("panel", undefined, "Even");
	evenPnl.orientation = "column";
	evenPnl.alignment = "fill";

	evenPnl.ddl = evenPnl.add("dropdownlist", undefined, ((!colorsSuccess) ? allSwatchNames : undefined));
	if (colors != null) {
		var k = colors.length;
		for (j = 0 ; j < k ; ++j) {
			 (evenPnl.ddl.add("item", "\xa0"+colors[j].name)).image = colors[j].png; 
		}
	}
	evenPnl.ddl.selection = set.evenSwatchColor[0];

	// edit text
	evenPnl.et = evenPnl.add("edittext", undefined, String(set.evenSwatchTint));
	evenPnl.et.alignment = "center";
	evenPnl.et.characters = 3;
	evenPnl.et.onChange = function() {
		evenPnl.sl.value = Number(this.text);
	}

	// slider
	evenPnl.sl = evenPnl.add("slider", undefined, set.evenSwatchTint, 0, 100);
	evenPnl.sl.alignment = "fill";
	 evenPnl.sl.onChange = function() {
		evenPnl.et.text = Math.floor(this.value);
	}

	oddPnl.et.helpTip = oddPnl.sl.helpTip = evenPnl.et.helpTip = evenPnl.sl.helpTip = "Tint";

	var altPtrnCbGr = altPtrnPnl.add("group");
	altPtrnCbGr.orientation = "row";
	
	var applyAltPtrnCb = altPtrnCbGr.add("checkbox", undefined, "Apply pattern");
	applyAltPtrnCb.value = set.applyAltPtrn;
	applyAltPtrnCb.onClick = function() {
		if (this.value) {
			altPtrnGr.enabled = true;
			resetCb.enabled = true;
		}
		else {
			altPtrnGr.enabled = false;
			resetCb.enabled = false;
		}
	}

	var resetCb = altPtrnCbGr.add("checkbox", undefined, "Reset to odd after another style");
	resetCb.value = set.reset;
	
	if (set.applyAltPtrn) {
		altPtrnGr.enabled = true;
		resetCb.enabled = true;
	}
	else {
		altPtrnGr.enabled = false;
		resetCb.enabled = false;
	}

	// END Apply alternating pattern ==============================================
	
	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok"});
	// disable OK until an Excel file is chosen
	if ((set.tabSelIndex == 0 && set.byMonthExcelDdl[0] == 0) || (set.tabSelIndex == 1 && set.byLocationExcelDdl[0] == 0) || (set.tabSelIndex == 2 && set.byBusinessUnitExcelDdl[0] == 0)) {
		w.bts.ok.enabled = false;
	}

	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	
	var showDialog = w.show();
	
	if (showDialog == 1) {
		with (set) {
			// Tab selected
			if (tabbedPanel.selection == tab) {
				tabSelIndex = 0;
			}
			else if (tabbedPanel.selection == tab1) {
				tabSelIndex = 1;
			}
			else if (tabbedPanel.selection == tab2) {
				tabSelIndex = 2;
			}

			// By Month
			byMonthExcelDdl = [leftCol.ddl.selection.index, leftCol.ddl.selection.text];
			byMonthParTitleDdl = [leftCol.g.g.ddl.selection.index, leftCol.g.g.ddl.selection.text];
			byMonthParTextDdl = [leftCol.g.g1.ddl.selection.index, leftCol.g.g1.ddl.selection.text];
			byMonthCourseDescriptionPosDdl = leftCol.g1.ddl.selection.index;
			byMonthReplaceCountryCodeCb = leftCol.g2.cb.value;
			byMonthCutCourseDescriptionCb = leftCol.g3.cb.value;
			byMonthAddHyperlinksCb = leftCol.g4.cb.value;
			byMonthAdvHyperlinkPathCb = leftCol.g4.cb1.value; // new

			if (rdBtnsGr.rb.value) {
				set.byMonthPageRb = 0;
			}
			else if (rdBtnsGr.rb1.value) {
				set.byMonthPageRb = 1;
			}
			else if (rdBtnsGr.rb2.value) {
				set.byMonthPageRb = 2;
			}

			// By Location
			byLocationExcelDdl = [leftCol1.dll.selection.index, leftCol1.dll.selection.text];
			byLocationParTitleDdl = [leftCol1.g.g.ddl.selection.index, leftCol1.g.g.ddl.selection.text];
			byLocationParTextDdl = [leftCol1.g.g1.ddl.selection.index, leftCol1.g.g1.ddl.selection.text];
			byLocationCourseDescriptionPosDdl = leftCol1.g1.ddl.selection.index; 
			byLocationCutCourseDescriptionCb = leftCol1.g2.cb.value;
			byLocationAddHyperlinksCb = leftCol1.g3.cb.value;
			byLocationAdvHyperlinkPathCb = leftCol1.g3.cb1.value; // new
			
			if (rdBtnsGr1.rb.value) {
				set.byLocationPageRb = 0;
			}
			else if (rdBtnsGr1.rb1.value) {
				set.byLocationPageRb = 1;
			}
			else if (rdBtnsGr1.rb2.value) {
				set.byLocationPageRb = 2;
			}

			// By Business Unit
			byBusinessUnitExcelDdl = [tab2.g.ddl.selection.index, tab2.g.ddl.selection.text];
			byBusinessUnitTitleDdl = [tab2.g.g.p.ddl.selection.index, tab2.g.g.p.ddl.selection.text];
			byBusinessUnitCourseTitleDdl = [tab2.g.g.p1.ddl.selection.index, tab2.g.g.p1.ddl.selection.text];
			byBusinessUnitParTextDdl = [tab2.g.g.p2.ddl.selection.index, tab2.g.g.p2.ddl.selection.text];
			byBusinessUnitTitleTint = tab2.g.g.p.sl.value;			
			byBusinessUnitCourseTitleTint = tab2.g.g.p1.sl.value;			
			byBusinessUnitTextTint = tab2.g.g.p2.sl.value;
			byBusinessUnitTitleUseBUcolorsCb = tab2.g.g.p.cb.value;
			byBusinessUnitCourseTitleUseBUcolorsCb = tab2.g.g.p1.cb.value;
			byBusinessUnitTextUseBUcolorsCb = tab2.g.g.p2.cb.value;
			byBusinessUnitAddHyperlinksCb = tab2.g.g1.cb.value;
			byBusinessUnitAdvHyperlinkPathCb = tab2.g.g1.cb1.value; // new
			
			// Apply alternating pattern
			oddSwatchColor = [oddPnl.ddl.selection.index, oddPnl.ddl.selection.text.replace(/^\s/, "")];
			oddSwatchTint = parseInt(oddPnl.sl.value);
			evenSwatchColor = [evenPnl.ddl.selection.index, evenPnl.ddl.selection.text.replace(/^\s/, "")];
			evenSwatchTint = parseInt(evenPnl.sl.value);
			applyAltPtrn = applyAltPtrnCb.value;
			reset = resetCb.value;
		}
	
		var tmp = set;
		app.insertLabel("Kas_" + scriptName, set.toSource());
		
		byMonthExcelFile = excelFiles[leftCol.ddl.selection - 1];
		byLocationExcelFile = excelFiles[leftCol1.dll.selection - 1];
		byBusinessUnitExcelFile = excelFiles[tab2.g.ddl.selection - 1];
	
//~ 		Main();
	}
	//--------------------------------------------------------------------------------------------
	function DisEnableOk() { // disable OK until an Excel file is chosen
		if (this.selection.index == 0) {
			w.bts.ok.enabled = false;
		}
		else {
			w.bts.ok.enabled = true;
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	var currentFunction = arguments.callee.toString().match(/function ([^\(]+)/)[1];
	set = eval(app.extractLabel("Kas_" + scriptName));

	if (set == undefined) {
		set = {   tabSelIndex: 0, // last selected tab
					byMonthExcelDdl: [0, "Choose an Excel file"], // Month
					byMonthParTitleDdl: [0, "[Basic Paragraph]"],
					byMonthParTextDdl: [0, "[Basic Paragraph]"],
					byMonthCourseDescriptionPosDdl: 1,
					byMonthReplaceCountryCodeCb: true,
					byMonthCutCourseDescriptionCb: true,
					byMonthAddHyperlinksCb: true,
					byMonthAdvHyperlinkPathCb: true, // new
					byMonthPageRb: 0,
					byLocationExcelDdl: [0, "Choose an Excel file"], // By Location
					byLocationParTitleDdl: [0, "[Basic Paragraph]"],
					byLocationParTextDdl: [0, "[Basic Paragraph]"],
					byLocationCourseDescriptionPosDdl: 0,
					byLocationCutCourseDescriptionCb: true,
					byLocationAddHyperlinksCb: true,
					byLocationAdvHyperlinkPathCb: true, // new
					byLocationPageRb: 0,
					byBusinessUnitExcelDdl: [0, "Choose an Excel file"], // By Business Unit
					byBusinessUnitTitleDdl: [0, "[Basic Paragraph]"],
					byBusinessUnitCourseTitleDdl: [0, "[Basic Paragraph]"],
					byBusinessUnitParTextDdl: [0, "[Basic Paragraph]"],
					byBusinessUnitTitleTint: 100,
					byBusinessUnitCourseTitleTint: 50,
					byBusinessUnitTextTint: 25,
					byBusinessUnitTitleUseBUcolorsCb: true,
					byBusinessUnitCourseTitleUseBUcolorsCb: true,
					byBusinessUnitTextUseBUcolorsCb: true,
					byBusinessUnitAddHyperlinksCb: true,
					byBusinessUnitAdvHyperlinkPathCb: true, // new
					oddSwatchColor: [0, "[None]"], // Apply alternating pattern
					oddSwatchTint: 20,
					evenSwatchColor: [0, "[None]"],
					evenSwatchTint: 20,
					applyAltPtrn: false,
					reset: true
				};
	}

	// Month
	if (excelFileNames[set.byMonthExcelDdl[0]] != set.byMonthExcelDdl[1]) {
		set.byMonthExcelDdl[0] = 0;
	}

	if (allParStyleNames[set.byMonthParTitleDdl[0]] != set.byMonthParTitleDdl[1]) {
		set.byMonthParTitleDdl[0] = 0;
	}

	if (allParStyleNames[set.byMonthParTextDdl[0]] != set.byMonthParTextDdl[1]) {
		set.byMonthParTextDdl[0] = 0;
	}

	// By Location
	if (excelFileNames[set.byLocationExcelDdl[0]] != set.byLocationExcelDdl[1]) {
		set.byLocationExcelDdl[0] = 0;
	}

	if (allParStyleNames[set.byLocationParTitleDdl[0]] != set.byLocationParTitleDdl[1]) {
		set.byLocationParTitleDdl[0] = 0;
	}

	if (allParStyleNames[set.byLocationParTextDdl[0]] != set.byLocationParTextDdl[1]) {
		set.byLocationParTextDdl[0] = 0;
	}

	// Business Unit
	if (excelFileNames[set.byBusinessUnitExcelDdl[0]] != set.byBusinessUnitExcelDdl[1]) {
		set.byBusinessUnitExcelDdl[0] = 0;
	}

	if (allParStyleNames[set.byBusinessUnitTitleDdl[0]] != set.byBusinessUnitTitleDdl[1]) {
		set.byBusinessUnitTitleDdl[0] = 0;
	}

	if (allParStyleNames[set.byBusinessUnitCourseTitleDdl[0]] != set.byBusinessUnitCourseTitleDdl[1]) {
		set.byBusinessUnitCourseTitleDdl[0] = 0;
	}

	if (allParStyleNames[set.byBusinessUnitParTextDdl[0]] != set.byBusinessUnitParTextDdl[1]) {
		set.byBusinessUnitParTextDdl[0] = 0;
	}

	//if (debug) ListSwatches(allSwatchNames);
	
	// Apply alternating pattern ==============================================
	if (set.oddSwatchColor[0] >= allSwatches.length || allSwatches[set.oddSwatchColor[0]].name != set.oddSwatchColor[1]) {
		set.oddSwatchColor[0] = 0;
	}

	if (set.evenSwatchColor[0] >= allSwatches.length || allSwatches[set.evenSwatchColor[0]].name != set.evenSwatchColor[1]) {
		set.evenSwatchColor[0] = 0;
	}
	//==================================================================

	var tmp = set;

	return set;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetLabeledItems(arr) {
	var item,
	labeledArr = [];
	
	for (var i = 0; i < arr.length; i++) {
		item = arr[i];
		
		if (item.hasOwnProperty("label") && item.label != "") {
			labeledArr.push(item);
		}
	}

	return labeledArr;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	try {
		var startTime = new Date();
		labeledTextFrames = GetLabeledItems(doc.textFrames.everyItem().getElements()),
		labeledGroups = GetLabeledItems(doc.groups.everyItem().getElements()),	
		savedHorizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits,
		savedVerticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits,
		savedRulerOrigin = doc.viewPreferences.rulerOrigin;

		labeledObjects = labeledTextFrames.concat(labeledGroups);

		// Make sure to use millimiters
		doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.MILLIMETERS;
		doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.MILLIMETERS;
		// Make sure ruler units origin is set to spread
		doc.viewPreferences.rulerOrigin = RulerOrigin.SPREAD_ORIGIN;

		progressWin = new Window("window", scriptName);
		progressBar = progressWin.add("progressbar" , undefined, 0, undefined);
		progressBar.preferredSize.width = 600;
		progressTxt = progressWin.add("statictext", undefined,  "");
		progressTxt.alignment = "fill";
		progressWin.show();

		if (set.tabSelIndex == 0) { // By Month
			progressTxt.text = "Processing Calendar / Catalog by Month";
			paragraphTitleStyle = allParStyles[set.byMonthParTitleDdl[0]];
			paragraphTextStyle = allParStyles[set.byMonthParTextDdl[0]];
			
			PlaceExcel(byMonthExcelFile);

			if (set.byMonthReplaceCountryCodeCb) {
				AbridgeCountries(countryCodesStr);
			}
	
			ProcessParagraphs();
		}
		else if (set.tabSelIndex == 1) { // By Location
			progressTxt.text = "Processing Calendar / Catalog by Location";
			paragraphTitleStyle = allParStyles[set.byLocationParTitleDdl[0]];			
			paragraphTextStyle = allParStyles[set.byLocationParTextDdl[0]];
			
			PlaceExcel(byLocationExcelFile);
			ProcessParagraphs(paragraphTitleStyle, paragraphTextStyle);
		}
		else if (set.tabSelIndex == 2) { // By Business Unit
			progressTxt.text = "Processing Catalog by Business Unit";
			paragraphTitleStyle = allParStyles[set.byBusinessUnitTitleDdl[0]];
			paragraphTextStyle = allParStyles[set.byBusinessUnitParTextDdl[0]];			
			paragraphCourseTitleStyle = allParStyles[set.byBusinessUnitCourseTitleDdl[0]];

			PlaceExcel(byBusinessUnitExcelFile);
			ProcessParagraphsBU();			
		}
	
		progressWin.close();
		
		// Restore units & ruler origin
		doc.viewPreferences.horizontalMeasurementUnits = savedHorizontalMeasurementUnits;
		doc.viewPreferences.verticalMeasurementUnits = savedVerticalMeasurementUnits;
		doc.viewPreferences.rulerOrigin = savedRulerOrigin;
		
		var endTime = new Date();
		var duration = GetDuration(startTime, endTime);
		var report = count + " hyperlink" + ((count == 1) ? " was" : "s were") + " created.\n(time elapsed: " + duration + ")";
		
		if (errorsArr.length > 0) {
			var errorsTxt = "\n\n" + errorsArr.length + " error" + ((errorsArr.length == 1) ? "" : "s") + " occured. See the log for details.";
			report += errorsTxt;
		}
		
		alert(report, scriptName);
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line);
		ErrorLog(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddPages(textFrame) {
	var newPage, gb, newTextFrame, currentTextFrame,
	currentPage = textFrame.parentPage;
	// if (debug) {
	// $.writeln("====================");
	// $.writeln("Entering function 'AddPages' from function '" + CallerName() + "'");
	// }

	while (story.overflows) {
		if (debug) $.writeln("currentPage.name = " + currentPage.name);
		newPage = doc.pages.add(LocationOptions.AFTER, currentPage);
		currentPage = newPage;
		gb = GetBounds(currentPage);
	
		if (doc.name.match(/calendar/i) != null) {
			gb = [gb[0], gb[1] - 2, gb[2], gb[3] + 2];
		}
		
		newTextFrame = currentPage.textFrames.add({geometricBounds: gb});
		textFrame.nextTextFrame = newTextFrame;
		textFrame = newTextFrame;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetBounds(page) {
	var X1, X2, Y1, Y2,
	pageWidth = doc.documentPreferences.pageWidth,
	pageHeight = doc.documentPreferences.pageHeight;
	
	if (page.side == PageSideOptions.LEFT_HAND) {
		X1 = page.marginPreferences.right;
		X2 = pageWidth - page.marginPreferences.left;
	}
	else if (page.side == PageSideOptions.RIGHT_HAND) {
		X1 = page.marginPreferences.left + pageWidth;
		X2 = pageWidth * 2 - page.marginPreferences.right;
	}

	Y1 = page.marginPreferences.top;
	Y2 = pageHeight - page.marginPreferences.bottom;
	
	return [Y1, X1, Y2, X2];
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CallerName() { // for debugging only
    var arr = $.stack.split(/[\n]/),  
    CallerName = arr[arr.length - 3].replace(/\(.*\)/, "")  
    return CallerName;  
} 
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IsInAbridgedCourseNamesList(string, arr) {
	var result = null;

	for (var i = 0; i < arr.length; i++) {
		if (string == arr[i][0]) {
			result = arr[i][1];
		}
	}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessParagraphs() {
	try {
		var arr, paragraphs, paragraph, parContents, courseNameOriginal, courseData, changed,
		bulletsTextAfter,
		page = null, 
		currentLocation = null;

		if (set.tabSelIndex == 0) { // By Month -- array to make it faster
			paragraphs = story.paragraphs.everyItem().getElements();
		}
		else if (set.tabSelIndex == 1) { // By Location -- need live collection because a line feed is added
			paragraphs = story.paragraphs;
			
			for (var j = 0; j < paragraphs.length; j++) { // workaround: get location from the previous 'header'
				paragraph = paragraphs[j];
				parContents = paragraph.contents;
				if (parContents == "\r") continue; // skip empty paragraphs
				
				if (parContents.match(regExPattAbridgedMonthes) == null) { // Title
					currentLocation = parContents.split("\t")[0];
				}
				else {
					paragraph.bulletsTextAfter = currentLocation;
				}
			}
		}

		// Apply styles
		var parLength = paragraphs.length;
		progressBar.maxvalue = parLength;

		for (var i = parLength - 1; i >= 0; i--) {
			paragraph = paragraphs[i];
			parContents = paragraph.contents;

			if (parContents == "\r") continue; // skip empty paragraphs

			progressBar.value = parLength - i;
			progressTxt.text = ((parContents.replace(/\t/g, " ").length < 51) ? parContents.replace(/\t/g, " ") : (parContents.replace(/\t/g, " ").substr(0, 50) + "...")) + " (paragraph " + (parLength - i) + " out of " + parLength + ")";
			// if (debug) $.writeln((parContents.replace(/\t/g, " ").length < 51) ? parContents.replace(/\t/g, " ") : (parContents.replace(/\t/g, " ").substr(0, 50) + "...")) + " (paragraph " + (parLength - i) + " out of " + parLength + ")";
			
			if (story.overflows) {
				if (debug) $.writeln("The story overflows - 1");
				AddPages(paragraph.parentTextFrames[0]);
			}
			
			if (set.tabSelIndex == 0) { // By Month
				if (parContents.match(regExPattFullMonthes) != null) { // Title
					if (set.byMonthPageRb > 0) { // add "P." at the end of the line
						paragraph.insertionPoints[paragraph.insertionPoints.length - 2].contents = "\tP.";
					}
					else { // remove the tab at the end if no page is selected
						app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
						app.findGrepPreferences.findWhat = "\\t+$";
						app.changeGrepPreferences.changeTo = "";

						changed = paragraph.changeGrep();
						app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
					}

					paragraph.applyParagraphStyle(paragraphTitleStyle, false);
				}
				else { // Text
					paragraph.applyParagraphStyle(paragraphTextStyle, false);
				}
			}
			else if (set.tabSelIndex == 1) { // By Location
				if (parContents.match(regExPattAbridgedMonthes) == null) { // Title
					paragraph.applyParagraphStyle(paragraphTitleStyle, false);
					app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
					app.findGrepPreferences.findWhat = "^.+?(?=\\tCourse Name)";
					app.changeGrepPreferences.changeTo = "$0\\n\\tDate";
					changed = paragraph.changeGrep();
					app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
					
					if (set.byLocationPageRb > 0) {
						app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
						app.findGrepPreferences.findWhat = "Industry$";
						app.changeGrepPreferences.changeTo = "$0\\tP\.";
						changed = paragraph.changeGrep();
						app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
					}
				}
				else { // Text
					bulletsTextAfter = paragraph.bulletsTextAfter;paragraph.bulletsTextAfter
					paragraph.applyParagraphStyle(paragraphTextStyle, false);
					paragraph.bulletsTextAfter = bulletsTextAfter;
				}
			}
		} // End for i

		// Make hyperlinks
		story.recompose(); // just in case
		paragraphs = story.paragraphs;
		progressBar.minvalue = 0;
		progressBar.maxvalue = parLength;
		
		for (var p = paragraphs.length - 1; p >= 0; p--) {
			paragraph = paragraphs[p];
			parContents = paragraph.contents;
	
			if (debug) $.writeln("==================================\rp = " + p + " | parContents = " + parContents);

			progressBar.value = parLength - p;
			progressTxt.text = ((parContents.replace(/\t/g, " ").length < 51) ? parContents.replace(/\t/g, " ") : (parContents.replace(/\t/g, " ").substr(0, 50) + "…")) + " (paragraph " + (parLength - p) + " out of " + parLength + ")";
	
			if (story.overflows) {
				if (debug) $.writeln("The story overflows - 2");
				AddPages(paragraph.parentTextFrames[0]);
			}

			if (set.tabSelIndex == 0 && paragraph.appliedParagraphStyle == paragraphTitleStyle) { // By Month
				app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
				app.findGrepPreferences.findWhat = "^(January|February|March|April|May|June|July|August|September|October|November|December)";
				app.changeGrepPreferences.changeTo = "$0\\n\\tDate";
				changed = paragraph.changeGrep();
				app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
				paragraph.parentStory.recompose();
				paragraph = paragraph.parentStory.paragraphs[p];
			}
		
			if (parContents == "\r") {
				continue;
			}
		
 			courseData = GetCourseData(paragraph, false);

			if (courseData.courseName == null) {
				if (debug) $.writeln("Can't find course name for " + parContents);
				ErrorLog("Can't find course name for " + parContents);
			}

			if ((set.tabSelIndex == 0 && set.byMonthPageRb > 0) || (set.tabSelIndex == 1 && set.byLocationPageRb > 0)) {
				if (paragraph.appliedParagraphStyle.name == "Kalendar - Month Text PN" || paragraph.appliedParagraphStyle.name == "Kalendar - Location Text PN") {
					page = GetPage(courseData.courseName);
					if (page == null) {
						if (debug) $.writeln("Can't find page number for " + courseData.courseName);
					}
				}
			}
	
			if (paragraph.appliedParagraphStyle == paragraphTextStyle && parContents != "\r") { // Text
				AddTabs(paragraph, page);
			}

			// Abridge Course Name
			if ((set.tabSelIndex == 0 && set.byMonthCutCourseDescriptionCb) || // By Month
				(set.tabSelIndex == 1 && set.byLocationCutCourseDescriptionCb)) // By Location
			{
				if (paragraph.lines.length > 1 && paragraph.appliedParagraphStyle == paragraphTextStyle) { // Month / Location
					AbridgeCourseNameWords(paragraph);
				}				
				if (paragraph.lines.length > 1 && paragraph.appliedParagraphStyle == paragraphTextStyle) {
					AbridgeCourseName(paragraph);
				}
			}

			if ((set.tabSelIndex == 0 && set.byMonthPageRb == 2 && paragraph.appliedParagraphStyle.name == "Kalendar - Month Text PN") || // By Month
				(set.tabSelIndex == 1 && set.byLocationPageRb == 2 && paragraph.appliedParagraphStyle.name == "Kalendar - Location Text PN")) // By Location
			{
				if (page != null) {
					MakePageHyperlink(paragraph, page);
				}
			}

			if (set.tabSelIndex == 0 && set.byMonthAddHyperlinksCb || // By Month - Add Hyperlinks is on
				set.tabSelIndex == 1 && set.byLocationAddHyperlinksCb) // By Location
			{
				var url = MakeURL(courseData);
				if (debug) $.writeln(p + " - url =" + url);

				if (paragraph.appliedParagraphStyle == paragraphTitleStyle) { // Title
					MakeWebHyperlink(paragraph.lines[0], url); // only 1-st line: e.g. 'Dubai, UAE' or 'January'
				}
				else {
					MakeWebHyperlink(paragraph, url);
				}
			}
		} // End for p
	
		if (set.applyAltPtrn) {
			ApplyAlternatingPattern(paragraphs);
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line);
		ErrorLog(err.message + ", line: " + err.line);
	}
} // End function ProcessParagraphs
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeURL(courseData) {
	var courseName = "",
	location = "",
	date = "";

	if ((set.tabSelIndex == 0 && set.byMonthAddHyperlinksCb == true && set.byMonthAdvHyperlinkPathCb == true) ||
		(set.tabSelIndex == 1 && set.byLocationAddHyperlinksCb == true && set.byLocationAdvHyperlinkPathCb == true) ||
		(set.tabSelIndex == 2 && set.byBusinessUnitAddHyperlinksCb == true && set.byBusinessUnitAdvHyperlinkPathCb == true)
	) {
		// course name
		if (courseData.courseName != null) {
			courseName = courseData.courseName;
			courseName = courseName.toLocaleLowerCase();
			courseName = courseName.replace(/\r$/, "");
			courseName = courseName.replace(/©|®|&|–|™|℠\/|\(|\)/g, "");
			courseName = Trim(courseName);
			courseName = courseName.replace(/\s+/g, "-");
			courseName = courseName.replace(/:|;|–|&|,|\//g, "-");
			courseName = courseName.replace(/\-+/g, "-");
		}

		// location
		if (courseData.location != null) {
			location = courseData.location;
			location = location.toLocaleLowerCase();
			location = location.replace(/\s+/g, "-");
			location = location.replace(/:|;|–|&|,|\//g, "-");
			location = location.replace(/\-+/g, "-");
		}
		
		// date
		if (courseData.date != null) {
			date = courseData.date;
			date = date.toLocaleLowerCase();
			date = date.replace(/\s+/g, "-");
			date = date.replace(/:|;|–|&|,|\//g, "-");
			date = date.replace(/\-+/g, "-");
			date = date.replace(/jan(?=-)/,  "january");
			date = date.replace(/feb(?=-)/,  "february");
			date = date.replace(/mar(?=-)/,  "march");
			date = date.replace(/apr(?=-)/,  "april"); // ?
			date = date.replace(/aug(?=-)/,  "august");
			date = date.replace(/sep(?=-)/,  "september");
			date = date.replace(/oct(?=-)/,  "october");
			date = date.replace(/nov(?=-)/,  "november");
			date = date.replace(/dec(?=-)/,  "december"); // ?
		}
		
		var str = "https://www.leoron.com/";
		if (courseName != "") str += courseName;
		if (location != "") str += "-" + location;	
		if (date != "") str += "-" + date;
	}
	else {
		if (courseData.courseName != null) {
			str = courseData.courseName.toLocaleLowerCase();
			str = str.replace(/\r$/, "");
			str = str.replace(/©|®|&|–|™|℠\/|\(|\)/g, "");
			str = str.replace(/\s+/g, "-");
			str = str.replace(/:|;|–|&|,|\//g, "-");
			str = str.replace(/\-+/g, "-");
			str = str.replace(/\-$/, "");
			str = "https://www.leoron.com/courses/" + str + "/"; // In the Calendar, by Business Unit, in the hyperlink only for the ‘Business Units Titles’  you should change from ‘courses’ to  ‘course-category’
		}
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AbridgeCourseNameWords(paragraph) {
	try {
		var courseData = GetCourseData(paragraph, true);

		if (courseData.courseName != null) {
			courseData.courseName = courseData.courseName.replace("(", "\\(").replace(")", "\\)");
			var arr, found, txt, changed,
			replacementMapArr = abridgementsStr.split("|");
			
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
			app.findGrepPreferences.findWhat = "(?<=\\t)" + courseData.courseName + "(?= ?\\t)"; // can be a space before the last tab
			found = paragraph.findGrep();
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;

			if (found.length == 1) {
				txt = found[0];
				
				app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
				app.findChangeTextOptions.wholeWord = true;

				for (var j = 0; j <  replacementMapArr.length; j++) {
					arr = replacementMapArr[j].split(",");
					app.findTextPreferences.findWhat = arr[1];
					app.changeTextPreferences.changeTo = arr[0];
					changed = txt.changeText();
					
					if (changed.length > 0) {
						// if (debug) {
							// $.writeln("j = " + j + " - " + replacementMapArr[j]);
							// $.writeln(paragraph.contents);
						// }
					}

					if (paragraph.lines.length == 1) {
						break;
					}
				}
			
				app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
			}
		}
		else {
			if (debug) $.writeln("2-courseData.courseName = null");
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line);
		ErrorLog(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AbridgeCourseName(paragraph) {
	try {
		var courseData = GetCourseData(paragraph, true);
		if (courseData.courseName != null) {
			app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
			app.findTextPreferences.findWhat = courseData.courseName;
			var foundItems = paragraph.findText();
			var foundItem = foundItems[0];
			app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
			var firstCharIndex = foundItem.characters[0].index;
			var lastCharIndex = foundItem.characters[foundItem.characters.length - 1].index;
			foundItem.insertionPoints[foundItem.insertionPoints.length - 1].contents = "…";

			while (paragraph.lines.length > 1 && lastCharIndex > firstCharIndex) {
				story.characters[lastCharIndex].remove();
				lastCharIndex--;
			}
		
			var courseNameNew = GetCourseData(paragraph, true);
			abridgedCourseNames.push([courseNameNew, courseData.courseName]);
			CleanUpPar(paragraph);
		}
		else {
			if (debug) $.writeln("1-courseData.courseName = null");
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line);
		ErrorLog(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AddTabs(txt, page) {
	var changed,
	hasNoTabAtEnd = (txt.contents.match(/\t\r$/) == null);

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	// double all tabs
	app.findGrepPreferences.findWhat = "\\t";
	app.changeGrepPreferences.changeTo = "\\t\\t";
	changed = txt.changeGrep();
	// add a tab at the beginning
	app.findGrepPreferences.findWhat = "^[[:alnum:]]";
	app.changeGrepPreferences.changeTo = "\\t$0";
	changed = txt.changeGrep();
	// add a tab at the end if no tab at the end
	if (hasNoTabAtEnd) {
		app.findGrepPreferences.findWhat = "[[:alnum:]]$";
		app.changeGrepPreferences.changeTo = "$0\\t";
		changed = txt.changeGrep();
	}

	if (page != null) {		
		// add a tab at the end only if page numbers are created
		if ((set.tabSelIndex == 0 && set.byMonthPageRb > 0) || (set.tabSelIndex == 1 && set.byLocationPageRb > 0)) {
			app.findGrepPreferences.findWhat = "\\t$";
			app.changeGrepPreferences.changeTo = "$0" + ((hasNoTabAtEnd) ? "\\t" : "")  + page.name + "\\t";
			changed = txt.changeGrep();
		}
		else { // replace two tabs at the end with one
			app.findGrepPreferences.findWhat = "\\t\\t$"; // !!! month - title -- tab at end
			app.changeGrepPreferences.changeTo = "\\t";
			changed = txt.changeGrep();
		}
	}

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	txt.recompose();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessParagraphsBU() {
	var url, paragraph, parContents, bulletsTextAfter, courseData,
	currentCourseName = null,
	paragraphs = story.paragraphs.everyItem().getElements(),
	parLength = paragraphs.length,
	businessUnitList = [];
	
	for (var k = 0; k < businessUnits.length; k++) {
		businessUnitList.push(businessUnits[k][0]);
	}

	for (var j = 0; j < paragraphs.length; j++) {
		paragraph = paragraphs[j];
		parContents = paragraph.contents;
		
		if (parContents == "\r" || parContents == "\t\t\t\r") continue; // skip empty paragraphs
		// if (debug) $.writeln("BU-1 parContents = " + parContents + "(" + j + ")-" + "[" + paragraph.appliedParagraphStyle.name + "]");

		// workaround: get Course Name from the previous 'header'
		if (!IsInArray(Trim(parContents), businessUnitList) && paragraph.contents.match(regExPattAbridgedMonthes) == null ) { // Course Name: niether Title, nor Text
			currentCourseName = parContents;
		}
		else if (paragraph.contents.match(regExPattAbridgedMonthes) != null ) { // Text
			paragraph.bulletsTextAfter = currentCourseName;
		}
	}
	
	progressBar.maxvalue = parLength;
	
	for (var i = parLength - 1; i >= 0; i--) {
		paragraph = paragraphs[i];
		parContents = paragraph.contents;

		if (parContents == "\r" || parContents == "\t\t\t\r") continue; // skip empty paragraphs
		// if (debug) $.writeln("BU-2 parContents = " + parContents);

		progressBar.value = parLength - i;
		progressTxt.text = ((parContents.replace(/\t/g, " ").length < 51) ? parContents.replace(/\t/g, " ") : (parContents.replace(/\t/g, " ").substr(0, 50) + "...")) + " (paragraph " + (parLength - i) + " out of " + parLength + ")";

		if (story.overflows) {
			if (debug) $.writeln("The story overflows - 3");
			AddPages(paragraph.parentTextFrames[0]);
		}
		
		if (IsInArray(Trim(parContents), businessUnitList)) {
			paragraph.applyParagraphStyle(paragraphTitleStyle, false); // Title
		}
		else if (paragraph.contents.match(regExPattAbridgedMonthes) != null) {
			bulletsTextAfter = paragraph.bulletsTextAfter;
			paragraph.applyParagraphStyle(paragraphTextStyle, false); // Text
			paragraph.bulletsTextAfter = bulletsTextAfter;
		}
		else {
			paragraph.applyParagraphStyle(paragraphCourseTitleStyle, false); // Subtitle
		}
	}

	CleanUpBU(story);

	// Make hyperlinks
	story.recompose(); // just in case
	paragraphs = story.paragraphs;
	parLength = paragraphs.length;
	progressBar.minvalue = 0;
	progressBar.maxvalue = parLength;
	
	for (var p = parLength - 1; p >= 0; p--) {
		paragraph = paragraphs[p];
		parContents = paragraph.contents;
		progressBar.value = parLength - p;
		progressTxt.text = ((parContents.replace(/\t/g, " ").length < 51) ? parContents.replace(/\t/g, " ") : (parContents.replace(/\t/g, " ").substr(0, 50) + "...")) + " (paragraph " + (parLength - p) + " out of " + parLength + ")";
		
		// if (debug) $.writeln("BU-3 parContents = " + p + " - " + parContents);
		courseData = GetCourseData(paragraph, false);
		
		if (paragraph.appliedParagraphStyle == paragraphTextStyle && parContents != "\r") { // Text
			AddTabs(paragraph, null);
		}
		
		if (set.tabSelIndex == 2 && set.byBusinessUnitAddHyperlinksCb) {
			url = MakeURL(courseData);
			// if (debug) $.writeln(p + " - url = " + url);
			MakeWebHyperlink(paragraph, url);
		}
	} // End for p

	if (set.byBusinessUnitTitleUseBUcolorsCb || set.byBusinessUnitCourseTitleUseBUcolorsCb || set.byBusinessUnitTextUseBUcolorsCb) {
		ApplyColorsBU();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetCourseData(paragraph, afterAddTabs) {
	if (typeof afterAddTabs == "undefined") afterAddTabs = false;
	var shift = 1,
	courseData = {courseName: null, location: null, date: null},
	parContents = paragraph.contents,
	tmp = paragraph.bulletsTextAfter,
	arr = parContents.split("\t");
	
	if (set.tabSelIndex == 0) { // By Month
		if (afterAddTabs) shift = 3;
		if (paragraph.appliedParagraphStyle == paragraphTitleStyle) {
			courseData.courseName = paragraph.lines[0].contents;
		}
		else {
			courseData.courseName = Trim(arr[set.byMonthCourseDescriptionPosDdl + shift]);
			courseData.location = arr[set.byMonthCourseDescriptionPosDdl + (shift - 1)]; //  arr[1]
			courseData.date = arr[set.byMonthCourseDescriptionPosDdl + (shift - 2)]; // arr[0]
		}
	}
	else if (set.tabSelIndex == 1) { // By Location
		if (afterAddTabs) shift = 2;
		if (paragraph.appliedParagraphStyle == paragraphTitleStyle) {
			courseData.courseName = paragraph.lines[0].contents;
		}
		else {		
			courseData.courseName = Trim(arr[set.byLocationCourseDescriptionPosDdl + shift]); //  arr[1]
			courseData.location = paragraph.bulletsTextAfter;
			courseData.date = arr[set.byLocationCourseDescriptionPosDdl + (shift - 1)]; // arr[0]
		}
	}
	else if (set.tabSelIndex == 2) { // By Focus Areas
		if (paragraph.appliedParagraphStyle.name == "Kalendar - BU Title" || paragraph.appliedParagraphStyle.name == "Kalendar - BU Course Name") {
			courseData.courseName = parContents;
		}
		else {
			courseData.courseName = paragraph.bulletsTextAfter;
			courseData.location = arr[1]; //  arr[1]
			courseData.date = arr[0]; // arr[0]
		}
	}

	if (courseData.courseName == "") courseData.courseName = null; // wrong element position in array

	return courseData;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CleanUpPar(paragraph) {
	var changed;
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = "(?<=…) ";
	app.changeGrepPreferences.changeTo = "";
	changed = paragraph.changeGrep();
	app.findGrepPreferences.findWhat = " (?=…)";
	changed = paragraph.changeGrep();
	app.findGrepPreferences.findWhat = " \\((?=…)";
	changed = paragraph.changeGrep();
	app.findGrepPreferences.findWhat = "(\\-|~_|~=)(?=~e)"; // !!! remove maybe dashes (normal, n-dash and m-dash) if it comes at the end ‘ - ‘
	changed = paragraph.changeGrep();	
	
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;	
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CleanUpBU() {
	
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	// remove 3 tabs
	app.findGrepPreferences.findWhat = "\\t{3}$";
	app.changeGrepPreferences.changeTo = "";
	var changed = story.changeGrep();
	
	app.findGrepPreferences.findWhat = "~b~b+";
	app.changeGrepPreferences.changeTo = "";
	changed = story.changeGrep();	

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;	
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ApplyColorsBU() {
	try {
		var paragraph, parContents, swatch,
		currentSwatch = null,
		paragraphs = story.paragraphs.everyItem().getElements(),
		parLength = paragraphs.length;
	
		progressBar.minvalue = 0;
		progressBar.maxvalue = parLength;
		
		for (var i = 0; i < parLength; i++) {
			paragraph = paragraphs[i];
			if (debug) $.writeln(i + " - " + paragraph.contents);
			progressBar.value = i;
			progressTxt.text = "Applying colors";

			if (paragraph.appliedParagraphStyle == paragraphTitleStyle) {
				parContents = paragraph.contents.replace(/\r$/, "");				
				swatch = doc.swatches.itemByName(parContents);

				if (swatch.isValid) {
					currentSwatch = swatch;
					
					if (set.byBusinessUnitTitleUseBUcolorsCb) {
						paragraph.paragraphShadingOn = true;
						paragraph.paragraphShadingColor = currentSwatch;
						paragraph.paragraphShadingTint = set.byBusinessUnitTitleTint;
					}
				}
				else {
					currentSwatch = null;
				}
			}
			else if (paragraph.appliedParagraphStyle == paragraphCourseTitleStyle && currentSwatch != null && set.byBusinessUnitCourseTitleUseBUcolorsCb) {
				paragraph.fillColor = currentSwatch;
				paragraph.ruleBelow = true;
				paragraph.ruleBelowColor = currentSwatch;
				paragraph.ruleBelowTint = set.byBusinessUnitCourseTitleTint;
			}
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line);
		ErrorLog(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Trim(str) {  
	return str.replace(/^\s+/, "").replace(/\s+$/, ""); 
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakePageHyperlink(txt, page) {
	try {
		var pageName = page.name;
		var pageNum = FindPageNumber(txt, pageName);
		
		if (pageNum != null) {
			var source = doc.hyperlinkTextSources.add(pageNum);
			var name = "Page " + pageName;
			var dest = doc.hyperlinkPageDestinations.itemByName(name);
			
			if (!dest.isValid) {
				dest = doc.hyperlinkPageDestinations.add(page, {name: name});
			}
			
			var oriName = name;
			var hyperlink = doc.hyperlinks.itemByName(name);

			if (hyperlink != null) {
				var increment = 1;
				while (doc.hyperlinks.itemByName(name) != null) {
					name = oriName + " (" + increment++ + ")";
				}
			}
			
			try { // just in case
				source.name = name;
			}
			catch(err) {
				if (debug) $.writeln(err.message + ", line: " + err.line);
				ErrorLog(err.message + ", line: " + err.line);
				source.name = name + " [" + GetRandomInt(1000000000) + "]";
				if (debug) $.writeln("New source.name: " + source.name);	
			}
	 
			var hyperlink = doc.hyperlinks.add(source, dest, {visible: debug});
			
			try {
				hyperlink.name = name;
			}
			catch(err) {
				if (debug) $.writeln(err.message + ", line: " + err.line);				
				ErrorLog("Trying to set hyperlink name: '" + name + "' - " + err.message + ", line: " + err.line);
				hyperlink.name = name + "[" + GetRandomInt(1000000000) + "]";
				if (debug) $.writeln("New hyperlink.name: " + hyperlink.name);	
			}
			
			if (hyperlink.isValid) {
				count++;
			}
		}
		else {
			if (debug) $.writeln("Can't find page number. Skipping making page hyperlink to page " + page.name);
			ErrorLog("Can't find page number. Skipping making page hyperlink to page " + page.name);
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line + " | txt:" + txt.contents + ", page: " + pageName);
		ErrorLog(err.message + ", line: " + err.line + " | txt:" + txt.contents + ", page: " + pageName);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FindPageNumber(txt, pageName) {
	txt = txt.paragraphs[0]; // redefine paragraph otherwise page number may get outside it after shortening text
	var result = null;
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = "(?<=\\t)" + pageName + "(?=\\t$)";
	var foundItems = txt.findGrep();

	if (foundItems.length > 0) {
		result = foundItems[0];
	}
	else {
		if (debug) $.writeln("Can't find page number at the end of the line: " + pageName);
	}

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetPage(courseName) {
	var foundItems,
	txt = null,
	page = null,
	paragraphStyles = doc.paragraphStyleGroups.itemByName("Ime na kurs").paragraphStyles.everyItem().getElements(),
	textFrame = GetItemFromCollection(courseName, labeledObjects);

	if (textFrame != null) {
		page = textFrame.parentPage;
	}
	else {
		for (var i = 0; i < paragraphStyles.length; i++) {
			app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
			app.findGrepPreferences.findWhat = courseName.replace("(", "\\(").replace(")", "\\)");	
			app.findGrepPreferences.appliedParagraphStyle = paragraphStyles[i];
			foundItems = doc.findGrep();

			if (foundItems.length > 0) {
				txt = foundItems[0];
				break;
			}
		}

		if (txt != null) {
			textFrame = txt.parentTextFrames[0];
			textFrame.label = courseName;
			if (textFrame.parentPage instanceof Page) page = textFrame.parentPage;
		}
	
		app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	}

	return page;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetItemFromCollection(label, collection) {
	for (var i = 0; i < collection.length; i++) {
		// if (debug) $.writeln("collection[" + i + "] = " + collection[i].label);
			if (label == collection[i].label) {
				return collection[i];
			}
	}
	return null;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeWebHyperlink(txt, url) {
	try {
		var text;
		
		if (set.tabSelIndex == 0 && set.byMonthPageRb > 0 || set.tabSelIndex == 1 && set.byLocationPageRb > 0) {
			text = FindTextBeforePageNumber(txt);
			if (text == null) { // course description is missing so create hyperlink for the whole paragraph
				text = txt;
			}
		}
		else {
			text = txt;
		}

		if (text != null) {
			var name = url;
			var oriName = name;

			if (doc.hyperlinks.itemByName(name) != null) {
				var increment = 1;
				while (doc.hyperlinks.itemByName(name) != null) {
					name = oriName + " (" + increment++ + ")";
				}
			}

			var dest = doc.hyperlinkURLDestinations.add(url, {hidden: true}); // 'hidden: true' -- to turn 'shared hyperlink' off
			var source = doc.hyperlinkTextSources.add(text);
			var hyperlink = doc.hyperlinks.add(source, dest, {highlight: HyperlinkAppearanceHighlight.NONE, visible: debug});

			try {
				hyperlink.name = name;
			}
			catch(err) {
				if (debug) $.writeln(err.message + ", line: " + err.line);
				hyperlink.name = name + "[" + GetRandomInt(1000000000) + "]";				
				ErrorLog("Trying to set hyperlink name: '" + name + "' - " + err.message + ", line: " + err.line + " - New hyperlink.name: " + hyperlink.name);				
				if (debug) $.writeln("New hyperlink.name: " + hyperlink.name);	
			}
			
			if (hyperlink.isValid) {
				count++;
			}
		}
		else {
			if (debug) $.writeln("text == null | url = " + url);
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line + " | URL: " + url);
		ErrorLog(err.message + ", line: " + err.line + " | URL: " + url);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FindTextBeforePageNumber(txt) {
	var result = null;
	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	app.findGrepPreferences.findWhat = "^.+\\t(?=\\d{1,3}\\t$)";		

	try {
		var foundItems = txt.paragraphs[0].findGrep();
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line + " | " + txt.contents);
		app.findGrepPreferences.findWhat = "^.+\\t(?=\\d{1,3})";
		var foundItems = txt.findGrep();
	}

	if (foundItems.length > 0) {
		result = foundItems[0];
	}

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PlaceExcel(file) {
	try {	
		with (app.excelImportPreferences) {
			tableFormatting = TableFormattingOptions.EXCEL_UNFORMATTED_TABBED_TEXT;
			sheetIndex = 0;
		}
		
		var result = firstTextFrame.place(file);
		if (result instanceof Story) ErrorExit("Unable to place the Excel file.", true); // should be array

		story.insertionPoints[-1].contents = "\r\r";
		
		var textFrames = story.textContainers;
		var lastTextFrame = textFrames[textFrames.length - 1];

		AddPages(lastTextFrame);
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line);
		ErrorLog(err.message + ", line: " + err.line);

		if (err.number == 29445) { // the file is open in Excel
			alert("Please close the Excel file you chose in the dialog box - " + file.displayName + " - and try again.", scriptName, true);
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	var currentFunction = arguments.callee.toString().match(/function ([^\(]+)/)[1];
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	// check if text is selected
	if (app.selection.length == 0 || app.selection.length > 1) ErrorExit("One text frame or some text should be selected, or the cursor should be inserted into the text.");
	var sel = app.selection[0];
		
	if (sel.constructor.name == "TextFrame") { // a text frame is selected
		story = sel.parentStory;
		firstTextFrame = sel;		
	}
	else if (sel.hasOwnProperty("baseline")) { // some text is selected or the cursor is placed in the text
		story = sel.parentStory;
		firstTextFrame = story.textContainers[0];
	}
	else {
		ErrorExit("One text frame or some text should be selected, or the cursor should be inserted into the text.");
	}

	if (story == undefined || !story.isValid) ErrorExit("Can't find the story.", true);
	if (firstTextFrame == undefined || !firstTextFrame.isValid) ErrorExit("Can't get the first text frame.", true);
	
	// Excel
	var documentsFolder = new Folder(Folder.myDocuments);
	var excelFolderPath = documentsFolder.absoluteURI+ "/Excel/";
	var excelFolder = ($.getenv("USERNAME") == "kas") ? new Folder("~/Documents/Excel") : new Folder("//192.168.1.10/Design/2022/LEORON/Training Calendar and Catalog/kursevi");
	if (!excelFolder.exists) ErrorExit("No 'Excel' folder in the 'Documents' folder.", true);
	excelFiles = excelFolder.getFiles("*.xlsx");
	if (excelFiles.length == 0) ErrorExit("No XLSL-files in the 'Excel > Documents' folder.", true);
	excelFileNames = ["Choose an Excel file"];
	for (var j = 0; j < excelFiles.length; j++) excelFileNames.push(excelFiles[j].displayName.replace(/\.xlsx$/i,""));
	
	// Paragraph styles
	var parStGr_KalendarMonth = doc.paragraphStyleGroups.itemByName("Kalendar Month");
	var parStGr_KalendarLocation = doc.paragraphStyleGroups.itemByName("Kalendar Location");
	
	if (!parStGr_KalendarMonth.isValid) ErrorExit("The paragraph style group 'Kalendar Month' is missing.", true);
	if (!parStGr_KalendarLocation.isValid) ErrorExit("The paragraph style group 'Kalendar Location' is missing.", true);
	
	if (!parStGr_KalendarMonth.paragraphStyles.itemByName("Kalendar - Month Title PN").isValid &&
		!parStGr_KalendarMonth.paragraphStyles.itemByName("Kalendar - Month Title").isValid)
		{
			ErrorExit("The paragraph style 'Kalendar - Month Title (PN)' is missing.", true);
		}
	
	if (!parStGr_KalendarMonth.paragraphStyles.itemByName("Kalendar - Month Text PN").isValid &&
		!parStGr_KalendarMonth.paragraphStyles.itemByName("Kalendar - Month Text").isValid)
		{
			ErrorExit("The paragraph style 'Kalendar - Month Text (PN)' is missing.", true);
		}	

	if (!parStGr_KalendarLocation.paragraphStyles.itemByName("Kalendar - Location Title PN").isValid &&
		!parStGr_KalendarLocation.paragraphStyles.itemByName("Kalendar - Location Title").isValid)
		{
			ErrorExit("The paragraph style 'Kalendar - Location Title (PN)' is missing.", true);
		}
	
	if (!parStGr_KalendarLocation.paragraphStyles.itemByName("Kalendar - Location Text PN").isValid &&
		!parStGr_KalendarLocation.paragraphStyles.itemByName("Kalendar - Location Text").isValid)
		{
			ErrorExit("The paragraph style 'Location - Text (PN)' is missing.", true);
		}
	
	// Check styles for the 'Business Unit' section
	if (doc.name.match(/calendar/i) != null) { // Only 'Calendar' have BU
		var parStGr_BU = doc.paragraphStyleGroups.itemByName("Kalendar BU");
		if (!parStGr_BU.isValid) ErrorExit("The paragraph style group 'Kalendar BU' is missing.", true);
		if (!parStGr_BU.paragraphStyles.itemByName("Kalendar - BU Title").isValid) ErrorExit("The paragraph style 'Kalendar - BU Title' is missing.", true);
		if (!parStGr_BU.paragraphStyles.itemByName("Kalendar - BU Course Name").isValid) ErrorExit("The paragraph style 'Kalendar - BU Course Name' is missing.", true);
		if (!parStGr_BU.paragraphStyles.itemByName("Kalendar - BU Text").isValid) ErrorExit("The paragraph style 'Kalendar - BU Text' is missing.", true);
	}

	allParStyles = doc.allParagraphStyles;
	allParStyles.shift();
	
	allParStyleNames = [];
	for (var i = 0; i < allParStyles.length; i++) allParStyleNames.push(allParStyles[i].name);

	InitVariables();
	
	// Swatches	
	CheckSwatches();

	if (!colorsSuccess) {
		if (debug) $.writeln("GetColors function returned null");
		colors = doc.swatches;
	}

	var swatch, colorName;
	
	for (var s = 0; s < colors.length; s++) {
		if (colorsSuccess) { // collection of swatches for drop downs in dialog box
			colorName = colors[s].name.replace(/\[/,"").replace(/\]/,"");
			swatch = doc.swatches.itemByName(colorName);
//~ 			if (debug) $.writeln(s + "- " + colorName + " | " + doc.swatches[s].name + " (" + (colorName == doc.swatches[s].name) + ")");
			
			if (swatch.isValid) {
				allSwatches.push(swatch);
				allSwatchNames.push(swatch.name);
			}
			else {
				if (debug) $.writeln(s + "- Oops!: " + colorName);
			}
		}
		else { // failed to get colors, proceed without them
			swatch = doc.swatches[s];
			allSwatches.push(swatch);
			allSwatchNames.push(swatch.name);			
		}
	} // end for

	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ListSwatches(allSwatchNames) { // for debugging
	var doc = app.documents[0];
	$.writeln("=================");
	$.writeln("doc.swatches.length = " + doc.swatches.length);
	for (var i = 0; i < doc.swatches.length; i++) {
		$.writeln(i + " - " + doc.swatches[i].name);
	}
	$.writeln("=================");
	$.writeln("allSwatchNames.length = " + allSwatchNames.length);
	for (var i = 0; i < allSwatchNames.length; i++) {
		$.writeln(i + " - " + allSwatchNames[i]);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorLog(text) {
	var file = new File("~/Desktop/" + scriptName + " - error log.txt");
	file.encoding = "UTF-8";
	
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
		if (errorsArr.length == 0) file.write("=========================================================\rDate & time: " + GetDate() + "\r=========================================================\r");
	}

	file.write(text + "\r"); 
	file.close();
	errorsArr.push(text);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDate() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function AbridgeCountries(replacementMapStr) {
	var arr, changed,
	replacementMapArr = replacementMapStr.split("|");

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
	if (debug) app.changeGrepPreferences.fillColor = swatchAbridgedText; // for debugging only
	
	for (i = 0; i <  replacementMapArr.length; i++) {
		arr = replacementMapArr[i].split(",");
		app.findGrepPreferences.findWhat = "(?<=,\\s)" + arr[1] + "(?=\\t)";
		app.changeGrepPreferences.changeTo = arr[0];
		changed = story.changeGrep();
	}

	app.findGrepPreferences = app.changeGrepPreferences = NothingEnum.NOTHING;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function InitVariables() {
	countryCodesStr = "AFG,Afghanistan|ALB,Albania|ALG,Algeria|AND,Andorra|ANG,Angola|ANT,Antigua and Barbuda|ARG,Argentina|ARM,Armenia|ARU,Aruba|ASA,American Samoa|AUS,Australia|AUT,Austria|AZE,Azerbaijan|BAH,Bahamas|BAN,Bangladesh|BAR,Barbados|BDI,Burundi|BEL,Belgium|BEN,Benin|BER,Bermuda|BHU,Bhutan|BIH,Bosnia and Herzegovina|BIZ,Belize|BLR,Belarus|BOL,Bolivia|BOT,Botswana|BRA,Brazil|BRN,Bahrain|BRU,Brunei|BUL,Bulgaria|BUR,Burkina Faso|CAF,Central African Republic|CAM,Cambodia|CAN,Canada|CAY,Cayman Islands|CGO,Congo|CHA,Chad|CHI,Chile|CHN,China|CIV,Ivory Coast|CMR,Cameroon|COD,DR Congo|COK,Cook Islands|COL,Colombia|COM,Comoros|CPV,Cape Verde|CRC,Costa Rica|CRO,Croatia|CUB,Cuba|CYP,Cyprus|CZE,Czech Republic|DEN,Denmark|DJI,Djibouti|DMA,Dominica|DOM,Dominican Republic|ECU,Ecuador|EGY,Egypt|ERI,Eritrea|ESA,El Salvador|ESP,Spain|EST,Estonia|ETH,Ethiopia|FIJ,Fiji|FIN,Finland|FRA,France|FSM,Micronesia|GAB,Gabon|GAM,The Gambia|GBR,Great Britain|GBS,Guinea-Bissau|GEO,Georgia|GEQ,Equatorial Guinea|GER,Germany|GHA,Ghana|GRE,Greece|GRN,Grenada|GUA,Guatemala|GUI,Guinea|GUM,Guam|GUY,Guyana|HAI,Haiti|HKG,Hong Kong|HON,Honduras|HUN,Hungary|INA,Indonesia|IND,India|IRI,Iran|IRL,Ireland|IRQ,Iraq|ISL,Iceland|ISR,Israel|ISV,Virgin Islands|ITA,Italy|IVB,British Virgin Islands|JAM,Jamaica|JOR,Jordan|JPN,Japan|KAZ,Kazakhstan|KEN,Kenya|KGZ,Kyrgyzstan|KIR,Kiribati|KOR,South Korea|KOS,Kosovo|KSA,Saudi Arabia|KUW,Kuwait|LAO,Laos|LAT,Latvia|LBA,Libya|LBR,Liberia|LCA,Saint Lucia|LES,Lesotho|LBN,Lebanon|LIE,Liechtenstein|LTU,Lithuania|LUX,Luxembourg|MAD,Madagascar|MAR,Morocco|MAS,Malaysia|MAW,Malawi|MDA,Moldova|MDV,Maldives|MEX,Mexico|MGL,Mongolia|MHL,Marshall Islands|MKD,Macedonia|MLI,Mali|MLT,Malta|MNE,Montenegro|MON,Monaco|MOZ,Mozambique|MRI,Mauritius|MTN,Mauritania|MYA,Myanmar|NAM,Namibia|NCA,Nicaragua|NED,Netherlands|NEP,Nepal|NGR,Nigeria|NIG,Niger|NOR,Norway|NRU,Nauru|NZL,New Zealand|OMA,Oman|PAK,Pakistan|PAN,Panama|PAR,Paraguay|PER,Peru|PHI,Philippines|PLE,Palestine|PLW,Palau|PNG,Papua New Guinea|POL,Poland|POR,Portugal|PRK,North Korea|PUR,Puerto Rico|QAT,Qatar|ROU,Romania|RSA,South Africa|RUS,Russia|RWA,Rwanda|SAM,Samoa|SEN,Senegal|SEY,Seychelles|SGP,Singapore|SKN,Saint Kitts and Nevis|SLE,Sierra Leone|SLO,Slovenia|SMR,San Marino|SOL,Solomon Islands|SOM,Somalia|SRB,Serbia|SRI,Sri Lanka|SSD,South Sudan|STP,São Tomé and Príncipe|SUD,Sudan|SUI,Switzerland|SUR,Suriname|SVK,Slovakia|SWE,Sweden|SWZ,Swaziland|SYR,Syria|TAN,Tanzania|TGA,Tonga|THA,Thailand|TJK,Tajikistan|TKM,Turkmenistan|TLS,Timor-Leste|TOG,Togo|TPE,Chinese Taipei[5]|TTO,Trinidad and Tobago|TUN,Tunisia|TUR,Turkey|TUV,Tuvalu|UAE,United Arab Emirates|UGA,Uganda|UK,United Kingdom|UKR,Ukraine|URU,Uruguay|USA,United States|UZB,Uzbekistan|VAN,Vanuatu|VEN,Venezuela|VIE,Vietnam|VIN,Saint Vincent and the Grenadines|YEM,Yemen|ZAM,Zambia|ZIM,Zimbabwe";
	abridgementsStr = "On-Line,Distance Learning Program|Certif.,Certified|Mgmt.,Management|Pro.,Professional|Cert.,Certificate|Mgr.,Manager|AR,Arabic|Crse.,Course|Financ.,Financial|Rev.,Review|Intl.,International|Bus.,Business|Qlty.,Quality|Spclst.,Specialist|Aud,Auditor|Proj.,Project|Adv.,Advanced|Plng.,Planning|Str.,Strategic|Fin.,Finance|Ops.,Operations";
	
	businessUnits = [
		["Administration", [0, 60, 40, 10]],
		["Audit, Governance & Compliance", [0, 40, 90, 10]],
		["Behavioral", [40, 50, 20, 0]],
		["CIPD", [0, 80, 80, 15]], // new
		["Engineering & Maintenance", [30, 35, 70, 10]],
		["Facility Management", [35, 15, 25, 35]],
		["Finance & Accounting", [60, 0, 85, 15]],
		["Financial Services", [70, 0, 70, 15]],
		["Healthcare", [55, 20, 70, 10]],
		["Human Resources", [0, 80, 80, 15]],
		["Technology & Development", [50, 35, 0, 10]], // the only thing that I have changed is the industry name Information Technology was renamed into Technology & Development
		["LEORON Mint/Tirkiz", [70, 20, 35, 0]],
		["LEORON Petroleum", [67, 50, 42, 15]],
		["Management & Leadership", [15, 80, 40, 10]],
		["Procurement & Contracts", [70, 0, 30, 15]],
		["Projects", [40, 20, 55, 10]],
		["Quality Management", [80, 50, 0, 15]],
		["Risk Management", [15, 15, 90, 15]],
		["Sales & Marketing", [0, 90, 50, 15]],
		["Supply Chain & Operations", [60, 15, 20, 20]]
	];
	
	regExPattAbridgedMonthes = /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/i;
	regExPattFullMonthes = /^(January|February|March|April|May|June|July|August|September|October|November|December)\t/i;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetRandomInt(max) {
  return Math.floor(Math.random() * Math.floor(max));
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckSwatches() {
	var swatch;

	var businessUnitSwatches = businessUnits;
	
	for (var i = 0; i < businessUnitSwatches.length; i++) {
		swatch = doc.swatches.itemByName(businessUnitSwatches[i][0]);
		
		if (swatch == null) {
			doc.colors.add({name : businessUnitSwatches[i][0], model : ColorModel.PROCESS, space : ColorSpace.CMYK, colorValue : businessUnitSwatches[i][1]});
		}
		else if (swatch.colorValue.join() != businessUnitSwatches[i][1].join()) {
			//$.writeln("changing colorValue - " + swatch.colorValue + " => " + businessUnitSwatches[i][1]);
			swatch.colorValue = businessUnitSwatches[i][1];
		}
	}
	
	if (doc.swatches.itemByName("===== Abridged Text =====") == null) {
		swatchAbridgedText = doc.colors.add({name : "===== Abridged Text =====", model : ColorModel.PROCESS, space : ColorSpace.RGB, colorValue : [200, 100, 0]});
	}
	else {
		swatchAbridgedText = doc.swatches.itemByName("===== Abridged Text =====");
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IsInArray(string, arr) {
	for (x in arr) {
		if (string.toLowerCase() == arr[x].toLowerCase()) {
			return true;
		}
	}
	return false;
}
//================================== Apply alternating pattern ==================================
function ApplyAlternatingPattern(pars) {
	try {
		var par,
		count = 0;

		for (var i = 0; i < pars.length; i++) {
			par = pars[i];
 
			if (par.appliedParagraphStyle == paragraphTextStyle) {
				par.clearOverrides(OverrideType.ALL);
				
				if (count % 2 == 0) {
					par.paragraphShadingOn = true;
					par.paragraphShadingColor = allSwatches[set.oddSwatchColor[0]];
					par.paragraphShadingTint = set.oddSwatchTint;
					count++;
				}
				else {
					par.paragraphShadingOn = true;
					par.paragraphShadingColor = allSwatches[set.evenSwatchColor[0]];
					par.paragraphShadingTint = set.evenSwatchTint;
					count++;
				}
			}
			else {
				if (set.reset && count != 0) {
					count = 0;
				}
			}
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetColors() {
	try { // The following code was borrowed from 'See Your Swatches in ScriptUI' by Marc Autret
			var pngSwatch = (function()
		{  
			 // Table of CRCs of 8-bit messages  
			 var CRC_256 = [0, 0x77073096, 0xee0e612c, 0x990951ba, 0x76dc419, 0x706af48f, 0xe963a535, 0x9e6495a3, 0xedb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988, 0x9b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2, 0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7, 0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9, 0xfa0f3d63, 0x8d080df5, 0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172, 0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 0x35b5a8fa, 0x42b2986c, 0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59, 0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423, 0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924, 0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 0x76dc4190, 0x1db7106, 0x98d220bc, 0xefd5102a, 0x71b18589, 0x6b6b51f, 0x9fbfe4a5, 0xe8b8d433, 0x7807c9a2, 0xf00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x86d3d2d, 0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e, 0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950, 0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65, 0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7, 0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0, 0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa, 0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f, 0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81, 0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x3b6e20c, 0x74b1d29a, 0xead54739, 0x9dd277af, 0x4db2615, 0x73dc1683, 0xe3630b12, 0x94643b84, 0xd6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0xa00ae27, 0x7d079eb1, 0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb, 0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc, 0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e, 0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b, 0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55, 0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236, 0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28, 0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d, 0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x26d930a, 0x9c0906a9, 0xeb0e363f, 0x72076785, 0x5005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0xcb61b38, 0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0xbdbdf21, 0x86d3d2d4, 0xf1d4e242, 0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777, 0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69, 0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2, 0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc, 0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9, 0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693, 0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94, 0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d];  
			   
			 // PNG Cyclic Redundancy Code algorithm -- http://www.w3.org/TR/PNG/#D-CRCAppendix  
			 var crc32 = function(/*uint[]*/buf)  
				  {  
				  var c = 0xffffffff >>> 0,  
					   n = buf.length >>> 0,  
					   i;  
				  for( i=0 ; i < n ; ++i )  
					   c = CRC_256[( ( c>>>0 ) ^ buf[i]) & 0xff] ^ (c >>> 8);  
			   
				  return (c ^ 0xffffffff)>>>0;  
				  };  
		  
			 var PNG_PROLOG = "\x89PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\r\x00\x00\x00\r\b\x03\x00\x00\x00E5\x14N\x00\x00\x00\x06",  
				  PNG_EPILOG = "\x00\x00\x00\x16IDATx\xDAb`D\x06\f\x8C\f\b0\xC8x\xC8\x00 \xC0\x00\x11\xC6\x001{U\x93\xB6\x00\x00\x00\x00IEND\xAEB`\x82";  
		  
			 return function(/*uint[3]*/rgb)  
				  {  
				  var buf = [0x50,0x4C,0x54,0x45, rgb[0], rgb[1], rgb[2], 0, 0, 0],  
					   crc = crc32(buf),  
					   i, r;  
					
				  buf = buf.concat([ (crc>>>24)&0xFF, (crc>>>16)&0xFF, (crc>>>8)&0xFF, (crc>>>0)&0xFF ]);  
				  i = buf.length;  
				  while( i-- )  
					   buf[i] = String.fromCharCode(buf[i]);  
					
				  r = PNG_PROLOG + buf.join('') + PNG_EPILOG;  
					
				  buf.length = 0;  
				  buf = null;  
				  return r;  
				  };  
		})();  
		  
		var PNG_NONE = "\x89PNG\r\n\x1A\n\x00\x00\x00\rIHDR\x00\x00\x00\r\x00\x00\x00\r\b\x03\x00\x00\x00E5\x14N\x00\x00\x00\fPLTE\xFF\xFF\xFF\x00\x00\x00\xFF\xBC\xBC\xFF\x00\x00 C\x89[\x00\x00\x002IDATx\xDAL\xC7\xC9\x01\x000\b\x020\xD4\xFDwn\xF1\xC2\xFC\x02\xBB`\x18\x1Eg\x1E\xAE\xFD`\xC7\xEC2\xB3J\xAFS\x9B\xE46\x9C\xC2)\xDC\xF5\x04\x18\x00+\xB9\x00z\xA7\xBDj\x1B\x00\x00\x00\x00IEND\xAEB`\x82";  
		  
		var localeColor = function(/*str*/name)  
		{  
			 return '['+app.translateKeyString('$ID/'+name)+']';  
		};  
		  
		// Parse the app|doc Swatches  
		//----------------------------------------------------------  
		var RGB = ColorSpace.RGB,  
			 SPOT = ColorModel.SPOT,  
			 REGISTRATION = ColorModel.REGISTRATION,  
			 MIXEDINK = ColorModel.MIXEDINKMODEL;  
		  
		var target = (app.documents.length&&app.activeDocument)||app,  
			 swatches = target.swatches.everyItem().getElements(),  
			 n = swatches.length,  
			 color, rgbValues,  
			 colors = [],
			 sp, md, nm,  
			 i, t, error;
			 
			 colors = [];  	 
		  
		for( i=n-1 ; i>=0 ; i-- )  
			 {
			 error = false;
			 color = swatches[i];
			// if (debug) $.writeln("===============\r" + i + " - color.name: " + color.name); //  + ", color.space: " + color.space
		  
			 if( !(color instanceof Color) ) continue;  
			   
			 color = color.getElements()[0];  
			 sp = color.space;  
			 md = color.model;  
			 nm = color.name;  
		  
			 if( MIXEDINK==md ) continue;     // TODO  
		  
			 switch( -(REGISTRATION==md||"Black" == nm) || + (RGB==sp) )  
				  {  
				  case -1:  
					   rgbValues = [0,0,0];  
					   nm = localeColor(nm);  
					   break;  
				  case 1:  
					   rgbValues = color.colorValue;  
					   break;  
				  default:  
					   // backup the color value  
					   t = color.colorValue;
					   
						try {
							// convert to rgb  
							color.space = RGB;
						}
						catch(err) {// skip this color: can't change in placed graphics
							// if (debug) $.writeln(err.message + ", line: " + err.line + ", color.name: " + color.name + ", color.space: " + color.space);
							error = true;
							break; // jump out of the switch statement.
						}
				   
					   rgbValues = color.colorValue;  
					   // revert to the color space  
					   color.space = sp;  
					   color.colorValue = t;  
				  } // end switch
			  
			 if (error) continue; // skip this color in for loop
			 if( nm=="Paper" ) nm = localeColor(nm);  
		  
			 colors.unshift({  
				  name: nm,  
				  png: pngSwatch(rgbValues),  
				  id: color.id  
				  });
			 } // end for
		  
		colors.unshift({  
			 name: localeColor("None"),  
			 png: PNG_NONE,  
			 id: target.swatches.itemByName('None').id  
			 });
	}
	catch(err) {
//~ 		if (debug) {
//~ 			try {
//~ 				if (debug) {
//~ 					$.writeln("colors = null");
//~ 					$.writeln(err.message + ", line: " + err.line + ", color.name: " + color.name + ", color.space: " + color.space);
//~ 				}
//~ 			}
//~ 			catch(err) {}
//~ 		}
		colors = null;
	}
 
	return colors;
 }
//--------------------------------------------------------------------------------------------------------------------------------------------------------
/*

*/