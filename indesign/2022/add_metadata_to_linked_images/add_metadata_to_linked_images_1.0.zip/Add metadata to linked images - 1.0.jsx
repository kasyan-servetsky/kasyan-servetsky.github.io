﻿/* Copyright 2022, Kasyan Servetsky
November 11, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Add metadata to linked images - 1.0",
debug = false, // for debugging only
doc;

preCheck();
//===================================== FUNCTIONS ======================================
function main() {
	try {
		var link, filePath,
		defaultAltTag = "Here goes default Alt Tag",
		arr = [],
		links = doc.links.everyItem().getElements(),
		imgTypes = ["TIFF", "JPEG", "Photoshop", "EPS", "InDesign Format Name", "CompuServe GIF", "Windows Bitmap", "Portable Network Graphics (PNG)", "Adobe Portable Document Format (PDF)"];

		for (var i = 0; i < links.length; i++) {
			link = links[i];
			
			if (!inArray(link.name, imgTypes)) {
				if (debug) $.writeln("processing: " + link.name);
				character = link.parent.parent.parent;
				paragraph = character.paragraphs[0];
				
				if (character == paragraph.characters[0]) {
					parContents = paragraph.contents.replace(/\uFFFC/g, "").replace(/\uFEFF/g, "").replace(/\r+$/, "").replace(/\n+$/, "");
					filePath = decodeURI(new File(link.filePath).absoluteURI);
					altTag = (parContents == "") ? defaultAltTag : parContents;
					arr.push([filePath, altTag]);
				}
			}
		} // end for
	
		if (arr.length > 0) {
			createBridgeTalkMessage(arr);
		}
		else {
			alert ("No valid links were found.", scriptName, true);
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function createBridgeTalkMessage(arr) {
	var bt = new BridgeTalk();
	bt.target = "bridge";
	var script = applyMetadata.toSource() + "(" + arr.toSource() + ")";
	bt.body = script;
	bt.onError = function(msg) {
		alert("Error: " + msg.body);
	}
	bt.send(100);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function applyMetadata(arr) {
	var filePath, docTitle, thumbnail, md, xmp, updatedPacket;
	if (!ExternalObject.AdobeXMPScript) {  
		ExternalObject.AdobeXMPScript = new ExternalObject("lib:AdobeXMPScript");
	}
	for (var i = 0; i < arr.length; i++) {
		filePath = arr[i][0];
		docTitle = arr[i][1];
		thumbnail = new Thumbnail(new File(filePath));
		if (thumbnail.exists) {
			md = thumbnail.synchronousMetadata;
			xmp = new XMPMeta(md.serialize());
			xmp.deleteProperty(XMPConst.NS_DC, "title");
			xmp.setLocalizedText(XMPConst.NS_DC, "title", "", "x-default", docTitle);
		}
		updatedPacket = xmp.serialize(XMPConst.SERIALIZE_OMIT_PACKET_WRAPPER | XMPConst.SERIALIZE_USE_COMPACT_FORMAT);
		thumbnail.metadata = new Metadata(updatedPacket);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function inArray(string, arr) {
	for (x in arr) {
		if (string == arr[x]) {
			return true;
		}
	}
	return false;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function preCheck() {
	if (app.documents.length == 0) errorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) errorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) errorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	var specifier = BridgeTalk.getSpecifier("photoshop");
	if (specifier == null) {
		errorExit("The script can't run because Bridge is not installed.");
	}
	
	if (!BridgeTalk.isRunning ("bridge")) {
		var answer = confirm("Bridge is not running. Do you want to launch it?", false, scriptName);
		if (answer) {
			BridgeTalk.launch("bridge");
			errorExit("Wait untill Bridge finishes loading and run the script again.");
		}
		else {
			exit();
		}
	}

	main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function errorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------