﻿/* Copyright 2022, Kasyan Servetsky
November 18, 2022
Written by Kasyan Servetsky
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Add metadata to linked images - 1.1",
debug = false, // for debugging only
log = true,
doc;

preCheck();
//===================================== FUNCTIONS ======================================
function main() {
	try {
		var link, filePath,
		defaultAltTag = "Here goes default Alt Tag",
		arr = [],
		links = doc.links.everyItem().getElements(),
		imgTypes = ["TIFF", "JPEG", "Photoshop", "EPS", "InDesign Format Name", "CompuServe GIF", "Windows Bitmap", "Portable Network Graphics (PNG)", "Adobe Portable Document Format (PDF)"];

		for (var i = 0; i < links.length; i++) {
			link = links[i];
			
			if (!inArray(link.name, imgTypes) && link.status != LinkStatus.LINK_MISSING) {
				if (debug) $.writeln("processing: " + link.name + " | " + link.status);
				character = link.parent.parent.parent;
				paragraph = character.paragraphs[0];
				
				if (character == paragraph.characters[0]) {
					parContents = paragraph.contents.replace(/\uFFFC/g, "").replace(/\uFEFF/g, "").replace(/\r+$/, "").replace(/\n+$/, "");
					filePath = decodeURI(link.filePath);
					altTag = (parContents == "") ? defaultAltTag : parContents;
					arr.push([filePath, altTag, link.name]);
				}
			}
		} // end for
	
		if (arr.length > 0) {
			applyMetadata(arr);
			var report = arr.length + " link" + ((arr.length == 1) ? " was" : "s were") + " processed.";
			alert(report, scriptName, false);
		}
		else {
			alert("No valid links were found.", scriptName, true);
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function applyMetadata(arr) {
	var filePath, file, fileName, docTitle, xmpFile, xmpMetaObj;
	logMessage("---------------------------------------");
	
	for (var i = 0; i < arr.length; i++) {
		filePath = arr[i][0];
		docTitle = arr[i][1];
		fileName = arr[i][2]; // for debugging only
		file = new File(filePath);
		
		if (file.exists && loadXMPLibrary()) {
			xmpFile = new XMPFile(filePath, XMPConst.UNKNOWN, XMPConst.OPEN_FOR_UPDATE);
			xmpMetaObj = xmpFile.getXMP();
			xmpMetaObj.setLocalizedText(XMPConst.NS_DC, "title", "", "x-default", docTitle);
			
			logMessage((i + 1) + " - " + fileName + " | " + docTitle + "\r");

			if (xmpFile.canPutXMP(xmpMetaObj)) {
				xmpFile.putXMP(xmpMetaObj);
			}

			xmpFile.closeFile(XMPConst.CLOSE_UPDATE_SAFELY);
		}
	} // end for
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function inArray(string, arr) {
	for (x in arr) {
		if (string == arr[x]) {
			return true;
		}
	}
	return false;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function preCheck() {
	if (app.documents.length == 0) errorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) errorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) errorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function logMessage(msg) {
	if (log) {
		var file = new File("~/Desktop/" + scriptName + " log.txt");
		file.encoding = "UTF-8";
		
		if (file.exists) {
			file.open("e");
			file.seek(0, 2);
		}
		else {
			file.open("w");
		}
	
		file.write(msg + "\r"); 
		file.close();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function loadXMPLibrary() {
	try {
		if (!ExternalObject.AdobeXMPScript) {  
			ExternalObject.AdobeXMPScript = new ExternalObject("lib:AdobeXMPScript");
		}
	}
	catch(err) {  
		$.writeln("ERROR: " + err.number +", "+ err.message + "\rUnable to load the AdobeXMPScript library!"); 
		return false;
	}

	return true; 
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function errorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------