﻿//StepAndRepeatImposition.jsx
//An InDesign CS JavaScript
//www.theonconnection.com
//Duplicates objects in a grid. Useful to impose for print.

if (app.documents.length != 0){
	if (app.selection.length > 0){
		myObjects = app.selection;
		if(myObjects.length > 0){
			myDisplayDialog(myObjects);
		}
		else{
			alert("Please select a rectangle, polygon, graphic line, oval, or text frame and try again.");
		}
	}
	else{
		alert("Please select an object and try again.");
	}
}
else{
	alert("Please open a document, select an object, and try again.");
}

//Display dialog.
function myDisplayDialog(myObjects){
	myDialog = app.dialogs.add();
	myDialog.name = "Step And Repeat Imposition";
	myLabelsColumn1 = myDialog.dialogColumns.add();
	myLabelsColumn1.staticTexts.add({staticLabel:"Rows:"});
	myLabelsColumn1.staticTexts.add({staticLabel:"Columns:"});
	//Spacer.
	myLabelsColumn1.staticTexts.add();
	myLabelsColumn1.staticTexts.add({staticLabel:"Horizontal Offset:"});
	myLabelsColumn1.staticTexts.add({staticLabel:"Vertical Offset:"});
	//Spacer.
	myControlsColumn1 = myDialog.dialogColumns.add();
	myRowsField = myControlsColumn1.integerEditboxes.add({editValue:2});
	myColumnsField = myControlsColumn1.integerEditboxes.add({editValue:2});
	myControlsColumn1.staticTexts.add();
	myXOffsetField = myControlsColumn1.measurementEditboxes.add({editValue:0});
	myYOffsetField = myControlsColumn1.measurementEditboxes.add({editValue:0});
	//Spacer.
	myResult = myDialog.show();
	if(myResult == true){
		//Gather the user input from the dialog controls.
		myNumberOfRows = myRowsField.editValue;
		myNumberOfColumns = myColumnsField.editValue;
		myXOffset = myXOffsetField.editValue;
		myYOffset = myYOffsetField.editValue;
		myDialog.destroy();
		myStepAndRepeat(myObjects, myNumberOfRows, myNumberOfColumns, myXOffset, myYOffset);
	}
	else{
		myDialog.destroy();
	}
}

function myStepAndRepeat(myObjects, myNumberOfRows, myNumberOfColumns, myXOffset, myYOffset){
	//looping here for the rows
	for (myYCounter = 0; myYCounter <= myNumberOfRows-1; myYCounter++){
		//looping here for the cols
		for (myXCounter = 0; myXCounter <= myNumberOfColumns-1; myXCounter++){
			if (myXCounter!=0 || myYCounter !=0) {
				for (myObjectCounter=0; myObjectCounter < myObjects.length; myObjectCounter++){
					myObject = myObjects[myObjectCounter];
					myObject = myObject.duplicate();
					myObject.move(undefined, [myXOffset*myXCounter, myYOffset*myYCounter]);
				}
			}
		}
	}
}