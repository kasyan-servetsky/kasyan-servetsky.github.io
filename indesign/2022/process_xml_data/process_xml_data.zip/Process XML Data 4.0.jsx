﻿// Copyright 2012, «Студия Форма» 
// April 10, 2012
// Written by Kasyan Servetsky
// http://www.kasyan.ho.com.ua
// e-mail: askoldich@yahoo.com
//==================================== GLOBALS ==========================================
const gScriptName = "Process XML Data";
const gScriptVersion = "4.0";

var gErrMsgArr = [];
//=======================================================================================
Main();
//=================================== FUNCTIONS  =========================================
function Main() {
	var xmlFiles, xmlFile, currentFolderPath, xmlStr, root, linksArr, copyCount, componentList, componentsLength, montageList, montagesLength, montage, currentFolder, doc, docFile, component, noErrors, pdfPath, pdfFile, targetPagesLength, destinationFolder, backgroundTask;
	
	var mainFolder =  new Folder("~/Desktop/Input/");
	if (mainFolder == null) exit();
	xmlFiles = GetFiles(mainFolder);
	if (xmlFiles.length == 0) exit();
	var outFolderPath = "~/Desktop/Output/";
	var outFolder = new Folder(outFolderPath);
	if (!outFolder.exists) outFolder.create();
	var failedDocs = [];
	var successfulDocs = [];
	
	for (var x = 0; x < xmlFiles.length; x++) {
		xmlFile = xmlFiles[x];
		currentFolder = xmlFile.parent;
		currentFolderPath = currentFolder.absoluteURI + "/";

		xmlFile.open("r"); 
		xmlStr = xmlFile.read();
		xmlFile.close();

		root = new XML(xmlStr);
		default xml namespace = "http://www.forma-studio.com/order";

		linksArr = [];
		copyCount = root.xpath("/order/copy-count");
		componentList = root.xpath("/order/product/components/component");
		componentsLength = componentList.length();
		
		for (var c = 0; c < componentsLength; c++) {
			component = componentList[c];

			linksArr.push({ name : component.images.image.file_name.toString(),
								width : parseInt(component.images.image.size.width),
								height : parseInt(component.images.image.size.height),
								resolution : parseInt(component.images.image.resolution),
							   });
		}

		montageList = root.xpath("/order/product/montages/montage");
		montagesLength = montageList.length();
		for (var i = 0; i < montagesLength; i++) {
			montage = montageList[i];
		
			app.scriptPreferences.userInteractionLevel = UserInteractionLevels.neverInteract;		
			app.open(new File(montage.layout_filename));
			doc = app.activeDocument;
			docFile = new File(outFolderPath + montage.result_filename + ".indd");
			doc.save(docFile);
			app.scriptPreferences.userInteractionLevel = UserInteractionLevels.interactWithAll;
			
			targetPagesLength = parseInt(montage.page_count)*copyCount;
			if (!isNaN(targetPagesLength)) {
				if( targetPagesLength != 0) {
					while (doc.pages.length > targetPagesLength) {
						doc.pages.lastItem().remove();
					}
				}
			}
		
			UpdateAllOutdatedLinks(doc);
			
			noErrors = ProcessDoc(doc, linksArr, currentFolderPath);
			if (noErrors) {
				destinationFolder = new Folder(montage.destination);
				VerifyFolder(destinationFolder);
				pdfPath = montage.destination + "/" + montage.result_filename + ".pdf"
				pdfFile = new File(pdfPath);
				backgroundTask = doc.asynchronousExportFile(ExportFormat.PDF_TYPE, pdfFile, false, "[High Quality Print]");
				var tasksPanel = app.panels.itemByName("Background Tasks");
				if (tasksPanel) tasksPanel.visible = true;
				successfulDocs.push(doc.name);
				if (xmlFile.name == "sforder.xml") xmlFile.rename("NoErrorProcecced_" + xmlFile.name);	
			}
			else {
				failedDocs.push(doc.name);
				if (xmlFile.name == "sforder.xml") xmlFile.rename("ErrorProcecced_" + xmlFile.name);
			}
		} // for montagesLength
	} // for xmlFiles
	
	//alert("Готово. Обработано " + xmlFiles.length + " XML-файлов\r\r" + ((successfulDocs.length > 0) ? "Експортировано:\r" + successfulDocs.join(", ") : "") + ((failedDocs.length > 0) ? "\r\rВыявлены ошибки:\r" + failedDocs.join(", ") : "") , gScriptName + " - " + gScriptVersion, false);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ProcessDoc(doc, linksArr, currentFolderPath) {
	var link, linkFile, errMessage;
	var noErrors = true;
	var reportFilePath = doc.fullName.absoluteURI.replace(/\.indd$/i, ".txt");
	var links = doc.links;

	for (var i = links.length-1; i >= 0; i--) {
		link = doc.links[i];
		
		for (var o = 0; o < linksArr.length; o++) {
			if (link.name == linksArr[o].name) {
				linkFile = new File(currentFolderPath + linksArr[o].name);
				if (linkFile.exists) {
					link.relink(linkFile);
					if (CheckLink(link, linksArr[o], doc) == false) {
						noErrors = false;
					}
				}
				else {
					errMessage = link.name + " — нет файла.\r";
					if (IsInArray(errMessage, gErrMsgArr) == false) {
						gErrMsgArr.push(errMessage);
						WriteToFile(errMessage, reportFilePath);
						noErrors = false;
					}
				}
			}
		}
	}
	
	return noErrors;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckLink(link, linkObj, doc) {
	var errMessage;
	var imageDeviation = 10; // размер картинки может отличаться на +/- эту величину в пикселях
	var result = true;
	var image = link.parent;
	var actualPpi = image.actualPpi;
	var md = link.linkXmp;
	var reportFilePath = doc.fullName.absoluteURI.replace(/\.indd$/i, ".txt");
	var pixelDimensionsArr = GetPixelDimensions(link.filePath);
	var width = parseInt(pixelDimensionsArr[0]);
	var height = parseInt(pixelDimensionsArr[1]);

	if (actualPpi[0] != linkObj.resolution && actualPpi[1] != linkObj.resolution) {
		errMessage = link.name + " — разрешение " + actualPpi[0] + "x" + actualPpi[1] + " пикселов вместо " + linkObj.resolution + "\r";
		if (IsInArray(errMessage, gErrMsgArr) == false) {
			gErrMsgArr.push(errMessage);
			WriteToFile(errMessage, reportFilePath);
			result = false;
		}
	}

	if (Math.abs(height - linkObj.height) > imageDeviation) {
		errMessage = link.name + " — высота " + height + " вместо " + linkObj.height + "\r";
		if (IsInArray(errMessage, gErrMsgArr) == false) {
			gErrMsgArr.push(errMessage);			
			WriteToFile(errMessage, reportFilePath);
			result = false;
		}		
	}

	if (Math.abs(height - linkObj.height) > imageDeviation) {
		errMessage = link.name + " — ширина " + width + " вместо " + linkObj.width + "\r";
		if (IsInArray(errMessage, gErrMsgArr) == false) {
			gErrMsgArr.push(errMessage);			
			WriteToFile(errMessage, reportFilePath);
			result = false;
		}
	}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function UpdateAllOutdatedLinks(doc) {
	var link;
	for (var i = doc.links.length-1; i >= 0; i--) {
		link = doc.links[i];
		if (link.status == LinkStatus.LINK_OUT_OF_DATE) link.update();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function WriteToFile(text, reportFilePath) {
	file = new File(reportFilePath);
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text); 
	file.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDate() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, gScriptName + " - " + gScriptVersion, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IsInArray(string, arr) {
	for (x in arr) {
		if (string.toLowerCase() == arr[x].toLowerCase()) {
			return true;
		}
	}
	return false;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function VerifyFolder(folder) {
	if (!folder.exists) {
		var folder = new Folder(folder.absoluteURI);
		var arr1 = new Array();
		while (!folder.exists) {
			arr1.push(folder);
			folder = new Folder(folder.path);
		}
		var arr2 = new Array();
		while (arr1.length > 0) {
			folder = arr1.pop();
			if (folder.create()) {
				arr2.push(folder);
			} else {
				while (arr2.length > 0) {
					arr2.pop.remove();
				}
				throw "Folder creation failed";
			} 
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetFiles(theFolder) {
	var files = [],
	fileList = theFolder.getFiles(),
	i, file;
	
	for (i = 0; i < fileList.length; i++) {
		file = fileList[i];
		if (file instanceof Folder) {
			files = files.concat(GetFiles(file));
		}
		else if (file instanceof File && file.name == "sforder.xml") {
			files.push(file);
		}
	}

	return files;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetPixelDimensions(linkPath) {
	try {
		if (xmpLib == undefined) {
			var pathToLib = (Folder.fs == "Windows") ? Folder.startup.fsName + "/AdobeXMPScript.dll" : "/Applications/Adobe Bridge CS5.1/Adobe Bridge CS5.1.app/Contents/MacOS/AdobeXMPScript.framework";
			var libfile = new File(pathToLib);
			var xmpLib = new ExternalObject("lib:" + pathToLib);
		}

		var f = new File(linkPath);
		var xmpFile = new XMPFile(linkPath, XMPConst.FILE_TIFF, XMPConst.OPEN_FOR_READ);
		var xmp = xmpFile.getXMP();
		var pixels_X = xmp.getProperty("http://ns.adobe.com/exif/1.0/", "exif:PixelXDimension");
		var pixels_Y = xmp.getProperty("http://ns.adobe.com/exif/1.0/", "exif:PixelYDimension");
		return [pixels_X, pixels_Y];
	}
	catch(err) {
		ErrorExit(err.message + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------