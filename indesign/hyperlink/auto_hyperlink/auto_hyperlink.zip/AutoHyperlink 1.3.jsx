﻿/* Copyright 2022, Kasyan Servetsky,
June 1 2022
Written by Kasyan Servetsky, but the original idea by Nobrainer Scripting - http://www.nobrainer.dk
http://www.kasyan.ho.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
// Feel free to edit the parameters in this section
var hyperlinkVisible = false, // If true, the Hyperlink is visible
hyperlinkBorderColor = UIColors.BLACK, // The hyperlink border color. Array of 3 Reals (0 - 255) or UIColors enumerator. For example: UIColors.RED or [255, 0, 0]
hyperlinkBorderStyle = HyperlinkAppearanceStyle.SOLID, // HyperlinkAppearanceStyle.SOLID | HyperlinkAppearanceStyle.DASHED
hyperlinkHighlight = HyperlinkAppearanceHighlight.NONE, // HyperlinkAppearanceHighlight.INSET | HyperlinkAppearanceHighlight.INVERT | HyperlinkAppearanceHighlight.NONE | HyperlinkAppearanceHighlight.OUTLINE
hyperlinkWidth = HyperlinkAppearanceWidth.THIN, // HyperlinkAppearanceWidth.MEDIUM | HyperlinkAppearanceWidth.THICK | HyperlinkAppearanceWidth.THIN
sharedHyperlinkOff = true, // set it to true to turn 'shared hyperlink' off
hyperlinkCharStyleName = "Hyperlink", // the character style name for hyperlinks -- set to null to skip applying it
hyperlinkSwatchName = "Hyperlink", // the swatch name for hyperlinks
hyperlinkSwatchColorSpace = "CMYK", // One of the following: CMYK | RGB | HSB | LAB | MIXEDINK | RGB. Make sure to read the next comment if you're going to change it.
hyperlinkSwatchColorValue = [80, 60, 0, 20]; // The ink values that create the color, specified as a percentage for each ink. Note: The number of values required and the range depends on the color space. For RGB, specify three values, with each value in the range 0 to 255; for CMYK, specify four values representing C, M, Y, and K, with each value in the range 0 to 100; for LAB, specify three values representing L (Range: 0 to 100), A (Range: -128 to 127), and B (Range: -128 to 127); for mixed ink, specify values for each ink in the ink list, with each value in the range 0 to 100.

// Find Change text options
with (app.findChangeTextOptions) { // Don't touch this line, but you can set the lines below either to true or false (bolean): works like a check box in InDesign
	caseSensitive = false; // If true, finds strings whose use of case matches the find text string. If false, finds strings that match the find text string regardless of case.
	wholeWord = false; // If true, finds only the complete find text string. If false, also finds strings that contain the find text string.
	includeHiddenLayers = false; // If true, includes hidden layers in the find/change query.
	includeLockedLayersForFind = false; // If true, includes locked layers in the find query.
	includeLockedStoriesForFind = false; // If true, includes locked stories in the find query.
	includeMasterPages = false; // If true, includes master (parent) pages in the find/change query.
	includeFootnotes = false; // If true, includes footnotes in the find/change query.
}
//======================================================================================
// Don’t mess with the stuff below unless you know what you’re doing
var scriptName = "AutoHyperlink - 1.3",
doc,
count = 0,
debugMode = false, // for debugging only
macOS = (File.fs == "Macintosh"),
calledFromBatchProcessor = CalledFromBatchProcessor();

if (calledFromBatchProcessor) { // called as a 'secondary' script from the batch processor
	if (g.doc != null) { // If the script is called from the batch processor and the g.doc variable is sent from it, the doc variable is set to g.doc.
		doc = g.doc; // With the all open documents option selected, make sure to use g.doc variable to send the current document from the batch processor to this script otherwise, it will not work correctly.
		Main();
	}
	else { // If something goes wrong, though it’s hardly possible, the error message is written to the log
		g.WriteToFile("ERROR: 'g.doc == null' - Failed to get the document to process.");
	}
}
else { // called as a 'regular' script
	PreCheck();
}
//===================================== FUNCTIONS =======================================
function Main() {
	try {
		var startTime = new Date(),
		list;
		
		if (calledFromBatchProcessor) { 
			if (typeof g.arguments == "undefined" || g.arguments.length == 0 || // check if we have at least one valid argument
				typeof g.arguments[0] === "undefined" ||
				g.arguments[0] === null ||
				g.arguments[0] === "") // empty string
			{
				g.WriteToFile("ERROR: Missing or invalid arguments file. Exiting the script.", scriptName, true);
				exit();
			}
			else {
				list = MakeList(g.arguments);
			}
		}
		else { // called as a 'regular' script
			var script = GetActiveScript();
			var scriptFolderPath = script.path;
			var findChangeFile = new File(scriptFolderPath + "/NamesAndURLs.txt");
			if (!findChangeFile.exists) {
				var findChangeFile = File.openDialog("Choose the file with Names and URLs", (macOS) ? FileFilter : "TXT files:*.txt;All files:*.*");
			}

			if (findChangeFile != null && findChangeFile.exists) {
				var txt = ReadTxtFile(findChangeFile);
				list = MakeList(txt);
			}
			else { // Cancelled
				exit();
			}
		}

		// common part for both when called from the batch processor and used as regular script
		var item;
		app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
		
		for (var i = 0; i < list.length; i++) {
			item = list[i];
			
			if (item[0] != "" && item[1] != "") { // skip empty elementls
				SearchAndReplace(item[0], item[1]);
			}
		}
	
		app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
		
		var endTime = new Date();
		var duration = GetDuration(startTime, endTime);
		var report = count + " hyperlink" + ((count == 1) ? " was" : "s were") + " created (time elapsed: " + duration + ")";

		if (calledFromBatchProcessor) {
			g.WriteToFile(report);
		}
		else {
			alert(report, scriptName);
		}
	}
	catch(err) { // if an error occurs, catch it and write the  document's name, error message and line# where it happened into the log
		if (calledFromBatchProcessor) {
			g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", Line: " + err.line + ", Time: " + GetTime());
		}
		else {
			if (debugMode) {
				$.writeln(err.message + ", line: " + err.line); // in debugMode -- write the error message and line# to ESTK console
			}
			else {
				ErrorExit("ERROR: " + err.message + ", line: " + err.line, true);
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeList(data) {
	var j,
	arr = (data.constructor.name == "Array") ? data : data.split("\n"),
	list = [];
	
	for (var i = 0; i < arr.length; i++) {
		j = arr[i];
		
		if (j.search(/\t/) != -1) {
			list.push(j.split("\t"));
		}
	}

	return list;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function SearchAndReplace(findStr, url) {
	try {	
		var foundItem;
		app.findTextPreferences.findWhat = findStr;
		var foundItems = doc.findText();

		for (var i = 0; i < foundItems.length; i++) {
			foundItem = foundItems[i];
			MakeWebHyperlink(foundItem, url);
		}
	}
	catch(err) {
		if (calledFromBatchProcessor) {
			g.WriteToFile("ERROR: " + doc.name + " - " + err.message + ", Line: " + err.line + ", Time: " + GetTime());
		}
		else {
			if (debugMode) {
				$.writeln(err.message + ", line: " + err.line); // in debugMode -- write the error message and line# to ESTK console
			}
			else {
				ErrorExit("ERROR: " + err.message + ", line: " + err.line, true);
			}
		}
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeWebHyperlink(txt, url) {
	try {
		var dest = doc.hyperlinkURLDestinations.add(url, {hidden: sharedHyperlinkOff});
		var source = GetSource(txt);
		if (source == null) {
			source = doc.hyperlinkTextSources.add(txt);
		}

		if (hyperlinkCharStyleName != null) {
			var hyperlinkSwatch = MakeColor(hyperlinkSwatchName, eval("ColorSpace." + hyperlinkSwatchColorSpace), ColorModel.process, hyperlinkSwatchColorValue);
			var hyperlinkStyle = MakeCharStyle("Hyperlink", {fillColor: hyperlinkSwatch, underline: true});
			source.sourceText.applyCharacterStyle(hyperlinkStyle);
		}
	
		var hyperlink = doc.hyperlinks.add(source, dest, {visible: hyperlinkVisible,
																		borderColor: hyperlinkBorderColor,
																		borderStyle: hyperlinkBorderStyle,
																		highlight: hyperlinkHighlight,
																		width: hyperlinkWidth
																		});

		if (hyperlink.isValid) count ++;
		
		try {
			hyperlink.name = url;
		}
		catch(err) {
			if (debugMode) $.writeln(err.message + ", line: " + err.line);
			hyperlink.name = url + "[" + GetRandomInt(1000000000) + "]";				
			if (debugMode) $.writeln("New hyperlink.name: " + hyperlink.name);	
		}
	}
	catch(err) {
		if (debugMode) $.writeln(err.message + ", line: " + err.line + " | URL: " + url);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetSource(txt) {
	var source = null;
	
	for (var i = 0; i < doc.hyperlinkTextSources.length; i++) {
		if (doc.hyperlinkTextSources[i].sourceText == txt) {
			source = doc.hyperlinkTextSources[i];
		}
	}

	return source;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function FileFilter(file) {
	var extention = ".txt";
	var lowerCaseName = file.name;
	lowerCaseName.toLowerCase();
	
	if (lowerCaseName.indexOf(extention) == file.name.length - extention.length) {
		return true;
	}
	else if (file instanceof Folder) {
		return true;
	}
	else {
		return false;
	}
}
//=======================================================================================
function GetTime() { // get exact time for the log -- hr : min : sec -- so we could know when exactly an error occured
	var date = new Date();
	var dateString = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CalledFromBatchProcessor() { // Let's see if it's called as a 'secondary' (returns true) or as a 'regular' (returns false) script
	var result = false;
	
	try {
		var arr = $.stack.split(/[\n]/);
		if (arr.length > 0 && arr[0].match(/\[Batch processor/i) != null) {
			result = true;
		}
	}
	catch(err) {}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetActiveScript() {
    try {
        return app.activeScript;
    }
    catch(err) {
        return new File(err.fileName);
    }
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ReadTxtFile(file) {
	file.open("r"); 
	var txt = file.read();
	file.close();
	return txt;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetRandomInt(max) {
  return Math.floor(Math.random() * Math.floor(max));
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeCharStyle(name, properties) {
	var charStyle = doc.characterStyles.item(name);
	if (!charStyle.isValid) {
		charStyle = doc.characterStyles.add({name: name});
		if (properties != undefined) charStyle.properties = properties;
	}
	return charStyle;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeColor(colorName, colorSpace, colorModel, colorValue) {
	var doc = app.activeDocument;
	var color = doc.colors.item(colorName);
	if (!color.isValid) {
		color = doc.colors.add({name: colorName, space: colorSpace, model: colorModel, colorValue: colorValue});
	}
	return color;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}