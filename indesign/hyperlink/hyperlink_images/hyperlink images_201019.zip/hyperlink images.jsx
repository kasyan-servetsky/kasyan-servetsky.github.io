﻿var scriptName = "Hyperlink images",
debugMode = false, // for debugging only
doc;

PreCheck();

//===================================== FUNCTIONS ======================================
function Main(excelFile) {
	try {
		var row,
		linkNames = [],
		links = doc.links.everyItem().getElements();
		
		for (var l = 0; l < links.length; l++) {
			linkNames.push(links[l].name);
		}		

		var excelFilePath = excelFile.fsName.replace(/\\/g, "\\\\");
		var data = GetDataFromExcelPC(excelFilePath, ";", "1");
		
		for (var i = 0; i < data.length; i++) {
			row = data[i];
			
			if (IsInArray(row[0], linkNames)) {
				MakeHyperLink(row[0], row[1]);
			}
		}
	}
	catch(err) {
		LogError("Error: " + err.message + ", function " + arguments.callee.toString().match(/function ([^\(]+)/)[1] + ", line: " + err.line);
		if (debugMode) $.writeln(err.message + ", function " + arguments.callee.toString().match(/function ([^\(]+)/)[1] + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function MakeHyperLink(linkName, url) {
	try {
		var link = doc.links.itemByName(linkName);
		var container = link.parent;
		var source = doc.hyperlinkPageItemSources.add(container);
		var destination = doc.hyperlinkURLDestinations.add(url);
		var hyperlink = doc.hyperlinks.add(source, destination);
		hyperlink.name = linkName;
	}
	catch(err) {
		if (debugMode) $.writeln(err.message + ", function " + arguments.callee.toString().match(/function ([^\(]+)/)[1] + ", line: " + err.line);
		LogError("Error: " + err.message + ", function " + arguments.callee.toString().match(/function ([^\(]+)/)[1] + ", line: " + err.line);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDataFromExcelPC(excelFilePath, splitChar, sheetNumber) {
	if (typeof splitChar === "undefined") var splitChar = ";";
	if (typeof sheetNumber === "undefined") var sheetNumber = "1";
	var appVersionNum = Number(String(app.version).split(".")[0]);

	var vbs = 'Public s\r';
	vbs += 'Function ReadFromExcel()\r';
	vbs += 'Set objExcel = CreateObject("Excel.Application")\r';
	vbs += 'Set objBook = objExcel.Workbooks.Open("' + excelFilePath + '")\r';
	vbs += 'Set objSheet =  objExcel.ActiveWorkbook.WorkSheets(' + sheetNumber + ')\r';
	vbs += 'objExcel.Visible = False\r';
	vbs += 'matrix = objSheet.UsedRange\r';
	vbs += 'maxDim0 = UBound(matrix, 1)\r';
	vbs += 'maxDim1 = UBound(matrix, 2)\r';
	vbs += 'For i = 1 To maxDim0\r';
	vbs += 'For j = 1 To maxDim1\r';
	vbs += 'If j = maxDim1 Then\r';
	vbs += 's = s & matrix(i, j)\r';
	vbs += 'Else\r';
	vbs += 's = s & matrix(i, j) & "' + splitChar + '"\r';
	vbs += 'End If\r';
	vbs += 'Next\r';
	vbs += 's = s & vbCr\r';
	vbs += 'Next\r';
	vbs += 'objBook.Close\r';
	vbs += 'Set objSheet = Nothing\r';
	vbs += 'Set objBook = Nothing\r';
	vbs += 'Set objExcel = Nothing\r';
	vbs += 'End Function\r';
	vbs += 'Function SetArgValue()\r';
	vbs += 'Set objInDesign = CreateObject("InDesign.Application")\r';
	vbs += 'objInDesign.ScriptArgs.SetValue "excelData", s\r';
	vbs += 'End Function\r';
	vbs += 'ReadFromExcel()\r';
	vbs += 'SetArgValue()\r';

	if (appVersionNum > 5) { // CS4 and above
		app.doScript(vbs, ScriptLanguage.VISUAL_BASIC, undefined, UndoModes.FAST_ENTIRE_SCRIPT);
	}
	else { // CS3 and below
		app.doScript(vbs, ScriptLanguage.VISUAL_BASIC);
	}

	var str = app.scriptArgs.getValue("excelData");
	app.scriptArgs.clear();
	
	var tempArrLine, line,
	data = [],
	tempArrData = str.split("\r");
	
	for (var i = 0; i < tempArrData.length; i++) {
		line = tempArrData[i];
		if (line == "") continue;
		tempArrLine = line.split(splitChar);
		data.push(tempArrLine);
	}
	
	return data;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (File.fs != "Windows") ErrorExit("This script is for Windows only.", true);
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	var excelFile = File.openDialog("Choose an Excel file.", "*.xlsx");
//~ 	var excelFile = new File("~/Desktop/Test/Test.xlsx"); // for debugging only
	if (excelFile != null) Main(excelFile);
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function LogError(text) {
	var file = new File("~/Desktop/" + scriptName + " - Error log.txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}

	file.write(GetDate() + "\r" + text + "\r==============================\r"); 
	file.close();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDate() {
	var date = new Date();
	if ((date.getYear() - 100) < 10) {
		var year = "0" + new String((date.getYear() - 100));
	}
	else {
		var year = new String((date.getYear() - 100));
	}
	var dateString = (date.getMonth() + 1) + "/" + date.getDate() + "/" + year + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
	return dateString;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function IsInArray(string, arr) {
	for (x in arr) {
		if (string.toLowerCase() == arr[x].toLowerCase()) {
			return true;
		}
	}
	return false;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------