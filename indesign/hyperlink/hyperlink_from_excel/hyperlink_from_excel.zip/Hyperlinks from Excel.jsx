﻿/* Copyright 2025, Kasyan Servetsky
March 6, 2025
Version 1.0
Written by Kasyan Servetsky
Site: http://kasyan.ho.ua/indesign/hyperlink/hyperlink_from_excel/hyperlink_from_excel.html
E-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "Hyperlinks from Excel",
debug = false,
doc, gExcelFilePath, gParStFind, gCharStApply,
gCount = 0;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" script");
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var item, txt, url, foundText,
		startTime = new Date();

		var progressWin = new Window("window", scriptName);
		var progressBar = progressWin.add("progressbar" , undefined, 0, 0);
		progressBar.preferredSize.width = 600;
		var progressTxt = progressWin.add("statictext", undefined,  "Reading data from Excel. Please, be patient: this may take a while.");
		progressTxt.alignment = "fill";
		progressWin.show(); // show only the message without progress before the data are read

		var data = GetDataFromExcelMac(gExcelFilePath, true);
		progressBar.maxvalue = data.length; // set maxvalue after the data are read

		for (var i = 0; i < data.length; i++) {
			item = data[i];
			txt = item[0];
			url = item[1];

			progressBar.value = (i + 1);
			progressTxt.text = "Making hyperlink '" +  txt + "' (" + (i + 1) + " out of " + data.length + " records)";

			if (txt.match(/Book Title/i) != null) continue; // skip header

			foundText = FindText(txt);
			if (foundText == null) continue;

			MakeWebHyperlink(foundText, url);
		}

		progressWin.close();
		var endTime = new Date();
		var duration = GetDuration(startTime, endTime);
        var report = "Finished. " + gCount + " hyperlink" + ((gCount == 1) ? " was" : "s were") + " created. Time elapsed: " + duration;
        alert(report, scriptName);
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}

function FindText(txt) {
	var result = null;
	app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;
	app.findTextPreferences.findWhat = txt;
	app.findTextPreferences.appliedParagraphStyle = gParStFind;
	var foundItems = doc.findText();
	if (foundItems.length > 0) {
		result = foundItems[0];
	}
	app.findTextPreferences = app.changeTextPreferences = NothingEnum.NOTHING;

	return result;
}

function MakeWebHyperlink(text, url) {
	try {
		if (text != null) {
			var name = url;
			var oriName = name;

			if (doc.hyperlinks.itemByName(name) != null) {
				var increment = 1;
				while (doc.hyperlinks.itemByName(name) != null) {
					name = oriName + " (" + increment++ + ")";
				}
			}

			var dest = doc.hyperlinkURLDestinations.add(url, {hidden: true}); // 'hidden: true' -- to turn 'shared hyperlink' off
			var source = doc.hyperlinkTextSources.add(text, {appliedCharacterStyle: gCharStApply});
			var hyperlink = doc.hyperlinks.add(source, dest, {highlight: HyperlinkAppearanceHighlight.OUTLINE, visible: false});

			try {
				hyperlink.name = name;
			}
			catch(err) {
				if (debug) $.writeln("Failed to set hyperlink name: " + err.message + ", line: " + err.line);
				hyperlink.name = name + "[" + GetRandomInt(1000000000) + "]";

				if (debug) {
					$.writeln("Trying to set a new hyperlink name: '" + name + "' - " + err.message + ", line: " + err.line + " - New hyperlink.name: " + hyperlink.name);
					$.writeln("New hyperlink.name: " + hyperlink.name);
				}
			}
			
			if (hyperlink.isValid) {
				gCount++;
			}
		}
		else {
			if (debug) $.writeln("text == null | url = " + url);
		}
	}
	catch(err) {
		if (debug) $.writeln(err.message + ", line: " + err.line + " | URL: " + url);
	}
}

function PreCheck() {
	if (File.fs != "Macintosh") ErrorExit("This script is for Macintosh computers only.", true);
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	// The name of the paragraph style to find. Change it to whatever you need.
	var gParStFindName = "Elite book title";
	gParStFind = doc.paragraphStyles.itemByName(gParStFindName);
	if (!gParStFind.isValid) ErrorExit("Paragraph style '" + gParStFindName + "' is missing in the current document.", true);

	// The name of the character style to apply to hyperlinks. Change it to whatever you need.
	var gCharStApplyName = "hyperlink";
	gCharStApply = doc.characterStyles.itemByName(gCharStApplyName);
	if (!gCharStApply.isValid) ErrorExit("Character style '" + gCharStApplyName + "' is missing in the current document.", true);

	var docPath = doc.filePath.fsName;  
	var excelFile = Folder(docPath).openDlg("Pick an Excel file", function (f) { return (f instanceof Folder) || f.name.match(/\.xlsx$/i);});
	if (excelFile != null) {
		gExcelFilePath = excelFile.fsName;
		if (debug) $.writeln(gExcelFilePath);
		Main();
	}
}

function GetDataFromExcelMac(excelFilePath, isPosix, splitCharRows, splitCharColumns, sheetNumber) {
	if (File.fs != "Macintosh") return null;
	if (typeof isPosix === "undefined") isPosix = true;
	if (typeof splitCharRows === "undefined") splitCharRows = "|";
	if (typeof splitCharColumns === "undefined") splitCharColumns = ";";
	if (typeof sheetNumber === "undefined") sheetNumber = "1";

	var appVersion,
	appVersionNum = Number(String(app.version).split(".")[0]);
	
	switch (appVersionNum) {
		case 20:
			appVersion = "2025";
			break;
		case 19:
			appVersion = "2024";
			break;
		case 18:
			appVersion = "2023";
			break;
		case 17:
			appVersion = "2022";
			break;		
		case 16:
			appVersion = "2021";
			break;		
		case 15:
			appVersion = "2020";
			break;
		case 14:
			appVersion = "CC 2019";
			break;
		case 13:
			appVersion = "CC 2018";
			break;
		case 12:
			appVersion = "CC 2017";
			break;
		case 11:
			appVersion = "CC 2015";
			break;
		case 10:
			appVersion = "CC 2014";
			break;			
		case 9:
			appVersion = "CC";
			break;		
		case 8:
			appVersion = "CS 6";
			break;
		case 7:
			if (app.version.match(/^7\.5/) != null) {
				appVersion = "CS 5.5";
			}
			else {
				appVersion = "CS 5";
			}
			break;
		case 6:
			appVersion = "CS 4";
			break;
		case 5:
			appVersion = "CS 3";
			break;
		case 4:
			appVersion = "CS 2";
			break;
		case 3:
			appVersion = "CS";
			break;			
		default:
		return null;
	}

	var as = 'tell application "Microsoft Excel"\r';
	as += 'if (' + isPosix + ' is true) then\r';
	as += 'set excelFilePath to POSIX file \"' + excelFilePath + '\"\r';
	as += 'end if\r';
	as += 'open file excelFilePath\r';
	as += 'set theWorkbook to active workbook\r';
	as += 'set theSheet to sheet ' + sheetNumber + ' of theWorkbook\r';
	as += 'set theMatrix to value of used range of theSheet\r';
	as += 'set theRowCount to count theMatrix\r';
	as += 'set str to ""\r';
	as += 'set oldDelimiters to AppleScript\'s text item delimiters\r';
	as += 'repeat with countRows from 1 to theRowCount\r';
	as += 'set theRow to item countRows of theMatrix\r';
	as += 'set AppleScript\'s text item delimiters to \"' + splitCharColumns + '\"\r';
	as += 'set str to str & (theRow as string) & \"' + splitCharRows + '\"\r';
	as += 'end repeat\r';
	as += 'set AppleScript\'s text item delimiters to oldDelimiters\r';
	as += 'close theWorkbook saving no\r';
	as += 'end tell\r';
	as += 'tell application "Adobe InDesign ' + appVersion + '\"\r';
	as += 'tell script args\r';
	as += 'set value name "excelData" value str\r';
	as += 'end tell\r';
	as += 'end tell';
	
	if (appVersionNum > 5) { // CS4 and above
		app.doScript(as, ScriptLanguage.APPLESCRIPT_LANGUAGE, undefined, UndoModes.ENTIRE_SCRIPT);
	}
	else { // CS3 and below
		app.doScript(as, ScriptLanguage.APPLESCRIPT_LANGUAGE);
	}

	var str = app.scriptArgs.getValue("excelData");
	app.scriptArgs.clear();
	
	var tempArrLine, line,
	data = [],
	tempArrData = str.split(splitCharRows);
	
	for (var i = 0; i < tempArrData.length; i++) {
		line = tempArrData[i];
		if (line == "") continue;
		tempArrLine = line.split(splitCharColumns);
		data.push(tempArrLine);
	}
	
	return data;
}

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}

function GetRandomInt(max) {
	return Math.floor(Math.random() * Math.floor(max));
}

function GetDuration(startTime, endTime) {
	var str;
	var duration = (endTime - startTime)/1000;
	duration = Math.round(duration);
	if (duration >= 60) {
		var minutes = Math.floor(duration/60);
		var seconds = duration - (minutes * 60);
		str = minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		if (minutes >= 60) {
			var hours = Math.floor(minutes/60);
			minutes = minutes - (hours * 60);
			str = hours + ((hours != 1) ? " hours, " : " hour, ") + minutes + ((minutes != 1) ? " minutes, " :  " minute, ") + seconds + ((seconds != 1) ? " seconds" : " second");
		}
	}
	else {
		str = duration + ((duration != 1) ? " seconds" : " second");
	}

	return str;
}