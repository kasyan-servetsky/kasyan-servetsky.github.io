﻿var scriptName = "Change automatically frame with hyperlink text into hyperlinked frame",
debug = false, // for debugging only
doc;

app.doScript(PreCheck, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");
//===================================== FUNCTIONS ======================================
function Main() {
	try {
		var hyperlink, sourceText, textFrame, storedName, newSource, newHyperlink,
		doc = app.activeDocument,	
		hyperlinks = doc.hyperlinks.everyItem().getElements();

		for (var i = 0; i < hyperlinks.length; i++) {
			hyperlink =hyperlinks[i];

			if (!hyperlink.source.hasOwnProperty("sourceText") || 
				hyperlink.source.sourceText == undefined
			) {
				continue;
			}
		
			sourceText = hyperlink.source.sourceText;
			
			textFrame = sourceText.parentTextFrames[0];	
			if (textFrame.extractLabel(scriptName) == "processed") continue;
			
			storedName = hyperlink.name;
			
			try {			
				newSource = doc.hyperlinkPageItemSources.add(textFrame);
			}
			catch(err) {
				if (debug) $.writeln(err.message + ", line: " + err.line);
				continue;
			}
		
			newHyperlink = doc.hyperlinks.add(newSource, hyperlink.destination);
			hyperlink.remove();
			textFrame.insertLabel(scriptName, "processed");
			
			 // clear the "Hyperlink" character style
			if (sourceText.appliedCharacterStyle.name == "Hyperlink") {
				sourceText.appliedCharacterStyle = doc.characterStyles.item("[None]");
				sourceText.clearOverrides();
			}
		
			newHyperlink.name = storedName;
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.documents[0];
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}