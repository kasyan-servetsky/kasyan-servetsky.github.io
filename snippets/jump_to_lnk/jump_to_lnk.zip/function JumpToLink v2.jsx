﻿var scriptName = "Find duplicate letters-words - 1.0",
gUrl = "http://kasyan.ho.ua/indesign/text/find_same_letters-words/find_same_letters-words.html", // URL to this script on my site
gTmpFileName = scriptName.replace(/\-\s\d+\.\d+$/, "").replace(/\s+/g, "_").toLowerCase(),
gTmpSubFolderName = "Kasyan";

Main();

function Main() {
	JumpToLink(gTmpSubFolderName, gTmpFileName + "temp", gUrl); // tmpSubFolderName, tmpFileName, url
}

function JumpToLink(tmpSubFolderName, tmpFileName, url) {
	var tmpFolder = new Folder(Folder.temp.absoluteURI + "/" + tmpSubFolderName);
	if (!tmpFolder.exists) tmpFolder.create();
	if (tmpFileName.match(/\.htm(l)*$/) == null) {
		tmpFileName += ".html"
	}
	var linkJumper = File(tmpFolder.absoluteURI + "/" + tmpFileName);
	
	if (!linkJumper.exists) {
		linkJumper.open("w");
		var linkBody = '<html><head><META HTTP-EQUIV=Refresh CONTENT="0; URL=' + url + '"></head><body> <p></body></html>'
		linkJumper.write(linkBody);
		linkJumper.close();
	}

	linkJumper.execute();
}