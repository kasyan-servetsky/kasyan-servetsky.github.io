/**
 * @fileoverview 指定のXML要素をインラインフレーム化するために、テンポラリマスターページにデータベースの作成と切り出したテキストフレームを配置する。切り出し位置には挿入用のインラインテキストフレームを作成する。実際の配置を行うには、続いてsilentMakeCodeBlock-stage2.jsxを実行する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
 * @requires libCodeBlock.jsx
*/

/*
    Copyright:
    2008 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
  */
#include "../libs/libCommon.jsx"
#include "../libs/libCodeBlock.jsx"

var myDocument = app.activeDocument;

var elements = myDocument.xmlTags;
var cc = new Array();
var ccselected = 0;
for (var i = 0; i < elements.length; i++) {
  cc[i] = elements[i].name;
  if (cc[i] == "list") ccselected = i;
}

var styles = myDocument.objectStyles;
var dlist = null;
var cc2 = new Array();
var cc2selected = 0;
for (var i = 0; i < styles.length; i++) {
  cc2[i] = styles[i].name;
  if (cc2[i] == "99-囲みリスト") cc2selected = i;
}

var wObj = app.dialogs.add({ name:"インラインテキストフレームの作成" });
with (wObj.dialogColumns.add()) {
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "対象要素", minWidth: 130});
    dlist = dropdowns.add({stringList: cc, selectedIndex: ccselected});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "ボックスの幅(mm)", minWidth: 130}); // FIXME:デフォルトは112mmとした
    var tObj = integerEditboxes.add({editValue: 112, minimumValue: 1, maximumValue: 1000});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "適用するオブジェクトスタイル", minWidth: 130});
    dlist2 = dropdowns.add({stringList: cc2, selectedIndex: cc2selected});
  }
}

if (wObj.show() == false) exit(0);

makeCodeBlock1(myDocument, dlist.stringList[dlist.selectedIndex], tObj.editValue, dlist2.stringList[dlist2.selectedIndex], [2, 2, 2, 2]);
