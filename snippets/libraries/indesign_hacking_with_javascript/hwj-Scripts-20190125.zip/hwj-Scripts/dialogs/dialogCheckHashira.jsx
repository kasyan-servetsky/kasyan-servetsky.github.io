﻿/**
 * @fileoverview InDesignファイルのリストを開き、変数の展開結果が登場順序と合致しているかどうかを調べる
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
*/

/*
    Copyright:
    2016 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2016 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"

var __previousval = null;
var __errs = [];

function normalize(s) {
  return String(s).replace(/[\t\r\n]/, "").replace(/\ufeff/g, "");
}

function getHashira(myDocument, orgname, num) {
  var tvs = myDocument.textVariables;
  if (tvs.length == 0) return;
  var tvs_names = [];
  for (var i = 0; i < tvs.length; i++) {
    tvs_names.push(tvs[i].name);
  }
  
  var wObj = app.dialogs.add({ name: "調査する柱テキスト変数 (" + num + ")" });
  var dList;
  with (wObj.dialogColumns.add(wObj.dialogColumns.add())) {
     with (dialogRows.add()) {
       staticTexts.add({staticLabel: orgname, minWidth: 150});
     }
     with (dialogRows.add()) {
       dList = dropdowns.add({stringList: tvs_names, selectedIndex: 0, minWidth: 150});
     }
  }

  if (__previousval == null) __previousval = tvs_names[0];
  for (var i = 0; i < tvs_names.length; i++) {
    if (__previousval == tvs_names[i]) {
      dList.selectedIndex = i;
      break;
    }
  }

  var data = [];
  var hits = null;
  app.findTextPreferences = NothingEnum.NOTHING;
  
  if (wObj.show() == true) {
    __previousval = tvs_names[dList.selectedIndex];
    // 適用スタイルを探す
    if (tvs[dList.selectedIndex].variableType == VariableTypes.MATCH_PARAGRAPH_STYLE_TYPE) {
      app.findTextPreferences.appliedParagraphStyle = tvs[dList.selectedIndex].variableOptions.appliedParagraphStyle;
      hits = myDocument.findText();
    } else if (tvs[dList.selectedIndex].variableType == VariableTypes.MATCH_CHARACTER_STYLE_TYPE) {
      app.findTextPreferences.appliedCharacterStyle = tvs[dList.selectedIndex].variableOptions.appliedCharacterStyle;
      hits = myDocument.findText();
    } else {
     alert(tvs[dList.selectedIndex].name + " は段落/文字スタイルに紐付いていません");
     return; // 次のドキュメントへ
    }
  } else {
    return; // キャンセルなら次のドキュメントへ
  }
  
  var backunit = toMmMode(myDocument);
  var backorigin = myDocument.viewPreferences.rulerOrigin;
  myDocument.viewPreferences.rulerOrigin = RulerOrigin.PAGE_ORIGIN;
  
  for (var i = 0; i < hits.length; i++) {
    var page = hits[i].characters[0].parentTextFrames[0].parentPage;
    if (page == null) continue;
    // [page, priority, contents]
    data.push([page.documentOffset, hits[i].characters[0].baseline * 1000 + hits[i].characters[0].horizontalOffset, normalize(hits[i].contents)]);
  }

  if (data.length == 0) return; // ヒットなし 
  
  data.sort(
    function(a, b) {
      var a1 = (a[0] * 1000000 + a[1]);
      var b1 = (b[0] * 1000000 + b[1]);
      if (a1 < b1) return -1;
      if (a1 > b1) return 1;
      return 0;
    }
  );
  
  var pages = [];
  var curv = null;
  
  for (var p = 0; p < myDocument.pages.length; p++) {
    for (var i = 0; i < data.length; i++) {
      if (data[i][0] == p) curv = i;
    }
    if (curv != null) break;
  }
  if (curv == null) return; // 頼りになる情報がなかった
  
  for (var p = 0; p < myDocument.pages.length; p++) {
    if (p > data[curv][0]) {
      for (var i = curv + 1; i < data.length; i++) { // 先を探索
        if (data[i][0] == p) curv = i;
      }
    }
    pages[p] = data[curv];
  }
  
  // 実際にテキストフレームを配置、左上なら大丈夫なはず
  for (var p = 0; p < myDocument.pages.length; p++) {
    var tf = myDocument.pages[p].textFrames.add({visibleBounds: [1, 1, 5, 120], contents: " "});
    tf.paragraphs[0].appliedParagraphStyle = myDocument.paragraphStyles[0];
    tf.paragraphs[0].appliedCharacterStyle = myDocument.characterStyles[0];
    tf.characters[0].textVariableInstances.add({associatedTextVariable: tvs[dList.selectedIndex]});
    var cont = normalize(tf.paragraphs[0].textVariableInstances[0].resultText);
    if (cont != "" && cont != pages[p][2]) {
      __errs.push(orgname + " : p." + myDocument.pages[p].name + ": 本来は「" + pages[p][2] + " 」しかし「 " + cont + "」");
    }
    tf.remove();
  }
  
  revertMmMode(myDocument, backunit);
  myDocument.viewPreferences.rulerOrigin = backorigin;
}

// メイン
showInteraction(true);
var filename = File.openDialog("IDファイルのマップファイル", "テキストファイル:*.txt,すべてのファイル:*" );
if (!filename) exit(0);
var fileObj = new File(filename);
if (fileObj.exists == false) exit(0);

var targets = [];
fileObj.open("r");
while (!fileObj.eof) {
  var fline = fileObj.readln();
  if (!fline.match(/^#/) && !fline.match(/^\s*$/)) {
    var flines = fline.split(/\s+/);
    if (flines.length < 1) {
      showInteraction(true);
      alert(fline + "の行が異常です。飛ばします。");
      continue;
    }
    targets.push(flines[0]);
  }
}

for (var i = 0; i < targets.length; i++) {
  showInteraction(false);
  var myDocument = app.open(targets[i], false, OpenOptions.OPEN_COPY);
  showInteraction(true);
  getHashira(myDocument, File(targets[i]).displayName, String(i+1) + "/" + targets.length);
  myDocument.close(SaveOptions.NO);
}
showInteraction(true);

if (__errs.length == 0) {
  alert("変数展開に問題はありませんでした。");
} else {
  alert("変数展開に問題あり\n" + __errs.join("\n"));
}
