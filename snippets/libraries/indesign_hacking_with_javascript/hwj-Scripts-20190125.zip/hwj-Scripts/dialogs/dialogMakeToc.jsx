/**
 * @fileoverview ファイルリストを開き、流し込みのための目次テキストを出力する。ページを通すこともできる
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
 * @requires libGetFrameIDs.jsx
*/

/*
    Copyright:
    2008 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"
#include "../libs/libGetFrameIDs.jsx"

app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;

var tocs = [];
var prevpage = 0;
var prevnmbl = "";

// 各行記述のファイルを開く

var filename = File.openDialog("目次ファイルリスト", "テキストファイル:*.txt,すべてのファイル:*" );
if (!filename) exit(0);

var fileObj = new File(filename);
if (fileObj.exists == false) exit(0);
fileObj.open("r");
app.scriptPreferences.userInteractionLevel = UserInteractionLevels.NEVER_INTERACT;
while (!fileObj.eof) {
  filename = fileObj.readln();
  if (!filename.match(/^#/) && !filename.match(/^\s*$/)) {
    var dtocs = processDocumentForToc(filename, prevpage, prevnmbl, false, true, false, false);
    var lastline = dtocs.pop().toString().split("\t");
    prevpage = lastline[0];
    prevnmbl = lastline[1];
    tocs = tocs.concat(dtocs);
  }
}
app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;
fileObj.close();

var loop = true;
do {
  filename = File.saveDialog("目次を保存するXMLファイル");
  if (filename) {
    fileObj = new File(filename);
    if (fileObj.exists == true) {
      var wObj = app.dialogs.add({ name: "ファイルが存在します" });
      var wtmp = wObj.dialogColumns.add();
      wtmp.staticTexts.add({staticLabel: filename + " はすでに存在します。上書きしますか?"});
      if (wObj.show() == false) continue;
    }
    fileObj.encoding = "UTF8";
	fileObj.lineFeed = "Unix";
    
    if (fileObj.open("w") == true) {
      var level = 3;
      var _level = prompt("拾う見出しレベル", level);
      if (_level.match(/^[0-9]+$/) == null) exit(0);
      level = parseInt(_level);
      exportTocXML(fileObj, tocs, level, true);
      fileObj.close();
      loop = false;
    } else {
      alert("ファイルを開けません。");
    }
  } else {
    loop = false;
  }
} while (loop == true);

/**
 * 目次配列からXMLを生成して出力する
 * @param {File} file ファイルオブジェクト
 * @param {String[]} tocs 目次配列
 * @param {Long} level 目次に掲載する深さ
 * @param {boolean} numorder タイトルとノンブルのどちらを先に記述するか (true=タイトル→ノンブル、false=ノンブル→タイトル)
 * @type Nothing
*/
function exportTocXML(file, tocs, level, numorder) {
  file.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<toc>");
  for (var i = 0; i < tocs.length; i++) {
    var items = tocs[i].toString().split("\t", 3);
    if (items.length < 3 || items[1] > level) continue;
    if (numorder == true) {
      file.write("<toc-h" + items[1] +  "><content>" + items[2] + "</content><tab>\t</tab><pageno>" + items[0] + "</pageno></toc-h" + items[1] + ">\n");
    } else {
      file.write("<toc-h" + items[1] +  "><pageno>" + items[0] + "</pageno><tab>\t</tab><content>" + items[2] + "</content></toc-h" + items[1] + ">\n");
    }
  }
  file.write("</toc>\n");
}

/**
 * ドキュメントを開き、指定レベルまでのタイトルを入れた配列を返す
 * @param {String} filename ファイル名
 * @param {Long} prevpage 1つ前のページ通し番号
 * @param {String} prevnmbl 1つ前のページノンブル文字列
 * @param {boolean} replace ページがずれているときに通し直す(true=通し直す、false=通し直さない)
 * @param {boolean} warnopen ファイルがすでに開かれているときに警告する(true=警告する、false=警告しない)
 * @param {boolean} warncont ページがずれているときに警告する(true=警告する、false=警告しない)
 * @param {boolean} warnwhite 右ページで終わっているときに白を入れるよう警告する(true=警告する、false=警告しない)
 * @type String[]
 * @return "ノンブル TAB レベル TAB タイトル"形式の配列。あとでXMLに変換される。最後に"最後のページのページ番号 TAB 最後のページのノンブル"が入る
*/
function processDocumentForToc(filename, prevpage, prevnmbl, replace, warnopen, warncont, warnwhite) {
  var file = new File(filename);
  if (file.exists == false) { // 存在チェック
    alert(filename + " というファイルがありません。");
    return [prevpage + "\t" + prevnmbl];
  }

/*
  for (var i = 0; i < app.documents.length; i++) { // 既存のオープンのチェック
    if (app.documents[i] == file) {
      if (warnopen) {
        alert(filename + "はすでに開かれています。一度このファイルを閉じてください。出力される目次ファイルは信用できないものとなるため、処理を中止します。");
        exit(0);
      } else {
        app.documents[i].close(SaveOptions.ask);
      }
    }
  }
*/
  
  var document = app.open(file);
  if (document == null) {
    alert(filename + " を開くのに何かの問題が発生しました。処理を中止します。");
    exit(0);
  }

  var p2s = getPagenumFromSection(document);
  var page = prevpage + document.pages.length;
  var nmbl = p2s[document.pages.length - 1];
  
  var arabicnmbl = (nmbl.toString().match(/^[0-9]+$/)) ? nmbl : roman2arabic(nmbl);
  
  var firstnmbl = p2s[document.pages[0].documentOffset];
  if (warncont || replace) {
    if (prevnmbl.toString().match(/^[0-9]+$/) && firstnmbl.toString().match(/^[0-9]+$/)) {
      // アラビア数字同士なら連続性チェック
      if (Number(prevnmbl) + 1 != Number(firstnmbl)) {
        if (warncont) {
          alert(filename + " はその前のファイルとノンブルが連続していません。" + (Number(prevnmbl) + 1) + "ページから開始すべきです。");
          exit(0);
        }
        document.pages[0].appliedSection.pageNumberStart = Number(prevnmbl) + 1; // FIXME
        document.save();
        p2s = getPagenumFromSection(document);
        nmbl = p2s[document.pages.length];
      }
    } // FIXME ローマ数字版
  }

  if (arabicnmbl % 2 == 1 && warnwhite) {
    alert(filename + " は偶数ページ(左)で終わっていません。白ページが必要と思われますが、処理を継続します。");
  }
  
  var tocs;
  if (getCSVersion() > 3) {
    tocs = processXMLforTOC(document, document.xmlElements, [], p2s);
  } else {
    tocs = processXMLforTOC(document, document.xmlItems, [], p2s);
  }
  try {
    document.close(SaveOptions.no);
  } catch (e) {
    alert(filename + " をクローズできませんでした。");
  }
  
  tocs.push([page + "\t" + nmbl]);
  
  return tocs;
}

/**
 * XMLインストラクションを検索して&lt;?dtp level="数値" section="文字列" ?&gt;形式のものを発見したら目次として配列に入れる
 * @param {Document} document ドキュメントオブジェクト
 * @param {XMLItems} items XMLItemsオブジェクト
 * @param {String} tocs 格納配列。呼び出し時は[]を指定する
 * @param {String[]) p2s getPagenumFromSectionから取得済みのページ/ノンブルの配列
 * @type String[]
 * @return 新しい格納配列
*/
function processXMLforTOC(document, items, tocs, p2s) {
  if (items == null || items.length == 0) {
    return tocs;
  }
  
  for (var i = 0; i < items.length; i++) {
    if (items[i].xmlInstructions != null && items[i].xmlInstructions.length > 0) {
      for (var i2 = 0; i2 < items[i].xmlInstructions.length; i2++) {
        var e = items[i].xmlInstructions[i2];
        
        if (e.target == "dtp") {
          if (e.data.search(/section/) != -1 && e.data.search(/level=/) != -1) {
             var sectname = e.data.match(/section="(.*?)"/)[1].replace("\t", "　");
             var level = parseInt(e.data.match(/level="(.*?)"/)[1]);
             var nmbl;
	     if (getCSVersion() == 2) {
	        nmbl = p2s[e.parent.parentStory.characters[e.storyOffset].insertionPoints[0].parentTextFrames[0].parent.documentOffset];
             } else {
               try {
	            nmbl = p2s[e.storyOffset.parentTextFrames[0].parentPage.documentOffset];
               } catch(e2) {
	            nmbl = p2s[e.storyOffset.parentTextFrames[0].parent.documentOffset];
              }
             }
             tocs.push([nmbl + "\t" + level + "\t" + sectname]);
          }
        }
      }
    }
    if (getCSVersion() > 3) {
      tocs = processXMLforTOC(document, items[i].xmlElements, tocs, p2s);
    } else {
      tocs = processXMLforTOC(document, items[i].xmlItems, tocs, p2s);
    }
  }
  return tocs;
}
