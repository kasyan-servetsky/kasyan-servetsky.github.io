﻿/**
 * @fileoverview 配置された数式画像のサイズおよびベースラインを調整する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2015 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2015 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
var myDocument = app.activeDocument;
var iostyle = app.activeDocument.objectStyles.item("inline-math"); // デフォルトインライン式スタイル
var eostyle = app.activeDocument.objectStyles.item("indep-math"); // デフォルト独立式スタイル
var Yoffset = 0;

if (iostyle == null) {
  alert("オブジェクトスタイル「inline-math」がありません。実行前に用意してください");
  exit(0);
}
if (eostyle == null) {
  alert("オブジェクトスタイル「indep-math」がありません。実行前に用意してください");
  exit(0);
}

var tf = myDocument.selection[0];
if (tf instanceof TextFrame) {
  if (confirm("テキストフレーム内の全数式に影響します。続けてもよいですか?", true, "数式の処理")) {
    var config = loadConfig();
    if (config != null) {
      var bunit = backUnit(myDocument);
      try {
        tweakImagePDF(myDocument, config, tf.parentStory, iostyle, eostyle, Yoffset);
      } catch(e) {
        alert(e);
      } finally {
        revertUnit(myDocument, bunit);
      }
      alert("完了しました。");
    }
  }
} else if (tf instanceof Text) {
  var config = loadConfig();
  if (config != null) {
    var bunit = backUnit(myDocument);
    try {
      for (var i = 0; i < tf.allPageItems.length; i++) { // 範囲選択
        if (tf.allPageItems[i] instanceof PDF) {
          tweakImagePDF(myDocument, config, tf.allPageItems[i].parent, iostyle, eostyle, Yoffset);
        }
      }
    } finally {
      revertUnit(myDocument, bunit);
    }
  }
} else if (tf instanceof Rectangle) {
  var config = loadConfig();
  if (config != null) {
    var bunit = backUnit(myDocument);
    try {
      for (var i = 0; i < myDocument.selection.length; i++) { // Rectangleなら複数指定可能…ではあるのだが実際には1つしかできないんだな
        tf = myDocument.selection[i];
        if (tf instanceof Rectangle) {
          tweakImagePDF(myDocument, config, tf, iostyle, eostyle, Yoffset);
        }
      }
    } finally {
      revertUnit(myDocument, bunit);
    }
  }
} else {
  alert("処理対象のテキストフレーム、または範囲、あるいは個別に設定する数式矩形を選択してください。");
}

/**
 * 位置情報ファイルを読み込む。ファイル名(PDF)・独立式か(空または1)・拡大率・ベースラインから下げる率・上書きオブジェクトスタイル名 をタブで区切ったもの。
 * @type String[]
 * @return 位置情報ハッシュ
*/
function loadConfig() {
  // 設定データを読み込み
  var config = [];
  var fObj = File.openDialog("数式位置設定ファイルを選択", "テキストファイル:*.txt,すべてのファイル:*");
  if (fObj == null) return null;
  fObj.open("r");
  while (!fObj.eof) {
    var l = fObj.readln();
    if (!l.match(/^#/) && !l.match(/^s*$/)) {
      var a = l.split("\t");
      for (var i = 0; i < a.length; i++) {
        if (a[i] == "") a[i] = null;
      }
      if (a[1] != null) a[1] = true; // float
      // filename = float, zoom, baseoffset, objectstyle
      config[a[0]] = [a[1], a[2], a[3], a[4]];
    }
  }
  fObj.close();
  return config;
}

/**
 * PDF数式を調整する
 * @param {Document} document ドキュメントオブジェクト
 * @param {String[]} config 位置情報ハッシュ
 * @param {PDF} target 対象PDF矩形
 * @param {ObjectStyle} iostyle インライン数式のオブジェクトスタイル
 * @param {ObjectStyle} eostyle 独立数式のオブジェクトスタイル
 * @param {Number} Yoffset 追加するベースラインオフセット比率(デフォルトは0)
 * @type Nothing
*/
function tweakImagePDF(document, config, target, iostyle, eostyle, Yoffset) {
  // progressbarの用意
  var wObj = new Window('window', '数式位置調整処理中');
  var max = target.allPageItems.length;
  with (wObj) {
    wObj.myProgressbar = add('progressbar', [12, 12, 200, 24], 0, max);
  }
  var pp = {
    'ProgressPanel': wObj,
    'show' : function() { this.ProgressPanel.show() },
    'hide' : function() { this.ProgressPanel.hide() },
    'max' : max,
    'barwidth' : 200,
    'val' : function(val) {
      if (typeof val == "undefined") return this.ProgressPanel.myProgressbar.value;
      this.ProgressPanel.myProgressbar.value = val + 1;
      this.show();
      this.hide();
      this.show();
     }
  }
  pp.show();
  
  for (var i=target.allPageItems.length - 1; i >= 0; i--) {
     if (target.allPageItems[i] instanceof PDF || target.allPageItems[i] instanceof EPS) {
       var pdf = target.allPageItems[i];
       var rect = pdf.parent;
       var pdfname = pdf.itemLink.name;
       if (config[pdfname] != null && rect.parent instanceof Character) {
         var basept = rect.parent.pointSize;
         if (config[pdfname][0] == true) {
           // 独立式の場合
           rect.appliedObjectStyle = eostyle;
         } else {
           // インライン式の場合
           rect.appliedObjectStyle = iostyle;
         }
         if (config[pdfname][3] != null && document.objectStyles.item(config[pdfname][3]) != null) {
           rect.appliedObjectStyle = config[pdfname][3];
         }

         if (config[pdfname][1] != null) {
           // リサイズ
           var unit = rect.visibleBounds;
           var rate = (basept * config[pdfname][1]) / (unit[2] - unit[0]);
           var myTrans = app.transformationMatrices.add();
           myTrans = myTrans.scaleMatrix(rate, rate);
           rect.transform(CoordinateSpaces.innerCoordinates, AnchorPoint.bottomLeftAnchor, myTrans);
           rect.fit(FitOptions.CONTENT_TO_FRAME);
         }
           
         if (config[pdfname][2] != null) {
           // ベースライン
           var unit = rect.visibleBounds;
           // ベースラインがずれている。1ptあたり0.12ptのベースラインずれ。
           rect.anchoredObjectSettings.anchorYoffset = (unit[2] - unit[0]) * config[pdfname][2]  - basept * 0.12 + Yoffset;
         }
           
          // アンカーを使うなら、全角スペースを後に入れて幅を調整する
          try {
           if (rect.anchoredObjectSettings.anchoredPosition != AnchorPosition.ANCHORED) continue;
         } catch(e) { continue; }

         try {
           var unit = rect.visibleBounds;
           var tc = rect.parent.parent.characters[rect.parent.index + 1];
           if (rect.parent.parent.characters.length == rect.parent.index + 1 || tc.contents != "　") {
             rect.parent.insertionPoints[-1].contents = "　";
             tc = rect.parent.parent.characters[rect.parent.index + 1];
           }
           var scale = (unit[3] - unit[1]) / basept * 100;
           if (scale > 1000) {
             for (var j = 1; j <= Math.floor(scale / 1000); j++) {
             tc.horizontalScale = 1000;
             rect.parent.insertionPoints[-1].contents = "　";
             tc = rect.parent.parent.characters[rect.parent.index + 1];
             }
             if (scale % 1000 > 1) {
               tc.horizontalScale = scale % 1000;
             } else {
                tc.remove();
             }
           } else {
             tc.horizontalScale = scale;
           }
         } catch(e) {
           alert("何かがおかしいです:" + i);
         }
       }
     }
     pp.val(max - i);
  }
  pp.hide();
}

/**
 * 単位系を保存する
 * @param {Document} document ドキュメントオブジェクト
 * @type Long[4]
 * @return 現在の単位配列
*/
function backUnit(document) {
  var bunit = [
    document.viewPreferences.horizontalMeasurementUnits,
    document.viewPreferences.verticalMeasurementUnits,
    document.viewPreferences.textSizeMeasurementUnits,
    document.viewPreferences.typographicMeasurementUnits
  ];

  document.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.POINTS;
  document.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS;
  document.viewPreferences.textSizeMeasurementUnits = MeasurementUnits.POINTS;
  document.viewPreferences.typographicMeasurementUnits = MeasurementUnits.POINTS;

  return bunit;
}

/**
 * 単位系を戻す
 * @param {Document} document ドキュメントオブジェクト
 * @param {Long[4]} unit 戻す単位配列
 * @type Nothing
*/
function revertUnit(document, bunit) {
  document.viewPreferences.horizontalMeasurementUnits = bunit[0];
  document.viewPreferences.verticalMeasurementUnits = bunit[1];
  document.viewPreferences.textSizeMeasurementUnits = bunit[2];
  document.viewPreferences.typographicMeasurementUnits = bunit[3];
}
