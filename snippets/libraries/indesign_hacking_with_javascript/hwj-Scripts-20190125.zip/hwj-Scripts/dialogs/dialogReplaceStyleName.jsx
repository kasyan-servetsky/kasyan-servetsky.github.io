﻿/**
 * @fileoverview 書き換え用にスタイル名の一覧をファイルに出力する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2013 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2013 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;

var myDocument;
if (app.documents.length > 0) myDocument = app.activeDocument;
var __plist = [];
var __clist = [];
var __olist = [];
var __tlist = [];
var __elist = [];

var __phash = [];
var __chash = [];
var __ohash = [];
var __thash = [];
var __ehash = [];

var labels = [" [スタイル出力] indbファイルから", " [スタイル出力] 現在開いている単一ドキュメントから", " [スタイル置換] indbファイルに対して", " [スタイル置換] 現在開いている単一ドキュメントに対して"];
var cc = new Array(labels.length);
var wObj = app.dialogs.add({name: "スタイル名の変更"});
with(wObj.dialogColumns.add()) {
  with (radiobuttonGroups.add()) {
    for (var i = 0; i < labels.length; i++) {
      cc[i] = radiobuttonControls.add({staticLabel: labels[i]});
    }
  }
}
cc[0].checkedState = true;
if (wObj.show() == false) exit(0);

switch(wObj.dialogColumns[0].radiobuttonGroups[0].selectedButton) {
  case 0: // indbから出力
    foreachIndb(true);
    break;
  case 1: // documentから出力
    if (myDocument != null) {
      getStyleFromDocument(myDocument);
      exportStyleList();
    }
    break;
  case 2: // indbで書き換え
    if (loadMap()) foreachIndb(false);
    break;
  case 3: // documentで書き換え
    if (loadMap()) setStyleToDocument(myDocument);
    break;
}

function loadMap() {
  var filename = File.openDialog("対応マップファイルを選択", "マップ:*.txt,すべてのファイル:*");
  if (!filename) return null;
  var fileObj = new File(filename);
  fileObj.open("r");
  while (!fileObj.eof) {
    var line = fileObj.readln();
    var type;
    if (line.match("!= PARAGRAPHSTYLES")) { type = "p"; continue; }
    if (line.match("!= CHARACTERSTYLES")) { type = "c"; continue; }
    if (line.match("!= OBJECTSTYLES")) { type = "o"; continue; }
    if (line.match("!= TABLESTYLES")) { type = "t"; continue; }
    if (line.match("!= CELLSTYLES")) { type = "e"; continue; }

    var pair = line.split("\t");
    if (pair.length < 2) continue;
    switch(type) {
      case "p":
        __phash[pair[0]] = pair[1];
        break;
      case "c":
        __chash[pair[0]] = pair[1];
        break;
      case "o":
        __ohash[pair[0]] = pair[1];
        break;
      case "t":
        __thash[pair[0]] = pair[1];
        break;
      case "e":
        __ehash[pair[0]] = pair[1];
        break;
    }
  }
  return true;
}

function setStyleToDocument(document) {
  setParagraphStyleList(document, "");
  setCharacterStyleList(document, "");
  setObjectStyleList(document, "");
  setTableStyleList(document, "");
  setCellStyleList(document, "");
}

function foreachIndb(type) {
  var filename = File.openDialog("ブックを選択", "ブック:*.indb,すべてのファイル:*");
  if (!filename) return null;
  var fileObj = new File(filename);
  var myBook;
  for (var i = 0; i < app.books.length; i++) {
    if (app.books[i].fullName + "" == filename) {
      myBook = app.books[i];
      break;
    }
  }
  if (myBook == null) myBook = app.open(fileObj, true);

  for (var i = 0; i < myBook.bookContents.length; i++) {
    var file = myBook.bookContents[i].fullName;
    app.scriptPreferences.userInteractionLevel = UserInteractionLevels.NEVER_INTERACT;
    var myDocument = app.open(file);
    app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;

    if (type == true) { // 出力
      getStyleFromDocument(myDocument);
      myDocument.close(SaveOptions.ask);     
    } else { // 置換
      setStyleToDocument(myDocument);
      myDocument.close(SaveOptions.YES);
    }
  }

  if (type == true) exportStyleList();
}

function getParagraphStyleList(group, prefix) {
  for (var i = 0; i < group.paragraphStyleGroups.length; i++) {
    if (__phash[prefix + group.paragraphStyleGroups[i].name] == null) {
      __phash[prefix + group.paragraphStyleGroups[i].name] = "yes";
      __plist.push(prefix + group.paragraphStyleGroups[i].name);
    }
    getParagraphStyleList(group.paragraphStyleGroups[i], prefix + group.paragraphStyleGroups[i].name + "<<>>");
  }
  var pstyles = group.paragraphStyles;
  for (var i = 0; i < pstyles.length; i++) {
    var stylename = pstyles[i].name;
    if (!skipName(stylename) && __phash[prefix + stylename] == null) {
      __phash[prefix + stylename] = "yes";
      __plist.push(prefix + stylename);
    }
  }
}

function getCharacterStyleList(group, prefix) {
  for (var i = 0; i < group.characterStyleGroups.length; i++) {
    if (__chash[prefix + group.characterStyleGroups[i].name] == null) {
      __chash[prefix + group.characterStyleGroups[i].name] = "yes";
      __clist.push(prefix + group.characterStyleGroups[i].name);
    }
    getCharacterStyleList(group.characterStyleGroups[i], prefix + group.characterStyleGroups[i].name + "<<>>");
  }
  var cstyles = group.characterStyles;
  for (var i = 0; i < cstyles.length; i++) {
    var stylename = cstyles[i].name;
    if (!skipName(stylename) && __chash[prefix + stylename] == null) {
      __chash[prefix + stylename] = "yes";
      __clist.push(prefix + stylename);
    }
  }
}

function getObjectStyleList(group, prefix) {
  for (var i = 0; i < group.objectStyleGroups.length; i++) {
    if (__ohash[prefix + group.objectStyleGroups[i].name] == null) {
      __ohash[prefix + group.objectStyleGroups[i].name] = "yes";
      __olist.push(prefix + group.objectStyleGroups[i].name);
    }
    getObjectStyleList(group.objectStyleGroups[i], prefix + group.objectStyleGroups[i].name + "<<>>");
  }
  var ostyles = group.objectStyles;
  for (var i = 0; i < ostyles.length; i++) {
    var stylename = ostyles[i].name;
    if (!skipName(stylename) && __ohash[prefix + stylename] == null) {
      __ohash[prefix + stylename] = "yes";
      __olist.push(prefix + stylename);
    }
  }
}

function getTableStyleList(group, prefix) {
  for (var i = 0; i < group.tableStyleGroups.length; i++) {
    if (__thash[prefix + group.tableStyleGroups[i].name] == null) {
      __thash[prefix + group.tableStyleGroups[i].name] = "yes";
      __tlist.push(prefix + group.tableStyleGroups[i].name);
    }
    getTableStyleList(group.tableStyleGroups[i], prefix + group.tableStyleGroups[i].name + "<<>>");
  }
  var tstyles = group.tableStyles;
  for (var i = 0; i < tstyles.length; i++) {
    var stylename = tstyles[i].name;
    if (!skipName(stylename) && __thash[prefix + stylename] == null) {
      __thash[prefix + stylename] = "yes";
      __tlist.push(prefix + stylename);
    }
  }
}

function getCellStyleList(group, prefix) {
  for (var i = 0; i < group.cellStyleGroups.length; i++) {
    if (__ehash[prefix + group.cellStyleGroups[i].name] == null) {
      __ehash[prefix + group.cellStyleGroups[i].name] = "yes";
      __elist.push(prefix + group.cellStyleGroups[i].name);
    }
    getCellStyleList(group.cellStyleGroups[i], prefix + group.cellStyleGroups[i].name + "<<>>");
  }
  var estyles = group.cellStyles;
  for (var i = 0; i < estyles.length; i++) {
    var stylename = estyles[i].name;
    if (!skipName(stylename) && __ehash[prefix + stylename] == null) {
      __ehash[prefix + stylename] = "yes";
      __elist.push(prefix + stylename);
    }
  }
}

function skipName(stylename) {
  var skips = ["[段落スタイルなし]", "[基本段落]", "[なし]", "[基本グラフィックフレーム]", "[基本テキストフレーム]", "[基本グリッド]", "[表スタイルなし]", "[基本表]"];
  for (var i = 0; i < skips.length; i++) {
    if (skips[i] == stylename) return true;
  }
  return false;
}

function getStyleFromDocument(document) {
  getParagraphStyleList(document, "");
  getCharacterStyleList(document, "");
  getObjectStyleList(document, "");
  getTableStyleList(document, "");
  getCellStyleList(document, "");  
}

function exportStyleList() {
  var fileObj;
  var filename = File.saveDialog("出力マップファイル");
  if (filename) {
    file = new File(filename);
    file.encoding = "UTF8";
    file.lineFeed = "Unix";
    if (file.open("w") != true) return null;

    file.write("!= PARAGRAPHSTYLES\n");
    for (var i = 0; i < __plist.length; i++) file.write(__plist[i] + "\t\n");
    file.write("\n!= CHARACTERSTYLES\n");
    for (var i = 0; i < __clist.length; i++) file.write(__clist[i] + "\t\n");
    file.write("\n!= OBJECTSTYLES\n");
    for (var i = 0; i < __olist.length; i++) file.write(__olist[i] + "\t\n");
    file.write("\n!= TABLESTYLES\n");
    for (var i = 0; i < __tlist.length; i++) file.write(__tlist[i] + "\t\n");
    file.write("\n!= CELLSTYLES\n");
    for (var i = 0; i < __elist.length; i++) file.write(__elist[i] + "\t\n");
    file.close();
  }
}

function setParagraphStyleList(group, prefix) {
  for (var i = 0; i < group.paragraphStyleGroups.length; i++) {
    if (__phash[prefix + group.paragraphStyleGroups[i].name] != null) {
      setParagraphStyleList(group.paragraphStyleGroups[i], prefix + group.paragraphStyleGroups[i].name + "<<>>");
      group.paragraphStyleGroups[i].name = __phash[prefix + group.paragraphStyleGroups[i].name].replace(/.+<<>>/, "");
    }
  }
  var pstyles = group.paragraphStyles;
  for (var i = 0; i < pstyles.length; i++) {
    var stylename = pstyles[i].name;
    if (__phash[prefix + stylename] != null) {
      pstyles[i].name = __phash[prefix + stylename].replace(/.+<<>>/, "");
    }
  }
}

function setCharacterStyleList(group, prefix) {
  for (var i = 0; i < group.characterStyleGroups.length; i++) {
    if (__chash[prefix + group.characterStyleGroups[i].name] != null) {
      setCharacterStyleList(group.characterStyleGroups[i], prefix + group.characterStyleGroups[i].name + "<<>>");
      group.characterStyleGroups[i].name = __chash[prefix + group.characterStyleGroups[i].name].replace(/.+<<>>/, "");
    }
  }
  var cstyles = group.characterStyles;
  for (var i = 0; i < cstyles.length; i++) {
    var stylename = cstyles[i].name;
    if (__chash[prefix + stylename] != null) {
      cstyles[i].name = __chash[prefix + stylename].replace(/.+<<>>/, "");
    }
  }
}

function setObjectStyleList(group, prefix) {
  for (var i = 0; i < group.objectStyleGroups.length; i++) {
    if (__ohash[prefix + group.objectStyleGroups[i].name] != null) {
      setObjectStyleList(group.objectStyleGroups[i], prefix + group.objectStyleGroups[i].name + "<<>>");
      group.objectStyleGroups[i].name = __ohash[prefix + group.objectStyleGroups[i].name].replace(/.+<<>>/, "");
    }
  }
  var ostyles = group.objectStyles;
  for (var i = 0; i < ostyles.length; i++) {
    var stylename = ostyles[i].name;
    if (__ohash[prefix + stylename] != null) {
      ostyles[i].name = __ohash[prefix + stylename].replace(/.+<<>>/, "");
    }
  }
}

function setTableStyleList(group, prefix) {
  for (var i = 0; i < group.tableStyleGroups.length; i++) {
    if (__thash[prefix + group.tableStyleGroups[i].name] != null) {
      setTableStyleList(group.tableStyleGroups[i], prefix + group.tableStyleGroups[i].name + "<<>>");
      group.tableStyleGroups[i].name = __thash[prefix + group.tableStyleGroups[i].name].replace(/.+<<>>/, "");
    }
  }
  var tstyles = group.tableStyles;
  for (var i = 0; i < tstyles.length; i++) {
    var stylename = tstyles[i].name;
    if (__thash[prefix + stylename] != null) {
      tstyles[i].name = __thash[prefix + stylename].replace(/.+<<>>/, "");
    }
  }
}

function setCellStyleList(group, prefix) {
  for (var i = 0; i < group.cellStyleGroups.length; i++) {
    if (__ehash[prefix + group.cellStyleGroups[i].name] != null) {
      setCellStyleList(group.cellStyleGroups[i], prefix + group.cellStyleGroups[i].name + "<<>>");
      group.cellStyleGroups[i].name = __ehash[prefix + group.cellStyleGroups[i].name].replace(/.+<<>>/, "");
    }
  }
  var estyles = group.cellStyles;
  for (var i = 0; i < estyles.length; i++) {
    var stylename = estyles[i].name;
    if (__ehash[prefix + stylename] != null) {
      estyles[i].name = __ehash[prefix + stylename].replace(/.+<<>>/, "");
    }
  }
}

