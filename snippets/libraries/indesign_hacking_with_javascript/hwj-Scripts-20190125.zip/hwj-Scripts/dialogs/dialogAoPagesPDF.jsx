﻿/**
 * @fileoverview 開いているドキュメントのタグを残したまま、単ページで複数ページのPDFを保存する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
 * @requires libArabic2Roman.jsx
*/

/*
    Copyright:
    2016 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2012-2016 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"
#include "../libs/libArabic2Roman.jsx"

/**
 * 指定ノンブルの単一PDFを作成する
 * @param {Document} document ドキュメントオブジェクト
 * @param {String} nmbl ノンブル文字列
 * @param {String} dir 書き込みフォルダ
 * @param {PdfPreset} preset PDFプリセット
 * @param {String[]} エラー文字列配列
 * @type String[]
 * @return errors文字列配列
*/
function exportSinglePDF(document, nmbl, dir, preset, aonametxt, errors) {
  nmbl = String(nmbl);
  if (document.pages.item(nmbl) != null) {
    var doc1Obj = new File(dir + "/" + document.name.replace(/\.indd$/, aonametxt + "p" + nmbl + ".pdf"));
    app.pdfExportPreferences.pageRange = nmbl;
    try {
       document.exportFile(ExportFormat.PDF_TYPE, doc1Obj, false, preset);
    } catch (e) { errors.push(nmbl + "*"); }
  } else {
    // 該当ページなし
    errors.push(nmbl + "?");
  }
  return errors;
}

var defaultpresetname = "INDD_PDF+X-1a2001";
var defaultaoname = "-ao-";
var setArray = readHwjStateFile(getHwjStateFileObj("dialogAoPagesPDF"));
if (setArray != null) {
  defaultpresetname = setArray[0];
  if (setArray.length >= 2) {
    defaultaoname = setArray[1];
  }
}

var myDocument = app.activeDocument;
// プリセットダイアログ
var defaultpreset = 0;
var wObj = app.dialogs.add({ name: "単ページPDFの出力" });

var pdfpresets = new Array(), pspresets = new Array();
for (var i = 0; i < app.pdfExportPresets.length; i++) {
  pdfpresets[i] = app.pdfExportPresets.item(i).name;
  if (pdfpresets[i] == defaultpresetname) defaultpreset = i;
}
var pdflist, untag, aoname;
var untagstate = false;
with (wObj.dialogColumns.add(wObj.dialogColumns.add())) {
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "PDFプリセット", minWidth: 120});
    pdflist = dropdowns.add({stringList:pdfpresets, selectedIndex: defaultpreset});
    untag = checkboxControls.add({staticLabel: "XMLタグ削除", checkedState:false});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "ファイル名<指定文字列>pXX.pdf", minWidth: 120});
    aoname = textEditboxes.add({editContents: defaultaoname, minWidth: 70});
  }
}
if (wObj.show() == false) exit(0);

singlepreset = app.pdfExportPresets.item(pdflist.selectedIndex);
if (singlepreset == null) {
  alert("プリセットがありません");
  exit(0);
}
writeHwjStateFile(getHwjStateFileObj("dialogAoPagesPDF"), [singlepreset.name, aoname.editContents]);

// PDFファイルの保存
// PDF保存パスを探索
var path = new Folder(myDocument.filePath).getFiles("*-PDF");
if (path.length == 0) path = new Folder(myDocument.filePath.parent).getFiles("*-PDF");

if (path.length > 0) {
  var pages = prompt("ノンブル指定(,で区切るか、-で範囲指定可能)", "");
  var parray = pages.split(/\s*,\s*/);
  var errors = [];
  
  if (untag == true && myDocument.xmlElements.length > 0 && myDocument.xmlElements[0].xmlElements.length > 0) {
    myDocument.xmlElements.item(0).xmlElements.everyItem().untag();
  } else {
     untag = null;
  }

  for (var i = 0; i < parray.length; i++) {
    if (parray[i].match("-")) {
      // 範囲
      p2array = parray[i].split("-");
      if (p2array[0].match(/^\d+$/) && p2array[1].match(/^\d+$/)) {
        // アラビア数字
        for (var j = p2array[0]; j <= p2array[1]; j++) {
          errors = exportSinglePDF(myDocument, j, path[0], singlepreset, aoname.editContents, errors);
        }
      } else if (roman2arabic(p2array[0]) > 0 && roman2arabic(p2array[1]) > 0) {
        // ローマ数字
        for (var j = roman2arabic(p2array[0]); j <= roman2arabic(p2array[1]); j++) {
          errors = exportSinglePDF(myDocument, arabic2roman(j), path[0], singlepreset, aoname.editContents, errors);
        }
      }
    } else {
      errors = exportSinglePDF(myDocument, parray[i], path[0], singlepreset, aoname.editContents, errors);
    }
  }
} else {
  alert("*-PDFのフォルダが見つかりません。「out-PDF」など適当なフォルダを作成してください。");
  exit(0);
}
app.pdfExportPreferences.pageRange = PageRange.ALL_PAGES;
var msg = "";
if (errors.length > 0) {
  msg = "\n以下のページは存在しない(?が付いているページ)か、PDF生成に問題(*が付いているページ)がありました：" + errors.join(", ");
}

if (untag) {
  myDocument.undo();
}
alert("完了しました。" + msg);
