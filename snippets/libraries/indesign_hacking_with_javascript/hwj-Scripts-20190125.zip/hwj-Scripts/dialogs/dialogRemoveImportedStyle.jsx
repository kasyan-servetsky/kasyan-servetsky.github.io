﻿var myDocument = app.activeDocument;

// 段落スタイルを削除
tps = [];
var pstyles = myDocument.paragraphStyles;
for (var i = 0; i < pstyles.length; i++) {
  if (pstyles[i].imported) {
    tps.push(pstyles[i]);
  }
}

for (var i = tps.length - 1; i >= 0; i--) {
   tps[i].remove(myDocument.paragraphStyles[0]);
}

// 文字スタイルグループを削除
var cgroup = myDocument.characterStyleGroups.item("Word/RTF 読み込みリストのスタイル");
cgroup.remove();
// 本当は置換が必要
