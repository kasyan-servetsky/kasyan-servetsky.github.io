﻿/**
 * @fileoverview マスターページの見開きで左右要素のずれを検出する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
*/

/*
    Copyright:
    2016 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2012-2016 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"

var myDocument;
if (confirm("複製で確認しますか? (「いいえ」を選ぶと、このドキュメントの内容は破壊されます)")) {
  // 「はい」にしたときには複製ファイルを作り、それを開く
  var _myDocument = app.activeDocument;
  var myFile = File(new String(_myDocument.fullName).replace(/\.\w+$/, "-mastercheck.indd"));
  _myDocument.saveACopy(myFile);
  try {
    showInteraction(false);
    myDocument = app.open(myFile);
  } finally {
    showInteraction(true);
  }
} else {
  // 「いいえ」にしたときには直接開いているファイルを書き換える
  myDocument = app.activeDocument;
}

for (var i = myDocument.pages.length - 1; i > 0; i--) {
  myDocument.pages[i].remove();
}
myDocument.pages.add();
myDocument.pages[0].remove();

myDocument.pages[0].appliedSection.continueNumbering = false;
myDocument.pages[0].appliedSection.pageNumberStart = 2;
myDocument.pages.add();
var firstsp = true;

var backunit = toMmMode(myDocument);
var rulerOrigin = myDocument.viewPreferences.rulerOrigin;
myDocument.viewPreferences.rulerOrigin = RulerOrigin.SPREAD_ORIGIN;

// マスターページの数だけ実ページを用意
try {
  for (var i = 0; i < myDocument.masterSpreads.length; i++) {
    var sp = myDocument.masterSpreads[i];
    if (sp.pages.length == 1) continue;

    if (firstsp) {
      firstsp = null;
    } else {
      myDocument.pages.add();
      myDocument.pages.add();
    }

    var lp = myDocument.pages[myDocument.pages.length - 2];
    var rp = myDocument.pages[myDocument.pages.length - 1];
    lp.appliedMaster = sp;
    rp.appliedMaster = sp;
  
    drawMasterItemsNote(myDocument, lp, rp, sp);
  }
} finally {
  revertMmMode(myDocument, backunit);
  myDocument.viewPreferences.rulerOrigin = rulerOrigin;
}

/**
 * 四捨五入する
 * @param {Number} val 数値
 * @param {Number} base いったん掛ける数(1=整数になる。100=小数点以下2桁になる)
 * @type Number
 * @return 四捨五入した値
*/
function simpleRound(val, base) {
  return Math.round(val * base) / base;
}

/**
 * 配列の各要素を四捨五入する
 * @param {Number} unit[] 数値配列
 * @param {Number} base いったん掛ける数(1=整数になる。100=小数点以下2桁になる)
 * @type Number
 * @return 四捨五入した値の配列
*/
function roundUnit(unit, base) {
  for (var i = 0; i < unit.length; i++) {
    unit[i] = simpleRound(unit[i], base);
  }
  return unit;
}

/**
 * テキストフレームの最初の段落の寄せ指定の文字列を返す
 * @param {TextFrame} tf テキストフレーム
 * @type String
 * @return 寄せ指定の文字列
*/
function getJustification(tf) {
  if (tf instanceof TextFrame && tf.paragraphs.length == 1) {
    switch (tf.paragraphs[0].justification) {
      case Justification.CENTER_ALIGN:
      case Justification.CENTER_JUSTIFIED:
        return " [中央]";
      case Justification.LEFT_ALIGN:
      case Justification.LEFT_JUSTIFIED:
      case Justification.FULLY_JUSTIFIED:
        return " [左]";
      case Justification.RIGHT_ALIGN:
      case Justification.RIGHT_JUSTIFIED:
        return " [右]";
      case Justification.AWAY_FROM_BINDING_SIDE:
      return " [小口]";
      default: return " [合わせ不定]" + tf.paragraphs[0].justification;
    }
  }
  return "";
}

/**
 * 座標キャプションの仮の位置を取得する
 * @param {Rectangle} item 対象オブジェクト(GraphicLineのこともある)
 * @param {Page} page ページオブジェクト
 * @param {Number} centerY 上下中央のY座標
 * @type Number
 * @return キャプションの仮の位置配列
*/
function getCaptionLocation(item, page, centerY) {
  var unit = roundUnit(item.visibleBounds, 100);
  if (unit[0] > centerY) {
    // 下側なので上にキャプション
    unit[0] = unit[0] - 3;
    if (unit[0] < 1) unit[0] = 1;
    unit[2] = unit[0] + 3;
    if (unit[1] < 1) unit[1] = 1; 
    unit[3] = unit[1] + 100;
  } else {
    // 上側なので下にキャプション
    unit[0] = unit[2] + 1;
    if (unit[0] > page.bounds[2] - 1 - 3) unit[0] = page.bounds[2] - 1 - 3;
    unit[2] = unit[0] + 3;
    if (unit[1] < 1) unit[1] = 1; 
    unit[3] = unit[1] + 100;
  }
  return unit;
}

/**
 * 座標キャプションを配置する
 * @param {String} id ID文字列
 * @param {Page} page ページオブジェクト
 * @param {Number} unit[] 位置
 * @param {String} contents キャプション文字列
 * @param {Color} color 色オブジェクト
 * @type TextFrame
 * @return キャプションのテキストフレームオブジェクト
*/
function setCaption(id, page, unit, contents, color) {
  var itemtxt = page.textFrames.add({name: id, label: id, visibleBounds: unit});
  itemtxt.contents = " ";
  itemtxt.paragraphs[0].appliedParagraphStyle = page.parent.parent.paragraphStyles[0];
  itemtxt.paragraphs[0].appliedCharacterStyle = page.parent.parent.characterStyles[0];;
  itemtxt.paragraphs[0].appliedFont = "小塚ゴシック Pro";
  itemtxt.paragraphs[0].pointSize = "9Q";
  itemtxt.contents = contents;
  itemtxt.fit(FitOptions.FRAME_TO_CONTENT);
  itemtxt.fit(FitOptions.FRAME_TO_CONTENT); // 2回やらないと効かないことがある
  return itemtxt;
}

/**
 * オブジェクトを罫線で囲む
 * @param {String} id ID文字列
 * @param {Page} page ページオブジェクト
 * @param {Rectangle} item 対象オブジェクト(GraphicLineのこともある)
 * @param {Color} color 色オブジェクト
 * @type Rectangle
 * @return 罫線のオブジェクト
*/
function surroundItem(id, page, item, color) {
  var rect;
  try {
    item.visibleBounds;
  } catch(e) { return null; } // たぶんガイド
  try {
    if (item instanceof GraphicLine) {
      rect = page.graphicLines.add({name: id, label: id, appliedObjectStyle: page.parent.parent.objectStyles[0], geometricBounds: item.geometricBounds,  strokeWeight: "0.5mm", strokeColor: color});
    } else {
      rect = page.rectangles.add({name: id, label: id, appliedObjectStyle: page.parent.parent.objectStyles[0], visibleBounds: item.visibleBounds,  strokeWeight: "0.5mm", strokeColor: color});
    }
  } catch(e) {}; // GraphicLine、Rectangle以外は無視してnullを返す
  return rect;
}

/**
 * キャプションが重ならないように地図で調整する
 * @param {Number} map[] マップ配列
 * @param {Number} bounds[] 右端を調べるための境界配列(右ページのbounds)
 * @param {Number} unit[] 対象オブジェクトの初期座標配列
 * @param {centerY} centerY 上下中央のY座標
 * @type Number
 * @return 調整した座標配列とマップ配列の配列
*/
function setMap(map, bounds, unit, centerY) {
  var dp = 2.5;
  var mapW = Math.ceil(bounds[3] / dp);
  var x1 = Math.floor(unit[1] / dp);
  var x2 = Math.ceil(unit[3] / dp);
  var y = Math.ceil(unit[0] / dp);
  var cy = Math.floor(centerY / dp);
  var origy = y;

  while(true) {
    var res = false;
    for (var x = x1; x <= x2; x++) {
      if (map[mapW * y + x] != null) {
        res = true;
        break;
      }
    }
    if (res == false) { // 空いていたので文字数分を予約
      for (var x = x1; x <= x2; x++) {
        map[mapW * y + x] = "reserved";
      }
      break; // OK
    } else {
      if (cy <= y) {   // 下側なので上にシフト
        if (y == cy) { // 達成できなかったら戻してあきらめる
          y = origy;
          break;
        }
        y--;
      } else { // 上側なので下にシフト
        y++;
      }
    }
  }

  if (y != origy) {
    var h = unit[2] - unit[0];
    unit[0] = y * dp;
    unit[2] = unit[0] + h;
  }
  
  return [unit, map];
}

/**
 * マスターページの各要素の座標を計算し、左右見開きでのずれを確認する。両方が正しく合う位置(小数点2桁以内誤差許容)にあれば緑、お互い四捨五入して合えば黄色(計算誤差の可能性もある)、大きくずれているか片側にしか存在しなければ赤で囲んで表示する。
 * @param {Document} document ドキュメントオブジェクト
 * @param {Page} lp 左ページ
 * @param {Page} rp 右ページ
 * @param {MasterSpread} sp マスターページスプレッド
 * @type Nothing
*/
function drawMasterItemsNote(document, lp, rp, sp) {
  var centerY = lp.bounds[2] / 2;
  var map = [];
  
  // スウォッチ作成
  if (document.swatches.item("__okcolor") == null) {
    document.colors.add({name: "__okcolor", colorValue: [75, 0, 100, 0]});
  }
  var okcolor = document.swatches.item("__okcolor");
  
  if (document.swatches.item("__unknowncolor") == null) {
    document.colors.add({name: "__unknowncolor", colorValue: [75, 100, 100, 0]});
  }
  var unknowncolor = document.swatches.item("__unknowncolor");

  if (document.swatches.item("__maybecolor") == null) {
    document.colors.add({name: "__maybecolor", colorValue: [0, 50, 100, 15]});
  }
  var maybecolor = document.swatches.item("__maybecolor");

  if (document.swatches.item("__badcolor") == null) {
    document.colors.add({name: "__badcolor", colorValue: [15, 100, 100, 0]});
  }
  var badcolor = document.swatches.item("__badcolor");

  // 左ページ調査
  var lpobj = [];
  for (var i = 0; i < lp.masterPageItems.length; i++) {
    var item = lp.masterPageItems[i];
    var rect = surroundItem("__rect-l-" + i, lp, item, unknowncolor);
    lpobj[i] = new Object;
    lpobj[i].item = rect;
    if (rect == null) continue; // たぶんガイド
    var unit = getCaptionLocation(item, lp, centerY);
    var itemunit = roundUnit(item.visibleBounds, 100);
    var itemtxt = setCaption("__text-l-" + i, lp, unit, "X:" + itemunit[1] + ", Y:" + itemunit[0] + ", W:" + simpleRound(itemunit[3] - itemunit[1], 100) + ", H:" + simpleRound(itemunit[2] - itemunit[0], 100) + getJustification(item), unknowncolor);
    lpobj[i].roundbox = [simpleRound(itemunit[1], 100), simpleRound(itemunit[0], 100), simpleRound(itemunit[3] - itemunit[1], 100), simpleRound(itemunit[2] - itemunit[0], 100)];
    lpobj[i].moreroundbox = roundUnit([simpleRound(itemunit[1], 100), simpleRound(itemunit[0], 100), simpleRound(itemunit[3] - itemunit[1], 100), simpleRound(itemunit[2] - itemunit[0], 100)], 1);
    unit = itemtxt.visibleBounds;
    if (itemtxt.visibleBounds[3] >= lp.bounds[3]) {
      var w = unit[3] - unit[1];
      unit[1] = lp.bounds[3] - 1 - w;
      unit[3] = unit[1] + w;
    }
    var array = setMap(map, rp.bounds, unit, centerY);
    unit = array[0];
    map = array[1];
    itemtxt.visibleBounds = unit;
  }

  // 右ページ調査
  var rpbounds = roundUnit(rp.bounds, 100);
  var rpobj = [];

  for (var i = 0; i < rp.masterPageItems.length; i++) {
    var item = rp.masterPageItems[i];
    var rect = surroundItem("__rect-r-" + i, rp, item, unknowncolor);
    rpobj[i] = new Object;
    rpobj[i].item = rect;
    if (rect == null) continue; // たぶんガイド
    var unit = getCaptionLocation(item, rp, centerY);
    var itemunit = roundUnit(item.visibleBounds, 100);
    var itemtxt = setCaption("__text-r-" + i, rp, unit, "X:" + simpleRound(itemunit[3] - rpbounds[3], 100) + ", Y:" + itemunit[0] + ", W:" + simpleRound(itemunit[3] - itemunit[1], 100) + ", H:" + simpleRound(itemunit[2] - itemunit[0], 100) + getJustification(item), unknowncolor);
    rpobj[i].roundbox = [simpleRound(itemunit[3] - rpbounds[3], 100), simpleRound(itemunit[0], 100), simpleRound(itemunit[3] - itemunit[1], 100), simpleRound(itemunit[2] - itemunit[0], 100)];
    rpobj[i].moreroundbox = roundUnit([simpleRound(itemunit[3] - rpbounds[3], 100), simpleRound(itemunit[0], 100), simpleRound(itemunit[3] - itemunit[1], 100), simpleRound(itemunit[2] - itemunit[0], 100)], 1);
    
    // 右寄せに
    var unit = itemtxt.visibleBounds;
    var w = unit[3] - unit[1];
    unit[1] = item.visibleBounds[3] - w;
    unit[3] = unit[1] + w;
    if (unit[3] > rp.bounds[3] - 1) {
      // はみ出している
      unit[1] = rp.bounds[3] - 1 - w;
      unit[3] = unit[1] + w;
    }
    
    if (unit[1] <= rp.bounds[1]) {
      // 左にいきすぎたのを戻す
      unit[1] = rp.bounds[1] + 1 - w;
      unit[3] = unit[1] + w;
    }
    var array = setMap(map, rp.bounds, unit, centerY);
    unit = array[0];
    map = array[1];
    itemtxt.visibleBounds = unit;
  }

  // マスタースプレッドの名前を配置
  var spname = lp.textFrames.add({visibleBounds: [centerY, (lp.bounds[3] - lp.bounds[1]) / 2, centerY + 10, lp.bounds[3]]});
  spname.contents = sp.name;
  spname.paragraphs[0].appliedFont = "小塚ゴシック Pro";
  spname.paragraphs[0].pointSize = "24Q";
  spname.fit(FitOptions.FRAME_TO_CONTENT);
  
  checkDifference(lpobj, rpobj, okcolor, maybecolor, badcolor);
}

/**
 * 左側オブジェクトと右側オブジェクトを比較し、座標のずれを調べて適宜色を変更する
 * @param {Object} lpobj 左ページ側オブジェクト
 * @param {Object} rpobj 右ページ側オブジェクト
 * @param {Color} okcolor 合致したときの色
 * @param {Color} maybecolor 2mm以内で合致したときの色
 * @param {Color} badcolor 大きくずれているか片側にしかないときの色
 * @type Nothing
*/
function checkDifference(lpobj, rpobj, okcolor, maybecolor, badcolor) {
  // 左のものが右にあるか
  for (var i = 0; i < lpobj.length; i++) {
    if (lpobj[i].item == null) continue;
    for (var j = 0; j < rpobj.length; j++) {
      if (rpobj[j].item == null || rpobj[j].checked == true) continue;
      // 完全一致
      if (rpobj[j].roundbox[0] * - 1 == lpobj[i].roundbox[0] &&
          rpobj[j].roundbox[1] == lpobj[i].roundbox[1] &&
          rpobj[j].roundbox[2] == lpobj[i].roundbox[2] &&
          rpobj[j].roundbox[3] == lpobj[i].roundbox[3]) {
        rpobj[j].checked = true;
        lpobj[i].checked = true;
        rpobj[j].item.strokeColor = okcolor;
        lpobj[i].item.strokeColor = okcolor;
        rpobj[j].item.parent.textFrames.item(rpobj[j].item.label.replace("rect-", "text-")).paragraphs[0].fillColor = okcolor;
        lpobj[i].item.parent.textFrames.item(lpobj[i].item.label.replace("rect-", "text-")).paragraphs[0].fillColor = okcolor;
        break;
      } else if (rpobj[j].moreroundbox[0] * - 1 == lpobj[i].moreroundbox[0] &&
          rpobj[j].moreroundbox[1] == lpobj[i].moreroundbox[1] &&
          rpobj[j].moreroundbox[2] == lpobj[i].moreroundbox[2] &&
          rpobj[j].moreroundbox[3] == lpobj[i].moreroundbox[3]) {
        rpobj[j].checked = true;
        lpobj[i].checked = true;
        rpobj[j].item.strokeColor = maybecolor;
        lpobj[i].item.strokeColor = maybecolor;
        rpobj[j].item.parent.textFrames.item(rpobj[j].item.label.replace("rect-", "text-")).paragraphs[0].fillColor = maybecolor;
        lpobj[i].item.parent.textFrames.item(lpobj[i].item.label.replace("rect-", "text-")).paragraphs[0].fillColor = maybecolor;
        break;
      }
    }
    if (lpobj[i].checked == null) {
      lpobj[i].item.strokeColor = badcolor;
      lpobj[i].item.parent.textFrames.item(lpobj[i].item.label.replace("rect-", "text-")).paragraphs[0].fillColor = badcolor;
    }
  }

  // 右のものが左にあるか…というのは調べる必要がない
  for (var i = 0; i < rpobj.length; i++) {
    if (rpobj[i].item == null) continue;
    if (rpobj[i].checked == null) {
      rpobj[i].item.strokeColor = badcolor;
      rpobj[i].item.parent.textFrames.item(rpobj[i].item.label.replace("rect-", "text-")).paragraphs[0].fillColor = badcolor;
    }
  }
}
