/**
 * @fileoverview 選択したテキストフレームをサブフレームを含めてテキスト化してファイルに出力する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2008 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"

var myDocument = app.activeDocument;

if (myDocument.selection.length != 1 || !myDocument.selection[0] instanceof TextFrame) {
  alert("テキストフレームを選択してください。");
  exit(0);
}

var loop = true;
do {
  var filename = File.saveDialog("XMLテキストを保存するファイル");
  if (filename) {
    var fileObj = new File(filename);
    if (fileObj.exists == true) {
      var wObj = app.dialogs.add({ name: "ファイルが存在します" });
      var wtmp = wObj.dialogColumns.add();
      wtmp.staticTexts.add({staticLabel: filename + " はすでに存在します。上書きしますか?"});
      if (wObj.show() == false) continue;
    }
      
    if (fileObj.open("w") == true) {
      fileObj.write("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n<doc>");
      storyToTag(fileObj, myDocument.selection[0].parentStory, null, null, null);
      fileObj.write("</doc>\n");
      fileObj.close();
      loop = false;
    } else {
      alert("ファイルを開けません。");
    }
  } else {
    loop = false;
  }
} while (loop == true);

/**
 * スタイル範囲データのテキスト部分をタグ付きで出力する
 * @param {StyleRange} content スタイル範囲オブジェクト
 * @type String
 * @return テキスト文字列
*/
function parseContentOfRange(content) {
  var s = "";
  if (content.characters.length == 1) {
    var c;
    try {
      c = content.characters[0].contents.charCodeAt(0);
    } catch (e) {
      // Enumeration
      return "<special code='" + Number(content.characters[0].contents) + "' />";
    }
  }
  
  if (content.contents.match(String.fromCharCode(0xfffc))) {
    for (var i = 0; i < content.characters.length; i++) {
      var c = content.characters[i];
      try {
        if (c.contents.charCodeAt(0) == 65532) {
          // Anchoredオブジェクト
          if (c.allGraphics.length > 0) {
            if (c.allGraphics[0].itemLink.filePath != "") {
              s += "<Image href='" + c.allGraphics[0].itemLink.filePath + "'/>";
            } else { 
              s += "<!-- Image / -->";
            }
          }
          continue;
        }
      } catch (e) {
        s += "<special code='" + Number(c.contents) + "' />";
        continue;
      }
      s += c.contents.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    return s;
  } else {
      return content.contents.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
}

/**
 * 指定のストーリーのテキスト部分をタグ付きでファイルに保存する
 * @param {File} fileObj 保存ファイルオブジェクト
 * @param {Story} story ストーリーオブジェクト
 * @param {ParagraphStyle} prepstyle 事前段落スタイル(呼び出し時はnull)
 * @param {CharacterStyle} precstyle 事前文字スタイル(呼び出し時はnull)
 * @param {Font} prefstyle 事前フォント(呼び出し時はnull)
 * @type Nothing
*/
function storyToTag(fileObj, story, prepstyle, precstyle, prefstyle) {
  var ranges = story.textStyleRanges;
  var s = "";
  
  for (var i = 0; i < ranges.length; i++) {
    pstyle = ranges[i].appliedParagraphStyle;
    cstyle = ranges[i].appliedCharacterStyle;
    fstyle = ranges[i].appliedFont;

    contents = parseContentOfRange(ranges[i]).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    
    if (pstyle != prepstyle) {
      // 段落スタイルの変化
      if (prepstyle != null) {
        if (prefstyle != null) {
          s+= "</" + prefstyle.fontFamily.replace(/ /g, ".") + ">";
          prefstyle = null;
        }
        if (precstyle != null) {
          s+= "</" + precstyle.name.replace(/\//g, "-") + ">";
          precstyle = null;
        }
        s += "</" + prepstyle.name.replace(/\//g, "-") + ">";
      }
      s += "<" + pstyle.name.replace(/\//g, "-") + ">" + contents;
      prepstyle = pstyle;
    } else if (cstyle != null && cstyle.name != "[なし]" && cstyle != precstyle) {
      // 文字スタイルの変化
      if (precstyle != null) {
         s+= "</" + precstyle.name.replace(/\//g, "-") + ">";
      }
      s += "<" + cstyle.name.replace(/\//g, "-") + ">" + contents;
      precstyle = cstyle;
    } else if (fstyle != null && fstyle != prefstyle) {
      if (prefstyle != null) {
        s+= "</" + prefstyle.fontFamily.replace(/ /g, ".") + ">";
      }
      s +=  "<" + fstyle.fontFamily.replace(/ /g, ".") + ">" + contents;
      prefstyle = fstyle;
    } else {
      s += contents;
    }
    
    fileObj.write(s);
    s = "";
  }

  s = "";
  if (prefstyle != null) {
    s+= "</" + prefstyle.fontFamily.replace(" ", ".") + ">";
    prefstyle = null;
  }
  if (precstyle != null) {
    s+= "</" + precstyle.name.replace("/", "-") + ">";
    precstyle = null;
  }
  s += "</" + prepstyle.name.replace("/", "-") + ">";
  
  fileObj.write(s);
}
