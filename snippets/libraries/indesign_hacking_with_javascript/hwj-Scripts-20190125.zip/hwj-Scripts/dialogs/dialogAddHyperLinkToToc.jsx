﻿/**
 * @fileoverview 目次のテキストフレームを選択し、ブックの情報を基にノンブルからのハイパーリンクを付ける
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libArabic2Roman.jsx
*/

/*
    Copyright:
    2012 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2012 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libArabic2Roman.jsx"
__icount = 0;

var myDocument = app.activeDocument;
var obj = new Object();

if (!(myDocument.selection[0] instanceof TextFrame)) {
  alert("目次テキストのあるテキストフレームを選択してください。");
  exit(0);
}
var tf = myDocument.selection[0];

var filename = File.openDialog("ブックを選択", "ブック:*.indb,すべてのファイル:*");
if (!filename) exit(0);
var fileObj = new File(filename);
if (fileObj.exists == false) exit(0);
var link = loadLinkDataFromBook(fileObj);

if (confirm("既存のハイパーリンクを削除してよいですか?(特別なことがなければ「はい」を推奨)")) {
  cleanUpHyperlink(myDocument);
}

app.findGrepPreferences = NothingEnum.NOTHING;
var fail = [];

// ~yは右寄せタブ
app.findGrepPreferences.findWhat = "(?<=\\t|~y)[ 　]*[ivx\\d, 〜-]+[ 　]*$"; // TODO:後にくっつくパターン
var matchwords = tf.parentStory.findGrep(true);
foreachAddHyperlink(matchwords, obj);

// 全角空白区切りの場合
app.findGrepPreferences.findWhat = "(?<!\\n|\\r|\\t|~y)[ 　]+[ivx\\d, 〜-]+[ 　]*$";
var matchwords = tf.parentStory.findGrep(true);
foreachAddHyperlink(matchwords, obj);

if (confirm("これは索引のハイパーリンク作業ですか? (折り返した索引のリンク付けをします)")) {
  app.findGrepPreferences.findWhat = "^[ 　]*[ivx\\d, 〜-]+[ 　]*$"; // 2行目索引パターン
  var matchwords = tf.parentStory.findGrep(true);
  foreachAddHyperlink(matchwords, obj);
}

if (fail.length > 0) {
  alert("ハイパーリンクの埋め込みを完了しましたが、" + fail.length + "個の参照を解決できませんでした。\n" + fail.join(", "));
} else {
  alert("ハイパーリンクの埋め込みを完了しました。");
}

function foreachAddHyperlink(matchwords, obj) {
  for (var i0 = 0; i0 < matchwords.length; i0++) {
    app.findGrepPreferences.findWhat = "[ivx]+";
    var matches = matchwords[i0].findGrep(true);
    for (var i = 0; i < matches.length; i++) {
      if (link["p" + matches[i].contents] != null) {
        addHyperlink(myDocument, matches[i], matches[i].paragraphs[0].contents.replace(/[\r\n]/, ""), link, obj);
      } else {
        fail.push("p." + matches[i].contents);
      }
    }
    app.findGrepPreferences.findWhat = "\\d+"; // TODO:リファクタリング
    var matches = matchwords[i0].findGrep(true);
    for (var i = 0; i < matches.length; i++) {
      if (link["p" + matches[i].contents] != null) {
        addHyperlink(myDocument, matches[i], matches[i].paragraphs[0].contents.replace(/[\r\n]/, ""), link, obj);
      } else {
        if (link["p" + matches[i].contents.replace(/^0+/, "")] != null) {
          addHyperlink(myDocument, matches[i], matches[i].paragraphs[0].contents.replace(/[\r\n]/, ""), link, obj);
        } else {
          fail.push("p." + matches[i].contents);
        }
      }
    }
  }
}

function addHyperlink(document, targetword, linkdesc, link, obj) {
  // ハイパーリンクの埋め込み
  var array;
  if (link["p" + targetword.contents] != null) {
    array = link["p" + targetword.contents].split("\t");
  } else {
    array = link["p" + targetword.contents.replace(/^0+/, "")].split("\t");
  }
  var file = array[0];
  var page = Number(array[1]);

  try {
    var h_s = document.hyperlinkTextSources.add(targetword, {label: "tmp-auto-h" + __icount});
    var h_d;
    if (document.fullName == file) {
      h_d = document.hyperlinkPageDestinations.add(undefined, {destinationPage: document.pages[page - 1], name: targetword.contents + "-i" + __icount, label: "tmp-auto-i" + __icount});
    } else {
      h_d = document.hyperlinkExternalPageDestinations.add(undefined, {documentPath: new File(file), destinationPageIndex: page, name: targetword.contents + "-e" + __icount, label: "tmp-auto-e" + __icount});
    }
    document.hyperlinks.add(h_s, h_d, {label: "tmp-auto-l" + __icount , visible: false, name: linkdesc + "-l" + __icount});
  } catch (e) { /* OK? */ }
  __icount++;
}

function loadLinkDataFromBook(file) {
  // データの読み込み(ブック)
  try {
    var myBook = app.open(file, true);
  } catch(e) {
    alert("いったんブックを閉じてください。");
    exit(0);
  }
  var link = [];
  for (var i = 0; i < myBook.bookContents.length; i++) {
    var file = myBook.bookContents[i].fullName;
    var range = myBook.bookContents[i].documentPageRange;
    // i-iv, 10-20
    var array = range.split("-");
    if (array.length > 2) {
      alert("ブック内の" + file + "のノンブルが奇妙です。中止します。\n" + rannge);
      exit(0);
    }
    if (array.length == 2) {
      if (array[0].match(/^[0-9]+$/)) {
        var start = Number(array[0]);
        var end = Number(array[1]);
        for (var i2 = start; i2 <= end; i2++) { 
          link["p" + i2] = file + "\t" + (i2 - start + 1);
        }
      } else { // ローマ数字
        var start = roman2arabic(array[0]);
        var end = roman2arabic(array[1]);
        for (var i2 = start; i2 <= end; i2++) { 
          link["p" + arabic2roman(i2)] = file + "\t" + (i2 - start + 1);
        }
      }
    } else {
      // 1ページのみ
      link["p" + range] = file + "\t1";
    }
  }
  // myBook.close(SaveOptions.NO);
  return link;
}

function cleanUpHyperlink(document) {
  // ハイパーリンクの解除
  for (var i = document.hyperlinks.length - 1; i >= 0; i--) {
    if (document.hyperlinks[i].source instanceof HyperlinkTextSource) {
      if (document.hyperlinks[i].label.match(/tmp\-auto/) ||
        document.hyperlinks[i].source.sourceText.contents.match(/\t[\s　]*[ivx]+\s*$/) ||
        document.hyperlinks[i].source.sourceText.contents.match(/\t[\s　]*\d+\s*$/)) {
      document.hyperlinks[i].remove();
      }
    }
  }
  for (var i = document.hyperlinkExternalPageDestinations.length - 1; i >= 0; i--) {
    if (document.hyperlinkExternalPageDestinations[i].label.match(/tmp\-auto/)) {
      document.hyperlinkExternalPageDestinations[i].remove();
    }
  }
  for (var i = document.hyperlinkPageDestinations.length - 1; i >= 0; i--) {
    if (document.hyperlinkPageDestinations[i].label.match(/tmp\-auto/)) {
      document.hyperlinkPageDestinations[i].remove();
    }
  }
  for (var i = document.hyperlinkTextSources.length - 1; i >= 0; i--) {
    if (document.hyperlinkTextSources[i].label.match(/tmp\-auto/) ||
      document.hyperlinkTextSources[i].name.match(/^\.\d+/)) {
      document.hyperlinkTextSources[i].remove();
    }
  }
}
