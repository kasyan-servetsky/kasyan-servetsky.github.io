/**
 * @fileoverview フォルダ内のInDesignファイルを再帰的に検索し、IDX、テキスト、PDF、PS、RTF、XMLに変換する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2009 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2009 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
app.scriptPreferences.userInteractionLevel = UserInteractionLevels.interactWithAll;
var inputfolder = Folder.selectDialog("変換元フォルダの指定");
if (inputfolder == null) exit(0);
var savefolder = Folder.selectDialog("変換先フォルダの指定");
if (savefolder == null) exit(0);

var wObj = app.dialogs.add({ name:"InDesignファイル変換／保存"});
var textoutput = true;
var rtfoutput = true;
var pdfoutput = false;
var psoutput = false;
var xmloutput = false;
var inxoutput = false;
var saveoutput = false;
var removeindex = true;
var limitcount = 20;
var textoutputButton;
var rtfoutputButton;
var pdfoutputButton;
var psoutputButton;
var xmloutputButton;
var inxoutputButton;
var saveoutputButton;
var removeindexButton;
var pspresetBox;
var textlimit;

with(wObj.dialogColumns.add()) {
  with(dialogRows.add()) {
     staticTexts.add({staticLabel:"変換元フォルダ", minWidth: 120});
     staticTexts.add({staticLabel:inputfolder.absoluteURI, minWidth: 180});
   }
   with(dialogRows.add()) {
     staticTexts.add({staticLabel:"変換元フォルダ", minWidth: 120});
     staticTexts.add({staticLabel:savefolder.absoluteURI, minWidth: 180});
   }
   with(dialogRows.add()) {
     textoutputButton = checkboxControls.add({staticLabel:"テキスト", checkedState:textoutput});
     rtfoutputButton = checkboxControls.add({staticLabel:"RTF", checkedState:rtfoutput});
     pdfoutputButton = checkboxControls.add({staticLabel:"PDF", checkedState:pdfoutput});
     psoutputButton = checkboxControls.add({staticLabel:"Postcript", checkedState:psoutput});
     xmloutputButton = checkboxControls.add({staticLabel:"XML(experimental)", checkedState:xmloutput});
     inxoutputButton = checkboxControls.add({staticLabel:"INX", checkedState:inxoutput});
     saveoutputButton = checkboxControls.add({staticLabel:"保存し直し(事前処理用、排他)", checkedState:saveoutput});
   }

  with(dialogRows.add()) {
     var pnames = [];
     for (var i = 0; i < app.printerPresets.length; i++) pnames.push(app.printerPresets[i].name);
     staticTexts.add({staticLabel:"PS出力時のプリセット", minWidth: 120});
     pspresetBox = dropdowns.add({stringList: pnames, selectedIndex:0});
   }
   with(dialogRows.add()) {
     removeindexButton = checkboxControls.add({staticLabel:"索引を除去(RTF)", checkedState:removeindex});
   }
   with(dialogRows.add()) {
     staticTexts.add({staticLabel:"テキスト/RTF/XML出力時にこの文字数以上のテキスト領域から抽出", minWidth: 120});
     textlimit = textEditboxes.add({editContents:String(limitcount)});
   }
}
if (wObj.show() == false) exit(0);

var count = 0;
// 実処理
if (saveoutputButton.checkedState == true) {
  openInputFolder(inputfolder, function(file) { openAndSave(file); });
} else {
  if (textoutputButton.checkedState == true) openInputFolder(inputfolder, function(file) { saveText(file); });
  if (rtfoutputButton.checkedState == true) openInputFolder(inputfolder, function(file) { saveRTF(file); });
  if (pdfoutputButton.checkedState == true) openInputFolder(inputfolder, function(file) { savePDF(file); });
  if (psoutputButton.checkedState == true) openInputFolder(inputfolder, function(file) { savePS(file); });
  if (xmloutputButton.checkedState == true) openInputFolder(inputfolder, function(file) { saveXML(file); });
  if (inxoutputButton.checkedState == true) openInputFolder(inputfolder, function(file) { saveINX(file); });
}
alert(count + "個のファイルを処理しました。");

// ジェネリックな再帰呼び出し
function openInputFolder(folder, action) {
  var list = folder.getFiles();
  for (var i = 0; i < list.length; i++) {
    if (list[i] instanceof Folder) {
      openInputFolder(list[i], action);
    } else if (list[i] instanceof File && list[i].name.match(/.(indd|inx)$/i)) {
      count++;
      action(list[i]);
    }
  }
}

function filename(file, ext) {
  var array = file.absoluteURI.split("/");
  return array[array.length - 1].replace(/\.(indd|inx)$/i, ext);
}

function openAndSave(file) {
  var myDocument = app.open(file, false);
  if (myDocument.modified == true) myDocument.save();
  myDocument.close(SaveOptions.YES);
}

function saveRTF(file) {
  var myDocument = app.open(file, false);
  // 索引除去
  if (removeindexButton.checkedState == true) {
    for (var i = 0; i < myDocument.indexes.length; i++) {
      while (myDocument.indexes[i].topics.length > 0) {
        myDocument.indexes[i].topics.firstItem().remove();
      }
    }
  }
  // テキスト分解
  for (var i = 0; i < myDocument.stories.length; i++) {
    if (myDocument.stories[i].contents.length > Number(textlimit.editContents)) {
      myDocument.stories[i].exportFile(ExportFormat.RTF, File(savefolder.absoluteURI + "/" + filename(file, "-" + (i + 1) + ".rtf")));
    }
  }
  myDocument.close(SaveOptions.NO);
}

function saveText(file) {
  var myDocument = app.open(file, false);
  var table = 1;
  // テキスト分解
  for (var i = 0; i < myDocument.stories.length; i++) {
    if (myDocument.stories[i].contents.length > Number(textlimit.editContents)) {
      myDocument.stories[i].exportFile(ExportFormat.TEXT_TYPE, File(savefolder.absoluteURI + "/" + filename(file, "-" + (i + 1) + ".txt")));
    }
    for (var i2 = 0; i2 < myDocument.stories[i].tables.length; i2++) {
      var t = myDocument.stories[i].tables[i2].contents;
      if (t instanceof Array) {
        if (t.join("").length > Number(textlimit.editContents)) {
          fileObj = File(savefolder.absoluteURI + "/" + filename(file, "-t" + (table) + ".txt"));
	  table++;
          fileObj.encoding = "UTF8";
          fileObj.lineFeed = "Windows";
          fileObj.open("w");
	  for (var i3 = 0; i3 < t.length; i3++) {
            fileObj.writeln(t[i3]);
	  }
          fileObj.close();
        }
      } else {
        if (t.length > Number(textlimit.editContents)) {
          fileObj = File(savefolder.absoluteURI + "/" + filename(file, "-t" + (table) + ".txt"));
	  table++;
          fileObj.encoding = "UTF8";
          fileObj.lineFeed = "Windows";
          fileObj.open("w");
          fileObj.writeln(t);
          fileObj.close();
        }
      }
    }
  }
  myDocument.close(SaveOptions.NO);
}

function savePDF(file) {
  var myDocument = app.open(file, false);
  myDocument.exportFile(ExportFormat.PDF_TYPE, File(savefolder.absoluteURI + "/" + filename(file, ".pdf")));
  myDocument.close(SaveOptions.NO);
}

function saveINX(file) {
  var myDocument = app.open(file, false);
  myDocument.exportFile(ExportFormat.INDESIGN_INTERCHANGE, File(savefolder.absoluteURI + "/" + filename(file, ".inx")));
  myDocument.close(SaveOptions.NO);
}

function savePS(file) {
  var myDocument = app.open(file, false);
  var mypreset = app.printerPresets.item(pspresetBox.selectedIndex);
  mypreset.printFile = File(savefolder.absoluteURI + "/" + filename(file, ".ps"));
  myDocument.print(false, mypreset);
  myDocument.close(SaveOptions.NO);
}

function saveXML(file) {
  var myDocument = app.open(file, false);
  // テキスト分解
  for (var i = 0; i < myDocument.stories.length; i++) {
    if (myDocument.stories[i].contents.length > Number(textlimit.editContents)) {
      fileObj = File(savefolder.absoluteURI + "/" + filename(file, "-" + (i + 1) + ".xml"));
      fileObj.encoding = "UTF8";
      fileObj.lineFeed = "Unix";
      fileObj.open("w");
      fileObj.write("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n<doc>");
      storyToTag(fileObj, myDocument.stories[i], null, null, null);
      fileObj.write("</doc>\n");
      fileObj.close();
    }
  }
  myDocument.close(SaveOptions.NO);
}

/**
 * スタイル範囲データのテキスト部分をタグ付きで出力する
 * @param {StyleRange} content スタイル範囲オブジェクト
 * @type String
 * @return テキスト文字列
*/
function parseContentOfRange(content) {
  var s = "";
  if (content.characters.length == 1) {
    var c;
    try {
      c = content.characters[0].contents.charCodeAt(0);
    } catch (e) {
      // Enumeration
      return "<special code='" + Number(content.characters[0].contents) + "' />";
    }
  }
  
  if (content.contents.match(String.fromCharCode(0xfffc))) {
    for (var i = 0; i < content.characters.length; i++) {
      var c = content.characters[i];
      try {
        if (c.contents.charCodeAt(0) == 65532) {
          // Anchoredオブジェクト
          if (c.allGraphics.length > 0) {
            if (c.allGraphics[0].itemLink.filePath != "") {
              s += "<Image href='" + c.allGraphics[0].itemLink.filePath + "'/>";
            } else { 
              s += "<!-- Image / -->";
            }
          }
          continue;
        }
      } catch (e) {
        s += "<special code='" + Number(c.contents) + "' />";
        continue;
      }
      s += c.contents.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    return s;
  } else {
      return content.contents.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
}

function xsub(s) {
  return s.replace(/ /g, ".").replace(/\//g, "-")
}

/**
 * 指定のストーリーのテキスト部分をタグ付きでファイルに保存する
 * @param {File} fileObj 保存ファイルオブジェクト
 * @param {Story} story ストーリーオブジェクト
 * @param {ParagraphStyle} prepstyle 事前段落スタイル(呼び出し時はnull)
 * @param {CharacterStyle} precstyle 事前文字スタイル(呼び出し時はnull)
 * @param {Font} prefstyle 事前フォント(呼び出し時はnull)
 * @type Nothing
*/
function storyToTag(fileObj, story, prepstyle, precstyle, prefstyle) {
  var ranges = story.textStyleRanges;
  var s = "";
  
  for (var i = 0; i < ranges.length; i++) {
    pstyle = ranges[i].appliedParagraphStyle;
    cstyle = ranges[i].appliedCharacterStyle;
    fstyle = ranges[i].appliedFont;

    contents = parseContentOfRange(ranges[i]).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    
    if (pstyle != prepstyle) {
      // 段落スタイルの変化
      if (prepstyle != null) {
        if (prefstyle != null) {
          s+= "</" + xsub(prefstyle.fontFamily) + ">";
          prefstyle = null;
        }
        if (precstyle != null) {
          s+= "</" + xsub(precstyle.name) + ">";
          precstyle = null;
        }
        s += "</" + xsub(prepstyle.name) + ">";
      }
      s += "<" + xsub(pstyle.name) + ">" + contents;
      prepstyle = pstyle;
    } else if (cstyle != null && cstyle.name != "[なし]" && cstyle != precstyle) {
      // 文字スタイルの変化
      if (precstyle != null) {
         s+= "</" + xsub(precstyle.name) + ">";
      }
      s += "<" + xsub(cstyle.name) + ">" + contents;
      precstyle = cstyle;
    } else if (fstyle != null && fstyle != prefstyle) {
      if (prefstyle != null) {
        s+= "</" + xsub(prefstyle.fontFamily) + ">";
      }
      s +=  "<" + xsub(fstyle.fontFamily) + ">" + contents;
      prefstyle = fstyle;
    } else {
      s += contents;
    }
    
    fileObj.write(s);
    s = "";
  }

  s = "";
  if (prefstyle != null) {
    s+= "</" + xsub(prefstyle.fontFamily) + ">";
    prefstyle = null;
  }
  if (precstyle != null) {
    s+= "</" + xsub(precstyle.name) + ">";
    precstyle = null;
  }
  s += "</" + xsub(prepstyle.name) + ">";
  
  fileObj.write(s);
}
