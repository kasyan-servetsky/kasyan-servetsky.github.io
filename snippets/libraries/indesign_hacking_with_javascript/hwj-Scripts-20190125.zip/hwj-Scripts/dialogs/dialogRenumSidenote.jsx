/**
 * @fileoverview 特定段落・文字スタイルの番号をリフレッシュする。リセット段落スタイルに出会ったら番号をリセットする
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2013 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2013 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
var myDocument = app.activeDocument;
var obj = new Object;

// 登場したら連番をリセットする段落スタイル
obj.sectionpstyle = myDocument.paragraphStyles.item("節タイトル");

// 本文側
// 対象の文字スタイル
obj.anchorcstyle = myDocument.characterStyles.item("＊");
// 対象の正規表現
obj.anchorregex = "＊\\d+";
// 置換時に数字の前に付ける記号
obj.anchorprefix = "＊";

// 側注側
// 対象の文字スタイル
obj.targetcstyle = null;
// 対象の段落スタイル群
obj.targetpstyles = [
  myDocument.paragraphStyles.item("ノーマル"),
  myDocument.paragraphStyles.item("脚注"),
  myDocument.paragraphStyles.item("ひとこと文")
];
// 対象の文字スウォッチ
obj.targetswatch = myDocument.swatches.item("M100");
// 対象の正規表現
obj.targetregex = "＊\\d+";
// 置換時に数字の前に付ける記号
obj.targetprefix = "＊";

// 以下は固定
obj.document = myDocument;
obj.sectionpageOffsets = [];
obj.anchornum = 0;
obj.anchorPreviousPage = -1;
obj.targetnum = 0;
obj.targetPreviousOffset = -1;
obj.targetPreviousPage = -1;

renumSidenote(obj);

function getPage(tf) {
   // ページオブジェクトを取得
   var p;
   try {
     p = tf.parentPage;
   } catch(e) {
     p = tf.parent;
   }
   if (p instanceof Page) return p;

   if (p instanceof Group) {
     if (p.parent instanceof Page) return p.parent;
   }
   
   alert("ページオブジェクトを取得できません。" + p);
   return null;
}

function renumSidenote(obj) {
  app.findGrepPreferences = NothingEnum.NOTHING;
  // 節タイトルの登場ページを記録
  if (obj.sectioncstyle != null) app.findGrepPreferences.appliedCharacterStyle = obj.sectioncstyle;
  if (obj.sectionpstyle != null) app.findGrepPreferences.appliedParagraphStyle = obj.sectionpstyle;
  var hits = obj.document.findGrep();

  for (var i = 0; i < hits.length; i++) {
    var p = getPage(hits[i].parentTextFrames[0]);
    obj.sectionpageOffsets[p.documentOffset] = true;
  }

  // 本文側
  obj.cstyle = obj.anchorcstyle;
  obj.pstyles = obj.anchorpstyles;
  obj.regex = obj.anchorregex;
  obj.swatch = obj.anchorswatch;
  obj.previousPage = -1;
  obj.num = obj.anchornum;
  obj.prefix = obj.anchorprefix;
  obj.sort = true;
  _renumSidenoteCommon(obj);
  obj.anchornum = obj.num;

  // 側注側
  obj.cstyle = obj.targetcstyle;
  obj.pstyles = obj.targetpstyles;
  obj.regex = obj.targetregex;
  obj.swatch = obj.targetswatch;
  obj.previousPage = -1;
  obj.num = obj.targetnum;
  obj.prefix = obj.targetprefix;
  obj.sort = true;
  _renumSidenoteCommon(obj);
  obj.targetnum = obj.num;
}

function _renumSidenoteCommon(obj) {
  app.findGrepPreferences = NothingEnum.NOTHING;
  if (obj.cstyle != null) app.findGrepPreferences.appliedCharacterStyle = obj.cstyle;
  if (obj.swatch != null) app.findGrepPreferences.fillColor = obj.swatch;
  if (obj.regex != null) app.findGrepPreferences.findWhat = obj.regex;
  var hits;

  if (obj.pstyles != null) {
    app.findGrepPreferences.appliedParagraphStyle = obj.pstyles[0];
    hits = obj.document.findGrep();
    for (var i = 1; i < obj.pstyles.length; i++) {
      app.findGrepPreferences.appliedParagraphStyle = obj.pstyles[i];
      hits = hits.concat(obj.document.findGrep());
    }
  } else {
    hits = obj.document.findGrep();
  }

  if (obj.sort == true) {
    // X、Yオフセットに基いてソートする
    obj.pageInfo = [];
    for (var i = 0; i < hits.length; i++) {
      var p = getPage(hits[i].parentTextFrames[0]);
      var page = p.documentOffset;
      var xoffset = hits[i].characters[0].horizontalOffset;
      var yoffset = hits[i].characters[0].baseline;
      if (obj.pageInfo[page] == null) obj.pageInfo[page] = [];
      obj.pageInfo[page].push([hits[i], xoffset, yoffset]);
    }
    for (var i = 0; i < obj.document.pages.length; i++) {
      if (obj.sectionpageOffsets[i] == true) obj.num = 0; // 節タイトルなのでリセット
      if (obj.pageInfo[i] != null) {
        obj.pageInfo[i].sort(
          function(a, b) {
            if (a[2] < b[2]) return -1;
              if (a[2] > b[2]) return 1;
              if (a[1] < b[1]) return -1;
              if (a[1] > b[1]) return 1;
              return 0;
           }
        );
        for (var i2 = 0; i2 < obj.pageInfo[i].length; i2++) {
          obj.num++;
          obj.pageInfo[i][i2][0].contents = obj.prefix + obj.num;
       }
     }
   }
  } else {
    // 何も考えない置換。配置によってはずれる
    for (var i = 0; i < hits.length; i++) {
      var p = getPage(hits[i].parentTextFrames[0]);
      var page = p.documentOffset;
      for (var i2 = obj.previousPage + 1; i2 <= page; i2++) {
        if (obj.sectionpageOffsets[i2] == true) obj.num = 0; // 節タイトルなのでリセット
      }
      obj.num++;
      hits[i].contents = obj.prefix + obj.num;
      obj.previousPage = page;
    }
  }
}
