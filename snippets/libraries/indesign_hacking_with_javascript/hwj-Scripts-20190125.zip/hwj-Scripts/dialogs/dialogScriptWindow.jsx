/**
 * @fileoverview APFSで順序が狂ってしまうスクリプトウィンドウの代替品
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2017 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2017 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#targetengine "hwjscriptwindow"
var scripts;
var treeobj = [];
var itemobj = [];
var win = new Window("palette", "SCRIPT", undefined, {resizeable: true});
win.preferredSize = [200, 200];
var fontobj = ScriptUI.newFont(win.graphics.font.family, win.graphics.font.style, 9); // default 13. but it seems ignored.

win.reload_button = win.add("button", undefined, "RELOAD");
win.reload_button.graphics.font = fontobj;
win.reload_button.onClick = function() { makeTree() };
win.tree_root = win.add("treeview", undefined, undefined);
win.tree_root.graphics.font = fontobj;
win.tree_root.size = [200 - 30, 200 - 80];
win.tree_root.onDoubleClick = function() { itemDoubleClickHandler() };
win.onResize = function() { win.tree_root.size = [win.frameSize[0] -30, win.frameSize[1] - 80]; }
makeTree();
win.show();

function itemDoubleClickHandler() {
  if (itemobj[win.tree_root.selection]) app.doScript(scripts[itemobj[win.tree_root.selection]][1], undefined, undefined, UndoModes.ENTIRE_SCRIPT);
}

function makeTree() {
  win.tree_root.removeAll();
  scripts = app.scriptPreferences.scriptsList.sort(function(a, b) { if (a[0] > b[0]) { return 1 } else if (a[0] < b[0]) { return -1 } else return 0 });
  treeobj = [];
  itemobj = [];
  for (var i = 0; i < scripts.length; i++) {
    if (!scripts[i][0].match(/:Scripts Panel:/) || !scripts[i][0].match(/\.(jsx|js|jsxbin)$/)) continue;
    scripts[i][0] = scripts[i][0].replace(":Scripts Panel:", ":").replace("book-", "").replace(/\.(jsx|js|jsxbin)/, "");
    var ps = scripts[i][0].split(":");
    for (var j = 0; j < ps.length - 1; j++) {
      var k = ps.slice(0, j + 1).join(":");
      if (!treeobj[k]) {
        var ptree = win.tree_root;
        if (j > 0) ptree = treeobj[ps.slice(0, j).join(":")];
        treeobj[k] = ptree.add("node", ps[j]);
      }
    }
    itemobj[treeobj[ps.slice(0, ps.length - 1).join(":")].add("item", ps[ps.length - 1])] = i;
  }
}

