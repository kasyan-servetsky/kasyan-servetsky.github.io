﻿/**
 * @fileoverview &lt;index&gt; XML要素を探し、そのページノンブルと索引項目からなるリストをファイルに出力する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libGetFrameIDs.jsx
 * @requires libCommon.jsx
*/

/*
  利用できるのは以下の形式。
   <index value="索引キーワード" [yomi="よみ"] />
   <index value="レベル1索引&lt;&lt;&gt;&gt;レベル2索引" [yomi="よみ"] />
   <index level1="レベル1索引" level2="レベル2索引" [level1yomi="れべる1よみ" level2yomi="れべる2よみ"] />
   
   省略形
   index: idx
   value: v, val
   yomi: y
   level1: l1
   level2: l2
   level1yomi: l1y, l1yomi
   level2yomi: l2y, l2yomi

    Copyright:
    2008-2010 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008-2010 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/

#include "../libs/libGetFrameIDs.jsx"
#include "../libs/libCommon.jsx"

var tocs = [];
var indices = new Array();
var fullindices = new Array();
var p2s;

// 各行記述のファイルを開く

var filename = File.openDialog("目次ファイルリスト", "テキストファイル:*.txt,すべてのファイル:*" );
if (!filename) exit(0);

var fileObj = new File(filename);
if (fileObj.exists == false) exit(0);
fileObj.open("r");
while (!fileObj.eof) {
  filename = fileObj.readln();
  if (!filename.match(/^#/) && !filename.match(/^\s*$/)) {
    showInteraction(false);
    processDocumentForIndex(filename);
    showInteraction(true);
  }
}
fileObj.close();

var loop = true;
do {
  filename = File.saveDialog("全索引の出力ファイル");
  if (filename) {
    fileObj = new File(filename);
    if (fileObj.exists == true) {
      var wObj = app.dialogs.add({name: "ファイルが存在します"});
      var wtmp = wObj.dialogColumns.add();
      wtmp.staticTexts.add({staticLabel: filename + " はすでに存在します。上書きしますか?"});
      if (wObj.show() == false) continue;
    }
    fileObj.encoding = "UTF8";
    fileObj.lineFeed = "Unix";
    if (fileObj.open("w") == true) {
      for (var i = 0; i < fullindices.length; i++) {
        fileObj.write(fullindices[i] + "\r\n");
      }
      fileObj.close();
      loop = false;
    } else {
      alert("ファイルを開けません。");
    }
  } else{
    loop = false;
  }
} while (loop == true);


function processDocumentForIndex(filename) {
  var file = new File(filename);
  if (file.exists == false) { // 存在チェック
    alert(filename + " というファイルがありません。");
    return false;
  }

  var document = app.open(file);

  if (document == null) {
    alert(filename + " を開くのに何かの問題が発生しました。処理を中止します。");
    exit(0);
  }

  processDocumentIndices(document);

  try {
    document.close(SaveOptions.no);
  } catch (e) {
    alert(filename + " をクローズできませんでした。");
  }
}

function processDocumentIndices(myDocument) {
  p2s = getPagenumFromSection(myDocument);
  processXMLforIndex(myDocument.xmlElements);
  if (indices.length == 0) {
  //  alert("ドキュメントに索引要素が見つかりませんでした。索引要素は、indexまたはidxです。");
  } else {
/*    var filename = myDocument.fullName.fullName.replace(/\.indd$/, ".idx");
    var fileObj = new File(filename);
    fileObj.encoding = "UTF8";
    fileObj.lineFeed = "Unix";

    if (fileObj.open("w") == true) {
      for (var i = 0; i < indices.length; i++) {
        fileObj.write(indices[i] + "\r\n");
      }
      fileObj.close();
    } else {
      alert("ファイル" + filename + "を開けません。");
    } */
    fullindices.push("# " + filename.replace(".idx", ""));
    fullindices = fullindices.concat(indices);
    indices = new Array();
  }
}

/**
 * index XML要素を探して「ページノンブル タブ 索引項目」の配列を作る。索引自体はグローバル変数のString indices[]に格納される
 * @param {XMLItems} items XMLItemsオブジェクト
 * @type boolean
 * @return 再帰のために関数処理を継続するか(true=継続する、false=継続しない)
*/
function processXMLforIndex(items) {
  if (items == null || items.length == 0)  {
    return false;
  }
  for (var i = 0; i < items.length; i++) {
    if (items[i].xmlElements != null && items[i].xmlElements.length > 0) {
      // element発見
      for (var i2 = 0; i2 < items[i].xmlElements.length; i2++) {
        var e = items[i].xmlElements[i2];
        if (e.markupTag.name == "index" || e.markupTag.name == "idx") {
          var val = null, yomi = null, l1 = null, l2 = null, l1yomi = null, l2yomi = null;
          for (var i3 = 0; i3 < e.xmlAttributes.length; i3++) {
            switch (e.xmlAttributes[i3].name) {
              case "v":
              case "val":
              case "value": val = e.xmlAttributes[i3].value; break;
              case "y":
              case "yomi": yomi = e.xmlAttributes[i3].value; break;
              case "l1":
              case "level1": l1 = e.xmlAttributes[i3].value; break;
              case "l2":
              case "level2": l2 = e.xmlAttributes[i3].value; break;
              case "l1y":
              case "l1yomi":
              case "level1yomi": l1yomi = e.xmlAttributes[i3].value; break;
              case "l2y":
              case "l2yomi":
              case "level2yomi": l2yomi = e.xmlAttributes[i3].value; break;
            }
          }
          if (l1 != null) val = l1;
          if (l2 != null) val += "<<>>" + l2;
          if (l1yomi != null) yomi = l1yomi;
          if (l2yomi != null) yomi += "<<>>" + l2yomi;
             
          var t;
                  if (getCSVersion() == 2) {
                    t = e.parent.parentStory.characters[e.storyOffset].insertionPoints[-1].parentTextFrames;
          } else {
                    t = e.storyOffset.insertionPoints[0].parentTextFrames;
                  }
          if (t != null && t.length > 0) {
            // FIXME: tは常に1つ?
            try {
               if (getCSVersion() > 3) {
                indices = indices.concat(p2s[t[0].parentPage.documentOffset] + "\t" + val + ((yomi != null) ? "\t" + yomi : ""));
              } else {
                indices = indices.concat(p2s[t[0].parent.documentOffset] + "\t" + val + ((yomi != null) ? "\t" + yomi : ""));
              } 
            } catch (e) {
              alert(val + " (読み: " + yomi + ")は以下の独立テキストボックス内にあります。手動で追加してください: " + t[0].contents);
            }
          }
        }
      }
    }
    processXMLforIndex(items[i].xmlElements);
  }
  return true;
}
