/**
 * @fileoverview 表の罫線を処理し、セルにスタイルを割り当てる
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
*/

/*
    Copyright:
    2008 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"

// 段落スタイル一覧のダイアログ
var myDocument = app.activeDocument;
var styles = myDocument.paragraphStyles;
var dlist = null;
var dlist2 = null;
var dlist3 = null;
var dlist4 = null;
var cc = new Array();
var cc2 = new Array();
var cc3 = new Array();
var cc4 = new Array();
var ccselected = 0;
var ccselected2 = 0;
var ccselected3 = 0;
var ccselected4 = 0;
for (var i = 0; i < styles.length; i++) {
  cc[i] = styles[i].name;
  cc2[i] = styles[i].name;
  cc3[i] = styles[i].name;
  cc4[i] = styles[i].name;
  if (cc[i].search(/表/) > -1 && cc[i].search(/見出し/) > -1) {
    ccselected = i;
    ccselected2 = i;
  }
  if (cc[i].search(/表/) > -1 && cc[i].search(/項目/) > -1) {
    ccselected3 = i;
  }
  if (cc[i].search(/表/) > -1 && cc[i].search(/最終行/) > -1) {
    ccselected4 = i;
  }
}

var wObj = app.dialogs.add({ name:"表の罫線・スタイル設定" });
with (wObj.dialogColumns.add()) {
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "行ヘッダ部スタイル", minWidth: 120});
    dlist = dropdowns.add({stringList: cc, selectedIndex:ccselected});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "列ヘッダ部スタイル", minWidth: 120});
    dlist2 = dropdowns.add({stringList: cc2, selectedIndex:ccselected2});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "通常セルスタイル", minWidth: 120});
    dlist3 = dropdowns.add({stringList: cc3, selectedIndex:ccselected3});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "最終行スタイル", minWidth: 120});
    dlist4 = dropdowns.add({stringList: cc4, selectedIndex:ccselected4});
  }

  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "左右の罫線の太さ(mm)", minWidth: 120});
    var tObj = textEditboxes.add({editContents:"0", minWidth: 30});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "左右の罫線の濃さ(%)", minWidth: 120});
    var tObj2 = textEditboxes.add({editContents:"100", minWidth: 30});
  }
}

if (wObj.show() == false) exit(0);

var backunit = toMmMode(myDocument);
var pages = myDocument.pages;
for (var i = 0; i < pages.length; i++) {
  var tf = pages[i].textFrames.item("main-content");
  for (var i2 = 0; i2 < tf.tables.length; i2++) {
    replaceRulerOfTable(tf.tables[i2],
      getParagraphStyleByName(myDocument, dlist.stringList[dlist.selectedIndex]),
      getParagraphStyleByName(myDocument, dlist2.stringList[dlist2.selectedIndex]),
      getParagraphStyleByName(myDocument, dlist3.stringList[dlist3.selectedIndex]),
      getParagraphStyleByName(myDocument, dlist4.stringList[dlist4.selectedIndex]),
      Number(tObj.editContents),
      Number(tObj2.editContents)
    );
  }
}
revertMmMode(myDocument, backunit);

/**
 * 表のデフォルト罫線を除去し、ヘッダ、セル、最終行に指定の段落スタイルを割り当てる。段落スタイルの上罫線および下罫線が採用される。上罫線が10ptを越える場合は、背景色と見なす
 * @param {Table} table 表オブジェクト
 * @param {ParagraphStyle} headerstyle 行ヘッダ部の段落スタイル
 * @param {ParagraphStyle} cheaderstyle カラムヘッダ部の段落スタイル
 * @param {ParagraphStyle} cellstyle 通常セルの段落スタイル
 * @param {ParagraphStyle} bottomstyle 最終行の段落スタイル
 * @param {Float} _siderulewidth 左右罫線幅(0にすると表示されない)
 * @param {Long} sideruletint 左右罫線の濃さ
 * @type Nothing
*/
function replaceRulerOfTable(table, headerstyle, cheaderstyle, cellstyle, bottomstyle, _siderulewidth, sideruletint) {
  var siderulewidth = pttomm(_siderulewidth);

  var rows = table.rows;
  for (var i = 0; i < rows.length; i++) {
    var toprulewidth = 0;
    var bottomrulewidth = 0;
    var topruletint = 0;
    var bottomruletint = 0;
    var fillcolor = null;
    var filltint = null;
    if (rows[i].rowType == RowTypes.headerRow) {
      // 行ヘッダ
      if (headerstyle.ruleAbove == true) {
        toprulewidth = headerstyle.ruleAboveLineWeight;
        topruletint = headerstyle.ruleAboveTint;
      }
      if (headerstyle.ruleBelow == true) {
        bottomrulewidth = headerstyle.ruleBelowLineWeight;
        bottomruletint = headerstyle.ruleBelowTint;
      }
     
      if (toprulewidth > 10) { // FIXME
        toprulewidth = 0;
        fillcolor = headerstyle.ruleAboveColor;
        filltint = headerstyle.ruleAboveTint;
      }
    } else {
      // 通常セルまたは末尾
      if (cellstyle.ruleAbove == true) {
        toprulewidth = cellstyle.ruleAboveLineWeight;
        topruletint = cellstyle.ruleAboveTint;
      }
      if (cellstyle.ruleBelow == true) {
        bottomrulewidth = cellstyle.ruleBelowLineWeight;
        bottomruletint = cellstyle.ruleBelowTint;
      }
    }
    if (i == rows.length - 1) {
      if (bottomstyle.ruleAbove == true) {
        toprulewidth = bottomstyle.ruleAboveLineWeight;
        topruletint = bottomstyle.ruleAboveTint;
      }
      if (bottomstyle.ruleBelow == true) {
        bottomrulewidth = bottomstyle.ruleBelowLineWeight;
        bottomruletint = bottomstyle.ruleBelowTint;
      }
    }

    for (var i2 = 0; i2 < rows[i].cells.length; i2++) {
      cell = rows[i].cells[i2];
      for (var i3 = 0; i3 < cell.paragraphs.length; i3++) {
        if (rows[i].rowType == RowTypes.headerRow) {
          cell.paragraphs[i3].appliedParagraphStyle = headerstyle;
        } else {
          cell.paragraphs[i3].appliedParagraphStyle = cellstyle;
          fillcolor = null;
          filltint = null; // FIXME 順序まずい

	     if (cell.associatedXMLElement != null) {
	       try {
	         var ch = cell.associatedXMLElement.xmlAttributes.item("cheader").value;
              cell.paragraphs[i3].appliedParagraphStyle = cheaderstyle;
              if (cheaderstyle.ruleAbove == true) {
                toprulewidth = cheaderstyle.ruleAboveLineWeight;
                topruletint = cheaderstyle.ruleAboveTint;
              }
              if (cheaderstyle.ruleBelow == true) {
                bottomrulewidth = cheaderstyle.ruleBelowLineWeight;
                bottomruletint = cheaderstyle.ruleBelowTint;
              }
              if (toprulewidth > 10) { // FIXME
                toprulewidth = 0;
                fillcolor = cheaderstyle.ruleAboveColor;
                filltint = cheaderstyle.ruleAboveTint;
              }
	       } catch (e) { }
	     }

        }
        cell.paragraphs[i3].ruleAbove = false;
        cell.paragraphs[i3].ruleBelow = false;
      }

      with (cell) {
        topEdgeStrokeWeight = toprulewidth;
        topEdgeStrokeTint = topruletint;
        bottomEdgeStrokeWeight = bottomrulewidth;
        bottomEdgeStrokeTint = bottomruletint;

        leftEdgeStrokeWeight = siderulewidth;
        rightEdgeStrokeWeight = siderulewidth;
        leftEdgeStrokeTint = sideruletint;
        rightEdgeStrokeTint = sideruletint;
        
        if (fillcolor != null) {
          fillColor = fillcolor;
          fillTint = filltint;
        }
      }
    }
  }
}
