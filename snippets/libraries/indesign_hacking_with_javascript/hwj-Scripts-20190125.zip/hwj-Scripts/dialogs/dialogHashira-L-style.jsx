/**
 * @fileoverview 指定の段落スタイルの文字列を左の柱とする。マスターページの柱の箇所には「柱左」というテンプレート文字列を含むテキストフレームを用意しておく
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2008 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/ 

var myDocument = app.activeDocument;
// 段落スタイル一覧のダイアログ
var styles = myDocument.paragraphStyles;
var targets = "";
var wObj = app.dialogs.add({ name:"左の柱対象にするスタイル" });
var wc = wObj.dialogColumns.add();
var cc = new Array(styles.length);
for (var i = 0; i < styles.length; i++) {
  cc[i] = wc.checkboxControls.add({staticLabel: styles[i].name});
  if (styles[i].name == "h1" || styles[i].name.search(/大見出し/) > -1) {
    cc[i].checkedState = true;
  }
}
if (wObj.show() == false) exit(0);
for (var i = 0; i < styles.length; i++) {
  if (cc[i].checkedState == true) targets += "|" + styles[i].name + "|";
}

var targetcontents = "FIXME, FIXME, FIXME";
var pages = myDocument.pages;
for (var p = 0; p < pages.length; p++) {
  var textframes = pages[p].textFrames;
  for (var t = 0; t < textframes.length; t++) {
    var paras = textframes[t].paragraphs;
    for (var para = 0; para < paras.length; para++) {
      try {
        var item = paras[para].appliedParagraphStyle.name; // スタイル名を取得
        if (targets.indexOf("|" + item + "|") != -1) {
          targetcontents = "";
          for (var i = 0; i < paras[para].contents.length; i++) {
            if (paras[para].contents.charCodeAt(i) == 65279 ||
              paras[para].contents.charCodeAt(i) == 13) continue;
            targetcontents += paras[para].contents.charAt(i);
          }
        }
      } catch (e) { }
    }
  }
}

var spreads = myDocument.masterSpreads;
for (var i = 0; i < spreads.length; i++) {
  var tfs = findStringFromObject(spread, "柱左");
  if (tfs.length == 1) tfs[0].contents = targetcontents;
}
