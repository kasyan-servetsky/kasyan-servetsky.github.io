/**
 * @fileoverview 選択した段落スタイルで図・表・リストなどが連番になっているかをチェックする
 * @author Moe Masuko
 */

#include "../libs/libCommon.jsx"
app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;

var myDocument = app.activeDocument;
var cursor;

// 調べたい段落に移動した状態で実行（どこの要素でもOK）
if (myDocument.selection.length == 0 || !(myDocument.selection[0] instanceof Text || myDocument.selection[0] instanceof InsertionPoint)) {
  alert("確認したい要素の段落へ移動してください");
  exit(0);
} else {
  cursor = myDocument.selection[0];
}

var ps;
if (confirm(cursor.appliedParagraphStyle.name + "の連番を確認しますか？")) {
  // カーソルがある段落の段落スタイルを設定
  ps = cursor.appliedParagraphStyle;
} else {
  // TODO?: 複数の段落スタイルを選びたい場合の対処
  exit();
}

// 連番をチェックする要素の確認（図〜〜、表〜〜、リスト〜〜など）
var labels = ["実行のキャンセル", "図", "表", "リスト", "その他"];
var cc = new Array(labels.length);
var wObj = app.dialogs.add({ name: "どの要素の連番をチェックしますか？" });
with (wObj.dialogColumns.add()) {
  with (radiobuttonGroups.add()) {
    for (var i = 0; i < labels.length; i++) {
      cc[i] = radiobuttonControls.add({staticLabel: labels[i]});
    }
  }
}
cc[0].checkedState = true;

if (wObj.show() == false) exit(0);

var elt = "";
switch (wObj.dialogColumns[0].radiobuttonGroups[0].selectedButton) {
  case 0: exit(0); 
  case 1, 2, 3: // 具体的に選択された場合: elt に各値を設定
    elt = labels[wObj.dialogColumns[0].radiobuttonGroups[0].selectedButton];
    break;
  case 4: // その他の場合: 名前を入力して貰う
    var text = prompt("連番を検索する要素の先頭文字列を入力してください", ""); 
    if (text) { 
      elt = text; break;
    } else { exit(0); }
}

// 設定値を保存
var findGrepPrefProp = app.findGrepPreferences.properties
var changeGrepPrefProp = app.changeGrepPreferences.properties

// 初期化
app.findGrepPreferences = NothingEnum.nothing;
app.changeGrepPreferences = NothingEnum.nothing;

var pre = new Array();	// 前の番号（最初はダミー）
var dlt = "DUMMY";	// 番号間のデリミタ（最初はダミー）
// 連番部分にマッチするための正規表現
var regexp = new RegExp(elt + '[ 　]?[0-9\-\.．–]+', 'g');
var alertMsg = new Array();	// エラーメッセージ

for (i = 0; i < myDocument.pages.length; i++) {
  // 段落スタイル名に一致するものを検索（正規表現検索で少し緩く...）
  var cs = findContentFromPageByStyles(myDocument.pages[i], [ps.name], "byregexp");
  // ノンブル（古いバージョンだとNG？）
  var nmbl = myDocument.pages[i].name;

  for (j = 0; j < cs.length; j++) {
    var matched = cs[j].match(regexp);
    if (matched == null) { // 検索にひっかからない場合はスキップ
      continue;
    } else if (pre.length == 0) { // 最初にヒットしたとき
      var s = matched[0];
      dlt = s.replace(RegExp(elt + '[ 　]?[0-9]+'), '')[0];	// デリミタを取得
      pre = s.replace(RegExp(elt + '[ 　]?'), '').split(dlt);	// デリミタで分割
      if (pre[pre.length - 1] != '1') {
	alertMsg.push(eltAndNmbl(s, nmbl) + "最初の要素が1からはじまっていません");
      }
    } else {
      var cur = matched[0].replace(RegExp(elt + '[ 　]?'), '').split(dlt);
      /* pre と cur を比較する */
      if (pre.length != cur.length) { // 長さが合っていない場合（図1／図1.1など）
	alertMsg.push(eltAndNmbl(matched[0], nmbl) + "要素数か区切り文字が合っていません");
      } else if (pre.join('') == cur.join(''))  { // 全く同じ場合
	alertMsg.push(eltAndNmbl(matched[0], nmbl) + "同じ番号が続いています");
      } else { // 長さは同じなので各要素を比較する
	var flg = false;  // インクリメントされている位置があるか
	var res = true;   // 結果を格納
	for (k = 0; k < pre.length; k++) {
	  if (flg) { // インクリメントされた位置以降は1
	    res = res && (cur[k] == '1');
	  } else if (Number(pre[k]) + 1 == Number(cur[k])) {
	    flg = true;
	  } else if (pre[k] != cur[k]) {
	    res = false;
	    break;
	  }
	}
	if (!res)
	  alertMsg.push(eltAndNmbl(matched[0], nmbl) + "前の番号と合っていません");
      }
      pre = cur;
    }
  }
}

if (alertMsg.length == 0) {
  alert("問題は見つかりませんでした。")
} else {
  alert("以下の問題が見つかりました。\n" + alertMsg.join('\n'));
}

// 設定値を戻す
app.findGrepPreferences.properties = findGrepPrefProp;
app.changeGrepPreferences.properties = changeGrepPrefProp;

/* 要素 elt とノンブル nmbl を受け取り、要素に続けてノンブルを括弧書きで入れる
 * Type: string => string => string */
function eltAndNmbl(elt, nmbl) {
  return (elt + "（" + nmbl + "ページ）：");
}