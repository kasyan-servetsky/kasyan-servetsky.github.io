﻿/**
 * @fileoverview InDesignファイルと出力ファイル名をタブで区切ったファイルリスト(「1-ch01/ch01.indd  ch01.pdf」など)を開き、PSまたはPDFを作成する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
*/

/*
    Copyright:
    2008-2014 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008-2014 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"
function showInteraction(flag) {
  if (flag == true) {
    app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;
  } else {
    app.scriptPreferences.userInteractionLevel = UserInteractionLevels.NEVER_INTERACT;
  }
}

showInteraction(true);
// タブ区切りの各行記述のファイル。InDesignファイルはこのファイルからの相対パスとなる
var filename = File.openDialog("IDファイル-出力ファイルのマップファイル", "テキストファイル:*.txt,すべてのファイル:*" );
if (!filename) exit(0);
var fileObj = new File(filename);
if (fileObj.exists == false) exit(0);
var folder = Folder.selectDialog("出力先");
if (folder == null) exit(0);

// 出力先フォルダ
var wObj = app.dialogs.add({ name: "PDF/PostScript のバッチ出力" });
var types = ["PDF(印刷・eBook)", "PDF(インタラクティブ)", "PostScript"];
var untagstate = false; // XMLタグ削除

// PDFとPSのプリセットを取得
var pdfpresets = new Array(), pspresets = new Array();
for (var i = 0; i < app.pdfExportPresets.length; i++) {
  pdfpresets[i] = app.pdfExportPresets.item(i).name;
}
for (var i = 0; i < app.printerPresets.length; i++) {
  pspresets[i] = app.printerPresets.item(i).name;
}
var typelist, pdflist, pslist, untag, suffix, showwin;

with (wObj.dialogColumns.add(wObj.dialogColumns.add())) {
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "出力形式", minWidth: 120});
    typelist = dropdowns.add({stringList: types, selectedIndex: 0});
    
    staticTexts.add({staticLabel: "任意サフィックス", minWidth: 120});
    suffix = textEditboxes.add({editContents: "", minWidth: 40});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "PDFプリセット", minWidth: 120});
    pdflist = dropdowns.add({stringList:pdfpresets, selectedIndex: 0});
    untag = checkboxControls.add({staticLabel: "XMLタグ削除", checkedState:untagstate});
    showwin = checkboxControls.add({staticLabel: "ウィンドウ表示", checkedState:true});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "PSプリセット", minWidth: 120});
    pslist = dropdowns.add({stringList:pspresets, selectedIndex: 0});
  }

}
if (wObj.show() == false) exit(0);

if (suffix.editContents != "") suffix.editContents = "-" + suffix.editContents;

// マップファイルを開き、各行を実行
fileObj.open("r");
while (!fileObj.eof) {
  fline = fileObj.readln();
  if (!fline.match(/^#/) && !fline.match(/^\s*$/)) {
    var flines = fline.split(/\s+/);
    if (flines.length < 1 || flines.length > 2) {
      showInteraction(true);
      alert(fline + "の行が異常です。飛ばします。");
      continue;
    }
    if (flines.length == 1) {
      var type = ".ps";
      if (typelist.selectedIndex == 0 || typelist.selectedIndex == 1) {
        type = ".pdf";
      }
      flines[1] = flines[0].replace(/.+\//, "").replace(".indd", suffix.editContents + type);
    }
    var infile = "";
    if (flines[0].match(/^\//)) {
      // showInteraction(false);
      infile = app.open(new File(flines[0]), showwin.checkedState);
    } else {
      // showInteraction(false);
      infile = app.open(new File(fileObj.path + "/" + flines[0]), showfwin.checkedState);
    }
    if (infile == null) {
      showInteraction(true);
      alert(flines[0] + "を開けませんでした。飛ばします。");
      continue;
    }
    var outfile = new File(folder + "/" + flines[1]);
    showInteraction(true);
    if (typelist.selectedIndex == 0) { // 標準PDF
      exportPDF(infile, outfile, pdflist.stringList[pdflist.selectedIndex], untag.checkedState, false);
    } else if (typelist.selectedIndex == 1) { // インタラクティブPDF
      exportPDF(infile, outfile, pdflist.stringList[pdflist.selectedIndex], untag.checkedState, true);
    } else {
      exportPS(infile, outfile, pslist.stringList[pslist.selectedIndex]);
    }
    infile.close(SaveOptions.no);
//    $.sleep(1000);
  }
}
fileObj.close();
showInteraction(true);
alert("処理を完了しました。");

/**
 * ドキュメントを指定の出力ファイル名/プリセットでPDF出力する
 * @param {Document} document ドキュメントオブジェクト
 * @param {File} outfile 出力ファイルオブジェクト
 * @param {String} presetname プリセット名
 * @param {Boolean} untag タグを解除するか
 * @param {Boolean} interactive インタラクティブPDFか
 * @return Nothing
*/
function exportPDF(document, outfile, presetname, untag, interactive) {
  app.pdfExportPreferences.pageRange = PageRange.ALL_PAGES;
  if (untag) {
    try {
      if (document.xmlElements.length > 0) {
        if (getCSVersion() > 3) {
          document.xmlElements.item(0).xmlElements.everyItem().untag(); // CS5.5ではこうしないとだめ
        } else {
          document.xmlElements.item(0).untag();
        }
      }
    } catch(e) { /* なぜかうまくいかないこともあるようなので、とりあえず無視 */ }
  }
  if (interactive == false) {
    document.exportFile(ExportFormat.PDF_TYPE, outfile, false, document.parent.pdfExportPresets.item(presetname));
  } else {
    // InteractivePDFExportPreferenceはプリセットできない…
    document.exportFile(ExportFormat.INTERACTIVE_PDF, outfile, true);
  }
}

/**
 * ドキュメントを指定の出力ファイル名/プリセットでPostScript出力する
 * @param {Document} document ドキュメントオブジェクト
 * @param {File} outfile 出力ファイルオブジェクト
 * @param {String} presetname プリセット名
 * @return Nothing
*/
function exportPS(document, outfile, presetname) {
  var preset = document.parent.printerPresets.item(presetname);
  preset.printFile = outfile;
  preset.printer = Printer.postscriptFile;
//  preset.ppd = PPDValues.deviceIndependent;
  document.print(false, preset);
}
