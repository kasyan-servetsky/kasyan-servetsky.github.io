﻿/**
 * @fileoverview ◆→math:図版ファイル名←◆を該当図版ファイルで置換する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2012-2016 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008-2016 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
var myDocument = app.activeDocument;
var prefix = "[♦◆]→math[:：][ 　]*"; // 前装飾
var postfix = "[ 　]*←[♦◆]";   // 後装飾
var mathTag = "([^♦◆]+?)";   // 検索対象
var scale = 100;

app.findGrepPreferences = NothingEnum.NOTHING;
app.findChangeGrepOptions = NothingEnum.NOTHING;
app.changeGrepPreferences = NothingEnum.NOTHING;

app.findChangeGrepOptions.widthSensitive = true; // おまじない

var tf = app.activeDocument.selection[0];
if (tf instanceof TextFrame) {
} else {
  alert("対象のテキストフレームを選択してください。");
  exit(0);
}
var imgfolder = Folder.selectDialog("図版のあるフォルダを選択してください");
if (!imgfolder) exit(0);

var wObj = app.dialogs.add({name: "数式置換"});
var scaleedit, prespaceitem, postspaceitem;
var spacename = ["なし", "極細", "1/6", "細い", "1/4", "1/3", "半角"];
var spacerealname = [null, SpecialCharacters.hairSpace, SpecialCharacters.sixthSpace, SpecialCharacters.thinSpace, SpecialCharacters.quarterSpace, SpecialCharacters.thirdSpace, " "];

with(wObj.dialogColumns.add()) {
  with(dialogRows.add()) {
    staticTexts.add({staticLabel: "拡縮率", minWidth: 120});
    scaleedit = percentComboboxes.add({editValue: scale, minimumValue: 1, maximumValue: 1000});
  }
  with(dialogRows.add()) {
    staticTexts.add({staticLabel: "数式の「前」に入れるスペース", minWidth: 120});
    prespaceitem = dropdowns.add({stringList: spacename, minWidth: 120, selectedIndex: 0});
  }
  with(dialogRows.add()) {
    staticTexts.add({staticLabel: "数式の「後」に入れるスペース", minWidth: 120});
    postspaceitem = dropdowns.add({stringList: spacename, minWidth: 120, selectedIndex: 0});
  }
}

if (wObj.show() == false) exit(0);

scale = scaleedit.editValue;
var prespace = spacerealname[prespaceitem.selectedIndex];
var postspace = spacerealname[postspaceitem.selectedIndex];

var total = 0;
var fails = [];

app.findGrepPreferences.findWhat = "^" + prefix + mathTag + postfix + "$";
var hits = tf.parentStory.findGrep(true);
total += hits.length;
fails = replaceMath(myDocument, hits, scale, fails, prefix, postfix, null, null);

app.findGrepPreferences.findWhat = "^" + prefix + mathTag + postfix;
var hits = tf.parentStory.findGrep(true);
total += hits.length;
fails = replaceMath(myDocument, hits, scale, fails, prefix, postfix, null, postspace);

app.findGrepPreferences.findWhat = prefix + mathTag + postfix + "$";
var hits = tf.parentStory.findGrep(true);
total += hits.length;
fails = replaceMath(myDocument, hits, scale, fails, prefix, postfix, prespace, null);

app.findGrepPreferences.findWhat = prefix + mathTag + postfix;
var hits = tf.parentStory.findGrep(true);
total += hits.length;
fails = replaceMath(myDocument, hits, scale, fails, prefix, postfix, prespace, postspace);

if (fails.length == 0) {
  alert(total + "箇所のマークアップを画像化することに成功しました。");
} else {
  alert(total + "箇所のマークアップを画像化しようとしました。\n" +
         (total - fails.length) + "箇所は成功。\n" +
         fails.length + "箇所に失敗しました。:" + fails.join(", "));
}

function replaceMath(myDocument, hits, scale, fails, prefix, postfix, prespace, postspace) {
  app.findGrepPreferences.findWhat = prefix + mathTag + postfix;
  for (var i = 0; i < hits.length; i++) {
    var fname = hits[i].contents.replace(new RegExp(prefix), "").replace(new RegExp(postfix), "");
    var imgfile = new File(imgfolder + "/" + fname);
    if (imgfile.exists == true) {
      hits[i].insertionPoints[-1].place(imgfile);

      // リサイズ
      if (scale != 100) {
        myDocument.recompose();
        var imgbox = hits[i].parent.characters[hits[i].index + hits[i].characters.length].rectangles[0];
        var mytrans = app.transformationMatrices.add();
        mytrans = mytrans.scaleMatrix(scale / 100, scale / 100);
        imgbox.transform(CoordinateSpaces.innerCoordinates, AnchorPoint.bottomLeftAnchor, mytrans);
      }
      if (postspace != null) {
        hits[i].parent.characters[hits[i].index + hits[i].characters.length - 1].insertionPoints[-1].contents = postspace; // 後
      }
      if (prespace != null) {
        hits[i].insertionPoints[-1].contents = prespace; // 前
      }

      if (imgfile.name.match(/\.(pdf|eps)/)) {
        var hs = hits[i].findGrep(); // 単に消すと画像も消える…
        hs[0].remove();
      } else {
        hits[i].remove(); // 置換したら元を削除
      }
    } else {
      fails.push(fname);
    }
  }
  return fails;
}

