﻿/**
 * @fileoverview 現在開いている空のInDesignファイルに、指定フォルダの図版を貼り込んでいく。キャプションのテキストフレームに利用するオブジェクトスタイルfig-captionを作っておくこと
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2016 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2016 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
// 元のページは1ページのみで、単位は「ページ」、「mm」であるものとする
var folder = Folder.selectDialog("画像のあるフォルダ");
if (folder == null) exit(0);

var myDocument = app.activeDocument;
var p_w = myDocument.documentPreferences.pageWidth;
var p_h = myDocument.documentPreferences.pageHeight;

var files = folder.getFiles();
var pagecount = 0;
for (var i = 0; i < files.length; i++) {
  var fname = String(files[i]);
  if (fname.match(/^\./)) continue;
  if (fname.match(/\.(ai|psd|png|eps|pdf|png|gif|bmp|jpg|jpeg|tif|tiff)/i)) {
    if (pagecount > 0) {
      myDocument.pages.add();
    }
    pagecount++;
    var page = myDocument.pages.lastItem();
    
    page.place(files[i]);
    var rect = page.rectangles[0];
    var geometry = rect.visibleBounds;
    var f_w = geometry[3] - geometry[1];
    var f_h = geometry[2] - geometry[0];
    rect.move([(p_w - f_w) / 2, (p_h - f_h) / 2]);
    geometry = rect.visibleBounds;

    page.textFrames.add({appliedObjectStyle: myDocument.objectStyles.item("fig-caption"),
      visibleBounds: [geometry[2] + 3, 0, geometry[2] + 8, p_w], contents: files[i].name});
  }
}
