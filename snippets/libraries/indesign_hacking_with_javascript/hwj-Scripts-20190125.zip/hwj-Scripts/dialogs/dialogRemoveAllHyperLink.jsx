﻿var document = app.activeDocument;

// ハイパーリンクの解除
for (var i = document.hyperlinks.length - 1; i >= 0; i--) {
  if (document.hyperlinks[i].source instanceof HyperlinkTextSource) {
    document.hyperlinks[i].remove();
  }
  for (var i = document.hyperlinkExternalPageDestinations.length - 1; i >= 0; i--) {
    document.hyperlinkExternalPageDestinations[i].remove();
  }
  for (var i = document.hyperlinkPageDestinations.length - 1; i >= 0; i--) {
    document.hyperlinkPageDestinations[i].remove();
  }
  for (var i = document.hyperlinkTextSources.length - 1; i >= 0; i--) {
    document.hyperlinkTextSources[i].remove();
  }
}
