﻿/**
 * @fileoverview キャプションの段落スタイルの文字列に連番を付ける
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @version 2
*/

/*
    Copyright:
    2008 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
var myTextFrame = app.activeDocument.selection[0];
if (!(myTextFrame instanceof TextFrame)) {
  alert("テキストフレームを選択してください。");
  exit(0);
}
var splitter = "　";
var prefix = "図1-";
var num = 1;

// ダイアログ
var myDocument = app.activeDocument;
var pstyles = myDocument.paragraphStyles;
var cstyles = myDocument.characterStyles;
var cc = new Array();
var ccselected = 0;
var cc2 = new Array();
var cc2selected = 0;
for (var i = 0; i < pstyles.length; i++) {
  cc[i] = pstyles[i].name;
  if (cc[i].match(/キャプション/)) ccselected = i;
}
cc2[0] = "[適用しない]";
for (var i = 0; i < cstyles.length; i++) {
  cc2[i + 1] = cstyles[i].name;
  // if (cc2[i + 1].match(/キャプション/)) cc2selected = i + 1;
}
var wObj = app.dialogs.add({ name: "キャプション連番付け" });
with (wObj.dialogColumns.add()) {
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "走査対象の段落スタイル", minWidth: 180});
    var dlist = dropdowns.add({stringList: cc, selectedIndex:ccselected});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "プレフィクスに設定する文字スタイル", minWidth: 180});
    var dlist2 = dropdowns.add({stringList: cc2, selectedIndex:cc2selected});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "プレフィクス文字列", minWidth: 180});
    var tObj = textEditboxes.add({editContents: prefix, minWidth: 130});
  }
  with (dialogRows.add()) {
    staticTexts.add({staticLabel: "プレフィクスとキャプションの分離文字", minWidth: 180});
    var tObj2 = textEditboxes.add({editContents: splitter, minWidth: 30});
  }
}
if (wObj.show() == false) exit(0);

prefix = tObj.editContents;
splitter = tObj2.editContents;
var targetname = dlist.stringList[dlist.selectedIndex];

// 適用処理
var myStory = myTextFrame.parentStory;
var cstyle = null;
if (dlist2.selectedIndex != 0) cstyle = getCharacterStyleByName(myDocument, dlist2.stringList[dlist2.selectedIndex]);

for (var i = 0; i < myStory.paragraphs.length; i++) {
  var paragraph = myStory.paragraphs[i];
  if (paragraph.appliedParagraphStyle.name == targetname) {
    var tmparray = paragraph.contents.split(splitter, 2);
    if (tmparray.length > 1) {
      paragraph.characters[0].appliedCharacterStyle = cstyles[0];
      paragraph.contents = tmparray[1]; // 既存のプリフィクスがあればトル FIXME: 文字スタイルが残る?
    }
    paragraph.characters[0].insertionPoints[-2].contents = prefix + num + splitter; // プリフィクス挿入
    num++;
    if (cstyle != null) {
      var chars = paragraph.characters;
      for (var i2 = 0; i2 < chars.length; i2++) {
        if (chars[i2].contents == splitter) break;
        if (chars[i2].contents == splitter) alert("are");
        chars[i2].appliedCharacterStyle = cstyle; // 文字スタイル適用
      }
    }
  }
}

function getCharacterStyleByName(document, name) {
  var styles = document.characterStyles;
  for (var i = 0; i < styles.length; i++) {
    if (styles[i].name == name) return styles[i];
  }
  return null;
}
