﻿/**
 * @fileoverview 選択したリストをもとに、パッケージを生成する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
  * @requires libCommon.jsx
*/

/*
    Copyright:
    2008 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2010 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"
var tocs = [];

// パッケージ生成フォルダを選択
var exportdir = Folder.selectDialog("パッケージを出力するフォルダ");
if (!exportdir) exit(0);

// 各行記述のファイルを開く
var filename = File.openDialog("目次ファイルリスト", "テキストファイル:*.txt,すべてのファイル:*" );
if (!filename) exit(0);

var count = 0;
var fileObj = new File(filename);
if (fileObj.exists == false) exit(0);
fileObj.open("r");
while (!fileObj.eof) {
  fline = fileObj.readln();
  if (!fline.match(/^#/) && !fline.match(/^\s*$/)) {
    var flines = fline.split(/\t/);
    var dtocs = processDocumentPackage(flines, exportdir);
    count++;
  }
}
fileObj.close();
alert(count + "個のパッケージ作成を完了しました。");

/**
 * ファイルを開き、パッケージ出力する
 * @param {String} filename[] 0:InDesignファイル名, 1:パス名
 * @param {Folder} exportdir 出力親フォルダ
 * @type Nothing
*/
function processDocumentPackage(filename, exportdir) {
  var document = app.open(new File(filename[0]));
  if (document == null) {
    alert(filename[0] + " を開くのに何かの問題が発生しました。処理を中止します。");
    exit(0);
  }
  var path = document.name.replace(/\.indd/, '');
  if (filename.length > 1) {
    path = filename[1];
  }
  if (getCSVersion() > 3) {
    document.packageForPrint(new File(exportdir + "/" + path), true, true, true, true, true, true, true);
  } else {
    document.packageForPrint(new File(exportdir + "/" + path), true, true, true, true, true, true);
  }
  document.close(SaveOptions.no);
}
