﻿/**
 * @fileoverview 現在開いているファイルのリンク図版について、フレームに対するサイズや位置の差異をレポートする
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2013 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008-2013 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
var myDocument = app.activeDocument;
var limit = 0.05; // サイズ値違いと判断する閾値

var log = checkLinkGeometry(myDocument, [], limit);
saveLog(myDocument.filePath + "/" + myDocument.name.replace(/\.indd$/, "-linkreport.txt"), log);

/**
 * ログファイルに保存する
 * @param {String} logfilename ファイルパス名
 * @param {String} log[] ログ文字列配列
 * @type Nothing
*/
function saveLog(logfilename, log) {
  var logObj = new File(logfilename);
  if (logObj.open("w")) {
    logObj.write(log.join("\n"));
    logObj.close();
    alert("レポートファイル " + logfilename + " を作成しました。");
  } else {
    alert("レポートファイル " + logfilename + " の保存に失敗しました。");
  }
}

/**
 * 小数点3桁で四捨五入する
 * @param {Number} f 浮動小数点値
 * @type Number
 * @return 四捨五入後の値
*/
function iRound(f) {
  return Math.round(f * 100) / 100;
}

/**
 * ドキュメントのリンクとテキストフレームのサイズの差異をチェックする
 * @param {Document} myDocument ドキュメントオブジェクト
 * @param {String} log[] 初期ログ配列
 * @param {Number} limit 差異があると見なす閾値
 * @type String[]
 * @return ログ配列
*/
function checkLinkGeometry(myDocument, log, limit) {
  for (var i = 0; i < myDocument.links.length; i++) {
    var link = myDocument.links[i];
    if (link.parent instanceof EPS || link.parent instanceof PDF || link.parent instanceof Image) {
      var page;
      try {
        page = link.parent.parentPage.name; // CS6-
      } catch(e) {
        // CS3
        var o = link.parent;
        var backloop = null;
        while(true) {
          if (o instanceof Character) {
            if (o.parentTextFrames[0].parent instanceof Page) {
              page = o.parentTextFrames[0].parent.name;
            } else if (o.parentTextFrames[0].parent instanceof Group) {
              page = o.parentTextFrames[0].parent.parent.name; // FIXME:怪しい
            }
            break;
          } else if (o instanceof Story || o instanceof Document) {
            log.push("[?] " + link.name + ": p." + page + " : この貼り付け方はCS3では調査できません。");
            backloop = true;
            break;
          }
          o = o.parent;
        }
        if (backloop) continue;
      }
      var orig_dimension = link.parent.visibleBounds;
      var link_dimension = link.parent.parent.visibleBounds;
      var hscale = link.parent.parent.horizontalScale;
      var vscale = link.parent.parent.verticalScale;
    
      if (hscale == 100 && vscale == 100) {
        // 完全一致
        var err = null;
        for (var j = 0; j < 4; j++) {
          if (orig_dimension[j] != link_dimension[j] &&  Math.abs(orig_dimension[j] - link_dimension[j]) > limit) err = true;
        }
        if (err != null) {
          log.push("[X] " + link.name + ": p." + page + " : 原図とボックスのサイズが異なっています。左上(" + iRound(link_dimension[1] - orig_dimension[1]) + ", " + iRound(link_dimension[0] - orig_dimension[0]) + ") 右下(" + iRound(link_dimension[3] - orig_dimension[3]) + ", " + iRound(link_dimension[2] - orig_dimension[2]) +")");
        } else {
          log.push("[-] " + link.name + ": p." + page + " : OK");
        }
      } else {
        // FIXME:左上基準とみなしてよいか？
        log.push("[?] " + link.name + ": p." + page + " : リサイズされており判断できません。");
      }
    } else {
      log.push("[!] " + link.name + ": 対処不明な形式 (" + link.parent + ")");
    }
  }
  return log;
}
