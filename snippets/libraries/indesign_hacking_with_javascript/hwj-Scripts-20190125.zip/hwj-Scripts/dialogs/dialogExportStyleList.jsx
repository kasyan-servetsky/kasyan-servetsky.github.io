﻿/**
 * @fileoverview スタイル名およびフォントの一覧をファイルに出力する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
*/

/*
    Copyright:
    2008-2016 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008-2011 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/

var myDocument = app.activeDocument;

var loop = true;
var filename, fileObj;
do {
  filename = File.saveDialog("出力テキストファイル");
  if (filename) {
    fileObj = new File(filename);
    if (fileObj.exists == true) {
      var wObj = app.dialogs.add({name: "ファイルが存在します"});
      var wtmp = wObj.dialogColumns.add();
      wtmp.staticTexts.add({staticLabel: filename + " はすでに存在します。上書きしますか?"});
      if (wObj.show() == false) continue;
    }

    fileObj.encoding = "UTF8";
    fileObj.lineFeed = "Unix";

    if (fileObj.open("w") == true) {
      exportStyleList(fileObj);
      fileObj.close();
      loop = false;
    } else {
      alert("ファイルを開けません。");
    }
  } else{
    loop = false;
  }
} while (loop == true);

function exportParagraphStyleList(file, group, level) {
  var tab = "";
  for (var i = 1; i <= level; i++) {
    tab += "  ";
  }
  for (var i = 0; i < group.paragraphStyleGroups.length; i++) {
    file.write(tab + "[グループ] " + group.paragraphStyleGroups[i].name + "\n");
    exportParagraphStyleList(file, group.paragraphStyleGroups[i], level + 1);
  }
  var pstyles = group.paragraphStyles;
  for (var i = 0; i < pstyles.length; i++) {
    var stylename = pstyles[i].name;
    var fontname;
    try {
      fontname = pstyles[i].appliedFont;
      if (fontname instanceof Font) fontname = fontname.name;
    } catch (e) { fontname = "[定義なし]"; }
    var basename;
    try {
       basename = pstyles[i].basedOn.name;
    } catch (e) { basename = "undefined"; }
    file.write(stylename + "\n\t" + fontname + "\t" + basename + "\n");
  }
}

function exportCharacterStyleList(file, group, level) {
  var tab = "";
  for (var i = 1; i <= level; i++) {
    tab += "  ";
  }
  for (var i = 0; i < group.characterStyleGroups.length; i++) {
    file.write(tab + "[グループ] " + group.characterStyleGroups[i].name + "\n");
    exportCharacterStyleList(file, group.characterStyleGroups[i], level + 1);
  }
  var cstyles = group.characterStyles;
  for (var i = 0; i < cstyles.length; i++) {
    var stylename = cstyles[i].name;
    var fontname;
    try {
      fontname = cstyles[i].appliedFont;
      if (fontname instanceof Font) fontname = fontname.name;
    } catch (e) { fontname = "[定義なし]"; }
    var basename;
    try {
       basename = pstyles[i].basedOn.name;
    } catch (e) { basename = "undefined"; }
    file.write(stylename + "\n\t" + fontname + "\t" + basename + "\n");
  }
}

function exportObjectStyleList(file, group, level) {
  var tab = "";
  for (var i = 1; i <= level; i++) {
    tab += "  ";
  }
  for (var i = 0; i < group.objectStyleGroups.length; i++) {
    file.write(tab + "[グループ] " + group.objectStyleGroups[i].name + "\n");
    exportObjectStyleList(file, group.objectStyleGroups[i], level + 1);
  }
  var ostyles = group.objectStyles;
  for (var i = 0; i < ostyles.length; i++) {
    var stylename = ostyles[i].name;
    var basename;
    try {
       basename = pstyles[i].basedOn.name;
    } catch (e) { basename = "undefined"; }
    file.write(stylename + "\t" + basename + "\n");
  }
}

function exportTableStyleList(file, group, level) {
  var tab = "";
  for (var i = 1; i <= level; i++) {
    tab += "  ";
  }
  for (var i = 0; i < group.tableStyleGroups.length; i++) {
    file.write(tab + "[グループ] " + group.tableStyleGroups[i].name + "\n");
    exportTableStyleList(file, group.tableStyleGroups[i], level + 1);
  }
  var tstyles = group.tableStyles;
  for (var i = 0; i < tstyles.length; i++) {
    var stylename = tstyles[i].name;
    var basename;
    try {
       basename = pstyles[i].basedOn.name;
    } catch (e) { basename = "undefined"; }
    file.write(stylename + "\t" + basename + "\n");
  }
}

function exportCellStyleList(file, group, level) {
  var tab = "";
  for (var i = 1; i <= level; i++) {
    tab += "  ";
  }
  for (var i = 0; i < group.cellStyleGroups.length; i++) {
    file.write(tab + "[グループ] " + group.cellStyleGroups[i].name + "\n");
    exportCellStyleList(file, group.cellStyleGroups[i], level + 1);
  }
  var estyles = group.cellStyles;
  for (var i = 0; i < estyles.length; i++) {
    var stylename = estyles[i].name;
    var basename;
    try {
       basename = pstyles[i].basedOn.name;
    } catch (e) { basename = "undefined"; }
    file.write(stylename + "\t" + basename + "\n");
  }
}

function exportStyleList(file) {
  var fontname;
  file.write("= 段落スタイル一覧\n");
  exportParagraphStyleList(file, myDocument, 0);

  file.write("\n= 文字スタイル一覧\n");
  exportCharacterStyleList(file, myDocument, 0);

  file.write("\n= オブジェクトスタイル一覧\n");
  exportObjectStyleList(file, myDocument, 0);

  file.write("\n= 表スタイル一覧\n");
  exportTableStyleList(file, myDocument, 0);

  file.write("\n= セルスタイル一覧\n");
  exportCellStyleList(file, myDocument, 0);
}
