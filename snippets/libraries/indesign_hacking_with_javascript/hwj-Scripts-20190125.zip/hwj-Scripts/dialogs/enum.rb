#!/usr/bin/ruby
require 'rexml/document'
include REXML
# "~/Library/Preferences/ExtendScript Toolkit/4.0/omv$indesign-8.0$8.0.xml"
doc = Document.new(ARGF)
puts "    // --- BEGIN ENUM ---"
puts "    // #{Time.now}"
doc.each_element("/dictionary/package/classdef[@enumeration='true']") do |e|
  e.each_element("elements/property") do |p|
    puts "    case #{e.attributes['name']}.#{p.attributes['name']}: return \"#{e.attributes['name']}.#{p.attributes['name']}\";"
  end
end
puts "    // --- END ENUM ---"
