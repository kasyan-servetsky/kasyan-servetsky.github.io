/**
 * @fileoverview XMLインストラクションを使い、特殊文字(改行や改ページなど)を挿入する(glue code版)
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
 * @requires glue code.jsx
*/

/*
    Copyright:
    2008-2012 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008-2012 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"
#include "../libs/glue code.jsx"

processXMLforSpecialCharacters(app.activeDocument);

/**
 * XMLインストラクションを検索して&lt;?dtp ... ?&gt;形式のものを発見したら特殊文字化操作を行う
 * @param {Document} document ドキュメントオブジェクト
 * @type Nothing
*/
function processXMLforSpecialCharacters(document) {
  var myRuleSet = new Array(new processSpecialCharacters());
  __processRuleSet(document.xmlItems.item(0), myRuleSet);
}

/**
 * XML検索して<?dtp?>にヒットしたものを処理するプロシージャ
 * @type boolean
 * @return 常にtrue
*/
function processSpecialCharacters() {
  this.name = "ProcessSubset";
  this.xpath = "//processing-instruction('dtp')";
  this.apply = function(myElement, myRuleProcessor) {
    insertSpecialCharacters(myElement);
    return true;
  }
}

/**
 * ヒットしたインストラクションを置換する
 * @param {XMLItem} myElement インストラクションノード
 * @return Nothing
*/
function insertSpecialCharacters(myElement) {
  var c = null;
  switch (myElement.data) {
  case "autopagenumber":
      c = SpecialCharacters.autoPageNumber;
      break;
  case "bulletcharacter":
      c = SpecialCharacters.bulletCharacter;
      break;
  case "columnbreak":
      c = SpecialCharacters.columnBreak;
      break;
  case "copyrightsymbol":
      c = SpecialCharacters.copyrightSymbol;
      break;
  case "degreesymbol":
      c = SpecialCharacters.degreeSymbol;
      break;
  case "discretionaryhyphen":
      c = SpecialCharacters.discretionaryHyphen;
      break;
  case "discretionarylinebreak":
      c = SpecialCharacters.DISCRETIONARY_LINE_BREAK;
      break;
  case "doubleleftquote":
      c = SpecialCharacters.doubleLeftQuote;
      break;
  case "doublerightquote": 
      c = SpecialCharacters.doubleRightQuote;
      break;
  case "doublestraightquote": 
      c = SpecialCharacters.DOUBLE_STRAIGHT_QUOTE;
      break;
  case "ellipsischaracter":
      c = SpecialCharacters.ellipsisCharacter;
      break;
  case "emdash":
      c = SpecialCharacters.emDash;
      break;
  case "emspace":
      c = SpecialCharacters.emSpace;
      break;
  case "endnestedstyle":
      c = SpecialCharacters.endNestedStyle;
      break;
  case "endash":
      c = SpecialCharacters.enDash;
      break;
  case "enspace":
      c = SpecialCharacters.enSpace;
      break;
  case "evenpagebreak":
      c = SpecialCharacters.evenPageBreak;
      break;
  case "figurespace":
      c = SpecialCharacters.figureSpace;
      break;
  case "fixedwidthnonbreakingspace":
      c = SpecialCharacters.FIXED_WIDTH_NONBREAKING_SPACE;
      break;
  case "flushspace":
      c = SpecialCharacters.flushSpace;
      break;
  case "footnotesymbol":
      c = SpecialCharacters.footnoteSymbol;
      break;
  case "forcedlinebreak":
      c = SpecialCharacters.forcedLineBreak;
      break;
  case "framebreak":
      c = SpecialCharacters.frameBreak;
      break;
  case "hairspace":
      c = SpecialCharacters.hairSpace;
      break;
  case "indentheretab":
      c = SpecialCharacters.indentHereTab;
      break;
  case "nextpagenumber":
      c = SpecialCharacters.nextPageNumber;
      break;
  case "nonbreakinghyphen":
      c = SpecialCharacters.nonbreakingHyphen;
      break;
  case "nonbreakingspace":
      c = SpecialCharacters.nonbreakingSpace;
      break;
  case "oddpagebreak":
      c = SpecialCharacters.oddPageBreak;
      break;
  case "pagebreak":
      c = SpecialCharacters.pageBreak;
      break;
  case "paragraphsymbol":
      c = SpecialCharacters.paragraphSymbol;
      break;
  case "previouspagenumber":
      c = SpecialCharacters.previousPageNumber;
      break;
  case "punctuationspace":
      c = SpecialCharacters.punctuationSpace;
      break;
  case "quarterspace":
      c = SpecialCharacters.QUARTER_SPACE;
      break;
  case "registeredtrademark":
      c = SpecialCharacters.registeredTrademark;
      break;
  case "rightindenttab":
      c = SpecialCharacters.rightIndentTab;
      break;
  case "sectionmarker":
      c = SpecialCharacters.sectionmarker;
      break;
  case "sectionsymbol":
      c = SpecialCharacters.sectionSymbol;
      break;
  case "singleleftquote":
      c = SpecialCharacters.singleLeftQuote;
      break;
  case "singlerightquote": 
      c = SpecialCharacters.singleRightQuote;
      break;
  case "singlestraightquote": 
      c = SpecialCharacters.SINGLE_STRAIGHT_QUOTE;
      break;
  case "sixthspace":
      c = SpecialCharacters.SIXTH_SPACE;
      break;
  case "textvariable":
      c = SpecialCharacters.TEXT_VARIABLE;
      break;
  case "thinspace":
      c = SpecialCharacters.thinSpace;
      break;
  case "thirdspace":
      c = SpecialCharacters.THIRD_SPACE;
      break;
  case "trademarksymbol":
      c = SpecialCharacters.trademarkSymbol;
      break;
  case "zerowidthnonjoiner":
      c = SpecialCharacters.ZERO_WIDTH_NONJOINER;
      break;
  }
  if (c != null) {
    if (getCSVersion() == 2) {
      myElement.parent.parentStory.characters[myElement.storyOffset].insertionPoints[-1].contents = c;
    } else {
      // XXX: CS3
      myElement.storyOffset.insertionPoints[-1].contents = c;
    }
  }
}
