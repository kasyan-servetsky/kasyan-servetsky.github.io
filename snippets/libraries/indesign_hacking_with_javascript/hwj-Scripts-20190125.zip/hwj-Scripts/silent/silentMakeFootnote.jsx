/**
 * @fileoverview &lt;footnote&gt;タグの内容を脚注とする。内容は1行であることを前提とし、文字スタイルは保持されるがそれ以外のXML情報およびスタイルは失われる。脚注の詳細オプションは、InDesign側の書式→脚注オプションで行う。注と監訳者注のように複数の注釈を行うことはできない
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
*/

/*
    Copyright:
    2008-2011 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008-2011 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/
#include "../libs/libCommon.jsx"

var myDocument = app.activeDocument;
if (getCSVersion() > 3) {
  processXMLforFootnote(myDocument, myDocument.xmlElements, "footnote", true);
  processXMLforFootnote(myDocument, myDocument.xmlElements, "footnote", false);
} else {
  processXMLforFootnote(myDocument, myDocument.xmlItems, "footnote", true);
  processXMLforFootnote(myDocument, myDocument.xmlItems, "footnote", false);
}

/**
 * footnote XML要素を探してその内容を脚注化する
 * @param {Document} document ドキュメントオブジェクト
 * @param {XMLItems} items XMLItemsオブジェクト
 * @param {String} tagname 対象XML要素名
 * @param {boolean} flag footnote XML要素の削除を行うか(true=削除しない、false=削除する)
 * @type boolean
 * @return 再帰のために関数処理を継続するか(true=継続する、false=継続しない)
*/
function processXMLforFootnote(document, items, tagname, flag) {
  if (items == null || items.length == 0)  {
    return false;
  }
  for (var i = 0; i < items.length; i++) {
    if (items[i].xmlElements != null && items[i].xmlElements.length > 0) {
      for (var i2 = 0; i2 < items[i].xmlElements.length; i2++) {
        var e = items[i].xmlElements[i2];
        if (e.markupTag.name == tagname) {
          if (flag == true) {
            var fn;
            if (getCSVersion() == 2) {
              fn = e.parentStory.characters[e.storyOffset - 1].insertionPoints[-1].footnotes.add();
            } else {
              // XXX: CS3
              fn = e.storyOffset.insertionPoints[-1].footnotes.add();
            }
            fn.insertionPoints[-1].contents = e.contents;
            var i3 = 0;
            do {
              // 文字スタイルを復帰
              // XXX: ここでforでe.characters[i3].lengthを使わず例外にしているのは、CS2では状況によって1つ少ない数を返す(？)から。
              try {
                if (e.characters[i3].appliedCharacterStyle.name != tagname) { // FIXME: tagnameじゃないほうがいいかな…
                  fn.characters[1 + document.footnoteOptions.separatorText.length + i3].appliedCharacterStyle =
                     e.characters[i3].appliedCharacterStyle;
                }
              } catch(e) {
                break;
              }
              i3++;
            } while (true);
          } else {
            e.remove();
          }
        }
      }
    }
    if (getCSVersion() > 3) {
      processXMLforFootnote(document, items[i].xmlElements, tagname, flag);
    } else {
      processXMLforFootnote(document, items[i].xmlItems, tagname, flag);
    }
  }
  return true;
}
