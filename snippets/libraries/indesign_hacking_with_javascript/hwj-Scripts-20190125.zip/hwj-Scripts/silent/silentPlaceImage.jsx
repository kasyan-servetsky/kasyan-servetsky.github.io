/**
 * @fileoverview XML要素のImageタグの画像を再貼り込みする
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
*/

/*
    Copyright:
    2008 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
  */
#include "libCommon.jsx"
var myDocument = app.activeDocument;

/**
 * 指定のXML要素のhrefを見て画像を貼り付ける
 * @param {XMLItems} items XMLItemsオブジェクト
 * @param {String} tagname XML要素名
 * @param {String} documentpath ルートドキュメントパス名
 * @type boolean
 * @return 再帰のために関数処理を継続するか(true=継続する、false=継続しない)
*/
function processXMLforPlaceImage(items, tagname, documentpath) {
  if (items == null || items.length == 0)  {
    return false;
  }
  for (var i = 0; i < items.length; i++) {
    if (items[i].xmlElements != null && items[i].xmlElements.length > 0) {
      for (var i2 = 0; i2 < items[i].xmlElements.length; i2++) {
        var e = items[i].xmlElements[i2];
        if (e.markupTag.name == tagname) {
          var href = e.xmlAttributes.itemByRange("href", "href");
          if (href == null || e.epss.length > 0) continue; // hrefがないときまたはepsがすでにあるときにはスキップ
          e.epss.add();
          var startelement = e;
          var startpoint = startelement.storyOffset;
          var endpoint = getEndStoryPoint(startelement);
          backGroundImage(layername, startelement.parentStory, startpoint, endpoint, offsets, files, ostyle, lfit, width, fit);
        }
      }
    }
    processXMLforPlaceImage(items[i].xmlItems, tagname, documentpath);
  }
  return true;
}

function placeImage(document, tagname, ostyle) {
  var stories = document.stories;
  for (var i = 0; i < stories.length; i++) {
    if (stories[i].rectangles.length > 0) {
      // rectangleの中に画像がある
      rects = stories[i].rectangles;
      for (var i2 = 0; i2 < rects.length; i2++) {
        if (rects[i2].associatedXMLElement != null && rects[i2].associatedXMLElement.markupTag.name == tagname) {
          var objstyle = null;
          if (rects[i2].associatedXMLElement.xmlAttributes.itemByRange("ostyle", "ostyle") != null) {
            objstyle = getObjectStyleByName(document, rects[i2].associatedXMLElement.xmlAttributes.itemByRange("ostyle", "ostyle").value);
          } else {
            objstyle = defaultobjstyle;
          }
          rects[i2].appliedObjectStyle = objstyle;
          with(rects[i2]) {
	      // 上書きされたオブジェクトスタイルを戻す。FIXME:もっと一発で直せないのか?
	      anchoredObjectSettings.anchoredPosition = objstyle.anchoredObjectSettings.anchoredPosition;
	      anchoredObjectSettings.anchorPoint = objstyle.anchoredObjectSettings.anchorPoint;
	      anchoredObjectSettings.anchorSpaceAbove = objstyle.anchoredObjectSettings.anchorSpaceAbove;
	      anchoredObjectSettings.anchorXoffset = objstyle.anchoredObjectSettings.anchorXoffset;
	      anchoredObjectSettings.anchorYoffset = objstyle.anchoredObjectSettings.anchorYoffset;
	      anchoredObjectSettings.horizontalAlignment = objstyle.anchoredObjectSettings.horizontalAlignment;
	      anchoredObjectSettings.horizontalReferencePoint = objstyle.anchoredObjectSettings.horizontalReferencePoint;
	      anchoredObjectSettings.lockPosition = objstyle.anchoredObjectSettings.lockPosition;
	      anchoredObjectSettings.pinPosition = objstyle.anchoredObjectSettings.pinPosition;
	      anchoredObjectSettings.spineRelative = objstyle.anchoredObjectSettings.spineRelative;
	      anchoredObjectSettings.verticalAlignment = objstyle.anchoredObjectSettings.verticalAlignment;
	      anchoredObjectSettings.verticalReferencePoint = objstyle.anchoredObjectSettings.verticalReferencePoint;
	      
	      textWrapPreferences.textWrapType = objstyle.textWrapPreferences.textWrapType;
	      // FIXME
	  }
	}
      }
    }
  }
}
