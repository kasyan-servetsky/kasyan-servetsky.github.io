﻿/**
 * @fileoverview 必須マスターページ以外のページ要素をすべて消去し、右ページから始まる2ページの白ページと連結フレームを配置する
 * @author Kenshi Muto &lt;kmuto@debian.org&gt;
 * @requires libCommon.jsx
 * @requires libGetBoundsOfPage.jsx
*/

/*
    Copyright:
    2008-2014 Kenshi Muto <kmuto@debian.org>
----------------------------------------------------------------------
ソフトウェア使用許諾同意書
本ソフトウェアの利用・変更・再配布にあたっては、下記の使用許諾同意書に
同意する必要があります。

1. 本使用許諾同意書における「ソフトウェア」とは、機械可読の資料 (ライブ
   ラリ、スクリプト、ソースファイル、データファイル)、実行形式、および
   文書を意味します。
2. 本ソフトウェアの使用許諾同意書に同意する限りにおいて、使用者は
   本ソフトウェアを自由に利用、変更することができます。
3. 本ソフトウェアに変更を加えない限りにおいて、使用者は本ソフトウェアを
   自由にコピー、再配布することができます。
4. 本ソフトウェアは無保証です。作者およびそれに関連する組織、配布者は、
   本ソフトウェアの使用に起因する一切の直接損害、間接損害、偶発的損害、
   特別損害、懲戒的損害、派生的損害について何らの責任・保証も負いません。
5. 本ソフトウェアを変更した上で再配布するときには、下記の事項すべてに
   従わなければなりません。
   - 使用許諾同意書の内容に変更を加えてはなりません。技術上の理由で
     文字エンコーディングの変換を行うことは許可しますが、その使用者が
     特殊な技術的措置なしに可読な形でなければなりません。
   - 技術上の理由でバイナリ化・難読化を行う場合も、変更箇所を含めた
     ソフトウェアを、その使用者が可読可能な形式の形で同一のメディアで
     提供しなければなりません。本使用許諾同意書の2条および3条により、
     使用者が可読形式の該当ソフトウェアを変更、コピー、再配布することを
     妨げてはなりません。
   - ソフトウェア構成物の所定の作者名の欄に、変更者のクレジット
     (個人名、企業名、所属、連絡先など)を「追加」しなければなりません。
6. 本ソフトウェアを変更した上で再配布するときには、変更理由および
   その内容を明記することが推奨されます。
7. 使用者がソフトウェアに適用可能な特許に対して特許侵害にかかわる何らか
   の行動を開始した時点で、この使用許諾同意書は自動的に終了し、以降
   使用者はこの使用許諾書によって与えられた一切の権利を放棄するものと
   します。

著作権所有者 Copyright (C) 2008-2014 Kenshi Muto. All rights reserved.
使用許諾同意書バージョン1.0
著作権所有者による書面での事前の許可がない限り、この使用許諾同意書
に変更を加えてはなりません。
----------------------------------------------------------------------
*/

#include "../libs/libCommon.jsx"
#include "../libs/libGetBoundsOfPage.jsx"

var myDocument = app.activeDocument;
var pages = myDocument.pages;
var backunit = toMmMode(document);

// 3ページ以降のページを削除する
for (var i = pages.length; i > 2; i--) {
  pages[i - 1].remove();
}

// 1〜2ページにあるページ部品を削除する
for (var i = 0; i < pages.length; i++) {
  items = pages[i].pageItems;
  for (var i2 = 0; i2 < items.length; i2++) {
    items[i2].remove();
  }
  items = pages[i].textFrames;
  for (var i2 = 0; i2 < items.length; i2++) {
    items[i2].remove();
  }
  items = pages[i].rectangles;
  for (var i2 = 0; i2 < items.length; i2++) {
    items[i2].remove();
  }
  pages[i].removeOverride();
  pages[i].appliedMaster = null;
}

var spreads = myDocument.masterSpreads;
// tmpラベルの付いているマスターページを削除
for (var i = spreads.length; i > 0; i--) {
  if (spreads[i - 1].label == "tmp") {
    spreads[i - 1].remove();
  }
}

var layers = myDocument.layers;
// tmpラベルの付いているレイヤーを削除
for (var i = layers.length; i > 0; i--) {
  if (layers[i - 1].label.match(/^tmp\-/)) {
    layers[i - 1].remove();
  }
}

// 版面のテキストフレームを2ページ分作成
var tf = pages[0].textFrames.add();
tf.geometricBounds = getBoundsOfPage(myDocument, pages[0]);
tf.appliedObjectStyle= getObjectStyleByName(document, "[Normal Text Frame]");
tf.label = "main-content";
if (getCSVersion() > 4) {
  try {
    tf.name = "main-content";
  } catch(e) {}
}
tf.insertionPoints[0].appliedParagraphStyle = myDocument.paragraphStyles[1]; // FIXME: 段落スタイルにはとりあえずインデックス1番([基本段落])を使う
var tf2 = pages[1].textFrames.add();
tf2.geometricBounds = getBoundsOfPage(myDocument, pages[1]);
tf2.appliedObjectStyle= getObjectStyleByName(document, "[Normal Text Frame]");
tf2.previousTextFrame = tf; // リンク
tf2.label = "main-content";
if (getCSVersion() > 4) {
  try {
    tf2.name = "main-content";
  } catch(e) {}
}

// XML要素を削除
if (getCSVersion() > 3) {
  myDocument.xmlItems[0].remove();
} else {
  var xmls = myDocument.xmlItems[0].xmlItems;
  for (var i = xmls.length; i > 0; i--) {
    xmls[i - 1].remove();
  }
}
revertMmMode(myDocument, backunit);
