﻿/* Copyright 2015, Kasyan Servetsky
July 27 2015
Written by Kasyan Servetsky
http://www.kasyan.ho.com.ua
e-mail: askoldich@yahoo.com */
//======================================================================================
var scriptName = "XML Workflow Parameters",
set, doc,
minBoxSize = 10, // minimum size of a box
maxBoxSize = 1000, // maximum size of a box
allObjStyles = [],
allObjStylesNames = [],
allParStyles = [],
allParStylesNames = [],
stopClosingDialog = false,
clickedButton = null;

PreCheck();

//===================================== FUNCTIONS ======================================
function CreateDialog() {
	var editTextWidth = 3,
	preferredDllWidth = 180;

	GetDialogSettings();
	
	var w = new Window("dialog", scriptName);
	
	// FIGURE
	w.p = w.add("panel", undefined, "Figure text:");
	w.p.orientation = "column";
	w.p.alignment = "fill";
	w.p.alignChildren = "right";
	
	w.p.g = w.p.add("group");
	w.p.g.orientation = "row";
	// FIGURE TEXT
	w.p.g.st = w.p.g.add("statictext", undefined, "Width:"); // Width
	w.p.g.et = w.p.g.add("edittext", undefined, set.widthFigTextBox);
	w.p.g.et.characters = editTextWidth;
	w.p.g.et.onChange = function() {
		CheckTextEditField(this, set.widthFigTextBox, "Width");
	}

	w.p.g.st1 = w.p.g.add("statictext", undefined, "Depth:"); // Depth
	w.p.g.et1 = w.p.g.add("edittext", undefined, set.depthFigTextBox);
	w.p.g.et1.characters = editTextWidth;
	w.p.g.et1.onChange = function() {
		CheckTextEditField(this, set.depthFigTextBox, "Depth");
	}

	w.p.g.st1 = w.p.g.add("statictext", undefined, "Object style:"); // Object style
	w.p.g.ddl = w.p.g.add("dropdownlist", undefined, allObjStylesNames);
	w.p.g.ddl.selection = set.objStyleFigTextBox[0];
	w.p.g.ddl.preferredSize.width = preferredDllWidth;

	w.p.g1 = w.p.add("group");
	w.p.g1.orientation = "row";
	w.p.g1.st = w.p.g1.add("statictext", undefined, "Paragraph style for Figure Holder:"); // Paragraph style for Figure Holder
	w.p.g1.ddl = w.p.g1.add("dropdownlist", undefined, allParStylesNames);
	w.p.g1.ddl.selection = set.parStyleFigHolder[0];
	w.p.g1.ddl.preferredSize.width = preferredDllWidth;

	w.p.g2 = w.p.add("group");
	w.p.g2.orientation = "row";
	w.p.g2.st = w.p.g2.add("statictext", undefined, "Paragraph style for Figure Caption:"); // Paragraph style for Figure Caption
	w.p.g2.ddl = w.p.g2.add("dropdownlist", undefined, allParStylesNames);
	w.p.g2.ddl.selection = set.parStyleFigCaption[0];
	w.p.g2.ddl.preferredSize.width = preferredDllWidth;
	
	// FIGURE PICTURE
	w.p1 = w.add("panel", undefined, "Figure picture:");
	w.p1.orientation = "column";
	w.p1.alignment = "fill";
	w.p1.alignChildren = "right";

	w.p1.g = w.p1.add("group");
	w.p1.g.orientation = "row";
	
	w.p1.g.st = w.p1.g.add("statictext", undefined, "Width:"); // Width
	w.p1.g.et = w.p1.g.add("edittext", undefined, set.widthFigPictureBox);
	w.p1.g.et.characters = editTextWidth;
	w.p1.g.et.onChange = function() {
		CheckTextEditField(this, set.widthFigPictureBox, "Width");
	}

	w.p1.g.st1 = w.p1.g.add("statictext", undefined, "Depth:"); // Depth
	w.p1.g.et1 = w.p1.g.add("edittext", undefined, set.depthFigPictureBox);
	w.p1.g.et1.characters = editTextWidth;
	w.p1.g.et1.onChange = function() {
		CheckTextEditField(this, set.depthFigPictureBox, "Depth");
	}

	w.p1.g.st1 = w.p1.g.add("statictext", undefined, "Object style:"); // Object style
	w.p1.g.ddl = w.p1.g.add("dropdownlist", undefined, allObjStylesNames);
	w.p1.g.ddl.selection = set.objStyleFigPictureBox[0];
	w.p1.g.ddl.preferredSize.width = preferredDllWidth;

	// TABLE
	w.p2 = w.add("panel", undefined, "Table:");
	w.p2.orientation = "column";
	w.p2.alignment = "fill";
	w.p2.alignChildren = "right";
	w.p2.g = w.p2.add("group");
	w.p2.g.orientation = "row";
	
	w.p2.g.st = w.p2.g.add("statictext", undefined, "Width:"); // Width
	w.p2.g.et = w.p2.g.add("edittext", undefined, set.widthTableBox);
	w.p2.g.et.characters = editTextWidth;
	w.p2.g.et.onChange = function() {
		CheckTextEditField(this, set.widthTableBox, "Width");
	}

	w.p2.g.st1 = w.p2.g.add("statictext", undefined, "Depth:"); // Depth
	w.p2.g.et1 = w.p2.g.add("edittext", undefined, set.depthTableBox);
	w.p2.g.et1.characters = editTextWidth;
	w.p2.g.et1.onChange = function() {
		CheckTextEditField(this, set.depthTableBox, "Depth");
	}

	w.p2.g.st1 = w.p2.g.add("statictext", undefined, "Object style:"); // Object style
	w.p2.g.ddl = w.p2.g.add("dropdownlist", undefined, allObjStylesNames);
	w.p2.g.ddl.selection = set.objStyleTableBox[0];
	w.p2.g.ddl.preferredSize.width = preferredDllWidth;

	// BOXED TEXT
	w.p3 = w.add("panel", undefined, "Boxed text:");
	w.p3.orientation = "column";
	w.p3.alignment = "fill";
	w.p3.alignChildren = "right";
	w.p3.g = w.p3.add("group");
	w.p3.g.orientation = "row";
	
	w.p3.g.st = w.p3.g.add("statictext", undefined, "Width:"); // Width
	w.p3.g.et = w.p3.g.add("edittext", undefined, set.widthBoxedTextBox);
	w.p3.g.et.characters = editTextWidth;
	w.p3.g.et.onChange = function() {
		CheckTextEditField(this, set.widthBoxedTextBox, "Width");
	}

	w.p3.g.st1 = w.p3.g.add("statictext", undefined, "Depth:"); // Depth
	w.p3.g.et1 = w.p3.g.add("edittext", undefined, set.depthBoxedTextBox);
	w.p3.g.et1.characters = editTextWidth;
	w.p3.g.et1.onChange = function() {
		CheckTextEditField(this, set.depthBoxedTextBox, "Depth");
	}

	w.p3.g.st1 = w.p3.g.add("statictext", undefined, "Object style:"); // Object style
	w.p3.g.ddl = w.p3.g.add("dropdownlist", undefined, allObjStylesNames);
	w.p3.g.ddl.selection = set.objStyleBoxedTextBox[0];
	w.p3.g.ddl.preferredSize.width = preferredDllWidth;
//--------------------------------------------------------------------------------------------------------------------------------------------------------
	// ADD PAGES
	w.p4 = w.add("panel", undefined, "");
	w.p4.orientation = "column";
	w.p4.alignment = "fill";
	w.p4.alignChildren = "left";
	w.p4.g = w.p4.add("group");
	w.p4.g.orientation = "row";
	
	w.p4.g.cb = w.p4.g.add("checkbox", undefined, "");
	w.p4.g.cb.value = set.addPagesAtEnd;
	w.p4.g.cb.onClick = function() {
		if (this.value) {
			w.p4.g.et.enabled = w.p4.g.st.enabled = w.p4.g.st1.enabled = true;
		}
		else {
			w.p4.g.et.enabled = w.p4.g.st.enabled = w.p4.g.st1.enabled = false;
		}
	}

	w.p4.g.st = w.p4.g.add("statictext", undefined, "Add");
	w.p4.g.et = w.p4.g.add("edittext", undefined, set.addPagesAtEndNum);
	w.p4.g.et.characters = editTextWidth;
	w.p4.g.et.onChange = function() {
		CheckTextEditField(this, set.addPagesAtEndNum, "Add empty pages at the end of the document");
	}

	w.p4.g.st1 = w.p4.g.add("statictext", undefined, "empty pages at the end of the document");
	
	if (w.p4.g.cb.value) {
		w.p4.g.et.enabled = w.p4.g.st.enabled = w.p4.g.st1.enabled = true;
	}
	else {
		w.p4.g.et.enabled = w.p4.g.st.enabled = w.p4.g.st1.enabled = false;
	}

	// Buttons
	w.bts = w.add("group");
	w.bts.orientation = "row";   
	w.bts.alignment = "center";
	w.bts.ok = w.bts.add("button", undefined, "OK", {name:"ok" });
	w.bts.ok.onClick = function() {
		if (stopClosingDialog) {
			stopClosingDialog = false;
			return;			
		}
		else {
			w.close(1);
		}
	}
	w.bts.cancel = w.bts.add("button", undefined, "Cancel", {name:"cancel"});
	w.bts.cancel.onClick = function() {
		w.close(2);
	}
	
	var showDialog = w.show();

	if (showDialog == 1) {
		with (set) {
			widthFigTextBox = parseInt(w.p.g.et.text).toString(); // Figure Text Box
			depthFigTextBox = parseInt(w.p.g.et1.text).toString();
			objStyleFigTextBox = [w.p.g.ddl.selection.index, w.p.g.ddl.selection.text];
			parStyleFigHolder = [w.p.g1.ddl.selection.index, w.p.g1.ddl.selection.text];
			parStyleFigCaption = [w.p.g2.ddl.selection.index, w.p.g2.ddl.selection.text];
			widthFigPictureBox = parseInt(w.p1.g.et.text).toString(); // Figure Picture Box
			depthFigPictureBox = w.p1.g.et1.text;
			objStyleFigPictureBox = [w.p1.g.ddl.selection.index, w.p1.g.ddl.selection.text];
			widthTableBox = parseInt(w.p2.g.et.text).toString(); // Table
			depthTableBox = parseInt(w.p2.g.et1.text).toString();
			objStyleTableBox = [w.p2.g.ddl.selection.index, w.p2.g.ddl.selection.text];
			widthBoxedTextBox = parseInt(w.p3.g.et.text).toString(); // Boxed-text
			depthBoxedTextBox = parseInt(w.p3.g.et1.text).toString();
			objStyleBoxedTextBox = [w.p3.g.ddl.selection.index, w.p3.g.ddl.selection.text];
			addPagesAtEnd = w.p4.g.cb.value;
			addPagesAtEndNum = parseInt(w.p4.g.et.text).toString();
		}

		doc.insertLabel("Kas_" + scriptName, set.toSource());
	}
	else if (showDialog == 2) { // for debugging only
		$.writeln("Cancelled");
	}	
}	
	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(doc.extractLabel("Kas_" + scriptName));
	var tmp = set;

	if (set == undefined) {
		set = {  widthFigTextBox: "300", // Figure Text Box
					depthFigTextBox: "200",
					objStyleFigTextBox: [undefined, "fig-toc"],
					parStyleFigHolder: [undefined, "fig-holder"],
					parStyleFigCaption: [undefined, "fig-caption"],
					widthFigPictureBox: "300", // Figure Picture Box
					depthFigPictureBox: "200",
					objStyleFigPictureBox: [undefined, "pic"],
					widthTableBox: "300", // Table
					depthTableBox: "200",
					objStyleTableBox: [undefined, "table-toc"],
					widthBoxedTextBox: "300", // Boxed-text
					depthBoxedTextBox: "200",
					objStyleBoxedTextBox: [undefined, "box-toc"],
					addPagesAtEnd: true,
					addPagesAtEndNum: "100"
				};
			$.writeln("Loaded defaults");
	}

	set.objStyleFigTextBox = CheckObjStyle(set.objStyleFigTextBox);
	set.objStyleFigPictureBox = CheckObjStyle(set.objStyleFigPictureBox);
	set.objStyleTableBox = CheckObjStyle(set.objStyleTableBox);
	set.objStyleBoxedTextBox = CheckObjStyle(set.objStyleBoxedTextBox);
	set.parStyleFigHolder = CheckParStyle(set.parStyleFigHolder);
	set.parStyleFigCaption = CheckParStyle(set.parStyleFigCaption);

	var tmp = set;

	return set;
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckObjStyle(objStyle) {
	//$.writeln("Entering: CheckObjStyle");
	if (objStyle[0] == undefined || allObjStylesNames[objStyle[0]] == undefined || allObjStylesNames[objStyle[0]] != objStyle[1]) {  // if run for the 1st time, or number of styles is less than before, or the style name doesn't match
		var objStyleByName = GetStyleByName(objStyle[1], allObjStylesNames, allObjStyles);
		
		if (objStyleByName != null) { // get style by name
			objStyle = objStyleByName;
		}
		else if (objStyle[1] != "[None]" && objStyle[1] != "[Basic Graphics Frame]" && objStyle[1] != "[Basic Text Frame]" && objStyle[1] != "[Basic Grid]") { // not found, reset to defaults
			alert("Object style '" + objStyle[1] + "' is missing in the active document so '[None]' will be selected instead.", scriptName, false);
			objStyle = [0, "[None]"]; // reset to [None]
		}
	}

	return objStyle;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckParStyle(parStyle) {
	//$.writeln("Entering: CheckParStyle");
	if (parStyle[0] == undefined || allParStylesNames[parStyle[0]] == undefined || allParStylesNames[parStyle[0]] != parStyle[1]) {
		var parStyleByName = GetStyleByName(parStyle[1], allParStylesNames, allParStyles);
		
		if (parStyleByName != null) { // get style by name
			parStyle = parStyleByName;
		}
		else if (applyParStyle && parStyle[1] != "[No Paragraph Style]" && parStyle[1] != "[Basic Paragraph]") { // not found, reset to defaults
			alert("Paragraph style '" + parStyle[1] + "' is missing in the active document so '[Basic Paragraph]' will be selected in the 'Paragraph' list.", scriptName, false);
			parStyle = [1, "[Basic Paragraph]"]; // reset to [Basic Paragraph]
		}
	}

	return parStyle;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetStyleByName(name, namesList, styles) {
	var result = null;
	
	for (var i = 0; i < namesList.length; i++) {
		if (namesList[i] == name) {
			result = [i, namesList[i]];
		}
	}

	return result;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.POINTS;
	doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.POINTS
	
	for (var p = 0; p < doc.allParagraphStyles.length; p++) {
		allParStyles.push(doc.allParagraphStyles[p]);
		allParStylesNames.push(doc.allParagraphStyles[p].name);
	}
	
	for (var i = 0; i < doc.allObjectStyles.length; i++) {
		allObjStyles.push(doc.allObjectStyles[i]);
		allObjStylesNames.push(doc.allObjectStyles[i].name);
	}
	
	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function CheckTextEditField(obj, defaultValue, fieldName) {
	//$.writeln("Entering: CheckTextEditField()");
	var num = parseInt(obj.text);
	if (obj.text == "") { // empty
		alert("The \"" + fieldName +"\" text edit field should not be empty!", scriptName, true);
		obj.text = defaultValue;
		stopClosingDialog = true;
	}
	else if (num.toString() == "NaN") { // some abra-cadabra -- can't convert to integer
		alert("\"" + obj.text + "\" is not a number!", scriptName, true);
		obj.text = defaultValue;
		stopClosingDialog = true;
	}
	else if (num < minBoxSize || num > maxBoxSize) { // the value is beyond reasonable limits
		alert("\"" + obj.text + "\" is a wrong setting! The value must be between " + minBoxSize + " pt and " + maxBoxSize +" pt.", scriptName, true);
		obj.text = defaultValue;
		stopClosingDialog = true;
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------