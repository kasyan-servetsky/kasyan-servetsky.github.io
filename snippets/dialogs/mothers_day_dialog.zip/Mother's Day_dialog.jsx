﻿var scriptName = "Mother's Day 1.3",
debugMode = false,
arrImg = [],
folderImg = null,
set, templatesFolderPath, pdfExportFolderPath, inddFolderPath, 
pdfPresetNoBleeds, pdfPresetBleeds, filesImg, progressTxt, progressBar,
templatesFolder = null;

PreCheck();

//===================================== FUNCTIONS ======================================
function CreateDialog() {
	GetDialogSettings();
	var w = new Window("dialog", scriptName);
	
	// Images folder
	w.p = w.add("panel", undefined, "Images folder:");
	w.p.alignment = "fill";
	w.p.st = w.p.add("statictext");
	if (folderImg == null || !folderImg.exists) { 
		w.p.st.text = "No folder has been selected";
	}
	else {
		w.p.st.text = TrimPath(folderImg.absoluteURI);
		w.p.st.helpTip = decodeURI(folderImg.fsName);
	}
	w.p.bt = w.p.add("button", undefined, "Select...");
	w.p.bt.onClick = function() {
		var result = SelectFolder(this, "Select a folder with images.");
		if (result != null) {
			folderImg = result;
		}
	}
	
	w.p1 = w.add("panel", undefined, "");
	w.p1.alignment = "fill";
	
	w.p1.cb = w.p1.add("checkbox", undefined, "Add a child’s name to the back");
	w.p1.cb.value = set.addName;
	w.p1.cb.alignment = "left";
	
	w.p1.g = w.p1.add("group");
	w.p1.g.orientation = "column";
	w.p1.g.alignment = "left";
	w.p1.g.rb = w.p1.g.add("radiobutton", undefined, "Mother's Day");
	w.p1.g.rb1 = w.p1.g.add("radiobutton", undefined, "Father's Day");
	if (set.rbDaySelected == 0) {
		w.p1.g.rb.value = true;
	}
	else {
		w.p1.g.rb1.value = true;
	}

	// Buttons
	w.g = w.add("group");
	w.g.orientation = "row";   
	w.g.alignment = "center";
	w.g.ok = w.g.add("button", undefined, "OK", {name: "ok" });
	w.g.ok.onClick = function() { // Use 'children[0]' because the panel is dynamically rebuilt on selecting a new folder so the original references become invalid
		if (w.p.children[0].text == "No folder has been selected") { //  || folderImg == null
			alert("No 'Images' folder has been selected.", scriptName, true);
			return;			
		}
		else { // everythin's OK
			w.close(1);
		}
	}

	w.g.cancel = w.g.add("button", undefined, "Cancel", {name: "cancel"});
	
	var showDialog = w.show();
	 
	if (showDialog == 1) {
		with (set) {	
			folderImgPath = (folderImg != null) ? folderImg.absoluteURI + "/" : "";
			set.addName = w.p1.cb.value;
			
			if (w.p1.g.rb.value) {
				set.rbDaySelected = 0;
			}
			else {
				set.rbDaySelected = 1;
			}
		}
		
		app.insertLabel("Kas_" + scriptName, set.toSource());
		Main();
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function SelectFolder(button, prompt) {
	var folder = Folder.selectDialog(prompt);
	
	if (folder != null) {
		var panel = button.parent;
		var window = panel.parent;
		var children = panel.children;
		var staticText = children[0];
		var button = button;
		panel.remove(staticText);
		panel.remove(button);
		staticText = panel.add("statictext", undefined, TrimPath(folder.absoluteURI));
		staticText.helpTip = decodeURI(folder.absoluteURI);
		button = panel.add("button", undefined, "Select...");
		button.onClick = function() {
			SelectFolder(this);
		}
		window.layout.layout(true);
		return folder;		
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function TrimPath(path) {
	path = decodeURI(path);
	var trimPath = ((path.split("/").length > 3) ? ".../" : "") + path.split("/").splice(-3).join("/");
	return trimPath;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function GetDialogSettings() {
	set = eval(app.extractLabel("Kas_" + scriptName));
	if (set == undefined) {
		set = {folderImgPath: "", addName: true, rbDaySelected: 0};
	}

	folderImg = new Folder(set.folderImgPath);
	if (!folderImg.exists) {
		folderImg = null;
	}

	return set;
}	
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function Main() {
	try {
		var startTime = new Date();
		
		filesImg = folderImg.getFiles("*.jpg");
		if (filesImg.length == 0) {
			ErrorExit("No images in the selected folder.", true); 
		}

		pdfExportFolderPath = set.folderImgPath + "Print Files/";
		var pdfExportFolder = GetFolder(pdfExportFolderPath);
		if (pdfExportFolder == null) ErrorExit("Failed to create the 'Print Files' folder. Interrupting the script.", true);
		
		inddFolderPath = set.folderImgPath + "Indd Files/";
		var inddFolder = GetFolder(inddFolderPath);
		if (inddFolder == null) ErrorExit("Failed to create the 'INDD Files' folder. Interrupting the script.", true);
		
		// Progress bar
		var progressWin = new Window("window", scriptName);
		progressBar = progressWin.add("progressbar" , undefined, 0, 3); // global
		progressBar.preferredSize.width = 300;
		progressTxt = progressWin.add("statictext", undefined,  ""); // global
		progressTxt.alignment = "fill";
		progressWin.show();
		
		MakeTempDoc();
		Make1up(((set.rbDaySelected == 0) ? "Mother's Day" : "Father's Day") + " Cards");
		Make1up(((set.rbDaySelected == 0) ? "Mother's Day" : "Father's Day") + " Mugs");
		
		progressWin.close();
		var endTime = new Date(),
		duration = GetDuration(startTime, endTime);
		
		if (!debugMode) {
			alert("Finished.\rTime elapsed: " + duration, scriptName, false);
		}
		else {
			$.writeln("Finished.\rTime elapsed: " + duration);
		}
	}
	catch(err) {
		alert("Something went wrong: " + err.message + ", line: " + err.line, scriptName, true);
	}
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	CreateDialog();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}