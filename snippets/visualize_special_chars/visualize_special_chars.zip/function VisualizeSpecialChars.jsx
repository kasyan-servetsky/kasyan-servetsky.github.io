﻿main();

function main() {
	// Usage example: select some text 
	// and run it up to the breakpoint
	var selectedText = app.selection[0];
	var strContents = selectedText.contents;
	var strVisualised = VisualizeSpecialChars(selectedText);
	var strCharcoaded = CharCodeString(strContents);
	if (strCharcoaded == null) {
		alert("You selected only one special character. Select more text and try again.","Error", true);
	}
}

function VisualizeSpecialChars(txt) {
	try {
		var str = "",
		contents,
		characters = txt.characters;
		
		for (var i = 0; i < characters.length; i++) {
			contents = characters[i].contents;
			
			if ("" + contents.constructor.name == "Enumerator") {
				if (contents == SpecialCharacters.FORCED_LINE_BREAK) {
					str += "\\n";
				}
				else {
					str += "{" + contents.toString().toLowerCase().replace(/_/g, " ") + "}";
				}
			}
			else {
				str += contents.replace(/\t/g, "\\t").replace(/\r/g, "\\r").replace(/ /g, "◊");
			}
		} 

		return str;
	}
	catch(err) {
		alert(err.message + ", line: " + err.line, scriptName, true);
	}
}

function CharCodeString(str) {
	if (str.constructor.name == "Enumerator") return null;
	
	var s = "";
	
	for (var i = 0; i < str.length; i++) {
		s += ((i != 0) ? "|" : "") + str.charCodeAt(i);
	}

	return s;
}