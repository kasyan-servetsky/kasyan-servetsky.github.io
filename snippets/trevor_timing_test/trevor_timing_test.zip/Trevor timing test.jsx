﻿    function compare(snippets, /* a function or array of functions to time */  
                     runs, /* [Amount of times to call the functions] */  
                     functionArguments, /* [Amount of loop] */  
                     digits /* [round results to n decimal points] */) {  
        var l, a = [], f, r, i, c, result = [], results = [], ranking = [], functionNames = [],  
            testsStarted, testsTook, start, end, t, n, snip,  
            quickest, slowest, quicker,slower, looser, winner, speed;  
        var DEFAULT_RUNS = 10; // Avoiding use of const for wider compatibility  
        var DEFAULT_DIGITS = 3;  
        var STARS = '\n**********************************************************************\n';  
        if (!snippets) {  
            throw "The first argument of the compare function must be a function or an array of functions";  
        }  
        if (!(snippets instanceof Array)) {  
            snippets = [snippets];  
        }  
        l = snippets.length;  
        // if runs is not a positive integer then assign it a default value  
        runs = ~~runs; // converts runs into an integer  
        if (runs < 1) {  
            runs = DEFAULT_RUNS;  
        }  
        // if digits is not a positive integer then assign it a default value  
        if (digits === undefined) {  
            digits = DEFAULT_DIGITS;  
        }  
        digits = ~~digits; // converts digits into an integer  
      
        /** If only one function is to be tested then we'll just do a simple timing test */  
      
        if (snippets.length === 1) {  
            n = runs;  
            t = 0;  
            while (n--) {  
                /* See below note on the use of the Date function */  
                start = new Date();  
                // call the function  
                snippets[0](functionArguments);  
                end = new Date();  
                t += end - start;  
            }  
            // Average out the times  
            t /= runs;  
            return 'Average execution time: ' + toDigits(t, digits) + 'ms';  
        }  
        /** For multiple funbctions */  
        // There is sometimes a bias towards the first tested function  
        // to "help" reduce this we shall randomly shuffle the execution order of the functions  
        // create an array of the snippet indexes so it can be shuffled  
        for (f = 0; f < l; f++) {  
            for (r = 0; r < runs; r++) {  
                a.push(f);  
            }  
        }  
      
        function shuffle(arr, preserve) { // This is my (Trevor) implementation of Fisher-Yates shuffle  
            var a, i, r, v;  
            // duplicate the array if one wants to preserve the order of the original array  
            a = (preserve) ? arr.slice() : arr;  
            i = a.length;  
            while (i--) {  
                // generate a random integer for an array index  
                r = ((1 + i) * Math.random()) | 0;  
                v = a[r]; // get the value of that index  
                // swap the values;  
                a[r] = a[i];  
                a[i] = v;  
            }  
            return a;  
        }  
      
        shuffle(a);  
        n = a.length;  
        // record test start time  
        testsStarted = new Date();  
        /** execute the snippets in the random order **/  
        while (n--) {  
            i = a[n];  
            /* There is an opinion that one should use more accurate time measuring methods than the Date method 
               While it is certainly true that when the clock is changed in the middle of executing the comparison 
               the results will be inaccurate however the "noise" and external factors that cause the discrepancy 
               in the result and even the time it takes to call even an empty function or to loop through a loop 
               in my opinion render a higher resolution recording pointless */  
            start = new Date();  
            // call the function  
            snippets[i](functionArguments);  
            end = new Date();  
            t = end - start;  
            // add the execution time to the results,  
            // if the result for that index is currently undefined set the result to the execution time  
            results[i] = (results[i] + t) || t;  
        }  
        testsTook = new Date() - testsStarted;  
        // rank the results  
        for (c = 0; c < l; c++) {  
            results[c] /= runs; // average out the results  
            ranking[c] = {snippet: c, rank: results[c], name: snippets[c].name};  
        }  
        ranking.sort(function(a, b) {return +(a.rank > b.rank) || -(a.rank !== b.rank)});  
      
        // For reporting the ranked function names  
        for (c = 0; c < l; c++) {  
            functionNames[c] = ranking[c].name  
        }  
      
        function toDigits(x, n) {  
            if (n === undefined) {  
                return x;  
            }  
            return (~~(Math.pow(10, n) * x)) / Math.pow(10, n);  
        }  
      
        quickest = ranking[0].rank;  
        slowest = ranking[l - 1].rank;  
        looser = l - 1;  
        winner = 0;  
      
        result.push(['Test Started: ' + testsStarted,  
                     'Functions Tested: (Listed in order of performance) "' + functionNames.join('", "') + '"',  
                     'Arguments: ' + functionArguments,  
                     'Runs: ' + runs,  
                     'Test Took: ' + testsTook + 'ms'].join('\n'));  
      
      
        for (c = 0; c < l; c++) {  
            snip = ranking[c];  
            speed = snip.rank  
            quicker = slowest / speed;  
            slower = speed / quickest;  
            result.push(['Function ' + (snip.snippet + 1) + ') "' + snip.name + '"',  
                         'Average execution time: ' + (speed) + 'ms',  
                         'Rank: ' + (c + 1)+ ' (1 is best)',  
                         (looser === c) ? '** SLOWEST **' : toDigits(quicker, digits) + ' times (' + toDigits(quicker * 100 - 100, digits)+ '%) quicker than slowest function',  
                         (winner === c) ? '** QUICKEST **' : toDigits(slower, digits) + ' times (' + toDigits(100 - 100 / slower, digits)+ '%) slower than quickest function',  
                         ].join('\n'));  
        }  
        return STARS + result.join(STARS) + STARS;  
    }  
      
    /************************************************************************************************************************************************************ 
    **************************************************************************** Sample use **************************************************************** 
    ************************************************************************************************************************************************************/  
      
    function While(n){  
        var n;  
        while (n--);  
    }  
      
    function For(n){  
        for (; n>=0; n--); //         for ( ; n-- ; );  
    }  
      
    $.writeln(compare ([ For, While], 10, 1e6, 3));  