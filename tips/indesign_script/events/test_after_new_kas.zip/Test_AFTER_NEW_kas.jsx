﻿//----------------------------------
// TEST AFTER_NEW
// [REM] This script does not require a persistent engine,
// run it once to install the event handler.
//----------------------------------

(function(/*any*/ev,  doc,msg,ff,t)
{
   $.level = 2;
   $.bp();
   if( !(ev||0).isValid )
   {
      // Install the event listener (if not yet installed!)
      // ---
      const UID = 'myAfterNewHandler';
      (ff=File($.fileName)).exists
      && !((t=app.eventListeners).itemByName(UID)).isValid
      && ((t.add('afterNew',ff)).name=UID);
      return;
   }

   // Checkpoint.
   // ---
   if( 'afterNew' != ev.eventType ) return; // Make sure this is the right event.
   doc = ev.target||0;
   if( 'Document' != doc.constructor.name ) return; // Make sure you're targeting a Doc.

   // Process.
   // ---
      try
      {
         doc.layers[0].name = 'TEST';
         msg = "Worked fine."
      }
      catch(e)
      {
		if (e.number == 30486)
		{
		    msg = "An error occured:\r" + e.message + " [ line: " + e.line + " ]\r"
		    + "You are probably creating a new document using the default dialog box. "
		    + "Try to turn on the 'Use Legacy \"New Document\" Dialog' check box and try again.  :-)";
		}
      }

   alert( msg );

})($.global.evt);