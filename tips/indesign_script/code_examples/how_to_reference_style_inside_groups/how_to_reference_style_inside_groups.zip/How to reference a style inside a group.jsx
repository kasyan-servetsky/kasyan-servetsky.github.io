﻿var scriptName = "Style inside a group";

var doc = app.activeDocument;
var parStGroup = doc.paragraphStyleGroups.item("My group");
if (!parStGroup.isValid) ErrorExit("Paragraph style group\"My group\" doesn't exist.", true);
var parStSubGroup = parStGroup.paragraphStyleGroups.item("My sub-group");
if (!parStSubGroup.isValid) ErrorExit("Paragraph style group\"My sub-group\" doesn't exist.", true);
var parStyle = parStSubGroup.paragraphStyles.item("My style");
if (!parStyle.isValid) ErrorExit("Paragraph style \"My style\" doesn't exist.", true);

function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}