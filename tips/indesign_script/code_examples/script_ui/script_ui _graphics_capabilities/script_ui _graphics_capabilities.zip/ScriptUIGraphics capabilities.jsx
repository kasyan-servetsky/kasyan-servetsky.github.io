﻿(function () {

    var size = 300;

    var w = new Window("dialog {text:'Canvas Test', canvas:Custom  {preferredSize:[" + size + "," + size + "]}}"),
        canvas = w.canvas,
        bottomUI = w.add("group {orientation:'row', alignment:['right','top'], alignChildren:'right' }"),
        buttons = bottomUI.add("group {orientation:'row', alignment:['right','top'], alignChildren:'right' }"),
        cancelButton = buttons.add('button', undefined, 'Cancel', { name: 'cancel' }),
        okButton = buttons.add('button', undefined, 'Draw', { name: 'ok' });

    canvas.onDraw = function () {
        var g = canvas.graphics;
        var color = [Math.random(), Math.random(), Math.random()],
            left = Math.floor(Math.random() * size / 2),
            top = Math.floor(Math.random() * size / 2),
            width = Math.floor(Math.random() * (size - left)),
            height = Math.floor(Math.random() * (size - top));

        g.newPath();

        switch (Math.floor(Math.random() * 3)) {
            case 0:
                g.rectPath(left, top, width, height);
                break;
            case 1:
                g.ellipsePath(left, top, width, height);
                break;
            case 2:
                g.moveTo(left, top);
                g.lineTo(width, height);
                break;
        }

        g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, color, 1));
        g.strokePath(g.newPen(g.BrushType.SOLID_COLOR, color, 1));

    };

    okButton.onClick = function () {
        canvas.notify('onDraw');
    };

    w.center();
    return w.show();

})();