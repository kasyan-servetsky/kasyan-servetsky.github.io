﻿var result;

// parameters
var p = {   x : 0,
				y : 0,
				width : 84,
				height : 40,
				gradShift : 2,
				color :   {   name : "PANTONE Rhodamine Red C",
								colorSpace : ColorSpace.LAB,
								colorModel : ColorModel.SPOT,
								colorValue : [51.4, 79, -14],
								tintStart : 10,
								tintEnd : 50
							}
			}

var doc = makeDoc();
main();
result;

function main() {
	try {
		// add base swatch and tints
		var swatchBase = makeColor(p.color.name, p.color.colorSpace, p.color.colorModel, p.color.colorValue);
		var swatchStart = makeTint(swatchBase, p.color.tintStart);
		var swatchEnd = makeTint(swatchBase, p.color.tintEnd);

		// add gradient swatch
		var gradName = p.color.name + " Gradient";
		var grad = doc.gradients.itemByName(gradName);
		if (!grad.isValid) {
			grad = doc.gradients.add({name : gradName, type : GradientType.LINEAR});
			with (grad) {
				gradientStops[0].location = 0;
				gradientStops[0].stopColor = swatchStart;
				gradientStops[1].location = 100;
				gradientStops[1].stopColor = swatchEnd;	
				gradientStops[1].midpoint = 50;
			}
		}
		
		// make rectangle
		var gb = [p.y, p.x, p.y + p.height, p.x + p.width];
		var rec = doc.rectangles.add({geometricBounds : gb, strokeColor : "None"});
		rec.fillColor = grad;
		// assuming that the gradient is always drawn from top-left to bottom-right
		rec.gradientFillStart = [p.x + p.gradShift, p.y + p.gradShift];
		var w = p.width - p.gradShift * 2;
		var h = p.height - p.gradShift * 2;
		rec.gradientFillLength = getLength(w, h);
		rec.gradientFillAngle = -(getAngles(w, h)[1]);

		if (app.name == "Adobe InDesign") {
			$.writeln("==================================");	
			$.writeln("gradientFillAngle = " + rec.gradientFillAngle);
			$.writeln("gradientFillLength = " + rec.gradientFillLength);
			$.writeln("gradientFillStart = " + rec.gradientFillStart);
		}
		else {
			app.consoleout("==================================");
			app.consoleout("gradientFillAngle = " + rec.gradientFillAngle);
			app.consoleout("gradientFillLength = " + rec.gradientFillLength);
			app.consoleout("gradientFillStart = " + rec.gradientFillStart);			
		}
	
		// save doc
		var folderPath = "/C/Test/";
		var folder = new Folder(folderPath);
		if (!folder.exists) folder.create();
		
		var file = new File(folderPath + "Test Gradient" + ".indd");
		if (file.exists) {
			var increment = 1;
			while (file.exists) {
				file = new File(folderPath + "/" + "Test Gradient" + "(" + increment++ + ").indd");
			}
		}
	
		doc.save(file);
		result = "Gradient was applied and the document saved to: " + decodeURI(doc.fullName.fsName);
		doc.close(SaveOptions.NO);
	}
	catch(err) {
		if (app.name == "Adobe InDesign") {
			alert(err.message + ", line: " + err.line, "Fatal error", true);
		}
		else {
			app.consoleerr("Fatal error: " + err.message + ", line: " + err.line);
			result = "Something went wrong: no document was saved.";
		}
	}
}

function getAngles(a, b) {
	var alpha =  Math.atan(a / b) * 180 / Math.PI;	
	var beta = (3.14159262689154419 - 1.570796313445772097 - Math.atan(a / b)) * 180 / Math.PI;
	return [alpha, beta];
}

function getLength(a, b) {
	return Math.sqrt(a * a + b * b);
}

function makeColor(colorName, colorSpace, colorModel, colorValue) {
	var color = doc.colors.itemByName(colorName);
	if (!color.isValid) {
		color = doc.colors.add({name: colorName, space: colorSpace, model: colorModel, colorValue: colorValue});
	}
	return color;
}

function makeTint(swatchBase, tintValue) {
	var swatchName = swatchBase.name + " " + tintValue + "%";
	var swatchTint = doc.swatches.itemByName(swatchName);
	if (!swatchTint.isValid) {
		var tint = doc.tints.add(swatchBase, {tintValue : tintValue});
	}
	return swatchTint;
}

function makeDoc() {
	doc = app.documents.add();
	doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.MILLIMETERS;
	doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.MILLIMETERS;
	doc.documentPreferences.pageWidth = 124;
	doc.documentPreferences.pageHeight = 80;
	with (doc.pages[0].marginPreferences) {
		top = bottom = left = right = 0;
	}

	doc.zeroPoint = [20, 20];
	// top left edge = zero point	
	doc.guides.add({orientation : HorizontalOrVertical.HORIZONTAL, location : 0, guideType : GuideTypeOptions.RULER});
	doc.guides.add({orientation : HorizontalOrVertical.VERTICAL, location : 0, guideType : GuideTypeOptions.RULER});
	// starting point
	doc.guides.add({orientation : HorizontalOrVertical.HORIZONTAL, location : p.gradShift, guideType : GuideTypeOptions.LIQUID});
	doc.guides.add({orientation : HorizontalOrVertical.VERTICAL, location : p.gradShift, guideType : GuideTypeOptions.LIQUID});
	// endpoint
	doc.guides.add({orientation : HorizontalOrVertical.HORIZONTAL, location : p.height, guideType : GuideTypeOptions.LIQUID});
	doc.guides.add({orientation : HorizontalOrVertical.VERTICAL, location : p.width, guideType : GuideTypeOptions.LIQUID});	
	// right bottom edge
	doc.guides.add({orientation : HorizontalOrVertical.HORIZONTAL, location : p.height - p.gradShift, guideType : GuideTypeOptions.LIQUID});
	doc.guides.add({orientation : HorizontalOrVertical.VERTICAL, location : p.width - p.gradShift, guideType : GuideTypeOptions.LIQUID});
	
	return doc;
}