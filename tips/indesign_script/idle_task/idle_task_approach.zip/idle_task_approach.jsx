﻿//----------------------------------
// DOC CREATION EVENT HANDLER
// [REM] This script does not require a persistent engine,
// run it once to install the event handler. (Can also be
// used as startup script.)
//----------------------------------

(function(/*any*/ev,  doc,ff,t)
{
   const UID = 'myDocCreationIdleEventHandler';

   if( !(ev||0).isValid )
   {
      // Install the event listener (if not yet ready.)
      // ---
      (ff=File($.fileName)).exists
      && !((t=app.idleTasks).itemByName(UID)).isValid
      && (t=t.add({ name:UID, sleep:500 }).eventListeners)
      && ((t.add('onIdle',ff)).name=UID);
   }
   else
   {
   	  // Checkpoint and additional conditions.
   	  // ---
      'onIdle'==ev.eventType
      && !app.modalState
      && (doc=app.properties.activeDocument)
      && !doc.properties.saved
      && !doc.extractLabel(UID)
      // DOM-Process.
      // ---
      &&
      (
         doc.insertLabel(UID,'1'),
         doc.layers[0].name='TEST'
         // etc
      );
   }

})($.global.evt);