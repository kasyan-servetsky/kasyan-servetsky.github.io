﻿var scriptName = "Sorted Lines",
debug = true,
doc = app.activeDocument;

app.doScript(SortLines, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");

function SortLines() {
	var textFrame = doc.textFrames.itemByID(372);
	var lines = textFrame.lines.everyItem().getElements();
	var line, lineLength;
	var n, i, l;
	var unsortedLines = [];
	var sortedLines = [];
	
	$.writeln("--------------- Unsorted ---------------");
	
	for (var n = 0; n < lines.length; n++) {
		line = lines[n];
		lineLength = GetLTextWidth(line);
		$.writeln(ZeroPad((n + 1), 2) + " - " + lineLength);
		
		unsortedLines.push({
			idx: n,
			lineLength: lineLength
		});
	}

	sortedLines = unsortedLines.sort(function(a, b) { return b.lineLength - a.lineLength;});
	
	$.writeln("--------------- Sorted ---------------");
	
	for (var j = 0; j < sortedLines.length; j++) {
		$.writeln(ZeroPad(sortedLines[j].idx +1, 2) + " - " + sortedLines[j].lineLength);
	}

	Stringify(sortedLines);
}

function Stringify(arr) {
	var item, str;
	
	for (var i = 0; i < arr.length; i++) {
		item = arr[i];
		str = item.toSource() + ((i < (arr.length - 1)) ? "|" : "");
		WriteToFile(str);
	}
}

function WriteToFile(text) {
	file = new File("~/Desktop/" + scriptName + ".txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text); 
	file.close();
}

function GetLTextWidth(txt) {
	try {
		var l = txt.characters[0].horizontalOffset;
		var r = txt.characters[-1].horizontalOffset;
		var w = r - l;
		w = RoundString(w, 1);
		
		return w;
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}

function RoundString(numVal, decimals) {
    var retVal = Math.round(numVal * Math.pow(10,decimals)) + "";
    retVal = retVal.substring(0, retVal.length - decimals) + "." + retVal.substring(retVal.length - decimals);
    return retVal;
}

function ZeroPad(num, digit) {
	var tmp = num.toString();
	while (tmp.length < digit) {
		tmp = "0" + tmp;
	}
	return tmp;
}