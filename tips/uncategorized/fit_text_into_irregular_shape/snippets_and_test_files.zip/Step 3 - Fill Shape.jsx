﻿var scriptName = "Fill Shape",
debug = true,
doc = app.activeDocument,
gStrNames, gUnsortedLines;

app.doScript(Main, ScriptLanguage.JAVASCRIPT, undefined, ((File.fs == "Macintosh") ? UndoModes.ENTIRE_SCRIPT : UndoModes.FAST_ENTIRE_SCRIPT), "\"" + scriptName + "\" Script");

function Main() {
	var textFrame = doc.textFrames.itemByID(372),
	story = textFrame.parentStory,
	lines = textFrame.lines.everyItem().getElements(),
	line, lineLength, closest;
	
	if (debug) $.writeln("--------------- closest ---------------");
	
	InitVars();
	var unsortedLines = RestoreData(gUnsortedLines);	
	var sortedNames = RestoreData(gStrNames);

	for (var i = 0; i < unsortedLines.length; i++) {
		line = unsortedLines[i];
		lineLength = line.lineLength;

		if (debug) $.writeln("Before: " + sortedNames.length);		
		closest = FindClosest(sortedNames, lineLength, "nameWidth");
		
		if (closest == null) {
			if (debug) $.writeln("!!! closest == null, i = " + i);
			continue;
		}
	
		// name | width | index
		if (debug) $.writeln(ZeroPad((i + 1), 2) + " - " + closest[0] + " | " + closest[1] + " | " + closest[2]);	
		sortedNames.splice(closest[2], 1);
		if (debug) $.writeln("After: " + sortedNames.length);
		
		story.insertionPoints[-1].contents = closest[0] + " ";
	}
}

function FindClosest(array, elem, prop) {
	var item, delta,
	result = null,
	minDelta = null,
	minIndex = null;

	for (var i = 0 ; i < array.length; i++) {
		item = eval("array[i]." + prop);
		delta = Math.abs(item - elem);
		
		if (minDelta == null || delta < minDelta) {
			minDelta = delta;
			minIndex = i;
		}
		else if (delta == minDelta) {
			result = [eval("array[i - 1].name"), item, i - 1];
			break;
		}
		else { // delta > minDelta
			result = [eval("array[i - 1].name"), eval("array[i - 1]." + prop), i - 1];
			break;
		}
	} // end for

	return result;
}

function RestoreData(input) { // File / String
	var str,
	restoredArr = [];
	
	if (input.constructor.name == "File") {
		str = ReadTxtFile(input);
	}
	else if (input.constructor.name == "String") {
		str = input;
	}

	var arr = str.split("|");
	
	for (var i = 0; i < arr.length; i++) {
		restoredArr.push(eval(arr[i]));
	}

	return restoredArr;
}

function GetLTextWidth(txt) {
	try {
		var l = txt.characters[0].horizontalOffset;
		var r = txt.characters[-1].horizontalOffset;
		var w = r - l;
		w = RoundString(w, 1);
		
		return w;
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}

function RoundString(numVal, decimals) {
    var retVal = Math.round(numVal * Math.pow(10,decimals)) + "";
    retVal = retVal.substring(0, retVal.length - decimals) + "." + retVal.substring(retVal.length - decimals);
    return retVal;
}

function ReadTxtFile(file) {
	file.open("r"); 
	var txt = file.read();
	file.close();
	return txt;
}

function ZeroPad(num, digit) {
	var tmp = num.toString();
	while (tmp.length < digit) {
		tmp = "0" + tmp;
	}
	return tmp;
}

function InitVars() {
	gStrNames = '({name:"Beyonce-Honey Serrant", nameWidth:"69.9"})|({name:"Alexandr Odumuyiwa", nameWidth:"66.7"})|({name:"Abigail Mcallister", nameWidth:"49.8"})|({name:"Maddison Powell", nameWidth:"49.7"})|({name:"Leonora Sheehan", nameWidth:"49.4"})|({name:"Amelia Volckman", nameWidth:"48.2"})|({name:"Ava McCormack", nameWidth:"45.6"})|({name:"Grace Summers", nameWidth:"45.2"})|({name:"Kourtney Harris", nameWidth:"44.5"})|({name:"Alarna Norquoy", nameWidth:"44.1"})|({name:"Brody Wakeling", nameWidth:"43.9"})|({name:"Annabelle Reed", nameWidth:"43.8"})|({name:"Grayson Davey", nameWidth:"42.7"})|({name:"Charlotte Teare", nameWidth:"42.6"})|({name:"Brooke Howell", nameWidth:"42.3"})|({name:"Charlie Barber", nameWidth:"41.3"})|({name:"Willow Durling", nameWidth:"40.2"})|({name:"Esme Candler", nameWidth:"39.9"})|({name:"Albie lovelock", nameWidth:"39.2"})|({name:"Oliver Pickett", nameWidth:"38.5"})|({name:"Dylan Benson", nameWidth:"38.5"})|({name:"Sean Flaherty", nameWidth:"38.1"})|({name:"Max Wheeler", nameWidth:"36.3"})|({name:"Scarlet Hidle", nameWidth:"34.9"})|({name:"Liam Hunter", nameWidth:"34.6"})|({name:"Mila Jiggens", nameWidth:"34.6"})|({name:"Freya Brown", nameWidth:"34.6"})|({name:"Freya Jones", nameWidth:"33.5"})|({name:"Kayla Burch", nameWidth:"33.2"})|({name:"Alfie Hawes", nameWidth:"32.1"})|({name:"Ollie Light", nameWidth:"28.9"})|({name:"Lily Broom", nameWidth:"27.5"})';

	gUnsortedLines = '({idx:0, lineLength:"54.3"})|({idx:1, lineLength:"66.6"})|({idx:2, lineLength:"83.5"})|({idx:3, lineLength:"100.4"})|({idx:4, lineLength:"108.1"})|({idx:5, lineLength:"108.1"})|({idx:6, lineLength:"28.7"})|({idx:7, lineLength:"28.7"})|({idx:8, lineLength:"28.7"})|({idx:9, lineLength:"28.7"})|({idx:10, lineLength:"28.1"})|({idx:11, lineLength:"75.4"})|({idx:12, lineLength:"75.4"})|({idx:13, lineLength:"75.4"})|({idx:14, lineLength:"28.4"})|({idx:15, lineLength:"28.4"})|({idx:16, lineLength:"28.4"})|({idx:17, lineLength:"28.4"})|({idx:18, lineLength:"28.4"})|({idx:19, lineLength:"108.1"})|({idx:20, lineLength:"108.1"})|({idx:21, lineLength:"108.2"})|({idx:22, lineLength:"108.2"})|({idx:23, lineLength:"108.2"})|({idx:24, lineLength:"54.1"})|({idx:25, lineLength:"66.3"})|({idx:26, lineLength:"83.2"})|({idx:27, lineLength:"100.2"})|({idx:28, lineLength:"108.4"})|({idx:29, lineLength:"108.4"})|({idx:30, lineLength:"28.7"})|({idx:31, lineLength:"28.7"})|({idx:32, lineLength:"28.7"})|({idx:33, lineLength:"28.7"})|({idx:34, lineLength:"27.5"})|({idx:35, lineLength:"51.8"})|({idx:36, lineLength:"48.5"})|({idx:37, lineLength:"55.3"})|({idx:38, lineLength:"28.7"})|({idx:39, lineLength:"28.7"})|({idx:40, lineLength:"28.7"})|({idx:41, lineLength:"28.7"})|({idx:42, lineLength:"28.7"})|({idx:43, lineLength:"108.4"})|({idx:44, lineLength:"108.4"})|({idx:45, lineLength:"96.2"})|({idx:46, lineLength:"79.3"})|({idx:47, lineLength:"64.6"})';
}