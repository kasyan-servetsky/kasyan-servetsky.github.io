﻿var scriptName = "Sort Names",
doc = app.activeDocument;

SortNames();

function SortNames() {
	var n, j, nameWidth, sortedNames,
	textFrame = doc.textFrames.itemByID(624),
	names = textFrame.lines.everyItem().getElements(),
	unsortedNames = [];
	
	$.writeln("--------------- Unsorted ---------------");
	
	for (n = 0; n < names.length; n++) {
		name = names[n];
		nameWidth = GetLTextWidth(name);
		$.writeln(ZeroPad((n + 1), 2) + " - " + name.contents.replace(/\r$/, "") + " | " + nameWidth);
		
		unsortedNames.push({
			name: name.contents.replace(/\r$/, ""),
			nameWidth: nameWidth
		});
	}

	sortedNames = unsortedNames.sort(function(a, b) {return b.nameWidth - a.nameWidth;});
	
	$.writeln("--------------- Sorted ---------------");
	
	for (j = 0; j < sortedNames.length; j++) {
		item = sortedNames[j];
		$.writeln(ZeroPad((j + 1), 2) + " - " + item.name.replace(/\r$/, "") + " | " + item.nameWidth);
	}

	Stringify(sortedNames);
}

function Stringify(arr) {
	var item, str;
	
	for (var i = 0; i < arr.length; i++) {
		item = arr[i];
		str = item.toSource() + ((i < (arr.length - 1)) ? "|" : "");
		WriteToFile(str);
	}
}

function WriteToFile(text) {
	file = new File("~/Desktop/" + scriptName + ".txt");
	file.encoding = "UTF-8";
	if (file.exists) {
		file.open("e");
		file.seek(0, 2);
	}
	else {
		file.open("w");
	}
	file.write(text); 
	file.close();
}

function GetLTextWidth(txt) {
	try {
		var l = txt.characters[0].horizontalOffset;
		var r = (txt.characters[-1].contents == "\r") ? txt.characters[-2].horizontalOffset : txt.characters[-1].horizontalOffset;
		var w = r - l;
		w = RoundString(w, 1);
		
		return w;
	}
	catch(err) {
		$.writeln(err.message + ", line: " + err.line);
	}
}

function RoundString(numVal, decimals) {
    var retVal = Math.round(numVal * Math.pow(10,decimals)) + "";
    retVal = retVal.substring(0, retVal.length - decimals) + "." + retVal.substring(retVal.length - decimals);
    return retVal;
}

function ZeroPad(num, digit) {
	var tmp = num.toString();
	while (tmp.length < digit) {
		tmp = "0" + tmp;
	}
	return tmp;
}