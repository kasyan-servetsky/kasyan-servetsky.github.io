﻿var scriptName = "Rotate characters 90 degrees",
doc;

PreCheck();

//===================================== FUNCTIONS ======================================
function Main() {
	var newTextProperties = {characterRotation: 90, composer: "$ID/HL Single J"};
	app.selection[0].properties = newTextProperties;
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function PreCheck() {
	if (app.documents.length == 0) ErrorExit("Please open a document and try again.", true);
	doc = app.activeDocument;
	if (doc.converted) ErrorExit("The current document has been modified by being converted from older version of InDesign. Please save the document and try again.", true);
	if (!doc.saved) ErrorExit("The current document has not been saved since it was created. Please save the document and try again.", true);
	
	if (app.selection.length == 0) {
		ErrorExit("Nothing is selected.", true);
	}
	else if (app.selection.length > 1 || (app.selection.length == 1 && !app.selection[0].hasOwnProperty("baseline"))) {
		ErrorExit("Some text sould be selected.", true);
	}

	Main();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ErrorExit(error, icon) {
	alert(error, scriptName, icon);
	exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------