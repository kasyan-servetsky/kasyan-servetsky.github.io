﻿main();

function main() {
	var n, k, j, sortedNames,
	namesLength = [], // Make an array of name lengths
	unsortedNames = [];	
	
	// Array of names
	var names = [ "Charlotte",
					"Alarna",
					"Albie",
					"Freya",
					"Ollie",
					"Alexandria",
					"Grayson",
					"Lily",
					"Freya",
					"Kourtney",
					"Amelia",
					"Dylan",
					"Mila",
					"Liam",
					"Esme",
					"Brody",
					"Brooke",
					"Ava",
					"Maddison",
					"Kayla",
					"Grace",
					"Sean",
					"Oliver",
					"Max",
					"Charlie",
					"Beyonce-Honey",
					"Abigail",
					"Leonora",
					"Alfie",
					"Willow",
					"Scarlet",
					"Annabelle" ];
	
	for (n = 0; n < names.length; n++) {
		namesLength.push(names[n].length);
	}

	for (k = 0; k < names.length; k++) {
		unsortedNames.push({
			name: names[k],
			namesLength: namesLength[k]
		});
	}

	// Now sorting the array by ‘namesLength’ in descending order
	// For ascending order swap a and b: a.namesLength - b.namesLength
	sortedNames = unsortedNames.sort(function(a, b) { return b.namesLength - a.namesLength; });

	for (var j = 0; j < sortedNames.length; j++) {
		$.writeln(sortedNames[j].name + " --> " + sortedNames[j].namesLength);
	}
}