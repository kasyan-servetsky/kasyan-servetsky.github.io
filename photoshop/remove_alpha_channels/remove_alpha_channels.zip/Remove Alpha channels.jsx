﻿function main() {
	if (app.documents.length == 0) {
		return;
	}

	var doc = app.activeDocument;

	var channels = doc.channels;
	var alphas = [];
	
	for (var i = 0; i < channels.length; i++) {
		var channel = channels[i];
		if (channel.kind == ChannelType.COMPONENT) {
			continue;
		}
		alphas.push(channel);
	}

	while (alphas.length) {
		var channel = alphas.pop();
		channel.remove();
	}
}

main();